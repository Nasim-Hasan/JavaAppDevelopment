# Restful BFF (Backend For Frontend)

## Pre-requisite
1. Java 11
1. Gradle 5+

## Build Locally. Follow the steps one after the other. 
1. Download dependency 
    ```
    git clone https://<user_intra_account>@gitpub.rakuten-it.com/scm/ecsg/bff.core.git
    ``` 
1. Go to project directory
    ```
    cd bff.core/
    ``` 
1. Build project with test:
    ```
    gradle clean build
    ```
1. Build project without test:
    ```
    gradle clean build -x test
    ```
1. jar will be found under this folder:
    ```
    build/libs/bff.core-1.0.0.jar
    ```
1. Running the project with the JAR:
    ```
    java -Xmx1024m -Djava.security.egd=file:/dev/./urandom $JAVA_OPTS -jar build/libs/bff.core-0.0.1-SNAPSHOT.jar --spring.profiles.active=stg
    ```
