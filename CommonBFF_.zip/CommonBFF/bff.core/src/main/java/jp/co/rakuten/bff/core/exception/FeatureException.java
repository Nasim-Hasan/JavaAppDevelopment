package jp.co.rakuten.bff.core.exception;

import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;

/**
 * <p>This Exception class is responsible for propagating all the errors related to
 * client request failure such as:
 * <ul>
 *     <li>bad_request<li/>
 *     <li>unsatisfied_condition<li/>
 * </ul>
 * </p>
 */
public class FeatureException extends BffException {

	private final String featureName;

	/**
	 * Constructor with cause exception
	 *
	 * @param featureName name of the feature from where this exception is thrown
	 * @param errorEnum   The error enum that contains code and type
	 * @param ex          The cause exception
	 * @param message     The message
	 * @param params      The optional parameters to insert in the message
	 */
	private FeatureException(String featureName, ClientErrorEnum errorEnum, Throwable ex, String message,
							 Object... params) {
		super(errorEnum.getErrorCode(), errorEnum.getErrorType(), ex, message, params);
		this.featureName = featureName;
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param featureName name of the feature from where this exception is thrown
	 * @param errorEnum   The error enum that contains code and type
	 * @param message     The message
	 * @param params      The optional parameters to insert in the message
	 * @return The client exception
	 */
	public static FeatureException create(String featureName, ClientErrorEnum errorEnum, String message,
										  Object... params) {
		return new FeatureException(featureName, errorEnum, null, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param featureName name of the feature from where this exception is thrown
	 * @param errorEnum   The error enum that contains code and type
	 * @param ex          The cause exception
	 * @param message     The message
	 * @param params      The optional parameters to insert in the message
	 * @return The client exception
	 */
	public static FeatureException create(String featureName, ClientErrorEnum errorEnum, Throwable ex, String message,
										  Object... params) {
		return new FeatureException(featureName, errorEnum, ex, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param featureName name of the feature from where this exception is thrown
	 * @param message     The message
	 * @param params      The optional parameters to insert in the message
	 * @return The client exception
	 */
	public static FeatureException create(String featureName, String message,
										  Object... params) {
		return new FeatureException(featureName, ClientErrorEnum.BAD_REQUEST, null, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param featureName name of the feature from where this exception is thrown
	 * @param ex          The cause exception
	 * @param message     The message
	 * @param params      The optional parameters to insert in the message
	 * @return The client exception
	 */
	public static FeatureException create(String featureName, String message, Throwable ex,
										  Object... params) {
		return new FeatureException(featureName, ClientErrorEnum.BAD_REQUEST, ex, message, params);
	}

	public String getFeatureName() {
		return featureName;
	}
}
