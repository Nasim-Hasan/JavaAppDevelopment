package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import org.apache.commons.lang3.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is responsible for dealing with Call responses from GG.
 */
public class CallDefinitionResponse {

	private CallDefinitionResponseStatus status;
	private MultipleResponses multipleResponses;
	private CallDefinitionError callDefinitionError;
	private Map<String, List<String>> interfaceToRequestIdMap;

	/**
	 * This is constructor method to instantiate CallDefinitionResponse object.
	 * @param status         call definition response status.
	 */
	public CallDefinitionResponse(CallDefinitionResponseStatus status) {
		this.status = status;
	}

	public CallDefinitionResponseStatus getStatus() {
		return status;
	}

	public void setStatus(CallDefinitionResponseStatus status) {
		this.status = status;
	}

	public MultipleResponses getMultipleResponses() {
		return multipleResponses;
	}

	public void setMultipleResponses(MultipleResponses multipleResponses) {
		this.multipleResponses = multipleResponses;
	}

	public CallDefinitionError getCallDefinitionError() {
		return callDefinitionError;
	}

	public void setCallDefinitionError(CallDefinitionError callDefinitionError) {
		this.callDefinitionError = callDefinitionError;
	}

	public Map<String, List<String>> getInterfaceToRequestIdMap() {
		return interfaceToRequestIdMap != null ? interfaceToRequestIdMap : new HashMap<>();
	}

	public void setInterfaceToRequestIdMap(Map<String, List<String>> interfaceToRequestIdMap) {
		this.interfaceToRequestIdMap = interfaceToRequestIdMap;
	}

	/**
	 * Get CustomHttpResponse from call definition by interface name for single call
	 *
	 * @param interfaceName Interface name
	 * @return CustomHttpResponse
	 */
	public CustomHttpResponse getResponseForSingleCall(String interfaceName) {
		List<String> requestIdList = interfaceToRequestIdMap.get(interfaceName);
		if (ObjectUtils.isEmpty(requestIdList)) {
			return null;
		}

		String requestId = interfaceToRequestIdMap.get(interfaceName).iterator().next();
		return multipleResponses.getResponses().get(requestId);
	}

	/**
	 * Check this call definition response is successful or not
	 *
	 * @return boolean
	 */
	public boolean isNotSuccessful() {
		return !isSuccessful();
	}

	/**
	 * Check this call definition response is successful or not
	 *
	 * @return boolean
	 */
	public boolean isSuccessful() {
		return this.status == CallDefinitionResponseStatus.SUCCESS;
	}

	@Override
	public String toString() {
		return "CallDefinitionResponse{" +
				"status=" + status +
				", multipleResponses=" + multipleResponses +
				", callDefinitionError=" + callDefinitionError +
				", interfaceToRequestIdMap=" + interfaceToRequestIdMap +
				'}';
	}
}
