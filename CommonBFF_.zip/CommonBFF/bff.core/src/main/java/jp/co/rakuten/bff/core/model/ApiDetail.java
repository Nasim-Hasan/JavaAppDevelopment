package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * This class contains an API's detail
 */

public class ApiDetail {

	private static final int IDX_SERVICE = 0;
	private static final int IDX_OPERATION = 1;
	private static final int IDX_VERSION = 2;

	private String apiKey;
	private String service;
	private String operation;
	private String version;
	private String path;

	/**
	 * ApiDetail constructor that generates the object
	 * by getting necessary info from provided apiKey
	 *
	 * @param apiKey must follow this format: {@code <service>.<operation>.<version>}
	 */
	public ApiDetail(String apiKey) {
		setApiKey(apiKey);
	}

	public final void setApiKey(String apiKey) {
		try {
			this.apiKey = apiKey;
			String[] apiKeyDissect = apiKey.split("\\.");
			this.service = apiKeyDissect[IDX_SERVICE];
			this.operation = apiKeyDissect[IDX_OPERATION];
			this.version = apiKeyDissect[IDX_VERSION];
			this.path = this.service +
					PATH_FRONT_SLASH + this.operation +
					UNION_DOT + this.version +
					JSON_EXTENSION;
		} catch (IndexOutOfBoundsException e) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, e, "Invalid ApiKey detected: %s", apiKey);
		}
	}

	public String getApiKey() {
		return apiKey;
	}

	public String getService() {
		return service;
	}

	public String getOperation() {
		return operation;
	}

	public String getVersion() {
		return version;
	}

	public String getPath() {
		return path;
	}

	@Override
	public String toString() {
		return "ApiDetail{" +
				"apiKey='" + apiKey + '\'' +
				", path='" + path + '\'' +
				'}';
	}
}
