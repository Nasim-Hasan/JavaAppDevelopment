package jp.co.rakuten.bff.core.service.upstream.client.impl;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.tcp.TcpClient;

import javax.annotation.PostConstruct;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static jp.co.rakuten.bff.core.constant.BffConstants.SO_TIMEOUT;
import static jp.co.rakuten.bff.core.constant.BffConstants.TIMEOUT;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_TIME_OUT_OCCURRED;

/**
 * Provide webClientBuilder for ecstatic and generic gateway call
 * with required tcp and pool settings
 */
@Service
public class EcstaticClientBuilder {
	private WebClient.Builder webClientBuilder;
	private Environment environment;
	private static final String CONNECTION_TIMEOUT_KEY = "ecstatic.call.timeout";
	private static final String SOCKET_TIMEOUT_KEY = "ecstatic.call.soTimeout";
	private static final String DEFAULT_TIMEOUT = "1000";
	private static final String DEFAULT_SO_TIMEOUT = "1000";
	protected static final String MAX_IDLE_TIME_KEY = "ecstatic.maximum.connection.idle.time";
	protected static final String MAX_CONNECTION = "ecstatic.maximum.http.connection.pool.size";

	protected static final Integer MAX_IDLE_TIME_DEFAULT = 30;
	private static final boolean SO_KEEP_ALIVE_STATUS = false;
	protected static final String CONNECTION_POOL_NAME = "ecstaticPool";
	private static final Integer MAX_LIFE_TIME_MINUTE_DEFAULT=1 ;
	private static final String MAX_LIFE_TIME_MINUTE_KEY="ecstatic.maximum.connection.life.time.minutes";
	private static final String KEEP_ALIVE_KEY = "ecstatic.connection.keep-alive";
	private static final Logger LOGGER = LoggerFactory.getLogger(EcstaticClientBuilder.class);


	/**
	 * The connection provider that can be updated at the runtime (max connection)
	 */
	protected ConnectionProvider connectionProvider;

	@Autowired
    EcstaticClientBuilder(WebClient.Builder webClientBuilder, Environment environment) {
		this.webClientBuilder = webClientBuilder;
		this.environment = environment;
	}


	@PostConstruct
	private void init() {
		updateConnectionProvider();
	}

	Duration getTimeoutDuration(Map<String, String> connectionMap) {
		return Duration.ofMillis(Integer.parseInt(connectionMap.get(SO_TIMEOUT)));
	}

	Mono<ClientResponse> getTimeoutException(String interfaceKey) {
		return Mono.error(BackendException
				.create(BackendErrorEnum.TIMEOUT, SERVICE_TIME_OUT_OCCURRED, interfaceKey));
	}

	/**
	 * Create the connection provider and allow runtime update.
	 */
	private void updateConnectionProvider() {
		//int maxLifeTime=env.getProperty(MAX_LIFE_TIME_MINUTE_KEY, Integer.class, MAX_LIFE_TIME_MINUTE_DEFAULT);
		//int maxConnectionIdleTime = env.getProperty(MAX_IDLE_TIME_KEY, Integer.class, MAX_IDLE_TIME_DEFAULT);
		int maxConnection = environment.getProperty(MAX_CONNECTION, Integer.class, ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS);
		if (connectionProvider == null) {
			this.connectionProvider=ConnectionProvider.builder(CONNECTION_POOL_NAME).maxConnections(maxConnection)
					.pendingAcquireTimeout(Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT))
					.metrics(true)
					//.maxLifeTime(Duration.ofMinutes(maxLifeTime))
					//.maxIdleTime(Duration.ofSeconds(maxConnectionIdleTime))
					.build();
		}
	}

	/**
	 * Create the reactive netty WebClient
	 *
	 * @return The WebClient to perform reactive web request
	 */
	WebClient getWebClient() {
		return webClientBuilder.clientConnector(new ReactorClientHttpConnector(getHttpClient())).build();
	}

	/**
	 * Prepare Reactor-Netty HttpClient with Http-Proxy-Settings, Read-Timeout and Write-Timeout.
	 *
	 * @return The http client
	 */
	private HttpClient getHttpClient() {
		return HttpClient.create(connectionProvider).tcpConfiguration(getTcpMapper());
	}

	/**
	 * Initialize tcp client with it's basic ChannelOption settings.
	 * SO_KEEPALIVE         If true then the channel try to keep alive when server allows similar functionality
	 * TCP_NODELAY          improved latency and throughput on a certain workload. Nagle's algorithm was introduced
	 * to reduce the overhead of TCP/IP packets (i.e. smaller a packet, bigger the overhead).
	 * It is basically to prevent a poor user application from generating too many small packets.
	 * AUTO_CLOSE           If true then the Channel is closed automatically and immediately on write failure.
	 *
	 * @param tcpClient     the targeted tcp client
	 * @return the tcp client
	 */
	protected TcpClient initTcpClient(TcpClient tcpClient) {
		return tcpClient
				.option(ChannelOption.SO_KEEPALIVE, true)
				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS,
						Integer.valueOf( environment.getProperty(CONNECTION_TIMEOUT_KEY, DEFAULT_TIMEOUT)))
				.doOnConnected(conn -> {
						long readWriteTimeout=Long.parseLong(environment.getProperty(SOCKET_TIMEOUT_KEY, DEFAULT_SO_TIMEOUT));
						conn.addHandlerLast(
						new ReadTimeoutHandler(readWriteTimeout, TimeUnit.MILLISECONDS));
				});
	}

	protected Function<TcpClient, TcpClient> getTcpMapper() {
		return (TcpClient tcpClient) -> {
			tcpClient = initTcpClient(tcpClient);
			return tcpClient;
		};
	}
}
