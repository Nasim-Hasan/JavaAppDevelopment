package jp.co.rakuten.bff.core.resolver;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.constant.ValidatorTypeEnum;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.util.DateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


/**
 * Validate the JsonSchema's request and response fields Upon
 * failure it will throw SystemException If there is any.
 * Exception while bootstrapping The application will log
 * the problem in the schema.
 * <p>validate(requestSchema,responseSchema,requestHeadersSchema)</p>
 */
@Component
public class JsonSchemaValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonSchemaValidator.class);
	private static final String TYPE = "type";

	/**
	 * This will validate the JsonSchema's request and response fields upon failure of
	 * any of the condition, application will be stopped.
	 *
	 * @param requestParamsSchema requestModel based upon which user request will be made
	 * @param responseParamsSchema responseModel based upon which user response will be prepared
	 * @param requestHeadersSchema requestHeadersSchema based upon which user response will be prepared
	 */
	public void validate(List<CommonSchema> requestParamsSchema, List<CommonSchema> responseParamsSchema,
						 List<CommonSchema> requestHeadersSchema) {
		if (CollectionUtils.isNotEmpty(requestParamsSchema)) {
			requestParamsSchema.forEach((CommonSchema commonSchema) -> {
				Object defaultValue = commonSchema.getDefaultValue();
				validateNameAndType(commonSchema);
				validateObjectAndObjectArray(commonSchema);
				//Checks the value of is required field, if empty then throw exception
				boolean required = BooleanUtils.toBoolean(commonSchema.getRequired());
				if (required && ObjectUtils.isNotEmpty(defaultValue)) {
					throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_FIELD_REQD_MSG);
				}
				//validates the Min Max for Numeric Type
				validateMinMax(commonSchema);

				//validates the Date Type
				validateDateType(commonSchema);

				//validates for the Prop Type
				validateProperty(commonSchema);

				//validates for the Option and List Type
				validateOptionsAndList(commonSchema);
			});
		}

		if (CollectionUtils.isNotEmpty(requestHeadersSchema)) {
			requestHeadersSchema.forEach((CommonSchema commonSchema) -> {
				validateNameAndType(commonSchema);
				validateProperty(commonSchema);
			});
		}

		if (CollectionUtils.isNotEmpty(responseParamsSchema)) {
			responseParamsSchema.forEach((CommonSchema commonSchema) -> {
				validateNameAndType(commonSchema);
				validateDateType(commonSchema);
				validateObjectAndObjectArray(commonSchema);
			});
		}
	}

	private void validateObjectAndObjectArray(CommonSchema commonSchema) {
		String type = commonSchema.getType();
		List<CommonSchema> parameters = commonSchema.getParameters();
		if ((ValidatorTypeEnum.OBJECT.getType().equals(type) || ValidatorTypeEnum.OBJECT_ARRAY.getType().equals(type))
				&& CollectionUtils.isEmpty(parameters)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_OBJECT_NOT_EMPTY_MSG);
		}
	}

	private void validateOptionsAndList(CommonSchema commonSchema) {
		String type = commonSchema.getType();
		List<Object> options = commonSchema.getOptions();
		if (ValidatorTypeEnum.getOptionsType().contains(type) && CollectionUtils.isEmpty(options)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_OPTIONS_NOT_EMPTY_MSG);
		}

		if (!ValidatorTypeEnum.getOptionsType().contains(type) && CollectionUtils.isNotEmpty(options)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, type
					+ MessageConstants.SCHEMA_VALID_OPTIONS_NOT_POSSIBLE_MSG);
		}

		if (CollectionUtils.isNotEmpty(options) && options.size() <= 1) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_OPTIONS_TYPE_MULTIOPTIONS_MSG);
		}

		String dataType = commonSchema.getDataType();
		validateDataType(type, dataType);
	}

	private void validateDataType(String type, String dataType) {
		if (ValidatorTypeEnum.LIST.getType().equals(type) || ValidatorTypeEnum.getOptionsType().contains(type)) {
			if (StringUtils.isBlank(dataType)) {
				throw SystemException
						.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_DATA_TYPE_REQD_MSG
								+ TYPE
								+ MessageConstants.SCHEMA_VALID_LIST_OR_OPTIONS_MSG);
			}

			if (!ValidatorTypeEnum.getNumericAndStringType().contains(dataType)) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						MessageConstants.SCHEMA_VALID_DATA_TYPE_NUM_OR_STR_MSG);
			}
		}
	}

	private void validateDateType(CommonSchema commonSchema) {
		if (ValidatorTypeEnum.DATE.getType().equals(commonSchema.getType())) {
			String format = commonSchema.getFormat();
			if (StringUtils.isBlank(format)) {
				throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_FORMAT_REQD_MSG
						+ TYPE + MessageConstants.SCHEMA_VALID_TYPE_DATE);
			} else {
				try {
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
					simpleDateFormat.format(DateUtil.getCurrentDate());
				} catch (IllegalArgumentException ex) {
					String message = MessageConstants.SCHEMA_VALID_FORMAT_WRONG_MSG + ex.getMessage();
					LOGGER.error(message);
					throw SystemException.create(SystemErrorEnum.INTERNAL, message);
				}
			}
		}
	}

	private void validateProperty(CommonSchema commonSchema) {
		String type = commonSchema.getType();
		String propType = commonSchema.getPropType();
		String propKeyPrefix = commonSchema.getPropKeyPrefix();

		if (type.equals(ValidatorTypeEnum.PROPERTY.getType())) {
			if (StringUtils.isBlank(propType)) {
				throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_PROP_TYPE_REQD_MSG
						+ TYPE + MessageConstants.SCHEMA_VALID_TYPE_PROPERTY);
			}

			if (StringUtils.isBlank(propKeyPrefix)) {
				throw SystemException
						.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_PROP_KEY_PREFIX_REQD_MSG
								+ TYPE + MessageConstants.SCHEMA_VALID_TYPE_PROPERTY);
			}
		}

		if (StringUtils.isNotBlank(propType) && !type.equals(ValidatorTypeEnum.PROPERTY.getType())) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_PROP_TYPE_DEFINE_MSG
					+ TYPE + MessageConstants.SCHEMA_VALID_TYPE_NOT_PROPERTY);
		}

		if (StringUtils.isNotBlank(propKeyPrefix) && !type.equals(ValidatorTypeEnum.PROPERTY.getType())) {
			throw SystemException
					.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_PROP_PREFIX_DEFINE_MSG
							+ TYPE
							+ MessageConstants.SCHEMA_VALID_TYPE_NOT_PROPERTY);
		}
	}

	private void validateMinMax(CommonSchema commonSchema) {
		Integer minSize = commonSchema.getMinSize();
		Integer maxSize = commonSchema.getMaxSize();
		Integer minLength = commonSchema.getMinLength();
		Integer maxLength = commonSchema.getMaxLength();
		Integer minValue = commonSchema.getMinValue();
		Integer maxValue = commonSchema.getMaxValue();
		String type = commonSchema.getType();

		minMaxValueValidate(minLength, maxLength, minSize, maxSize, minValue, maxValue, type);
		minMaxSizeValidate(minLength, maxLength, minSize, maxSize, minValue, maxValue, type);
		minMaxLengthValidate(minLength, maxLength, minSize, maxSize, minValue, maxValue, type);
	}

	private void minMaxValueValidate(Integer minLength, Integer maxLength,
									 Integer minSize, Integer maxSize, Integer minValue, Integer maxValue,
									 String type) {
		if (ValidatorTypeEnum.getNumericType().contains(type)) {
			if (ObjectUtils.isNotEmpty(minSize) || ObjectUtils.isNotEmpty(maxSize)
					|| ObjectUtils.isNotEmpty(minLength) || ObjectUtils.isNotEmpty(maxLength)) {
				throw SystemException
						.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_SIZE_LEN_NOT_VALID_MSG
								+ type + " " + TYPE);
			}

			if (ObjectUtils.isNotEmpty(minValue) && ObjectUtils.isNotEmpty(maxValue) && minValue > maxValue) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						MessageConstants.SCHEMA_VALID_MIN_VALUE_EXCEED_WARN_MSG);
			}
		}
	}

	private void minMaxSizeValidate(Integer minLength, Integer maxLength,
									Integer minSize, Integer maxSize, Integer minValue, Integer maxValue,
									String type) {
		if (ValidatorTypeEnum.LIST.getType().equals(type)) {
			if (ObjectUtils.isNotEmpty(minValue) || ObjectUtils.isNotEmpty(maxValue)
					|| ObjectUtils.isNotEmpty(minLength) || ObjectUtils.isNotEmpty(maxLength)) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						MessageConstants.SCHEMA_VALID_VALUE_LEN_NOT_PROPER_WARN_MSG + type + " " + TYPE);
			}

			if (ObjectUtils.isNotEmpty(minSize) && ObjectUtils.isNotEmpty(maxSize) && minSize > maxSize) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						MessageConstants.SCHEMA_VALID_MIN_SIZE_EXCEED_WARN_MSG);
			}
		}
	}

	private void minMaxLengthValidate(Integer minLength, Integer maxLength,
									  Integer minSize, Integer maxSize, Integer minValue, Integer maxValue,
									  String type) {
		if (ValidatorTypeEnum.STRING.getType().equals(type)) {
			if (ObjectUtils.isNotEmpty(minValue) || ObjectUtils.isNotEmpty(maxValue)
					|| ObjectUtils.isNotEmpty(minSize) || ObjectUtils.isNotEmpty(maxSize)) {
				throw SystemException
						.create(SystemErrorEnum.INTERNAL,
								MessageConstants.SCHEMA_VALID_VALUE_SIZE_NOT_PROPER_WARN_MSG
								+ type + " " + TYPE);
			}

			if (ObjectUtils.isNotEmpty(minLength) && ObjectUtils.isNotEmpty(maxLength) && minLength > maxLength) {
				throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_MIN_LEN_EXCEED_WARN_MSG);
			}
		}
	}

	private void validateNameAndType(CommonSchema commonSchema) {
		String name = commonSchema.getName();

		if (StringUtils.isBlank(name)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.SCHEMA_VALID_NAME_REQD_MSG);
		}

		String type = commonSchema.getType();
		if (StringUtils.isBlank(type)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, TYPE + MessageConstants.SCHEMA_VALID_IS_REQD_MSG);
		}

		if (!ValidatorTypeEnum.contains(type)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, type + MessageConstants.SCHEMA_VALID_IS_NOT_SUPPORT_MSG);
		}
	}
}
