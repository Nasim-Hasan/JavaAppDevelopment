package jp.co.rakuten.bff.core.service.upstream.client.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import jp.co.rakuten.bff.core.cache.IchibaCacheManager;
import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import jp.co.rakuten.bff.core.config.json.CustomizedObjectTypeAdapter;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.GenericEndpointConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.logger.BffContext;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.logger.HttpLoggerHelper;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.upstream.client.BodyMapConversionLogic;
import jp.co.rakuten.bff.core.service.upstream.client.EcstaticRequestHelper;
import jp.co.rakuten.bff.core.service.upstream.client.OverallStatusLogic;
import jp.co.rakuten.bff.core.service.upstream.client.UpstreamClient;
import jp.co.rakuten.bff.core.service.upstream.client.UrlParameterLogic;
import jp.co.rakuten.bff.core.util.BFFUtil;
import jp.co.rakuten.bff.core.util.ExceptionUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;
import reactor.util.context.Context;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.BFF_MOCKING_ENABLED;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.OVERRIDE_CONFIG_PWD;
import static jp.co.rakuten.bff.core.exception.type.BackendErrorEnum.NOT_FOUND;
import static jp.co.rakuten.bff.core.exception.type.BackendErrorEnum.SERVICE_CONDITION;
import static jp.co.rakuten.bff.core.exception.type.SystemErrorEnum.INTERNAL;
import static jp.co.rakuten.bff.core.service.upstream.client.EcstaticRequestHelper.getHttpHeaders;

/**
 * EC static call definition client
 */
@Service
public class EcstaticUpstreamClient implements UpstreamClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(EcstaticUpstreamClient.class);
	private static final String TEXT_RESPONSE_FORMAT = "text";
	private static final String XML_RESPONSE_FORMAT = "xml";
	private InterfaceConfigLoader interfaceConfigLoader;
	private OverallStatusLogic overallStatusLogic;
	private final HttpLogger serviceLogger;
	private EcstaticClientBuilder ecstaticClientBuilder;
	private IchibaCacheManager ichibaCacheManager;
	private final ObjectMapper mapper;
	private final BodyMapConversionLogic conversionLogic;
	private final Gson gson;
	private Environment environment;
	protected WebClient ecstaticWebClient;
	/**
	 * Default constructor
	 *
	 * @param interfaceConfigLoader {@link InterfaceConfigLoader}
	 * @param ecstaticClientBuilder {@link EcstaticClientBuilder}
	 * @param overallStatusLogic    {@link OverallStatusLogic}
	 * @param serviceLogger         {@link HttpLogger}
	 * @param ichibaCacheManager    {@link IchibaCacheManager}
	 */
	@Autowired
	public EcstaticUpstreamClient(InterfaceConfigLoader interfaceConfigLoader,
								  OverallStatusLogic overallStatusLogic,
								  @Qualifier("serviceLogger") HttpLogger serviceLogger,
								  IchibaCacheManager ichibaCacheManager, EcstaticClientBuilder ecstaticClientBuilder) {
		this.interfaceConfigLoader = interfaceConfigLoader;
		this.overallStatusLogic = overallStatusLogic;
		this.serviceLogger = serviceLogger;
		this.ichibaCacheManager = ichibaCacheManager;
		this.ecstaticClientBuilder = ecstaticClientBuilder;
		this.mapper = new ObjectMapper();
		this.conversionLogic = new BodyMapConversionLogic();
		CustomizedObjectTypeAdapter adapter = new CustomizedObjectTypeAdapter();
		this.gson = new GsonBuilder()
				.registerTypeAdapter(Map.class, adapter)
				.registerTypeAdapter(List.class, adapter)
				.create();
	}

	@PostConstruct
	void initWebClient(){
		ecstaticWebClient =  ecstaticClientBuilder.getWebClient();
	}

	/**
	 * environment setter
	 *
	 * @param environment {@link Environment}
	 */
	@Autowired
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	/**
	 * This method is responsible for execute the request.
	 *
	 * @param requests list of request. for http first element of list will startTimebe used
	 * @return Mono of a response map
	 */
	@Override
	public Mono<MultipleResponses> execute(String callDefinitionName, Collection<Map<String, Object>> requests,
										   String type) {
		HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
		List<Mono<Boolean>> responsePromises = new ArrayList<>();
		List<CustomHttpResponse> responses = new ArrayList<>();
		HttpHeaders httpHeaders = new HttpHeaders();

		return Mono.just(requests)
				.doOnEach((Signal<Collection<Map<String, Object>>> signal) -> {
					if (signal.isOnNext()) {
						Context context = signal.getContext();
						if (context.hasKey(BffConstants.BFF_CONTEXT)) {
							BffContext bffContext = context.get(BffConstants.BFF_CONTEXT);
							httpHeaders.setCacheControl(bffContext.getCacheControl());
							Boolean isMockEnabled = Boolean.parseBoolean(environment.getProperty(BFF_MOCKING_ENABLED,
									"false"));
							if (isMockEnabled && StringUtils.isNotEmpty(bffContext.getOverridingConfigPassword())
									&& StringUtils.isNotEmpty(bffContext.overridingConfigEnabled())) {
								httpHeaders.set(GenericEndpointConstants.OVERRIDE_CONFIG_PWD, bffContext.getOverridingConfigPassword());
								httpHeaders.set(GenericEndpointConstants.OVERRIDE_CONFIG_ENABLE_KEY, bffContext.overridingConfigEnabled());
							}
						}
					}
				})
				.flatMap((Collection<Map<String, Object>> requestsFromMono) -> {
					requestsFromMono.forEach((Map<String, Object> request) -> {
						Boolean isMockingEnabled = Boolean.parseBoolean(environment.getProperty(BFF_MOCKING_ENABLED,"false"));
						CustomHttpRequest customHttpRequest =
								EcstaticRequestHelper.getCustomRequest(request, interfaceConfigLoader, httpHeaders,
										environment.getProperty(OVERRIDE_CONFIG_PWD),isMockingEnabled);
						Mono<CustomHttpResponse> customHttpResponseMono =
								doRequest(callDefinitionName, customHttpRequest, httpHeaders);

						Mono<Boolean> responseReferences = customHttpResponseMono.flatMap((CustomHttpResponse response) -> {
							responses.add(response);
							responseMap.put(customHttpRequest.getRequestId(), response);
							return Mono.just(true);
						});
						responsePromises.add(responseReferences);
					});

					Mono<List<Boolean>> responseMonoList = Flux.merge(responsePromises).collectList();
					return responseMonoList.flatMap((List<Boolean> responseList) -> {
						MultipleResponses multipleResponses =
								new MultipleResponses(overallStatusLogic.computeOverallStatus(responses), responseMap);
						return Mono.just(multipleResponses);
					});
				});
	}

	/**
	 * This method is responsible for webclient request.
	 *
	 * @param callDefinitionName name of call definition for request
	 * @param customRequest      object contains all request related information
	 * @return Mono of CustomHttpResponse
	 */
	public Mono<CustomHttpResponse> doRequest(String callDefinitionName, CustomHttpRequest customRequest) {
		return doRequest(callDefinitionName, customRequest, null);
	}
	/**
	 * This method is responsible for webclient request.
	 *
	 * @param callDefinitionName name of call definition for request
	 * @param customRequest      object contains all request related information
	 * @param httpHeaders        {@link HttpHeaders}
	 * @return Mono of CustomHttpResponse
	 */
	public Mono<CustomHttpResponse> doRequest(String callDefinitionName, CustomHttpRequest customRequest,
											  HttpHeaders httpHeaders) {
		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		URI url = UrlParameterLogic.buildUri(customRequest);

		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();
		loggerRequest.setMethod(HttpMethod.GET);
		loggerRequest.setUri(url);
		loggerRequest.getExtras().put("requestId", customRequest.getRequestId());
		loggerRequest.getExtras().put("interfaceKey", customRequest.getInterfaceKey());

		return ichibaCacheManager.getFromCache(url.toString(), customRequest.getInterfaceKey(), httpHeaders)
				.flatMap(response ->
						onCacheResponseFound(callDefinitionName, customRequest, customHttpResponse, url, loggerRequest,
								httpHeaders, response))
				.onErrorResume((Throwable throwable) -> {
					LOGGER.error("Error occurred while fetching from cache for {}, calling backend now.",
							customRequest.getInterfaceKey());
					return requestBackend(callDefinitionName, customRequest, customHttpResponse, url, loggerRequest)
							.flatMap(
									responseMap -> setToCacheAndHandleError(customRequest.getInterfaceKey(),
											httpHeaders, url.toString(), responseMap));
				})
				.switchIfEmpty(Mono.defer(() -> {
					LOGGER.debug("Calling backend for {} data.", customRequest.getInterfaceKey());
					return requestBackend(callDefinitionName, customRequest, customHttpResponse, url, loggerRequest)
							.flatMap(
									responseMap -> setToCacheAndHandleError(customRequest.getInterfaceKey(),
											httpHeaders, url.toString(), responseMap));
				}));
	}

	private Mono<CustomHttpResponse> onCacheResponseFound(String callDefinitionName,
														  CustomHttpRequest customRequest,
														  CustomHttpResponse customHttpResponse, URI url,
														  HttpLogger.LoggerRequest loggerRequest,
														  HttpHeaders httpHeaders, CacheDataModel response) {
		if (response.isStaleCache()) {
			return onCacheResponseBeingStale(callDefinitionName, customRequest, customHttpResponse, url, loggerRequest,
					httpHeaders, response);
		} else {
			LOGGER.info("Data found in cache for interface: {}.", customRequest.getInterfaceKey());
			return Mono.just(validateAndGetHttpResponse(response));
		}
	}

	protected Mono<CustomHttpResponse> onCacheResponseBeingStale(String callDefinitionName,
	                                                             CustomHttpRequest customRequest,
	                                                             CustomHttpResponse customHttpResponse, URI url,
	                                                             HttpLogger.LoggerRequest loggerRequest,
	                                                             HttpHeaders httpHeaders, CacheDataModel response) {
		return ichibaCacheManager.getStaleActiveFlagFromCache(url + STALE_ACTIVE_KEY_SUFFIX)
				.flatMap(isStaleActive -> Mono.just(validateAndGetHttpResponse(response)))
				.switchIfEmpty(Mono.defer(() -> {
					LOGGER.info("Cache is stale for interface:{} and StaleActiveFlag is not set, trying to call " +
							            "backend", customRequest.getInterfaceKey());
					return onCacheBeingStaleAndNotActive(callDefinitionName, customRequest, customHttpResponse, url,
					                                     loggerRequest, httpHeaders, response);
				}))
				.onErrorResume(error -> {
					LOGGER.error("Exception while reading from cache with key={} ", url + STALE_ACTIVE_KEY_SUFFIX, error);
					return onCacheBeingStaleAndNotActive(callDefinitionName, customRequest, customHttpResponse, url,
					                                     loggerRequest, httpHeaders, response);
				});
	}

	protected Mono<CustomHttpResponse> onCacheBeingStaleAndNotActive(String callDefinitionName,
																	 CustomHttpRequest customRequest,
																	 CustomHttpResponse customHttpResponse, URI url,
																	 HttpLogger.LoggerRequest loggerRequest,
																	 HttpHeaders httpHeaders, CacheDataModel response) {
		return ichibaCacheManager.setStaleActiveFlagToCache(url + STALE_ACTIVE_KEY_SUFFIX,
				BFFUtil.getActiveFlagTimeout(environment))
				.onErrorResume(error -> {
					LOGGER.error("Exception while storing staleActiveFlag for key:{} to cache: ",
							url, error);
					return Mono.just(true);
				})
				.flatMap(ignoredValue ->
						requestBackend(callDefinitionName, customRequest, customHttpResponse, url, loggerRequest)
								.flatMap(responseMap -> setToCacheAndHandleError(customRequest.getInterfaceKey(), httpHeaders,
										url.toString(), responseMap))
								.onErrorResume((Throwable ex) -> {
									LOGGER.error("Error occurred while calling backend for interface:{}, serving stale cached data",
											customRequest.getInterfaceKey(), ex);
									return ichibaCacheManager.setStaleActiveFlagToCache(url + STALE_ACTIVE_KEY_SUFFIX,
											BFFUtil.getActiveFlagTimeout(environment))
											.onErrorResume(error -> {
												LOGGER.error("Exception while storing staleActiveFlag for key:{} to cache: ",
														url, error);
												return Mono.just(true);
											})
											.flatMap(ignored -> Mono.just(validateAndGetHttpResponse(response)));
								}));

	}

	private Mono<CustomHttpResponse> setToCacheAndHandleError(String interfaceKey,
															  HttpHeaders header, String url,
															  CustomHttpResponse response) {
		return ichibaCacheManager.
				setToCache(url, Map.of(BffConstants.ECATATIC_RESPONSE_KEY,
				                       ResponseUtil.copyCustomHttpResponse(response)), interfaceKey, header)
				.onErrorResume((Throwable throwable) -> {
					LOGGER.error("Error occurred while saving data to cache for {}", interfaceKey, throwable);
					return Mono.just(true);
				}).then(Mono.just(response));
	}

	CustomHttpResponse validateAndGetHttpResponse(CacheDataModel response) {
		if (ObjectUtils.isNotEmpty(response.getCacheMap())
				&& ObjectUtils.isNotEmpty(response.getCacheMap().get(BffConstants.ECATATIC_RESPONSE_KEY))) {
			if (response.getCacheMap().get(BffConstants.ECATATIC_RESPONSE_KEY) instanceof CustomHttpResponse) {
				CustomHttpResponse cacheResponse =
						(CustomHttpResponse) response.getCacheMap().get(BffConstants.ECATATIC_RESPONSE_KEY);
				return ResponseUtil.copyCustomHttpResponse(cacheResponse);
			} else {
				return mapper.convertValue(response.getCacheMap().get(BffConstants.ECATATIC_RESPONSE_KEY),
				                           CustomHttpResponse.class);
			}
		} else {
			throw SystemException.create(INTERNAL, MessageConstants.SERVICE_CACHE_RESPONSE_ERROR
					,
					response.getCacheMap());
		}
	}

	private Mono<CustomHttpResponse> requestBackend(String callDefinitionName, CustomHttpRequest customRequest,
													CustomHttpResponse customHttpResponse, URI url,
													HttpLogger.LoggerRequest loggerRequest) {

		return ecstaticWebClient
				.get()
				.uri(url)
				.headers(getHttpHeaders(customRequest.getHeaderMap()))
				.exchange()
				.timeout(ecstaticClientBuilder.getTimeoutDuration(customRequest.getConnectionMap()),
						ecstaticClientBuilder.getTimeoutException(customRequest.getInterfaceKey()))
				.retry(Integer.parseInt(customRequest.getConnectionMap().get("retry")))
				.flatMap((ClientResponse response) -> {
					throwExceptionIfAnyError(customRequest, response, loggerRequest);
					return response.bodyToMono(ByteArrayResource.class);
				})
				.flatMap((byteArrayResource) -> {
					byte[] resBodyByteArray = byteArrayResource.getByteArray();
					String charset = getCharset(customRequest.getMetaParameterMap());
					String responseBody = BFFUtil.decode(resBodyByteArray, charset);
					customHttpResponse.setBodyAsString(responseBody);
					String responseFormat = String.valueOf(customRequest.getMetaParameterMap().get(BffConstants.RESPONSE_FORMAT));
					return prepareCustomResponse(customHttpResponse, responseBody, responseFormat, customRequest,
					                              callDefinitionName);
				})
				.doOnEach((Signal<CustomHttpResponse> signal) -> {
					if (signal.isOnNext() || signal.isOnError()) {
						HttpLoggerHelper.prepareServiceLoggerRequest(loggerRequest, signal.getContext());
					}
				})
				.doOnSubscribe((Subscription subscription) -> {
					loggerRequest.startTimeCounting();
					LOGGER.info("{} ECSTATIC_CALL START", customRequest.getRequestId());
				})
				.doOnSuccess((CustomHttpResponse r) -> {
					serviceLogger.log(loggerRequest);
					LOGGER.info("{} ECSTATIC_CALL END ", customRequest.getRequestId());
				})
				.doOnError((Throwable r) -> {
					if (!((r instanceof TimeoutException) || (r instanceof BackendException))) {
						LOGGER.error("{} GENERIC_GATEWAY_CALL ERROR", callDefinitionName, r);
					} else {
						LOGGER.info("{} GENERIC_GATEWAY_CALL Timeout or BackendException!!", callDefinitionName);
					}
					writeServiceLog(r, serviceLogger, loggerRequest);
				}).onErrorResume((Throwable throwable) -> {
					throw ExceptionUtil.getBackendException(throwable);
				});
	}

	private void throwExceptionIfAnyError(CustomHttpRequest customRequest, ClientResponse response,
	                                      HttpLogger.LoggerRequest loggerRequest) {
		HttpStatus httpStatus = response.statusCode();
		loggerRequest.setStatus(HttpStatus.resolve(response.rawStatusCode()));
		if (httpStatus.is4xxClientError()) {
			LOGGER.debug("requestId:{} Response status: {}  from backend api", response.rawStatusCode(),
			             customRequest.getRequestId());
			throw BackendException.create(NOT_FOUND,
			                              MessageConstants.SERVICE_BACKEND_RESPONSE_STATUS, response.rawStatusCode());
		} else if (httpStatus.is5xxServerError()) {
			LOGGER.error("requestId:{} Response status: {}  from backend api", response.rawStatusCode(),
			             customRequest.getRequestId());
			throw BackendException.create(SERVICE_CONDITION,
			                              MessageConstants.SERVICE_BACKEND_RESPONSE_STATUS, response.rawStatusCode());
		}
	}

	private Mono<CustomHttpResponse> prepareCustomResponse(CustomHttpResponse customHttpResponse, String responseBody,
	                                                        String responseFormat, CustomHttpRequest customRequest, String callDefinitionName) {
		try {
			if (StringUtils.equals(responseFormat, XML_RESPONSE_FORMAT)) {
				customHttpResponse.setBodyMap(conversionLogic.xmlToMap(responseBody, false));
			} else if (!StringUtils.equals(responseFormat, TEXT_RESPONSE_FORMAT)) {
				customHttpResponse.setBodyMap(gson.fromJson(responseBody, Map.class));
			}
		} catch (JsonParseException e) {
			LOGGER.error("requestId:{} Unexpected response format from ecstatic endpoints {}: {}",
			             customRequest.getRequestId(), callDefinitionName, responseBody);
			return Mono.error(BackendException.create(SERVICE_CONDITION, e,
			                                          MessageConstants.SERVICE_UNEXPECTED_RESPONSE_FORMAT,
			                                          callDefinitionName));
		} catch (IOException e) {
			LOGGER.error("requestId:{} Unexpected IO error from ecstatic endpoints {}",
			             customRequest.getRequestId(), callDefinitionName);
			return Mono.error(BackendException.create(SERVICE_CONDITION, e,
			                                          MessageConstants.SERVICE_UNEXPECTED_RESPONSE_FORMAT,
			                                          callDefinitionName));
		}
		return Mono.just(customHttpResponse);
	}

	private String getCharset(Map<String, String> metaParameterMap) {
		String charset = "UTF-8";
		if (ObjectUtils.isNotEmpty(metaParameterMap) &&
				StringUtils.isNotBlank(metaParameterMap.get("metaParameter.charset"))) {
			charset = String.valueOf(metaParameterMap.get("metaParameter.charset"));
		}
		return charset;
	}
}
