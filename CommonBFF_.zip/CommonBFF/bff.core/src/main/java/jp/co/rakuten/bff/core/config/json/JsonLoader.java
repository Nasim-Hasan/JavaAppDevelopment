package jp.co.rakuten.bff.core.config.json;

import reactor.core.publisher.Mono;

/**
 * Loads Json configuration
 */
public interface JsonLoader {

	/**
	 * Load Json configuration
	 * and then convert to target classType object
	 *
	 * @param path      json file path
	 * @param classType target class type
	 * @return the mono
	 */
	<T> Mono<T> load(String path, Class<T> classType);
}
