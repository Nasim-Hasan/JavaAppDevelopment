package jp.co.rakuten.bff.core.constant;

import java.util.Set;

/**
 * All global constants related to BFF should be kept in here.
 */

public final class BffConstants {
	// Request keys
	public static final String REQUEST_ID = "requestId";
	public static final String INTERFACE_KEY = "interfaceKey";
	public static final String HEADERS = "headerParameters";
	public static final String URL_PARAMETERS = "urlParameters";
	public static final String META_PARAMETERS = "metaParameters";
	public static final String X_CLIENT_ID = "X-ClientId";
	public static final String X_TRACE_ID = "X-TraceId";
	public static final String EASY_ID = "easyId" ;


	//Response keys
	public static final String ERROR = "error";
	public static final String CODE = "code";
	public static final String MESSAGE = "message";
	public static final String REQUEST_CHARSET = "request_charset";
	public static final String STATUS = "status";
	public static final String BODY = "body";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";

	// Connection map keys
	public static final String CONNECTION_PREFIX = "connection.";
	public static final String TIMEOUT = "timeout";
	public static final String SO_TIMEOUT = "soTimeout";
	public static final String URL = "url";
	public static final String PORT = "port";
	public static final String BASE_URL = "baseUrl";
	public static final String REQUEST_PATH = "requestPath";

	// Call definition types
	public static final String CALL_DEFINITION_TYPE_SINGLE = "single";
	public static final String CALL_DEFINITION_TYPE_PARALLEL = "parallel";
	public static final String CALL_DEFINITION_TYPE_COMPLEX = "complex";
	public static final String CALL_DEFINITION_TYPE_ECSTATIC = "ecstatic";

	// Parameter map keys
	public static final String URL_PARAMETERS_PREFIX = "urlParameter.";
	public static final String BODY_PARAMETERS_PREFIX = "bodyParameter.";

	//prefix
	public static final String CIRCUIT = "circuit";

	// Header map keys
	public static final String HEADER_PREFIX = "headerParameters.";

	// Interface related keys
	public static final String GLOBAL_PREFIX = "interfaceGlobal.";
	public static final String CONFIG_LOADING_TIMEOUT_PROP = "config.loading.timeout";

	// Metadata map keys
	public static final String IGNORE_URL_ENCODE = "ignoreUrlEncode";
	public static final String RESPONSE_FORMAT = "responseFormat";

	// response status
	public static final String UPSTREAM_RESPONSE_SUCCESS = "SUCCESS";
	public static final String UPSTREAM_RESPONSE_PARTIAL_FAILURE = "PARTIAL_FAILURE";
	public static final String UPSTREAM_RESPONSE_FAILURE = "FAILURE";
	public static final String UPSTREAM_NO_RESPONSE = "NO_RESPONSE";

	// Api Repository
	public static final String PROP_KEY_API_REPO_PATH = "repository.api.path";
	public static final String PROP_KEY_API_CONFIG_REPO_PATH = "repository.api.config.path";
	public static final String PROP_KEY_INTERFACE_REPO_PATH = "repository.interface.path";
	public static final String PROP_KEY_CLOUD_CONFIG_ENABLED = "spring.cloud.config.enabled";
	public static final String PROP_KEY_REPO_LOADING_TIMEOUT = "repository.loading.timeout";

	// Json Loader constants
	public static final String JSON_EXTENSION = ".json";
	public static final String PATH_FRONT_SLASH = "/";
	public static final String UNION_DOT = ".";
	public static final String SPRING_CLOUD_CONFIG_URI = "spring.cloud.config.uri";
	public static final String SPRING_APPLICATION_NAME = "spring.application.name";
	public static final String SPRING_PROFILES_ACTIVE = "spring.profiles.active";
	public static final String SPRING_CLOUD_CONFIG_LABEL = "spring.cloud.config.label";

	// generic gateway uri
	public static final String GATEWAY_URI = "gateway.uri";
	public static final String SINGLE_REQUEST_PATH = "gateway.single.request.path";
	public static final String PARALLEL_REQUEST_PATH = "gateway.parallel.request.path";
	public static final String COMPLEX_REQUEST_PATH = "gateway.complex.request.path";
	public static final Set<String> VALID_CALL_DEFINITION_TYPES =
			Set.of(CALL_DEFINITION_TYPE_SINGLE, CALL_DEFINITION_TYPE_PARALLEL,
					CALL_DEFINITION_TYPE_COMPLEX, CALL_DEFINITION_TYPE_ECSTATIC);

	//Call definition response
	public static final String CALL_DEFINITION_RESPONSE_STATUS = "callDefinitionResponseStatus";
	public static final String CALL_DEFINITION_RESPONSE_KEY = "response";
	public static final String CALL_DEFINITION_INTERFACE_KEY = "interfaceKey";

	//interface
	public static final String INTERFACE_PARAM_NAME = "name";
	public static final String INTERFACE_PARAM_PATH = "path";
	public static final String INTERFACE_PARAM_SOURCE = "source";
	public static final String INTERFACE_PARAM_TYPE_KEY = "type";
	public static final String INTERFACE_PARAM_TYPE_PROPERTY = "property";
	public static final String INTERFACE_PARAM_PROPERTY_DEFAULT = "default";
	public static final String INTERFACE_PARAM_PROPERTY_KEY = "propKey";
	public static final String INTERFACE_PARAM_PROPERTY_KEY_PREFIX = "propKeyPrefix";
	public static final String INTERFACE_PARAM_PROPERTY_KEY_SUFFIX = "propKeySuffix";
	public static final String INTERFACE_PARAM_PROPERTY_KEY_DOT = ".";
	public static final String INTERFACE_PARAM_PROPERTY_DYNAMIC_PARAM_KEY = "dynamicParamKey";
	public static final String MAINTENANCE_PROP = ".maintenance";
	public static final String UNKNOWN_ERROR = "unknown error";
	public static final String INTERFACE_RESPONSE_BODY = "body";
	public static final String INTERFACE_RESPONSE_ERRORS = "errors";

	//generic gateway response
	public static final String GG_RESPONSES_KEY = "responses";
	public static final int GG_FAILED_RESPONSE_STATUS = 503;
	public static final String GG_FAILED_RESPONSE_MSG = "Service condition error";
	public static final int GG_NOT_CALL_RESPONSE_STATUS = 424;
	public static final String GG_NOT_CALL_RESPONSE_MSG = "Failed Dependency";
	public static final int PRECONDITION_FAILED_RESPONSE_STATUS = 412;
	public static final String PRECONDITION_FAILED_RESPONSE_MSG = "Precondition to call Backend failed";


	// Cache Manager constants
	public static final int DEFAULT_LOCAL_CACHE_TIMEOUT_MILLIS = 5000;
	public static final int DEFAULT_SHARED_CACHE_TIMEOUT_MILLIS = 6000;
	public static final int DEFAULT_STALE_TIMEOUT_MILLIS = 6000;
	public static final int LOCAL_CACHE_MAX_SIZE = 100;
	public static final String ENABLED_PROP_KEY = "enabled";
	public static final String LOCAL_TIMEOUT_PROP_KEY = "localTimeout";
	public static final String LOCAL_MAX_SIZE_PROP_KEY = "localMaxSize";
	public static final String SHARED_TIMEOUT_PROP_KEY = "sharedTimeout";
	public static final String TYPE_PROP_KEY = "type";
	public static final String STALE_ENABLED_PROP_KEY = "staleEnabled";
	public static final String STALE_TIMEOUT_PROP_KEY = "staleTimeout";
	public static final String CACHE_HEADER_NO_CACHE = "no-cache";
	public static final String CACHE_PREFIX = "cache.";
	public static final String DATA = "data";
	public static final String HEADER = "header";
	public static final int BUILDER_CAPACITY = 32;
	public static final String CALL_DEFINITION = "callDefinition -> {}";
	public static final String FEATURE_POSTFIX_FOR_ECSTATIC = "_ecstatic";
	public static final String KEY_SEPARATOR_HASH = "#";
	public static final String KEY_SEPARATOR_DOT = "\\.";
	public static final String KEY_SEPARATOR_SLASH_DOT = "\\\\.";
	public static final String KEY_SEPARATOR_UNDER_SCORE = "_";
	public static final String KEY_SEPARATOR_SLASH = "\\";
	public static final String SEPARATOR_INNER_DOT = ".";
	public static final String SEPARATOR_COLON =":";
	public static final String ECATATIC_RESPONSE_KEY = "response";
	public static final String STALE_ACTIVE_KEY_SUFFIX = "_staleActive";
	public static final String STALE_ACTIVE_KEY_TIMEOUT_PROP_KEY = "cache.default.staleActiveTimeout";
	public static final long STALE_ACTIVE_KEY_DEFAULT_TIMEOUT_VALUE = 10000L;
	public static final String STALE_ACTIVE_KEY_DEFAULT_TIMEOUT_STR_VALUE = "10000";
	public static final String CACHE_EXPIRY_TIME = "cacheExpiryTime";

	//Error responses
	public static final String INVALID_REQUEST_BODY = "invalid request body";
	public static final String EMPTY_FEATURES_REQUEST = "No available feature is being requested";

	public static final String INVALID_VERSION_FORMAT = "invalid version format";
	public static final String INTERNAL_SERVER_ERROR = "internal server error";
	public static final String NO_DATA_FOUND = "no data found";
	public static final String UNABLE_TO_FETCH_DATA_FROM_BACKEND = "Unable to fetch data from backend";
	public static final String RESPONSE_PREPARATION_ERROR_MSG = "Failed to prepare response";

	public static final String BFF_CONTEXT = "bffContext";
	public static final String METHOD = "method";

	public static final String SYSTEM_DATE = "sysdate";

	public static final String EMPTY_ALLOWED = "empty_allowed";

	private BffConstants() {
		// constant class
	}
}
