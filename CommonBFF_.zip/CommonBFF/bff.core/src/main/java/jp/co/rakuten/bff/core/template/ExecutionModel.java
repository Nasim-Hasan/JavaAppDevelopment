package jp.co.rakuten.bff.core.template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Its a POJO class which will be used in Feature Execution Service. It holds following info <br/>
 * <ul>
 *     <li>1. Call definition to feature map</li>
 *     <li>2. FeatureTemplate list</li>
 *     <li>3. Call definition template map</li>
 *     <li>4. Only client requested feature's interface set</li>
 * </ul>
 */
public class ExecutionModel {
	private Map<String, List<FeatureTemplate>> callDefinitionToFeatureMap = new HashMap<>();
	private List<FeatureTemplate> featureModelList = new ArrayList<>();
	private Map<String, CallDefinitionTemplate> executionMap = new HashMap<>();
	private Set<String> requiredInterfaces = new HashSet<>();
	private Map<String, Object> defaultResponse = new HashMap<>();

	public Map<String, List<FeatureTemplate>> getCallDefinitionToFeatureMap() {
		return this.callDefinitionToFeatureMap;
	}

	public List<FeatureTemplate> getFeatureModelList() {
		return this.featureModelList;
	}

	public Map<String, CallDefinitionTemplate> getExecutionMap() {
		return this.executionMap;
	}

	public Set<String> getRequiredInterfaces() {
		return this.requiredInterfaces;
	}

	public Map<String, Object> getDefaultResponse() {
		return defaultResponse;
	}

	public void setCallDefinitionToFeatureMap(Map<String, List<FeatureTemplate>> callDefinitionToFeatureMap) {
		this.callDefinitionToFeatureMap = callDefinitionToFeatureMap;
	}

	public void setFeatureModelList(List<FeatureTemplate> featureModelList) {
		this.featureModelList = featureModelList;
	}

	public void setExecutionMap(Map<String, CallDefinitionTemplate> executionMap) {
		this.executionMap = executionMap;
	}

	public void setRequiredInterfaces(Set<String> requiredInterfaces) {
		this.requiredInterfaces = requiredInterfaces;
	}

	public void setDefaultResponse(Map<String, Object> defaultResponse) {
		this.defaultResponse = defaultResponse;
	}

	public String toString() {
		return "ExecutionModel(callDefinitionToFeatureMap=" + this.getCallDefinitionToFeatureMap() +
				", featureModelList=" + this.getFeatureModelList() + ", executionMap=" + this.getExecutionMap() +
				", requiredInterfaces=" + this.getRequiredInterfaces() + ")";
	}
}
