package jp.co.rakuten.bff.core.constant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * This enum is using in parameter resolver class.
 * For type validation it's required to determine,
 * whether the provided type is valid or not.
 * */
public enum ValidatorTypeEnum {

	INTEGER("integer"),
	LONG("long"),
	DOUBLE("double"),
	DECIMAL("decimal"),
	BOOLEAN("boolean"),
	STRING("string"),
	PROPERTY("property"),
	OPTION("option"),
	MULTI_OPTION("multioption"),
	OBJECT("object"),
	OBJECT_ARRAY("objectarray"),
	LIST("list"),
	DATE("date");

	String type;

	private static final List<String> numericAndStringType = new ArrayList<>();
	private static final List<String> numericTypes = new ArrayList<>();
	private static final List<String> optionTypes = new ArrayList<>();

	ValidatorTypeEnum(String type) {
		this.type = type;
	}

	static {
		Collections.addAll(numericAndStringType,
				INTEGER.getType(), LONG.getType(), DOUBLE.getType(), DECIMAL.getType(), STRING.getType(), DATE.getType());
		Collections.addAll(numericTypes, INTEGER.getType(), LONG.getType(), DOUBLE.getType(), DECIMAL.getType());
		Collections.addAll(optionTypes, OPTION.getType(), MULTI_OPTION.getType());
	}

	public static List<String> getNumericAndStringType() {
		return numericAndStringType;
	}

	public static List<String> getNumericType() {
		return numericTypes;
	}

	public static List<String> getOptionsType() {
		return optionTypes;
	}

	/**
	 * Validate the provided key
	 *
	 * @param name {@link String}
	 * @return the corresponding enum
	 * */
	public static ValidatorTypeEnum getValidator(String name){
		if("objectarray".equals(name)) {
			return ValidatorTypeEnum.OBJECT_ARRAY;
		}

		if("multioption".equals(name)) {
			return ValidatorTypeEnum.MULTI_OPTION;
		}

		return ValidatorTypeEnum.valueOf(name.toUpperCase());
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Check the provided type is present or not
	 *
	 * @param type {@link String}
	 * @return the new boolean
	 * */
	public static boolean contains(String type) {
		for (ValidatorTypeEnum validatorTypeEnum : ValidatorTypeEnum.values()) {
			String numericType = validatorTypeEnum.getType();
			if (numericType.equals(type)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
