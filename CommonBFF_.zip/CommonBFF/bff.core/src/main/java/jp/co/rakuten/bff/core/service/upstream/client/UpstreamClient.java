package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import jp.co.rakuten.bff.core.logger.HttpLogger.LoggerRequest;

import java.util.Collection;
import java.util.Map;

/**
 * Call definition client interface
 */
@Component
public interface UpstreamClient {
	/**
	 * This method is responsible for execute the request.
	 *
	 * @param callDefinitionName name of callDefinition
	 * @param requests           list of request. for http first element of list will be used
	 * @param type               Call definition type
	 * @return Mono of a response map
	 */
	Mono<MultipleResponses> execute(String callDefinitionName, Collection<Map<String, Object>> requests, String type);

	/**
	 * Responsible to write service log for exceptional case
	 *
	 * @param throwable     Could be BackendException, IOException etc
	 * @param serviceLogger {@link HttpLogger}
	 * @param loggerRequest {@link LoggerRequest}
	 * */
	default void writeServiceLog(Throwable throwable, HttpLogger serviceLogger, LoggerRequest loggerRequest) {
		if (!(throwable instanceof BackendException)) {
			loggerRequest.setStatus(HttpStatus.SERVICE_UNAVAILABLE);
		}
		serviceLogger.log(loggerRequest);
	}
}
