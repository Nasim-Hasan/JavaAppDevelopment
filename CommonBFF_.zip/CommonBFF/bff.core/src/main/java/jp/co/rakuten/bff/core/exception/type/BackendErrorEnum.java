package jp.co.rakuten.bff.core.exception.type;

import jp.co.rakuten.bff.core.model.CallDefinitionError;
import org.springframework.http.HttpStatus;

/**
 * It will have the below error definition which will be later
 * used by BackendException
 * <li>NOT_FOUND --- 404</li>
 * <li>UNAUTHORIZED --- 503</li>
 * <li>UNKNOWN --- 503</li>
 * <li>SERVICE_CONDITION --- 503</li>
 * <li>TIMEOUT --- 503</li>
 */
public enum BackendErrorEnum {

	NOT_FOUND("not_found", HttpStatus.NOT_FOUND),
	BAD_REQUEST("Wrong Parameter", HttpStatus.BAD_REQUEST),
	UNAUTHORIZED("unauthorized", HttpStatus.SERVICE_UNAVAILABLE),
	UNKNOWN("unknown_status", HttpStatus.SERVICE_UNAVAILABLE),
	PRECONDITION_FAILED("precondition_failed", HttpStatus.PRECONDITION_FAILED),
	FAILED_DEPENDENCY("failed_dependency", HttpStatus.FAILED_DEPENDENCY),
	INTERNAL_SERVER_ERROR("internal_server_error", HttpStatus.INTERNAL_SERVER_ERROR, true),
	SERVICE_CONDITION("service_condition", HttpStatus.SERVICE_UNAVAILABLE, true),
	TIMEOUT("timeout", HttpStatus.SERVICE_UNAVAILABLE, true);

	private static final BackendErrorEnum DEFAULT_ERR = SERVICE_CONDITION;
	private String errorType;
	private HttpStatus errorCode;
	private boolean canOpenCircuitBreaker;

	BackendErrorEnum(String errorType, HttpStatus errorCode, boolean canOpenCircuitBreaker) {
		this.errorType = errorType;
		this.errorCode = errorCode;
		this.canOpenCircuitBreaker = canOpenCircuitBreaker;
	}

	BackendErrorEnum(String errorType, HttpStatus errorCode) {
		this(errorType, errorCode, false);
	}

	/**
	 * Resolve the given error to this enum, if possible, or {@link #DEFAULT_ERR} otherwise.
	 *
	 * @param callDefError {@link CallDefinitionError}
	 * @return the corresponding enum
	 */
	public static BackendErrorEnum resolve(CallDefinitionError callDefError) {
		if (callDefError != null) {
			return resolve(callDefError.getCode());
		}
		return DEFAULT_ERR;
	}

	/**
	 * Resolve the given error code to this enum, if possible, or {@link #DEFAULT_ERR} otherwise.
	 *
	 * @param statusCode the HTTP status code
	 * @return the corresponding enum
	 */
	public static BackendErrorEnum resolve(int statusCode) {
		for (BackendErrorEnum value : values()) {
			if (value.errorCode.value() == statusCode) {
				return value;
			}
		}
		return DEFAULT_ERR;
	}

	public String getErrorType() {
		return errorType;
	}

	public HttpStatus getErrorCode() {
		return errorCode;
	}

	/**
	 * Indicate if the exception should count for circuit breaker computation.
	 *
	 * @return true if the exception should count
	 */
	public boolean canOpenCircuitBreaker() {
		return canOpenCircuitBreaker;
	}
}
