package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.ValidatorTypeEnum;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_BOOL_CONVERT_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_DOUBLE_CONVERT_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_INTEGER_CONVERT_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_KEY_MISSING_FOR_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_KEY_MISSING_MSG;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PROP_LONG_CONVERT_ERROR;


/**
 * <p>This Spring component is responsible for loading properties
 * this can load properties if the properties are found otherwise it will fetch default values from the properties if
 * not found either it will throw SystemException
 * </p>
 */
@Component
public class PropertyReader {

	private Environment environment;

	/**
	 * Default value constructor
	 *
	 * @param environment {@link Environment}
	 * */
	public PropertyReader (Environment environment) {
		this.environment = environment;
	}

	/**
	 * Get properties value with given propKey and also cast to the given output type
	 *
	 * @param propKey    properties key
	 * @param outputType expected output type
	 * @return properties value
	 */
	public <T> T getPropertyValue(String propKey, String outputType) {
		String propValue = loadPropertiesValue(propKey);
		if (propValue == null) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, UTIL_PROP_KEY_MISSING_MSG);


		}

		return propValueConversion(propValue, ValidatorTypeEnum.valueOf(outputType.toUpperCase()));
	}

	/**
	 * Get properties value with given propKey and appended value from the client request and also cast to the given
	 * output type
	 *
	 * @param prefix    full property key or property prefix key
	 * @param suffix    properties suffix key
	 * @param dynamicKey      the value which is using to generate property key
	 * @param outputType expected output type
	 * @return properties value
	 */
	public <T> T getPropertyValue(String prefix, String suffix, Object dynamicKey, String outputType) {
		String propKey = prefix;

		if (ObjectUtils.isEmpty(dynamicKey)) {
			return propValueConversion(loadDefaultProperties(propKey), ValidatorTypeEnum.valueOf(outputType.toUpperCase()));
		}

		if (StringUtils.isNotBlank(suffix)) {
			propKey = prefix + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT +
					 dynamicKey + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT + suffix;
		} else {
			propKey = prefix + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT + dynamicKey;
		}

		String propValue = loadPropertiesValue(propKey);

		if (StringUtils.isEmpty(propValue)) {
			propValue = loadDefaultProperties(propKey);
		}

		return propValueConversion(propValue, ValidatorTypeEnum.valueOf(outputType.toUpperCase()));
	}

	private <T> T propValueConversion(String propValue, ValidatorTypeEnum outputType) {
		T outputValue;
		switch (outputType) {
			case INTEGER:
				try {
					outputValue = (T) Integer.valueOf(propValue);
				} catch (NumberFormatException ex) {
					throw SystemException.create(SystemErrorEnum.INTERNAL, UTIL_PROP_INTEGER_CONVERT_ERROR, ex);
				}
				break;
			case LONG:
				try {
					outputValue = (T) Long.valueOf(propValue);
				} catch (NumberFormatException ex) {
					throw SystemException.create(SystemErrorEnum.INTERNAL, UTIL_PROP_LONG_CONVERT_ERROR, ex);
				}
				break;
			case DOUBLE:
				try {
					outputValue = (T) Double.valueOf(propValue);
				} catch (NumberFormatException ex) {
					throw SystemException.create(SystemErrorEnum.INTERNAL, UTIL_PROP_DOUBLE_CONVERT_ERROR, ex);
				}
				break;
			case BOOLEAN:
				if ("true".equals(propValue) || "false".equals(propValue)) {
					outputValue = (T) Boolean.valueOf(propValue);
				} else {
					throw SystemException.create(SystemErrorEnum.INTERNAL, UTIL_PROP_BOOL_CONVERT_ERROR);
				}
				break;
			default:
				outputValue = (T) propValue;
				break;
		}

		return outputValue;
	}

	private String loadPropertiesValue(String propKey) {
		return environment.getProperty(propKey);
	}

	private String loadDefaultProperties(String propKey) {
		String defaultProperties = loadPropertiesValue(propKey + ".default");
		if (StringUtils.isEmpty(defaultProperties)) {
			throw SystemException
					.create(SystemErrorEnum.INTERNAL, UTIL_PROP_KEY_MISSING_FOR_ERROR + propKey);
		}

		return defaultProperties;
	}
}
