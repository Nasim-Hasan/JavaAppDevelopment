package jp.co.rakuten.bff.core.cache;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Contains shared cache stats
 * hitCount, missCount and staleCount
 */
public class RedisCacheStats {
	private final AtomicLong hitCount = new AtomicLong(0);
	private final AtomicLong missCount = new AtomicLong(0);
	private final AtomicLong staleCount = new AtomicLong(0);

	public RedisCacheStats() {
	}

	/**
	 * Constructs this class with provided initial values
	 * @param newHitCount   initial shared cache hit count of this instance
	 * @param newMissCount  initial shared cache miss count of this instance
	 * @param newStaleCount initial shared cache stale count of this instance
	 */
	public RedisCacheStats(long newHitCount, long newMissCount, long newStaleCount) {
		this.hitCount.set(newHitCount);
		this.missCount.set(newMissCount);
		this.staleCount.set(newStaleCount);
	}

	public long getHitCount() {
		return hitCount.get();
	}

	public long getMissCount() {
		return missCount.get();
	}

	public long getStaleCount() {
		return staleCount.get();
	}

	/**
	 * increments this shared cache's hit count
	 */
	public void incrementHitCount() {
		hitCount.incrementAndGet();
	}

	/**
	 * increments this shared cache's miss count
	 */
	public void incrementMissCount() {
		missCount.incrementAndGet();
	}

	/**
	 * increments this shared cache's stale count
	 */
	public void incrementStaleCount() {
		staleCount.incrementAndGet();
	}
}
