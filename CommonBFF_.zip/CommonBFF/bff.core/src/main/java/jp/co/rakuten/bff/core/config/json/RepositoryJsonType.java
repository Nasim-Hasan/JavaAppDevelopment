package jp.co.rakuten.bff.core.config.json;

/**
 * The enum Json type.
 */
public enum RepositoryJsonType {
	/**
	 * api template json type.
	 */
	API("api"),
	/**
	 * apiConfig json type.
	 */
	API_CONFIG("apiConfig"),
	/**
	 * interface json type.
	 */
	INTERFACE("interface");

	private String jsonContentType;

	RepositoryJsonType(String jsonContentType) {
		this.jsonContentType = jsonContentType;
	}

	/**
	 * Gets value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return jsonContentType;
	}
}
