package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Template Model Class intended for mapping corresponding Json field
 * <br>
 * Resolved from api Json file
 */
public class ApiParamsTemplate {
	@JsonProperty("commonHeaders")
	private List<CommonSchema> commonHeaders = new ArrayList<>();
	// Set via setter
	private Set<String> defaultFeatures = new HashSet<>();
	@JsonProperty("features")
	private Map<String, FeatureTemplate> featuresParamsMap = new HashMap<>();

	public List<CommonSchema> getCommonHeaders() {
		return commonHeaders;
	}

	public void setCommonHeaders(List<CommonSchema> commonHeaders) {
		this.commonHeaders = commonHeaders;
	}

	public Map<String, FeatureTemplate> getFeaturesParamsMap() {
		return featuresParamsMap;
	}

	public void setFeaturesParamsMap(Map<String, FeatureTemplate> featuresParamsMap) {
		this.featuresParamsMap = featuresParamsMap;
	}

	public Set<String> getDefaultFeatures() {
		return defaultFeatures == null ? new HashSet<>() : defaultFeatures;
	}

	@JsonProperty("defaultFeatures")
	public void setDefaultFeatures(List<String> defaultFeatures) {
		this.defaultFeatures = new HashSet<>(defaultFeatures);
	}

	@Override
	public String toString() {
		return "ApiParamsTemplate{" +
				"commonHeaders=" + commonHeaders +
				", defaultFeatures=" + defaultFeatures +
				", featuresParamsMap=" + featuresParamsMap +
				'}';
	}
}
