package jp.co.rakuten.bff.core.model;

import org.springframework.http.HttpHeaders;

/**
 * Will hold all the user requested parameters.
 */
public class ClientRequestModel {
	private String service;
	private String operation;
	private String version;
	private RequestModel requestModel;
	private String clientId;
	private HttpHeaders header;

	/**
	 * parameterized constructor
	 *
	 * @param service      will hold the api-service
	 * @param operation    specific operation of a service
	 * @param version      indicate the version number
	 * @param requestModel hold the requested parameters, more specifically the body parameter user passed.
	 * @param clientId     client Id
	 * @param header       All request specific header both user provided and
	 */
	public ClientRequestModel(String service, String operation, String version, RequestModel requestModel,
							  String clientId, HttpHeaders header) {
		this.service = service;
		this.operation = operation;
		this.version = version;
		this.requestModel = requestModel;
		this.clientId = clientId;
		this.header = header;
	}

	/**
	 * Default constructor
	 */
	public ClientRequestModel() {
		// intentionally kept it empty. Assuming instance will be created by json libraries.
	}

	public String getService() {
		return this.service;
	}

	public String getOperation() {
		return this.operation;
	}

	public String getVersion() {
		return this.version;
	}

	public RequestModel getRequestModel() {
		return this.requestModel;
	}

	public String getClientId() {
		return this.clientId;
	}

	public HttpHeaders getHeader() {
		return this.header;
	}

	public void setService(String service) {
		this.service = service;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public void setRequestModel(RequestModel requestModel) {
		this.requestModel = requestModel;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public void setHeader(HttpHeaders header) {
		this.header = header;
	}

	public String toString() {
		return "UserRequestModel(service=" + this.getService() + ", operation=" + this.getOperation() + ", version=" +
				this.getVersion() + ", parameters=" + this.getRequestModel() + ", clientId=" + this.getClientId() +
				", header=" + this.getHeader() + ")";
	}
}
