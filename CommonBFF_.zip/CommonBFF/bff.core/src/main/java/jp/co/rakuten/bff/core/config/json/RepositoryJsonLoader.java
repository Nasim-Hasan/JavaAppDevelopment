package jp.co.rakuten.bff.core.config.json;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.template.ApiParamsTemplate;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

import static jp.co.rakuten.bff.core.config.json.RepositoryJsonType.*;
import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * Load json files for Repository from external or local source
 */
@Component
public class RepositoryJsonLoader {

	private static final Logger LOGGER = LoggerFactory.getLogger(RepositoryJsonLoader.class);
	private static final Map<RepositoryJsonType, String> localDirPathPropKeys = Map.of(
			API, PROP_KEY_API_REPO_PATH,
			API_CONFIG, PROP_KEY_API_CONFIG_REPO_PATH,
			INTERFACE, PROP_KEY_INTERFACE_REPO_PATH
	);

	private Environment env;
	private ExternalJsonLoader externalJsonLoader;
	private LocalJsonLoader localJsonLoader;

	/**
	 * Autowired constructor, uses Spring Injection
	 * @param env Enviromment variable
	 * @param externalJsonLoader the loader for external json
	 * @param localJsonLoader    the loader for local json
	 */
	@Autowired
	public RepositoryJsonLoader(Environment env, ExternalJsonLoader externalJsonLoader, LocalJsonLoader localJsonLoader) {
		this.env = env;
		this.externalJsonLoader = externalJsonLoader;
		this.localJsonLoader = localJsonLoader;
	}

	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public ExternalJsonLoader getExternalJsonLoader() {
		return externalJsonLoader;
	}

	public void setExternalJsonLoader(ExternalJsonLoader externalJsonLoader) {
		this.externalJsonLoader = externalJsonLoader;
	}

	public LocalJsonLoader getLocalJsonLoader() {
		return localJsonLoader;
	}

	public void setLocalJsonLoader(LocalJsonLoader localJsonLoader) {
		this.localJsonLoader = localJsonLoader;
	}

	/**
	 * Loads ApiTemplate<br>
	 * Logic:
	 * <ul>
	 *     <li>Try to load Api Config json</li>
	 *     <li>If successful, try to load Api json</li>
	 *     <li>If successful, set necessary values and return</li>
	 * </ul>
	 *
	 * @param apiDetail    {@link ApiDetail} object for target Api
	 * @param fromExternal whether should be loaded from external or local
	 * @return Mono<ApiTemplate>
	 */
	public Mono<ApiTemplate> loadApiTemplate(ApiDetail apiDetail, boolean fromExternal) {
		return getTemplate(apiDetail.getPath(), API_CONFIG, fromExternal, ApiTemplate.class)
				.flatMap(apiTemplate -> getTemplate(apiDetail.getPath(), API, fromExternal, ApiParamsTemplate.class)
						.flatMap(apiParamsTemplate ->
								finalizeApiTemplate(apiTemplate, apiDetail, apiParamsTemplate, fromExternal)
						)
				);
	}

	private Mono<ApiTemplate> finalizeApiTemplate(ApiTemplate apiTemplate, ApiDetail apiDetail,
												  ApiParamsTemplate apiParamsTemplate, boolean fromExternal) {
		apiTemplate.setFromExternal(fromExternal);
		apiTemplate.setApiParamsTemplate(apiParamsTemplate);
		apiTemplate.setApiDetail(apiDetail);
		return Mono.just(apiTemplate);
	}

	/**
	 * Loads InterfaceTemplate<br>
	 * - Tries to load from external first<br>
	 * - In case failed, loads from local
	 *
	 * @param interfacePath path of the interface json
	 * @return Mono<InterfaceTemplate>
	 */
	public Mono<InterfaceTemplate> loadInterfaceTemplate(String interfacePath) {
		return loadInterfaceTemplate(interfacePath, true)
				.onErrorResume((Throwable externalException) -> {
					LOGGER.error(interfacePath + MessageConstants.CONFIG_CLOUD_LOAD_JSON_ERROR_MSG,
								 externalException);
					return loadInterfaceTemplate(interfacePath, false);
				});
	}

	/**
	 * Loads InterfaceTemplate
	 *
	 * @param interfacePath path of the interface json
	 * @param fromExternal  whether should be loaded from external or local
	 * @return Mono<InterfaceTemplate>
	 */
	public Mono<InterfaceTemplate> loadInterfaceTemplate(String interfacePath, boolean fromExternal) {
		return getTemplate(interfacePath, INTERFACE, fromExternal, InterfaceTemplate.class);
	}

	/**
	 * Load Json configuration for specified {@code RepositoryJsonType}
	 * and then convert to target classType object
	 *
	 * @param path      json file path, INCLUDING json Extension
	 * @param jsonType  the type of {@link RepositoryJsonType}
	 * @param classType target class type
	 * @return the mono
	 */
	private <T> Mono<T> getTemplate(String path, RepositoryJsonType jsonType, boolean fromExternal, Class<T> classType){
		JsonLoader jsonLoader;
		if (fromExternal) {
			jsonLoader = externalJsonLoader;
		} else {
			jsonLoader = localJsonLoader;
		}
		path = env.getProperty(localDirPathPropKeys.get(jsonType)) + path;
		return jsonLoader.load(path, classType);
	}
}
