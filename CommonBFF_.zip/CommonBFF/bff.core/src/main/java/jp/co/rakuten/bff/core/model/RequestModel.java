package jp.co.rakuten.bff.core.model;

import java.util.Map;

/**
 * Represent the BFF specific user request model. will contain common parameters and feature-wise
 * all parameters.
 */
public class RequestModel {
	private CommonRequestModel common;
	private Map<String, CommonRequestModel> features;
	private Map<String, ?> mockConnections;

	/**
	 * Default constructor
	 */
	public RequestModel() {
		// intentionally kept it empty. Assuming instance will be created by json libraries.
	}

	public CommonRequestModel getCommon() {
		return this.common;
	}

	public Map<String, CommonRequestModel> getFeatures() {
		return this.features;
	}

	public void setCommon(CommonRequestModel common) {
		this.common = common;
	}

	public void setFeatures(Map<String, CommonRequestModel> features) {
		this.features = features;
	}

	public Map<String, ?> getMockConnections() {
		return mockConnections;
	}

	public void setMockConnections(Map<String, ?> mockConnections) {
		this.mockConnections = mockConnections;
	}

	public String toString() {
		return "RequestModel(common=" + this.getCommon() + ", features=" + this.getFeatures() + ")";
	}
}
