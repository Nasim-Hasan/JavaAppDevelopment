package jp.co.rakuten.bff.core.model;

import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/**
 * Feature post processor response POJO<br/>
 * interfaceResponseMap - Interface name as key and interface response as value
 */
public class FeaturePostProcessorResponse {
	private boolean isCacheable;
	private Map<String, Object> responseMap;
	private Map<String, String> headers = new HashMap<>();

	/**
	 * Default constructor
	 */
	public FeaturePostProcessorResponse() {
		this.isCacheable = false;
	}

	public boolean isCacheable() {
		return isCacheable;
	}

	public void setCacheable(boolean cacheable) {
		isCacheable = cacheable;
	}

	public Map<String, Object> getResponseMap() {
		return this.responseMap != null ? responseMap : new HashMap<>();
	}

	public void setResponseMap(Map<String, Object> responseMap) {
		this.responseMap = responseMap;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	@Override
	public String toString() {
		return "FeaturePostProcessorResponse{" +
				"isCacheable=" + isCacheable +
				", responseMap=" + responseMap +
				", headers=" + headers +
				'}';
	}

	/**
	 * Its static factory method. Generate a {@link FeaturePostProcessorResponse} Mono
	 *
	 * @return Mono<FeaturePostProcessorResponse>
	 */
	public static Mono<FeaturePostProcessorResponse> getEmptyResponseMono() {
		return Mono.just(new FeaturePostProcessorResponse());
	}
}
