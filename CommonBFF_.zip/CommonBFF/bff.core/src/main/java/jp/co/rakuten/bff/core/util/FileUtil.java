package jp.co.rakuten.bff.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;

import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PARSE_JSON_STRING_ERROR;

/**
 * File utility class that provides different types of utility
 * i.e. getting Json file list of a directory or directory list
 */
public class FileUtil {
	private static final String JSON_NAME_REGEX = "^([0-9a-zA-Z_.-]+)\\.json";

	private FileUtil() {
		// kept empty
	}

	/**
	 * Provide valid json file list of a directory
	 *
	 * @param dir directory
	 * @return File[]
	 */
	public static File[] getValidJsonFiles(File dir) {
		return dir.listFiles(file ->
				file.isFile() && file.getName().matches(JSON_NAME_REGEX)
		);
	}

	/**
	 * Provide list of directory of a directory
	 *
	 * @param dir directory
	 * @return File[]
	 */
	public static File[] getDirList(File dir) {
		return dir.listFiles(File::isDirectory);
	}

	/**
	 * Gets object of target classType from jsonString
	 *
	 * @param jsonString json String to be parsed
	 * @param classType  target classType
	 * @param <T>        classType
	 * @return prepared object
	 */
	public static <T> T getObjectFromJson(String jsonString, Class<T> classType) {
		try {
			return new ObjectMapper().readValue(jsonString, classType);
		} catch (IOException e) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, e, UTIL_PARSE_JSON_STRING_ERROR);
		}
	}
}
