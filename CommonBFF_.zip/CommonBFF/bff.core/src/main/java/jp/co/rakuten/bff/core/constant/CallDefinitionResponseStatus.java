package jp.co.rakuten.bff.core.constant;

/**
 * Interface  call definition response status enum<br/>
 * NOT_CALLED - not called to generic gateway due to dependency doesn't resolved
 * SUCCESS - Successfully called generic gateway
 * FAILURE - If http request client throw any kind of exception
 */
public enum CallDefinitionResponseStatus {
	NOT_CALLED,
	SUCCESS,
	FAILURE
}
