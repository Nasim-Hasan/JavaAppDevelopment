package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.config.ApiConfigurationProperties;
import jp.co.rakuten.bff.core.config.json.RepositoryJsonLoader;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.instrumentation.prometheus.PrometheusInitializer;
import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.resolver.JsonSchemaValidator;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiParamsTemplate;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.template.RequestSchema;
import jp.co.rakuten.bff.core.util.RequestUtil;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * This class parse each api json files and makes the API Repository ready
 * to be used later during runtime.<br><br>
 * <p>
 * The task of parsing and converting the json files to api map and api
 * template model is done during initialization of the application,
 * done via Spring PostConstruct annotation. In case of refresh is triggered,
 * it can also reload the api repository during runtime.<br><br>
 */
@Configuration
public class ApiRepositoryImpl implements ApiRepository {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiRepositoryImpl.class);
	// as we are using long for generating hashKey, so assuming that
	// each of the API will not contain more than 62 features(technically 64 but as we were considering singed long).
	private static final int MAX_NUMBER_OF_FEATURES = 62;
	private static boolean isConfigServerEnabled;

	private Environment env;
	private ApplicationContext context;
	private ConcurrentHashMap<String, ApiTemplate> allApiTemplates = new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Mono<InterfaceTemplate>> allInterfaceMonos = new ConcurrentHashMap<>();
	private JsonSchemaValidator schemaValidator;
	private ApiConfigurationProperties apiConfigProperties;
	private RepositoryJsonLoader repositoryJsonLoader;

	/**
	 * Autowired constructor, uses Spring Injection
	 *
	 * @param env                  {@link Environment}
	 * @param context              {@link ApplicationContext}
	 * @param schemaValidator      {@link JsonSchemaValidator}
	 * @param apiConfigProperties  {@link ApiConfigurationProperties}
	 * @param repositoryJsonLoader {@link RepositoryJsonLoader}
	 */
	@Autowired
	public ApiRepositoryImpl(Environment env, ApplicationContext context, JsonSchemaValidator schemaValidator,
							 ApiConfigurationProperties apiConfigProperties, RepositoryJsonLoader repositoryJsonLoader) {
		this.env = env;
		this.context = context;
		this.schemaValidator = schemaValidator;
		this.apiConfigProperties = apiConfigProperties;
		this.repositoryJsonLoader = repositoryJsonLoader;
	}

	/**
	 * Refresh handlers for actuator refresh triggering configuration updates
	 * @param event {@link RefreshScopeRefreshedEvent} is triggered after {@code RefreshScope}
	 */
	@EventListener(RefreshScopeRefreshedEvent.class)
	public void onRefresh(RefreshScopeRefreshedEvent event) {
		LOGGER.info("{} received by {}", event.getClass().getSimpleName(), this.getClass().getSimpleName());
		load();
	}

	/**
	 * Loads the repository by parsing json files,
	 * converting them to templates and resolve necessary logic
	 * and storing them to repository collection. It should run
	 * during PostConstruct, during init of the application.
	 */
	@PostConstruct
	public void load() {
		reloadRepository().subscribe(null, ex -> LOGGER.error(MessageConstants.SERVICE_API_REPO_LOAD_ERROR_MSG, ex));
	}

	private synchronized Mono<Boolean> reloadRepository() {
		long startTime;
		startTime = System.currentTimeMillis();
		Map<String, String> apiMapping = apiConfigProperties.getMapping();
		if (apiMapping == null) {
			apiMapping = new HashMap<>();
			LOGGER.warn(MessageConstants.SERVICE_API_REPO_LOAD_MAPPING_WARN_MSG);
		}
		final Set<String> apiKeys = apiMapping.keySet();
		List<Mono<Boolean>> repoMonos = new ArrayList<>();
		allInterfaceMonos.clear();
		isConfigServerEnabled = Boolean.parseBoolean(env.getProperty(PROP_KEY_CLOUD_CONFIG_ENABLED));
		ConcurrentHashMap<String, ApiTemplate> newApiTemplatesMap = new ConcurrentHashMap<>();
		for (String apiKey : apiKeys) {
			LOGGER.info(MessageConstants.SERVICE_API_REPO_READ_JSON_FILE_MSG, apiKey);
			ApiDetail apiDetail;
			try {
				apiDetail = new ApiDetail(apiKey);
			} catch (SystemException e) {
				LOGGER.error(e.getMessage(), e);
				continue;
			}
			Mono<Boolean> loadMono = loadApiConfiguration(apiDetail)
					.flatMap((ApiTemplate newApiTemplate) -> {
						if (newApiTemplate != null) {
							newApiTemplatesMap.put(newApiTemplate.getApiKey(), newApiTemplate);
							LOGGER.info("API template loaded successfully: {}", newApiTemplate.getApiKey());
							return Mono.just(true);
						} else {
							return Mono.just(false);
						}
					})
					.onErrorResume((Throwable e) -> {
						LOGGER.error(apiKey + ": Template loading failed", e);
						return Mono.just(false);
					});
			repoMonos.add(loadMono);
		}
		Mono<List<Boolean>> resultsMono = Flux.merge(repoMonos).collectList();
		return resultsMono.flatMap((List<Boolean> result) -> {
			allApiTemplates = newApiTemplatesMap;
			long loadDuration = System.currentTimeMillis() - startTime;
			long configLoadingTimeout = Long.parseLong(env.getProperty(PROP_KEY_REPO_LOADING_TIMEOUT));
			String loadDurationMessage = String.format(MessageConstants.SERVICE_API_REPO_TEMPLATE_LOAD_INFO,
					allApiTemplates.size(), apiKeys.size(), loadDuration);
			if (loadDuration > configLoadingTimeout) {
				LOGGER.warn(loadDurationMessage);
			} else {
				LOGGER.info(loadDurationMessage);
			}
			PrometheusInitializer.oninit(this,this.env);
			return Mono.just(true);
		});
	}

	@Override
	public ApiTemplate getApiRepositoryTemplate(String apiKey) {
		return getFromApiTemplates(apiKey);
	}

	/**
	 * will fetch the {@link ApiTemplate} using the {@link ClientRequestModel#getService()},
	 * {@link ClientRequestModel#getOperation()}, {@link ClientRequestModel#getVersion()}.
	 *
	 * @param data contains user specific paramters.
	 * @return {@link ApiTemplate} of requested api.
	 */
	@Override
	public ApiTemplate getApiRepositoryTemplate(ClientRequestModel data) {
		return getFromApiTemplates(RequestUtil.buildAPIKey(data));
	}

	private ApiTemplate getFromApiTemplates(String key) {
		if (!allApiTemplates.containsKey(key)) {
			throw ClientException.create(ClientErrorEnum.BAD_REQUEST, "Template not found for apiKey: " + key);
		}
		return allApiTemplates.get(key);
	}

	public Map<String,ApiTemplate> getAllApiTemplates(){
		return allApiTemplates;
	}

	/**
	 * Logic for loading for configuration files will be this:
	 * <Pre>{@code
	 * if (config server is enabled)
	 * try to load external json first
	 * if (external json loaded successfully) {
	 * => use external json to prepare configuration
	 * } else { // unable to load or parse external json
	 * if (previous configuration is from External) {
	 * => use the previous configuration
	 * } else { // no previous configuration or previous is local
	 * load the local json
	 * if (local json loaded with success) {
	 * => use local json to prepare configuration
	 * } else if (previous exists) {
	 * => use the previous configuration
	 * } else {
	 * Log error and return null configuration
	 * }
	 * }
	 * }
	 * }</Pre>
	 *
	 * @param apiDetail           {@link ApiDetail} for target API
	 * @return loaded configuration
	 */
	private Mono<ApiTemplate> loadApiConfiguration(ApiDetail apiDetail) {
		Mono<ApiTemplate> resultMono;
		ApiTemplate existingApiTemplate = allApiTemplates.get(apiDetail.getApiKey());
		if (isConfigServerEnabled) {
			resultMono = repositoryJsonLoader
					.loadApiTemplate(apiDetail, true)
					.flatMap(loadedApiTemplate -> prepareApiTemplateModel(loadedApiTemplate, apiDetail)
							.flatMap((ApiTemplate apiTemplate) -> {
								LOGGER.info(MessageConstants.SERVICE_API_REPO_JSON_LOAD_INFO, loadedApiTemplate.getApiKey());
								return Mono.just(apiTemplate);
							})
					).onErrorResume((Throwable externalException) -> {
						LOGGER.error(apiDetail.getApiKey() + MessageConstants.SERVICE_API_REPO_JSON_LOAD_FAIL_INFO,
								externalException);
						return onUnableToLoadExternalApiTemplate(apiDetail, existingApiTemplate);
					});
		} else {
			resultMono = onUnableToLoadExternalApiTemplate(apiDetail, existingApiTemplate);
		}
		return resultMono;
	}

	private Mono<ApiTemplate> onUnableToLoadExternalApiTemplate(ApiDetail apiDetail, ApiTemplate existingApiTemplate) {
		String apiKey = apiDetail.getApiKey();
		if (existingApiTemplate != null) {
			LOGGER.info("{}: Previous template will be used", apiKey);
			return Mono.just(existingApiTemplate);
		} else {
			return repositoryJsonLoader.loadApiTemplate(apiDetail, false)
					.flatMap(loadedApiTemplate -> prepareApiTemplateModel(loadedApiTemplate, apiDetail)
							.flatMap((ApiTemplate apiTemplate) -> {
								LOGGER.info(MessageConstants.SERVICE_API_REPO_JSON_LOAD_LOCAL_INFO, apiKey);
								return Mono.just(apiTemplate);
							})
					).onErrorResume((Throwable localException) -> {
						LOGGER.error(apiKey + MessageConstants.SERVICE_API_REPO_JSON_LOAD_LOCAL_FAIL_INFO, localException);
						return Mono.error(SystemException.create(SystemErrorEnum.INTERNAL, localException,
								MessageConstants.SERVICE_API_REPO_UNABLE_CONFIG_LOAD_INFO));
					});
		}
	}

	private Mono<ApiTemplate> prepareApiTemplateModel(ApiTemplate apiTemplateModel, ApiDetail apiDetail) {
		apiTemplateModel.setApiDetail(apiDetail);
		apiTemplateModel.setValidatorBean(getCustomValidatorBean(apiTemplateModel.getValidatorName()));

		return resolveInterfaceModels(apiTemplateModel.getInterfacesMap())
				.flatMap((List<InterfaceTemplate> interfaceTemplateList) -> {
					resolveCallDefinitionModels(apiTemplateModel.getCallDefinitionsMap());
					resolveFeatureModels(apiTemplateModel);
					return Mono.just(apiTemplateModel);
				});
	}

	private void resolveFeatureModels(ApiTemplate apiTemplateModel) {
		Map<String, FeatureTemplate> featuresMap = apiTemplateModel.getFeaturesMap();
		AtomicInteger featureIds = new AtomicInteger(0);
		featuresMap.forEach((String featureName, FeatureTemplate featureModel) -> {
			int id = featureIds.incrementAndGet();
			if (id > MAX_NUMBER_OF_FEATURES) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						MessageConstants.SERVICE_API_REPO_MAX_OBTAIN_WARN + MAX_NUMBER_OF_FEATURES +
								MessageConstants.SERVICE_API_REPO_HASH_FUNC_UPDATE);
			}
			featureModel.setId(id);
			featureModel.setName(featureName);
			featureModel.setProcessorBean(getProcessorBean(featureModel.getProcessorName(), FeatureProcessor.class));
			resolveInterfaces(apiTemplateModel, featureName, featureModel);
			ApiParamsTemplate apiFeaturesParamsModel = apiTemplateModel.getApiParamsTemplate();
			validateDefaultFeatures(apiTemplateModel);
			resolveFeatureParamsModels(apiFeaturesParamsModel, featureName, featureModel);
			mergeCommonHeadersToFeatureHeaders(featureModel, apiFeaturesParamsModel.getCommonHeaders());
		});
	}

	private void resolveInterfaces(ApiTemplate apiTemplateModel, String featureName, FeatureTemplate featureModel) {
		featureModel.getInterfaceNameList().forEach((String currentInterfaceName) -> {
			InterfaceTemplate interfaceTemplate = apiTemplateModel.getInterfacesMap().get(currentInterfaceName);
			if (interfaceTemplate == null) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						"Interface '" + currentInterfaceName + "' used in feature '" + featureName
								+ MessageConstants.SERVICE_API_REPO_DEFINE_IN_INTERFACE_MAP	);
			}
			featureModel.getInterfacesMap().put(currentInterfaceName, interfaceTemplate);
			for (Map.Entry<String, CallDefinitionTemplate> entry : apiTemplateModel.getCallDefinitionsMap()
					.entrySet()) {
				CallDefinitionTemplate callDefinitionTemplateModel = entry.getValue();
				if (callDefinitionTemplateModel.getInterfacesList().contains(currentInterfaceName)) {
					featureModel.getCallDefinitionsSet().add(callDefinitionTemplateModel);
					break;
				}
			}
		});
	}

	void validateDefaultFeatures(ApiTemplate templateModel) {
		Map<String, FeatureTemplate> features = templateModel.getFeaturesMap();
		Set<String> defaultFeatures = templateModel.getApiParamsTemplate().getDefaultFeatures();
		if (CollectionUtils.isNotEmpty(defaultFeatures) && !features.keySet().containsAll(defaultFeatures)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL,
					"Feature(s) declared as defaultFeature does not match with any existing feature!");
		}
	}

	private void resolveFeatureParamsModels(ApiParamsTemplate apiFeaturesParamsModel, String featureName,
											FeatureTemplate featureModel) {
		FeatureTemplate featureParamsModel = apiFeaturesParamsModel.getFeaturesParamsMap().get(featureName);
		if (featureParamsModel != null) {
			try {
				List<CommonSchema> requestParamsSchema = featureParamsModel.getRequest().getParameters();
				List<CommonSchema> requestHeadersSchema = featureParamsModel.getRequest().getHeaders();
				List<CommonSchema> responseParamsSchema = featureParamsModel.getResponse().getParameters();
				schemaValidator.validate(requestParamsSchema, responseParamsSchema, requestHeadersSchema);
			} catch (SystemException ex) {
				LOGGER.error(MessageConstants.SERVICE_API_REPO_SCHEMA_LOAD_ERROR, ex.getMessage(),ex);
			}
			featureModel.setRequest(featureParamsModel.getRequest());
			featureModel.setResponse(featureParamsModel.getResponse());
		}
	}

	private void mergeCommonHeadersToFeatureHeaders(FeatureTemplate featureTemplate, List<CommonSchema> commonHeaders) {
		RequestSchema request = featureTemplate.getRequest();
		if (request == null) {
			request = new RequestSchema();
		}
		List<CommonSchema> featureHeaders = request.getHeaders();
		if (featureHeaders.isEmpty()) {
			featureHeaders.addAll(commonHeaders);
		} else {
			commonHeaders.forEach((CommonSchema commonHeader) -> {
				List<CommonSchema> matches = featureHeaders.stream()
						.filter(header -> commonHeader.getName().equals(header.getName()))
						.collect(Collectors.toList());
				if (CollectionUtils.isEmpty(matches)) {
					featureHeaders.add(commonHeader);
				}
			});
		}
	}

	/**
	 * Contains logic to resolve necssary fields for callDefinition models
	 *
	 * @param callDefinitionsMap
	 */
	private void resolveCallDefinitionModels(Map<String, CallDefinitionTemplate> callDefinitionsMap) {
		callDefinitionsMap.forEach((String modelName, CallDefinitionTemplate currentModel) -> {
			if (!VALID_CALL_DEFINITION_TYPES.contains(currentModel.getType())) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						"Invalid type '" + currentModel.getType()
								+ MessageConstants.SERVICE_API_REPO_CALL_DEF_DEFINE + modelName);
			}
			currentModel.setName(modelName);
			List<String> currentDependsList = currentModel.getDependsList();
			Map<String, CallDefinitionTemplate> currentDependsMap = currentModel.getDependsMap();
			currentDependsList.forEach((String callDefinitionName) -> {
				if (callDefinitionsMap.get(callDefinitionName) == null) {
					throw SystemException.create(SystemErrorEnum.INTERNAL,
							MessageConstants.SERVICE_API_REPO_CALL_DEF_DEPENDENCY + callDefinitionName +
									MessageConstants.SERVICE_API_REPO_SAME_API_SCOPE);
				}
				currentDependsMap.put(callDefinitionName, callDefinitionsMap.get(callDefinitionName));
			});
		});
	}

	private Mono<List<InterfaceTemplate>> resolveInterfaceModels(Map<String, InterfaceTemplate> interfacesMap) {
		List<Mono<InterfaceTemplate>> interfacesMapMonoList = new ArrayList<>();
		interfacesMap.forEach((String modelName, InterfaceTemplate currentModel) -> {
			String path = modelName + JSON_EXTENSION;
			Mono<InterfaceTemplate> interfaceMono = allInterfaceMonos.computeIfAbsent(path, k ->
					repositoryJsonLoader.loadInterfaceTemplate(path, false).cache()
			).flatMap((InterfaceTemplate interfaceTemplate) -> {
				currentModel.setProcessorBean(getProcessorBean(currentModel.getProcessorName(), InterfaceProcessor.class));
				currentModel.mergeWith(interfaceTemplate);
				if (StringUtils.isBlank(currentModel.getInterfaceKey())) {
					currentModel.setInterfaceKey(modelName);
				}
				return Mono.just(currentModel);
			});
			interfacesMapMonoList.add(interfaceMono);
		});
		return Flux.merge(interfacesMapMonoList).collectList();
	}

	private <T> T getProcessorBean(String processorName, Class<T> processorType) {
		T processorBean = null;
		if (StringUtils.isNotBlank(processorName)) {
			try {
				processorBean = processorType.cast(context.getBean(processorName));
			} catch (ClassCastException | NoSuchBeanDefinitionException e) {
				SystemException.create(SystemErrorEnum.INTERNAL, e,
						MessageConstants.SERVICE_API_REPO_BEAN_NAME_FIND_ISSUE
						+ processorName);
			}
		}
		return processorBean;
	}

	/**
	 * Get custom validator bean from Spring context by name.
	 *
	 * @param validatorName Custom validator bean name
	 * @return CustomValidator bean
	 */
	private CustomValidator getCustomValidatorBean(String validatorName) {
		CustomValidator customValidator = null;
		if (StringUtils.isNotBlank(validatorName)) {
			customValidator = (CustomValidator) context.getBean(validatorName);
		}
		return customValidator;
	}
}
