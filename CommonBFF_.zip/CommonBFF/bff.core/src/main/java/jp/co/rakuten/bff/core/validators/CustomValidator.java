package jp.co.rakuten.bff.core.validators;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;

import java.util.List;
import java.util.Map;

/**
 * Custom request validator interface
 */
public interface CustomValidator {

	/**
	 * Perform validation related task if generic validator doesn't fulfill business criteria.
	 *
	 * @param validatedData       Generically validated data. key: feature name, value: {@link CommonRequestModel}
	 * @param featureTemplateList List of {@link FeatureTemplate}
	 * @param actualRequest       User's requested data - {@link ClientRequestModel}
	 * @return Map<String, CommonRequestModel> - key: feature name, value: {@link CommonRequestModel}
	 */
	Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
											 List<FeatureTemplate> featureTemplateList,
											 ClientRequestModel actualRequest);
}
