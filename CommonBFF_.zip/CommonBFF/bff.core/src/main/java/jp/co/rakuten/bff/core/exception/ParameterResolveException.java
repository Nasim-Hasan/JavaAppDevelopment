package jp.co.rakuten.bff.core.exception;

/**
 * ParameterResolveException will be responsible for validation for
 * <ul>
 *     <li>Request</li>
 *     <li>Response</li>
 * </ul>
 *
 * Upon failure of validation
 * It will be caught for Request and then propagate ClientException
 * It will be caught for Response and further response building would be performed
 */
public class ParameterResolveException extends RuntimeException {

	/**
	 * Default constructor
	 *
	 * @param message {@link String}
	 * */
	public ParameterResolveException(String message) {
		super(message);
	}
}
