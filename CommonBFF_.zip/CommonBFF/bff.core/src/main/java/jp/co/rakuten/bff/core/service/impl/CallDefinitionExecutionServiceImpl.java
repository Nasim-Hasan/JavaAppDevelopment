package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.logger.BffContext;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.CallDefinitionExecutionService;
import jp.co.rakuten.bff.core.service.upstream.client.UpstreamClient;
import jp.co.rakuten.bff.core.service.upstream.client.impl.EcstaticUpstreamClient;
import jp.co.rakuten.bff.core.service.upstream.client.impl.GenericGatewayUpstreamClient;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.util.RequestUtil;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;
import reactor.util.context.Context;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ArrayList;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * This component do 3 major task.<br/>
 * <ul>
 * <li>Run generic call definition pre-processor which will prepare generic gateway call parameter based on config
 * file and client request.</li>
 * <li>Make decision - this call definition should call or not.</li>
 * <li>Decide which type of call definition call ( single/parallel/complex ) this is and call call definition client
 * accordingly.</li>
 * </ul>
 */
@Service
public class CallDefinitionExecutionServiceImpl implements CallDefinitionExecutionService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CallDefinitionExecutionServiceImpl.class);

	private GenericCallDefinitionProcessor genericCallDefinitionProcessor;
	private GenericGatewayUpstreamClient genericGatewayUpstreamClient;
	private EcstaticUpstreamClient ecstaticUpstreamClient;

	/**
	 * Default constructor.
	 *
	 * @param genericCallDefinitionProcessor {@link GenericCallDefinitionProcessor}
	 * @param genericGatewayUpstreamClient {@link GenericGatewayUpstreamClient}
	 * @param ecstaticUpstreamClient {@link EcstaticUpstreamClient}
	 */
	@Autowired
	public CallDefinitionExecutionServiceImpl(GenericCallDefinitionProcessor genericCallDefinitionProcessor,
											  GenericGatewayUpstreamClient genericGatewayUpstreamClient,
											  EcstaticUpstreamClient ecstaticUpstreamClient) {
		this.genericCallDefinitionProcessor = genericCallDefinitionProcessor;
		this.genericGatewayUpstreamClient = genericGatewayUpstreamClient;
		this.ecstaticUpstreamClient = ecstaticUpstreamClient;
	}

	/**
	 * First decide provided call definition should call or not, then take the action accordingly.<br/> If dependent call
	 * definition resolved properly then return the call definition response mono. <br/> Else return pre-define error
	 * response mono.
	 *
	 * @param callDefinitionTemplate CallDefinitionTemplate - holds processor, interface list and dependency list
	 * @param validatedRequest Validated request - feature name as key and {@link CommonRequestModel} as value
	 * @param apiTemplate ApiTemplate - holds api specific {@link InterfaceTemplate}, {@link CallDefinitionTemplate},
	 * {@link FeatureTemplate}
	 * @param executionModel Execution model
	 * @param callDefinitionResponseMap Map<String, Object> - holds already resolved call definition response. Key - Call
	 * definition name, Value - Call definition response object
	 * @param headers contains header values from user
	 * @return Mono<Object> - Call definition response mono.
	 */
	@Override
	public Mono<CallDefinitionResponse> getCallDefinitionResponse(CallDefinitionTemplate callDefinitionTemplate,
																  Map<String, CommonRequestModel> validatedRequest,
																  ApiTemplate apiTemplate,
																  ExecutionModel executionModel,
																  Map<String, CallDefinitionResponse> callDefinitionResponseMap,
																  HttpHeaders headers, Map<String,?> mockBackend) {
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		//iterate call definition's interface list and collect only requested feature's interface
		callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
			if (executionModel.getRequiredInterfaces().contains(interfaceName)) {
				InterfaceTemplate interfaceTemplate = apiTemplate.getInterfacesMap().get(interfaceName);
				interfaceMap.put(interfaceName, interfaceTemplate);
			}
		});

		//run generic call definition pre processor, which will prepare generic gateway format param for
		//all requested interface
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCallDefinitionProcessor.preProcess(
				interfaceMap, validatedRequest,
				executionModel.getCallDefinitionToFeatureMap().get(callDefinitionTemplate.getName()), mockBackend);

		//run interface post processor and decide call definition should c all or not
		Mono<Boolean> callDefinitionShouldRunMono = runInterfacesPreProcessor(validatedRequest, callDefinitionResponseMap,
				interfaceMap, genericCDProcessedData, headers);
		return callDefinitionShouldRunMono.flatMap(callDefinitionShouldRun -> {
			if (callDefinitionShouldRun) {
				UpstreamClient upstreamClient;
				String callDefinitionType = callDefinitionTemplate.getType();
				if (callDefinitionType.equalsIgnoreCase(CALL_DEFINITION_TYPE_ECSTATIC)) {
					upstreamClient = ecstaticUpstreamClient;
				} else {
					upstreamClient = genericGatewayUpstreamClient;
				}

			return Mono.just(callDefinitionTemplate.getName())
					.doOnEach((Signal<String> signal) -> {
						if (signal.isOnNext()) {
							Context context = signal.getContext();
							if (context.hasKey(BFF_CONTEXT)) {
								BffContext bffContext = context.get(BFF_CONTEXT);
								bffContext.setApiKey(apiTemplate.getApiKey());
							}
						}
					}).flatMap(ignoredValue ->
						upstreamClient
								.execute(callDefinitionTemplate.getName(),
								         genericCDProcessedData.getPreparedRequest().values(), callDefinitionType)
								.flatMap((MultipleResponses multipleResponses) -> {
									CallDefinitionResponse callDefinitionResponse =
											new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
									multipleResponses.getResponses()
											.putAll(genericCDProcessedData.getInterfaceResponses());
									callDefinitionResponse.setMultipleResponses(multipleResponses);
									callDefinitionResponse.setInterfaceToRequestIdMap(
											genericCDProcessedData.getInterfaceToRequestIdMap());
									return runInterfacesPostProcessor(validatedRequest, callDefinitionResponse,
												callDefinitionResponseMap, interfaceMap, genericCDProcessedData,headers)
											.flatMap(status->{
												return Mono.just(callDefinitionResponse);
											});
								})
						);
			} else {
				CallDefinitionResponseStatus cdResponseStatus;
				Integer errorCode = null;
				String errorMsg = null;
				if (interfaceMap.size() == genericCDProcessedData.getInterfaceResponses().size()) {
					boolean callDefFailed = true;
					for (CustomHttpResponse interfaceResponse : genericCDProcessedData.getInterfaceResponses().values()) {
						if (interfaceResponse.getError() == null &&
								(interfaceResponse.getBodyMap() != null || interfaceResponse.getBodyAsString() != null)) {
							callDefFailed = false;
							break;
						}
					}
					if (callDefFailed) {
						cdResponseStatus = CallDefinitionResponseStatus.FAILURE;
						errorCode = PRECONDITION_FAILED_RESPONSE_STATUS;
						errorMsg = PRECONDITION_FAILED_RESPONSE_MSG;
					} else {
						cdResponseStatus = CallDefinitionResponseStatus.SUCCESS;
					}
				} else {
					cdResponseStatus = CallDefinitionResponseStatus.NOT_CALLED;
					errorCode = GG_NOT_CALL_RESPONSE_STATUS;
					errorMsg = GG_NOT_CALL_RESPONSE_MSG;
				}
				CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(cdResponseStatus);
				if (cdResponseStatus != CallDefinitionResponseStatus.SUCCESS) {
					CallDefinitionError callDefinitionError = new CallDefinitionError(errorCode, errorMsg);
					callDefinitionResponse.setCallDefinitionError(callDefinitionError);
				} else {
					MultipleResponses multipleResponses = new MultipleResponses();
					multipleResponses.setOverallStatus(SUCCESS);
					multipleResponses.setResponses(genericCDProcessedData.getInterfaceResponses());
					callDefinitionResponse.setMultipleResponses(multipleResponses);
					callDefinitionResponse.setInterfaceToRequestIdMap(genericCDProcessedData.getInterfaceToRequestIdMap());
				}
				return Mono.just(callDefinitionResponse);
			}
		});
	}

	/**
	 * Run interface custom pre processor which eventually decide this call definition should call or not.
	 *
	 * @param validatedRequest          Validated user request data map
	 * @param callDefinitionResponseMap call definition response map
	 * @param interfaceMap              Interface map - key: interface name, value: {@link InterfaceTemplate}
	 * @param genericCDProcessedData    generic Call Definition Processed Data
	 * @return boolean
	 */
	private Mono<Boolean> runInterfacesPreProcessor(Map<String, CommonRequestModel> validatedRequest,
											  Map<String, CallDefinitionResponse> callDefinitionResponseMap,
											  Map<String, InterfaceTemplate> interfaceMap,
											  GenericCallDefinitionProcessedData genericCDProcessedData, HttpHeaders headers) {
		List<Mono<Boolean>> interfaceResultList = new ArrayList<>();
		return Mono.just(interfaceResultList).flatMap(allInterfacesResultMonos-> {
			for (Map.Entry<String, InterfaceTemplate> entry : interfaceMap.entrySet()) {
				//if interface's custom post processor exist run it
				String interfaceName = entry.getKey();
				InterfaceTemplate interfaceTemplate = entry.getValue();
				if (Objects.nonNull(interfaceTemplate.getProcessorBean())) {
					boolean preProcessStatus = needToCallInterface(interfaceTemplate, validatedRequest);
					if (!preProcessStatus) {
						genericCDProcessedData.removeRequestByInterface(interfaceName);
					} else {
						Mono<Boolean> preProcessorMono = preProcessor(validatedRequest, callDefinitionResponseMap,
								genericCDProcessedData, interfaceTemplate, interfaceName, headers).flatMap(status -> {
							if (!status) {
								genericCDProcessedData.removeRequestByInterface(interfaceName);
							}
							return Mono.just(status);
						}).onErrorResume(err-> {
							genericCDProcessedData.removeRequestByInterface(interfaceName);
							return Mono.just(false);
						});
						allInterfacesResultMonos.add(preProcessorMono);
					}
				} else {
					allInterfacesResultMonos.add(Mono.just(true));
				}
			}
			return Flux.merge(allInterfacesResultMonos).collectList().flatMap((List<Boolean> interfacesStatusList) -> {
				boolean needToCallBacked = false;
				for (Boolean callBackend : interfacesStatusList) {
					if (callBackend) {
						needToCallBacked = callBackend;
						break;
					}
				}
				return Mono.just(needToCallBacked);
			});
		});
	}

	boolean needToCallInterface(InterfaceTemplate interfaceTemplate,
	                                    Map<String, CommonRequestModel> validatedRequest) {
		Map<String, List<String>> validResponseKeys = interfaceTemplate.getTargetResponseMappings();
		boolean needToCall = true;
		if (MapUtils.isNotEmpty(validResponseKeys)) {
			needToCall = validResponseKeys.entrySet().stream()
					.anyMatch(entry -> validatedRequest.containsKey(entry.getKey()) &&
							RequestUtil.isIncluded(entry.getValue(), validatedRequest.get(entry.getKey())));
		}
		return needToCall;
	}

	/**
	 * Run interface pre processor
	 *
	 * @param validatedRequest          Validated request map
	 * @param callDefinitionResponseMap call definition response map
	 * @param genericCDProcessedData    generically prepared request {@link GenericCallDefinitionProcessedData}
	 * @param interfaceTemplate         Interface template
	 * @param interfaceName             Interface name
	 * @return boolean
	 */
	private Mono<Boolean> preProcessor(Map<String, CommonRequestModel> validatedRequest,
								 Map<String, CallDefinitionResponse> callDefinitionResponseMap,
								 GenericCallDefinitionProcessedData genericCDProcessedData,
								 InterfaceTemplate interfaceTemplate, String interfaceName, HttpHeaders headers) {
		try {
			Mono<Boolean> preProcessorMono = interfaceTemplate.getProcessorBean()
					.preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap, headers);
			return preProcessorMono.flatMap(result -> {
				if (!result && genericCDProcessedData.getInterfaceResponse(interfaceName) == null) {
					CustomError error = new CustomError(
							String.valueOf(PRECONDITION_FAILED_RESPONSE_STATUS), PRECONDITION_FAILED_RESPONSE_MSG);
					genericCDProcessedData.setInterfaceResponse(interfaceName, CustomHttpResponse.builder()
							.interfaceKey(interfaceTemplate.getInterfaceKey())
							.error(error)
							.build());
				}
				return Mono.just(result);
			}).onErrorResume(ex -> {
				if (ex instanceof ClientException) {
					ClientException clientException = (ClientException) ex;
					CustomError error = new CustomError(String.valueOf(clientException.getErrorCode().value()), clientException.getMessage());
					genericCDProcessedData.setInterfaceResponse(interfaceName, CustomHttpResponse.builder()
							.interfaceKey(interfaceTemplate.getInterfaceKey())
							.error(error)
							.build());
				} else if (ex instanceof BffException) {
					CustomError error = new CustomError(String.valueOf(GG_NOT_CALL_RESPONSE_STATUS), GG_NOT_CALL_RESPONSE_MSG);
					genericCDProcessedData.setInterfaceResponse(interfaceName, CustomHttpResponse.builder()
							.interfaceKey(interfaceTemplate.getInterfaceKey())
							.error(error)
							.build());
				} else {
					LOGGER.error("interface pre processor error -> {}", interfaceTemplate.getInterfaceKey(), ex);
				}
				return Mono.error(ex);
			});
		} catch (Exception ex) {
			LOGGER.error("interface pre processor error -> {}", interfaceTemplate.getInterfaceKey(), ex);
			return Mono.just(false);
		}
	}

	/**
	 * Run interface custom post processor
	 *
	 * @param validatedRequest          Validated user request data map
	 * @param callDefinitionResponseMap call definition response map
	 * @param interfaceMap              Interface map - key: interface name, value: {@link InterfaceTemplate}
	 * @param genericCDProcessedData    {@link GenericCallDefinitionProcessedData}
	 */
	private Mono<Boolean> runInterfacesPostProcessor(Map<String, CommonRequestModel> validatedRequest,
													 CallDefinitionResponse callDefinitionResponse,
													 Map<String, CallDefinitionResponse> callDefinitionResponseMap,
													 Map<String, InterfaceTemplate> interfaceMap,
													 GenericCallDefinitionProcessedData genericCDProcessedData,
													 HttpHeaders headers) {
		List<Mono<Boolean>> interfaceResultList = new ArrayList<>();
		return Mono.just(interfaceResultList).flatMap(allInterfacesResultMonos-> {
			for (InterfaceTemplate interfaceTemplate : interfaceMap.values()) {
				//if interface's custom post processor exist run it
				if (Objects.nonNull(interfaceTemplate.getProcessorBean())) {
					Mono<Boolean> postProcessorMono = postProcessor(validatedRequest, callDefinitionResponse, callDefinitionResponseMap,
							genericCDProcessedData, interfaceTemplate, headers);
					allInterfacesResultMonos.add(postProcessorMono);
				}
			}
			return Flux.merge(allInterfacesResultMonos).collectList().flatMap((List<Boolean> interfacesStatusList) -> {
				return Mono.just(true);
			});
		});
	}

	/**
	 * Run interface pre processor
	 *
	 * @param validatedRequest          Validated request map
	 * @param callDefinitionResponse    {@link CallDefinitionResponse}
	 * @param callDefinitionResponseMap call definition response map
	 * @param genericCDProcessedData    generically prepared request {@link GenericCallDefinitionProcessedData}
	 * @param interfaceTemplate         Interface template
	 */
	Mono<Boolean> postProcessor(Map<String, CommonRequestModel> validatedRequest,
							   CallDefinitionResponse callDefinitionResponse,
							   Map<String, CallDefinitionResponse> callDefinitionResponseMap,
							   GenericCallDefinitionProcessedData genericCDProcessedData,
							   InterfaceTemplate interfaceTemplate,HttpHeaders headers) {
			try {
				return interfaceTemplate.getProcessorBean()
						.postProcess(validatedRequest, callDefinitionResponse, genericCDProcessedData,
								callDefinitionResponseMap, headers)
						.onErrorResume(ex -> {
							if (ex instanceof BffException) {
								BffException exception = (BffException) ex;
								LOGGER.debug("interface post processor error -> {}, error code -> {}, reason -> {}", interfaceTemplate
										.getInterfaceKey(), exception.getErrorCode().value(), exception.getErrorCode().getReasonPhrase());
							} else {
								LOGGER.error("interface post processor error -> {}", interfaceTemplate.getInterfaceKey(), ex);
							}
							return Mono.just(false);
						});
			} catch (Exception ex) {
				LOGGER.error("interface post processor error -> {}", interfaceTemplate.getInterfaceKey(), ex);
				return Mono.just(false);
			}
	}
}
