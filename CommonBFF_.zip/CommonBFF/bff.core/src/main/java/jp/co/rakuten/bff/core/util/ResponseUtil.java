package jp.co.rakuten.bff.core.util;

import brave.Tracer;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.codec.http.HttpResponseStatus;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.NotAcceptableStatusException;
import org.springframework.web.server.UnsupportedMediaTypeStatusException;
import reactor.core.publisher.Mono;

import javax.validation.ValidationException;
import java.util.HashMap;
import java.util.Map;

/**
 * This util class is responsible to create api responses either success or failure. Should create response from the
 * defined format mentioned in specification.
 */
@Component
public class ResponseUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseUtil.class);
	public static final ObjectMapper objectMapper = new ObjectMapper();

	private final Tracer tracer;

	/**
	 * public constructor
	 *
	 * @param tracer will be auto-configured. tracer is need to attach the tracing ID in response header.
	 */
	@Autowired
	public ResponseUtil(Tracer tracer) {
		this.tracer = tracer;
	}

	/**
	 * Catch the unexpected exception, assuming the whole API is failed, extract bff exception and then build appropriate
	 * responses with error.
	 *
	 * @param throwable  The exception (unexpected or gateway)
	 * @param clientData {@link ClientRequestModel}
	 * @return The ResponseEntity that contains status and response's body
	 */
	public ResponseEntity<Map> catchExceptionAndBuildApiResponse(Throwable throwable, ClientRequestModel clientData) {
		if (throwable instanceof FeatureException) {
			FeatureException featureException = (FeatureException) throwable;
			return buildApiResponse(HttpStatus.BAD_REQUEST,
					BffConstants.UPSTREAM_RESPONSE_FAILURE,
					Map.of(
							featureException.getFeatureName(),
							getFeatureErrorResponseMap(
									featureException.getMessage(),
									featureException.getErrorCode().value()
							)
					), clientData);
		}
		return buildApiErrorResponse(ExceptionUtil.getBffException(throwable));
	}

	/**
	 * Build API error responses from the BFF exception assuming whole api failed.
	 *
	 * @param exception The gateway exception
	 * @return The ResponseEntity that contains status and response's body
	 */
	private ResponseEntity<Map> buildApiErrorResponse(BffException exception) {
		return appendTraceId(ResponseEntity.status(exception.getErrorCode()))
				.body(getApiErrorResponseMap(exception.getMessage(), exception.getErrorCode().value()));
	}

	/**
	 * It will create the defined structured success response model
	 *
	 * @param featureResponses featureResponses
	 * @param clientData       {@link ClientRequestModel}
	 * @return map of response.
	 */
	private ResponseEntity<Map> buildApiResponse(HttpStatus httpStatus, String overallApiStatus,
												 Map<String, Object> featureResponses, ClientRequestModel clientData) {
		Map<String, Object> bodyAndHeader = extractBodyAndHeader(featureResponses, clientData);

		BodyBuilder bodyBuilder = appendTraceId(ResponseEntity.status(httpStatus));
		if (ObjectUtils.isNotEmpty(bodyAndHeader.get(BffConstants.HEADER))) {
			bodyBuilder.headers((HttpHeaders) bodyAndHeader.get(BffConstants.HEADER));
		}
		return bodyBuilder.body(
				Map.of(
						BffConstants.STATUS, overallApiStatus,
						BffConstants.BODY, bodyAndHeader.get(BffConstants.BODY)
				)
		);
	}

	// Not a good practice
	// But have to do it this way as we are not changing method signatures and MAP to POJO/DTOs
	private Map<String, Object> extractBodyAndHeader(Map<String, Object> featureResponses,
													 ClientRequestModel clientData) {
		Map<String, Object> body = new HashMap<>();
		HttpHeaders headers = new HttpHeaders();
		featureResponses.forEach((String s, Object o) -> {
			Map response = (Map) o;
			Map data = (Map) response.get(BffConstants.DATA);
			if (data == null) {
				// empty data, so feature must be failed.
				// filling response/body with errors.
				Map error = (Map) response.get(BffConstants.ERROR);
				if (MapUtils.isEmpty(error)) {
					body.put(s, getFeatureErrorResponseMap(
							BffConstants.UNKNOWN_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()));
				} else {
					body.put(s, Map.of(BffConstants.ERROR, error));
				}
			} else {
				body.put(s, Map.of(BffConstants.DATA, data));
			}
			Map<String, String> header = (Map) response.get(BffConstants.HEADER);
			if (header != null) {
				header.forEach(headers::add);
			}
		});
		// Add cache related headers
		if (ObjectUtils.isNotEmpty(clientData) && ObjectUtils.isNotEmpty(clientData.getHeader()) && StringUtils
				.equalsIgnoreCase(BffConstants.CACHE_HEADER_NO_CACHE, clientData.getHeader().getCacheControl())) {
			headers.setCacheControl(CacheControl.noStore());
		}
		return Map.of(BffConstants.BODY, body, BffConstants.HEADER, headers);
	}

	/**
	 * It will create the defined structured API responses.
	 *
	 * @param featureResponses featureResponses
	 * @param clientData       {@link ClientRequestModel}
	 * @return map of response.
	 */
	private Mono<ResponseEntity<Map>> buildApiResponseMono(HttpStatus httpStatus, String overallApiStatus,
														   Map<String, Object> featureResponses, ClientRequestModel clientData) {
		return Mono.just(buildApiResponse(httpStatus, overallApiStatus, featureResponses, clientData));
	}


	/**
	 * It will create the defined structured API error response model from the exception message, status and response
	 * code.
	 *
	 * @param message error message.
	 * @param code    HTTP-response code.
	 * @return map of response.
	 */
	private static Map<String, Object> getApiErrorResponseMap(String message, int code) {
		return Map.of(BffConstants.STATUS, BffConstants.UPSTREAM_RESPONSE_FAILURE,
				BffConstants.ERROR, Map.of(BffConstants.CODE, code, BffConstants.MESSAGE, message));
	}

	/**
	 * It will create the defined structured error response model from the exception message, status and response code.
	 *
	 * @param httpStatus Http response status
	 * @param message    error message.
	 * @param code       HTTP-response code.
	 * @return map of response.
	 */
	private Mono<ResponseEntity<Map>> getApiErrorResponseMono(HttpStatus httpStatus, String message, int code) {
		return Mono.just(appendTraceId(ResponseEntity.status(httpStatus)).body(getApiErrorResponseMap(message, code)));
	}

	/**
	 * It will create the defined structured Feature error model from the exception message and error code
	 *
	 * @param message error message.
	 * @param code    HTTP-response code.
	 * @return map of response.
	 */
	public static Map<String, Object> getFeatureErrorResponseMap(String message, int code) {
		return Map.of(BffConstants.ERROR, Map.of(BffConstants.CODE, code, BffConstants.MESSAGE, message));
	}

	/**
	 * This method will parse the error message, as sometimes error messages code much more tracing information, that
	 * should not be provided to client. So we will parse that message to ':' as stacktrace information are provided after
	 * the ":" char.
	 *
	 * @param message exception's message.
	 * @return parsed response.
	 */
	private static String parseErrorMessage(String message) {
		if (StringUtils.isBlank(message)) {
			return BffConstants.UNKNOWN_ERROR;
		}
		int index = message.indexOf(';');
		index = index < 0 ? message.length() : index;
		return message.substring(0, index);
	}


	/**
	 * Will prepare the error response model from error map and status code.
	 *
	 * @param errorPropertiesMap error map that is actually provided in global error handler class.
	 * @param statusCode         extracted response code.
	 * @return response body this request.
	 */
	public static Map<String, Object> prepareErrorResponses(Map<String, Object> errorPropertiesMap, int statusCode) {
		String message = parseErrorMessage(
				ObjectUtils.defaultIfNull(errorPropertiesMap.get(BffConstants.MESSAGE),
						ObjectUtils.defaultIfNull(errorPropertiesMap.get(BffConstants.ERROR),
								BffConstants.UNKNOWN_ERROR)).toString());
		return getApiErrorResponseMap(message, statusCode);
	}

	/**
	 * It will try to extract actual response status from the exception class if not found then it will extract status
	 * message from the provided map. This provided map should contain the {@code status} value, other wise treat it as an
	 * {@link HttpStatus#INTERNAL_SERVER_ERROR} = {@code 500} value.
	 *
	 * @param errorPropertiesMap error map that is provided as a parameter in global exception handler.
	 * @param throwable          is the actual exception.
	 * @return status code.
	 */
	public static int extractStatus(Map<String, Object> errorPropertiesMap, Throwable throwable) {
		int errorCode;
		if (throwable instanceof BffException) {
			errorCode = ((BffException) throwable).getErrorCode().value();
		} else if (throwable instanceof ValidationException) {
			errorCode = HttpStatus.BAD_REQUEST.value();
		} else if (throwable instanceof UnsupportedMediaTypeStatusException) {
			errorCode = HttpStatus.BAD_REQUEST.value();
		} else if (throwable instanceof NotAcceptableStatusException) {
			errorCode = HttpStatus.BAD_REQUEST.value();
		} else if (throwable instanceof MethodNotAllowedException) {
			errorCode = HttpStatus.BAD_REQUEST.value();
		} else {
			errorCode = NumberUtils.toInt(errorPropertiesMap.get(BffConstants.STATUS).toString(),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		return errorCode;
	}


	/**
	 * Will prepare the final response as all the requested features data are collected and already validated. This method
	 * expects that the data will be in the given format:
	 * <ul>
	 * <li>
	 * Success:
	 * <pre>
	 *             {
	 *                 "data":{
	 *                    "key1":"value1",
	 *                    "key2":value2
	 *                 },
	 *                 "header":{
	 *                     "h_K":"v1",
	 *                     "h_k_2": "v2"
	 *                 }
	 *             }
	 *         </pre>
	 * </li>
	 * <li>
	 * Failed:
	 * <pre>
	 *                  {
	 * 	                  "error":"{
	 * 	                     "code": http status code,
	 * 	                     "message": "reason/ error description"
	 *                      }
	 *                  }
	 * 	          </pre>
	 * </li>
	 * </ul>
	 *
	 * @param responseMap contains the feature-wise response where feature name is the key and {@code data} or {@code
	 *                    error} as value map.
	 * @param template    {@link ApiTemplate}
	 * @param clientData  {@link ClientRequestModel}
	 * @return final prepared responses for API.
	 */
	public Mono<ResponseEntity<Map>> prepareAPIResponse(Map<String, Object> responseMap, ApiTemplate template
			, ClientRequestModel clientData) {
		boolean isSingleFeaturedApi = template.getFeaturesMap().size() == 1;
		Mono<ResponseEntity<Map>> responseEntityMono = prepareSingleFeaturedEmptyAPIResponse(responseMap,
				isSingleFeaturedApi);
		if (responseEntityMono != null) {
			return responseEntityMono;
		}
		int successCount = 0;
		for (Object featureResponse : responseMap.values()) {
			successCount += isFeatureSuccess(featureResponse) ? 1 : 0;
		}
		return prepareFeaturedResponse(responseMap, isSingleFeaturedApi, successCount, clientData);
	}

	/**
	 * It will log the response error. for 500 status it will log error stack trace.
	 * For other status it will be a simple info log without stack trace.
	 *
	 * @param throwable response error
	 */
	public void logResponseError(Throwable throwable) {
		BffException exception = ExceptionUtil.getBffException(throwable);
		if (HttpStatus.INTERNAL_SERVER_ERROR.value() == exception.getErrorCode().value()) {
			LOGGER.info(MessageConstants.SERVICE_FEATURE_EXCEPTION_MSG, throwable.getMessage(), throwable);
			LOGGER.error(MessageConstants.SERVICE_FEATURE_EXCEPTION_MSG, exception.getMessage(), exception);
		} else {
			LOGGER.info(MessageConstants.SERVICE_FEATURE_EXCEPTION_MSG, exception.getMessage());
		}
	}

	private Mono<ResponseEntity<Map>> prepareSingleFeaturedEmptyAPIResponse(Map<String, Object> responseMap,
																			boolean isSingleFeaturedApi) {
		if (ObjectUtils.isEmpty(responseMap)) {
			if (isSingleFeaturedApi) {
				return getApiErrorResponseMono(HttpStatus.INTERNAL_SERVER_ERROR, BffConstants.NO_DATA_FOUND,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			} else {
				return getApiErrorResponseMono(HttpStatus.MULTI_STATUS, BffConstants.NO_DATA_FOUND,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}
		return null;
	}

	private Mono<ResponseEntity<Map>> prepareFeaturedResponse(Map<String, Object> responseMap,
															  boolean isSingleFeaturedApi, int successCount, ClientRequestModel clientData) {
		if (successCount == responseMap.size()) {
			return buildApiResponseMono(isSingleFeaturedApi ? HttpStatus.OK : HttpStatus.MULTI_STATUS,
					BffConstants.UPSTREAM_RESPONSE_SUCCESS,
					responseMap, clientData);
		} else if (isSingleFeaturedApi) {
			// single feature response (Failed).
			return prepareSingleFeaturedAPIResponse(responseMap, clientData);
		} else {
			// multiple feature response (always partial in-case of failure)
			String overallStatus = successCount == 0 ? BffConstants.UPSTREAM_RESPONSE_FAILURE :
					BffConstants.UPSTREAM_RESPONSE_PARTIAL_FAILURE;
			return buildApiResponseMono(HttpStatus.MULTI_STATUS, overallStatus, responseMap, clientData);
		}
	}

	private Mono<ResponseEntity<Map>> prepareSingleFeaturedAPIResponse(Map<String, Object> responseMap,
																	   ClientRequestModel clientData) {
		Map<String, Object> errorMap;
		int statusCode = HttpResponseStatus.INTERNAL_SERVER_ERROR.code();
		for (Object responses : responseMap.values()) {
			Map<String, Object> singleFeatureResponse = (Map) responses;
			if (singleFeatureResponse != null) {
				errorMap = (Map<String, Object>) singleFeatureResponse.get(BffConstants.ERROR);
				if (errorMap != null) {
					statusCode = getInteger(errorMap.get(BffConstants.CODE), HttpResponseStatus.INTERNAL_SERVER_ERROR.code());
				}
			}
		}
		return buildApiResponseMono(
				HttpStatus.resolve(statusCode),
				BffConstants.UPSTREAM_RESPONSE_FAILURE,
				responseMap,clientData
		);
	}

	/**
	 * This method will check the provided {@code data} is a instance of Map and contains the {@code "data"} as key. If
	 * data key exists then assumes that the feature is success and data is available otherwise feature failed return
	 * false.
	 * <pre>
	 *        {
	 *           "data":{
	 *              "key1":"value1",
	 *              "key2":"value2"
	 *           }
	 *        }
	 * </pre>
	 * Failed:
	 * <pre>
	 *        {
	 *           "error":{
	 *              "code":500,
	 *              "message":"reason error description"
	 *           }
	 *        }
	 * <pre/>
	 *
	 * @param data feature response map. corresponding data should be one of this format: Success:
	 *
	 *
	 * @return either the feature is success or failed.
	 */
	private boolean isFeatureSuccess(Object data) {
		return data instanceof Map && ((Map) data).containsKey(BffConstants.DATA);
	}

	/**
	 * Convert the Object to integer or return the default value.
	 *
	 * <pre>
	 * NucleusUtil.getInteger(null, 0)        = 0
	 * NucleusUtil.getInteger("", 0)          = 0
	 * NucleusUtil.getInteger(" 10 ", 0)      = 0
	 * NucleusUtil.getInteger("10.10", 0)     = 0
	 * NucleusUtil.getInteger(10.10, 0)       = 0
	 * StringUtils.getInteger(10)             = 10
	 * </pre>
	 *
	 * @param value        the Object to check
	 * @param defaultValue the defaultValue to return is exception occur
	 * @return the valid integer or the default value
	 */
	public static Integer getInteger(Object value, Integer defaultValue) {
		if (value != null) {
			try {
				return Integer.parseInt(value.toString());
			} catch (NumberFormatException e) {
				//
			}
		}
		return defaultValue;
	}

	public static CustomHttpResponse copyCustomHttpResponse(CustomHttpResponse existingResponse) {
		return CustomHttpResponse.builder().interfaceKey(existingResponse.getInterfaceKey())
				.bodyMap(DeepCopyUtil.deepCopy(existingResponse.getBodyMap(), Map.class))
				.bodyAsString(existingResponse.getBodyAsString())
				.error(existingResponse.getError()).header(existingResponse.getHeader()).build();
	}

	private BodyBuilder appendTraceId(BodyBuilder responseBuilder) {
		if (tracer.currentSpan() != null) {
			String traceId = tracer.currentSpan().context().traceIdString();
			if (traceId != null) {
				return responseBuilder.header(BffConstants.X_TRACE_ID, traceId);
			}
		}
		return responseBuilder;
	}
}
