package jp.co.rakuten.bff.core.util.inputexchangeutils;

public class IEHankanaToZenkanaUtil extends IEKana {

    protected static final String dakuHankana[] = {
            "ｶﾞ","ｷﾞ","ｸﾞ","ｹﾞ","ｺﾞ",
            "ｻﾞ","ｼﾞ","ｽﾞ","ｾﾞ","ｿﾞ",
            "ﾀﾞ","ﾁﾞ","ﾂﾞ","ﾃﾞ","ﾄﾞ",
            "ﾊﾞ","ﾋﾞ","ﾌﾞ","ﾍﾞ","ﾎﾞ",
            "ｳﾞ"
    };

    protected static final String dakuZenkana[] = {
            "ガ","ギ","グ","ゲ","ゴ",
            "ザ","ジ","ズ","ゼ","ゾ",
            "ダ","ヂ","ヅ","デ","ド",
            "バ","ビ","ブ","ベ","ボ",
            "ヴ"
    };

    protected static final String handakuHankana[] = {
            "ﾊﾟ","ﾋﾟ","ﾌﾟ","ﾍﾟ","ﾎﾟ"
    };

    protected static final String handakuZenkana[] = {
            "パ","ピ","プ","ペ","ポ"
    };

    protected static final String hankana =
            "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"+
                    "ﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔｲﾕｴﾖﾗﾘﾙﾚﾛﾜｲｳｴｵｦﾝ"+
                    "ｧｨｩｪｫｬｭｮｯ";

    protected static final String zenkana =
            "アイウエオカキクケコサシスセソタチツテトナニヌネノ"+
                    "ハヒフヘホマミムメモヤイユエヨラリルレロワイウエオヲン"+
                    "ァィゥェォャュョッ";

    protected static final String hankanapunc =
            "ﾞﾟ｡｢｣､･ｰ";

    protected static final String zenkanapunc =
            "゛゜。「」、・ー";


    /**
     * コンストラクタ
     */
    public IEHankanaToZenkanaUtil() {
        ;
    }

    /**
     * コンストラクタ
     */
    public IEHankanaToZenkanaUtil(String key) {
        super(key);
    }

    /**
     * 半角カタカナ ---> 全角カタカナ変換
     * @param src (String)
     * @return 変換後文字列 (String)
     */
    public static String exec(String src) {

        String ret = src;

        // 濁音変換
        for (int i = 0 ; i < dakuHankana.length ; i++){
            ret = ret.replace(dakuHankana[i], dakuZenkana[i]);
        }

        // 半濁音変換
        for (int i = 0 ; i < handakuHankana.length ; i++){
            ret = ret.replace(handakuHankana[i], handakuZenkana[i]);
        }

        // 清音変換
        for (int i = 0 ; i < hankana.length();i++){
            ret = ret.replace(hankana.charAt(i), zenkana.charAt(i));
        }

        // 濁点・半濁点、長音記号、カギ括弧など変換
        for (int i = 0 ; i < hankanapunc.length();i++){
            ret = ret.replace(hankanapunc.charAt(i),zenkanapunc.charAt(i));
        }

        return ret;
    }

}