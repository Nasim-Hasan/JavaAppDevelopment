package jp.co.rakuten.bff.core.event;

import jp.co.rakuten.bff.core.config.InterfaceConfig;
import org.springframework.context.ApplicationEvent;

import java.util.Collection;

/**
 * This event is sent when the configuration have been loaded or reloaded.
 *
 * @author tony.rouillard
 */
public class OnInterfacesLoadedEvent extends ApplicationEvent {
	private static final long serialVersionUID = 1L;

	/** List of interfaces config recently updated */
	private transient Collection<InterfaceConfig> interfaceConfigs;

	/**
	 * Event triggered when the interfaces are (re)loaded
	 *
	 * @param source           The source
	 * @param interfaceConfigs The list of interfaces config recently updated
	 */
	public OnInterfacesLoadedEvent(Object source, Collection<InterfaceConfig> interfaceConfigs) {
		super(source);
		this.interfaceConfigs = interfaceConfigs;
	}

	/**
	 * Return the list of interfaces config recently updated.
	 *
	 * @return the list of interfaces config
	 */
	public Collection<InterfaceConfig> getInterfaceConfigs() {
		return interfaceConfigs;
	}
}
