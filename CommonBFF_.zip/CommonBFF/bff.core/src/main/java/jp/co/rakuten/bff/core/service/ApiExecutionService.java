package jp.co.rakuten.bff.core.service;

import java.util.Map;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

/**
 * Responsible to execute requested api and generate responses by filtering fetched responses.
 *
 * @see <a href=
 * "https://confluence.rakuten-it.com/confluence/display/ECSG/%5BDraft%5D%5BFrameworkComponent%5DApiExecutionService">
 * API execution Service Design Doc
 * </a>
 */
public interface ApiExecutionService {
	/**
	 * Will execute user requested api and prepare final responses containing overall status of the api.
	 *
	 * @param clientData will contain all of the user's clientData such as
	 *                   {@code service}, {@code operation}, {@code header}, {@code parameters} etc.
	 * @return prepared api response which contain overall status and feature specific responses.
	 */
	Mono<ResponseEntity<Map>> executeApi(ClientRequestModel clientData);
}
