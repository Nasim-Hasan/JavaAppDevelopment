package jp.co.rakuten.bff.core.processors;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Feature business specific custom processor should implement this interface.
 */
@FunctionalInterface
public interface FeatureProcessor {
	/**
	 * Business specific feature post processor - will check/traverse upstream response
	 * and prepare api specific response
	 *
	 * @param validatedClientData       validated client or default data
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionResponseMap It holds call definition response.
	 * @return FeaturePostProcessorResponse Feature's processed data as mono.
	 */
	Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
												   FeatureTemplate featureTemplate,
												   Map<String, CallDefinitionResponse> callDefinitionResponseMap);
}
