package jp.co.rakuten.bff.core.controller;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Custom global error handler for webflux based rest-controller.
 * This {@link ApiExceptionHandler} class {@link Order} value must be set less than -1
 * otherwise it will not be executed because of priority issue.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApiExceptionHandler extends AbstractErrorWebExceptionHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiExceptionHandler.class);

	/**
	 * Default constructor for global custom error handler.
	 *
	 * @param serverCodecConfigurer Extension of CodecConfigurer for HTTP message reader and writer options relevant on
	 *                              the server side
	 * @param errorAttributes       Provides access to error attributes which can be logged or presented to the user
	 * @param resourceProperties    Properties used to configure resource handling.
	 * @param applicationContext    Central interface to provide configuration for an application.
	 */
	@Autowired
	public ApiExceptionHandler(ServerCodecConfigurer serverCodecConfigurer, ErrorAttributes errorAttributes,
							   ResourceProperties resourceProperties, ApplicationContext applicationContext) {
		super(errorAttributes, resourceProperties, applicationContext);
		super.setMessageReaders(serverCodecConfigurer.getReaders());
		super.setMessageWriters(serverCodecConfigurer.getWriters());
	}

	/**
	 * Create a {@link RouterFunction} that can route and handle errors as JSON responses
	 * or HTML views.
	 * <p>
	 * If the returned {@link RouterFunction} doesn't route to a {@code HandlerFunction},
	 * the original exception is propagated in the pipeline and can be processed by other
	 * {@link org.springframework.web.server.WebExceptionHandler}s.
	 * @param errorAttributes the {@code ErrorAttributes} instance to use to extract error
	 * information
	 * @return a {@link RouterFunction} that routes and handles errors
	 */
	@Override
	protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes errorAttributes) {
		return RouterFunctions.route(RequestPredicates.all(), this::renderErrorResponse);
	}

	/**
	 * Responsible to prepare global error response. it will render responses from actual exception
	 * and parse and create appropriate message and code.
	 *
	 * @param request to extract the ErrorAttributes
	 * @return final {@link Mono<ServerResponse>} error map.
	 */
	private Mono<ServerResponse> renderErrorResponse(ServerRequest request) {
		Map<String, Object> errorPropertiesMap = getErrorAttributes(request, false);
		Throwable t = getError(request);
		LOGGER.debug(MessageConstants.CONTROLLER_EXCEPTION_INFO_MSG, errorPropertiesMap, t);
		int statusCode = ResponseUtil.extractStatus(errorPropertiesMap, t);
		Map<String, Object> responses = ResponseUtil.prepareErrorResponses(errorPropertiesMap, statusCode);
		LOGGER.info(MessageConstants.CONTROLLER_ERROR_RESPONSE_INFO_MSG, errorPropertiesMap.get("status"), responses);

		return ServerResponse.status(statusCode)
				.contentType(MediaType.APPLICATION_JSON)
				.bodyValue(responses);
	}
}
