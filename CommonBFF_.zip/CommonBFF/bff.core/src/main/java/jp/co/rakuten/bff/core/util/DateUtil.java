package jp.co.rakuten.bff.core.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Date utils class
 */
public class DateUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);
	private static final String RESPONSE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	public static final String RESPONSE_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+09:00'";
	public static final String UTC_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String DATE_FORMAT_WITH_MILLISEC = "yyyy-MM-dd'T'HH:mm:ss.SSS'+09:00'";
	private static final String TIME_ZONE_REGEX = "(['])([+-])(\\d{2})[:]?(\\d{2})(['])$";
	private static final Pattern TIME_ZONE_PATTERN = Pattern.compile(TIME_ZONE_REGEX);
	public static final String ZONE_ID_TOKYO = "GMT+09:00";
	public static final String ZONE_ID_UTC = "GMT+00:00";
	private DateUtil() {
	}

	/**
	 * Convert string to {@link Date} jp Date
	 *
	 * @param dateString Date string
	 * @return {@link Date}
	 */
	public static Date convertToDate(String dateString, String dateInputFormat) {
		if (StringUtils.isEmpty(dateString) || StringUtils.isEmpty(dateInputFormat)) {
			return null;
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(dateInputFormat);
			String inputZoneId = parseTimeZone(dateInputFormat);
			sdf.setTimeZone(TimeZone.getTimeZone(inputZoneId));
			long inputDateTimeInMillis = sdf.parse(dateString).getTime();
			return DateUtil.parse(inputDateTimeInMillis, TimeZone.getDefault().getID(), ZONE_ID_TOKYO);
		} catch (Exception e) {
			LOGGER.error("Date conversion failed. dateString - {}, dateFormat - {}", dateString, dateInputFormat);
			return null;
		}
	}

	/**
	 * Convert string to {@link Date} jp Date
	 *
	 * @param dateString Date string
	 * @return {@link Date}
	 */
	public static Date convertToUTCDate(String dateString, String dateInputFormat) {
		if (StringUtils.isEmpty(dateString) || StringUtils.isEmpty(dateInputFormat)) {
			return null;
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(dateInputFormat);
			String inputZoneId = parseTimeZone(dateInputFormat);
			sdf.setTimeZone(TimeZone.getTimeZone(inputZoneId));
			long inputDateTimeInMillis = sdf.parse(dateString).getTime();
			return DateUtil.parse(inputDateTimeInMillis, TimeZone.getDefault().getID(), ZONE_ID_UTC);
		} catch (Exception e) {
			LOGGER.error("Date conversion failed. dateString - {}, dateFormat - {}", dateString, dateInputFormat);
			return null;
		}
	}

	private static String parseTimeZone(String input) {
		if (input.endsWith("'Z'")) {
			input = input.replaceAll("'Z'", "'+00:00'");
		}
		Matcher matcher = TIME_ZONE_PATTERN.matcher(input);
		String timeZoneString = ZONE_ID_TOKYO;
		if (matcher.find()) {
			String sign = matcher.group(2);
			String hours = matcher.group(3);
			String minutes = matcher.group(4);
			timeZoneString = "GMT" + sign + hours + ":" + minutes;
		}
		return timeZoneString;
	}

	/**
	 * Check current time in between start date and end date
	 *
	 * @param startDate Start jst date
	 * @param endDate   End jst date
	 * @return boolean
	 */
	public static boolean isInBetweenCurrentTime(Date startDate, Date endDate) {
		return isBeforeCurrentTime(startDate) && isAfterCurrentTime(endDate);
	}

	/**
	 * validate endDate
	 *
	 * @param startDate   date to be formatted
	 * @param endDate Date format
	 * @return boolean
	 */
	public static boolean isValidRange(Date startDate, Date endDate) {
		if(endDate == null || startDate == null) {
			return false;
		}
		return endDate.compareTo(startDate) >= 0;
	}

	/**
	 * to check startDate with current jst date
	 *
	 * @param startDate   jst date to check
	 * @return boolean
	 */
	public static boolean isBeforeCurrentTime(Date startDate) {
		boolean result = false;
		if (Objects.isNull(startDate)) {
			return result;
		}
		Date currentDate = getCurrentDate();
		if(null != currentDate) {
			result = currentDate.compareTo(startDate) >= 0;
		}
		return result;
	}

	/**
	 * to check endDate with current jst date
	 *
	 * @param endDate   jst date to check
	 * @return boolean
	 */
	public static boolean isAfterCurrentTime(Date endDate) {
		boolean result = false;
		if (Objects.isNull(endDate)) {
			return result;
		}
		Date currentDate = getCurrentDate();
		if(null != currentDate) {
			result = currentDate.compareTo(endDate) <= 0;
		}
		return result;
	}

	/**
	 * format date to string in system time zone
	 *
	 * @param date   date to be formatted
	 * @param format Date format
	 * @return String
	 */
	public static String format(Date date, String format) {
		if (date == null || StringUtils.isBlank(format)) {
			return null;
		}
		return new SimpleDateFormat(format).format(date);
	}

	/**
	 * format date to string in system time zone
	 *
	 * @param date   date to be formatted
	 * @param inputFormat Date format
	 * @param outputFormat Date format
	 * @return String
	 */
	public static String format(String date, String inputFormat, String outputFormat) {
		if (date == null || StringUtils.isBlank(inputFormat)) {
			return null;
		}
		String formattedDate = null;
		try {
			SimpleDateFormat inputFormatter = new SimpleDateFormat(inputFormat);
			Date inputDate = inputFormatter.parse(date);
			SimpleDateFormat outFormatter = new SimpleDateFormat(outputFormat);
			formattedDate = outFormatter.format(inputDate);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing date.  dateString - {}, inputFormat - {} outputFormat {}", date, inputFormat, outputFormat, e);
		}
		return formattedDate;
	}

	/**
	 * convert milliseconds to date string of the outputTimeZoneId
	 * use this method very carefully because the milliseconds and format has a relationship with timezone.
	 * Make sure the milliseconds has been created from proper time zoned date
	 * in which timezone the string date is expected.
	 * @param outputFormat Date format
	 * @param milliSeconds   time in milliseconds
	 * @param outputTimeZoneId   output zone id
	 * @return String
	 */
	public static String format(long milliSeconds, String outputFormat, String inputZoneId, String outputTimeZoneId) {
		if (StringUtils.isBlank(outputFormat)) {
			return null;
		}
		String date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(outputFormat);
			String sysZoneName = getZoneName(TimeZone.getDefault());
			String inputZoneName = getZoneName(TimeZone.getTimeZone(inputZoneId));
			TimeZone outputZone = TimeZone.getTimeZone(outputTimeZoneId);
			String outputZoneName =getZoneName(outputZone);
			if (!inputZoneName.equals(outputZoneName) && sysZoneName.equals(inputZoneName) && !sysZoneName.equals(outputZoneName)) {
				sdf.setTimeZone(outputZone); //useCase2
			} else if (!inputZoneName.equals(outputZoneName) && !sysZoneName.equals(inputZoneName) && sysZoneName.equals(outputZoneName)) {
				sdf.setTimeZone(outputZone); //useCase3
			} else if (!inputZoneName.equals(outputZoneName) && !sysZoneName.equals(inputZoneName) && !sysZoneName.equals(outputZoneName)) {
				sdf.setTimeZone(outputZone);
			}
			date = sdf.format(milliSeconds);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing date.  milliSeconds - {}, inputFormat - {} outputFormat {}", milliSeconds, outputFormat, outputTimeZoneId, e);
		}
		return date;
	}

	private static String getZoneName(TimeZone zone) {
		if ("UTC".equals(zone.getID())) {
			return ZONE_ID_UTC;
		} else if ("Asia/Tokyo".equals(zone.getID())) {
			return ZONE_ID_TOKYO;
		} else if (zone.getID().contains("GMT")){
			return zone.getID();
		} else {
			return zone.getDisplayName();
		}
	}

	/**
	 * convert milliseconds to Date object of outputTimeZoneId
	 * remember the milliseconds that is given will be converted to date in implicit zone as specified in format
	 * argument
	 * @param outputTimeZoneId output time zone id
	 * @param milliSeconds   time in milliseconds
	 * @return Date
	 */
	public static Date parse(long milliSeconds, String inputZoneId, String outputTimeZoneId) {
		Date date = null;
		try {
			String dateStr = DateUtil.format(milliSeconds, RESPONSE_FORMAT, inputZoneId, outputTimeZoneId);
			SimpleDateFormat sdfParser = new SimpleDateFormat(RESPONSE_FORMAT);
			date = sdfParser.parse(dateStr);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing date.  milliSeconds - {}, outputTimeZoneId {}", milliSeconds, outputTimeZoneId, e);
		}
		return date;
	}

	/**
	 * Returns current date in GMT+09:00 time zone
	 *
	 * @return Date
	 */
	public static Date getCurrentDate() {
		return parse(System.currentTimeMillis(), TimeZone.getDefault().getID(), ZONE_ID_TOKYO);
	}

	/**
	 * Returns current time in millis in GMT+09:00 time zone
	 *
	 * @return long
	 */
	public static long getCurrentTimeMillis() {
		return getCurrentDate().getTime();
	}
}