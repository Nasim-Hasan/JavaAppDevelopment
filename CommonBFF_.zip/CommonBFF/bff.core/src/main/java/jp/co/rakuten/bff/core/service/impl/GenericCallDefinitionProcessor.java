package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.util.DeepCopyUtil;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.*;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_API_REPO_PARAM_KEY_MISSING;

/**
 * Generic call definition processor generically parse supplied interface template and collect
 * each parameter value from validated request from feature wise parameter map.
 */
@Component
public class GenericCallDefinitionProcessor {

	private Environment env;

	/**
	 * Default constructor
	 *
	 * @param env {@link Environment}
	 */
	@Autowired
	public GenericCallDefinitionProcessor(Environment env) {
		this.env = env;
	}

	/**
	 * Prepare supplied interface's parameter list ( generic gateway format ) from validated request
	 * and {@link InterfaceTemplate} list
	 *
	 * @param interfaceMap     Map of {@link InterfaceTemplate}
	 * @param validatedRequest validatedRequest Validated request map - feature name as key and
	 *                         {@link CommonRequestModel} as value
	 * @param featureList      List of {@link FeatureTemplate}
	 * @return GenericCallDefinitionProcessedData - {@link GenericCallDefinitionProcessedData}
	 *
	 *
	 */
	public GenericCallDefinitionProcessedData preProcess(Map<String, InterfaceTemplate> interfaceMap,
														 Map<String, CommonRequestModel> validatedRequest,
														 List<FeatureTemplate> featureList) {
		return preProcess(interfaceMap, validatedRequest, featureList, null);
	}
	public GenericCallDefinitionProcessedData preProcess(Map<String, InterfaceTemplate> interfaceMap,
														 Map<String, CommonRequestModel> validatedRequest,
														 List<FeatureTemplate> featureList, Map<String,?> mockConnections) {

		GenericCallDefinitionProcessedData genericCDProcessedData =
				new GenericCallDefinitionProcessedData();

		Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
		Map<String, Map<String, Object>> preparedRequestMap = new HashMap<>();
		interfaceMap.forEach((String interfaceName, InterfaceTemplate interfaceTemplate) -> {
			Map<String, Object> requestMap = new HashMap<>();
			String interfaceKey = interfaceTemplate.getInterfaceKey();
			requestMap.put(INTERFACE_KEY,interfaceKey);
			String requestId = UUID.randomUUID().toString();
			requestMap.put(REQUEST_ID, requestId);

			setParamsFromModelToRequestMap(interfaceTemplate, validatedRequest, featureList, requestMap);
			if(MapUtils.isNotEmpty(mockConnections)) {
				Boolean isMockEnabled = Boolean.parseBoolean(env.getProperty(BFF_MOCKING_ENABLED,"false"));
				if (isMockEnabled && mockConnections.containsKey(interfaceKey)) {
					Map<String, ?> interfaceMock = (Map<String, ?>)mockConnections.get(interfaceKey);
					if (interfaceMock.containsKey(CONNECTION)) {
						requestMap.put(CONNECTION, interfaceMock.get(CONNECTION));
					}
				}
			}

			preparedRequestMap.put(requestId, requestMap);
			if (interfaceToRequestIdMap.containsKey(interfaceName)) {
				interfaceToRequestIdMap.get(interfaceName).add(requestId);
			} else {
				List<String> requestIdList = new ArrayList<>();
				requestIdList.add(requestId);
				interfaceToRequestIdMap.put(interfaceName, requestIdList);
			}
		});

		genericCDProcessedData.setInterfaceToRequestIdMap(interfaceToRequestIdMap);
		genericCDProcessedData.setPreparedRequest(preparedRequestMap);

		return genericCDProcessedData;
	}

	/**
	 * Set interface specific parameter (bodyParameters, headerParameters, urlParameters) for generic gateway
	 * from validated request
	 *
	 * @param interfaceTemplate {@link InterfaceTemplate}
	 * @param validatedRequest  validatedRequest Validated request map - feature name as key and
	 *                          {@link CommonRequestModel} as value
	 * @param featureList       List of {@link FeatureTemplate}
	 * @param requestMap        key - param type (bodyParameters, headerParameters, urlParameters)<br/>
	 *                          value - client provided data
	 */
	void setParamsFromModelToRequestMap(InterfaceTemplate interfaceTemplate,
												Map<String, CommonRequestModel> validatedRequest,
												List<FeatureTemplate> featureList,
												Map<String, Object> requestMap) {

		Map<String, Object> allParamsMap = getAllParamsForInterface(interfaceTemplate, validatedRequest, featureList);
		// set body parameter
		Map<String, Object> bodyParameter = processParameter(interfaceTemplate.getBodyParams(), allParamsMap);
		if (!CollectionUtils.isEmpty(bodyParameter)) {
			requestMap.put(BODY_PARAMETERS, bodyParameter);
		}

		processBody(interfaceTemplate, allParamsMap, requestMap);

		// set header
		Map<String, Object> headerMap = processParameter(interfaceTemplate.getHeaders(),
				allParamsMap);
		if (!CollectionUtils.isEmpty(headerMap)) {
			requestMap.put(HEADER_PARAMETERS, headerMap);
		}

		// set url parameter
		Map<String, Object> urlParameter = processParameter(interfaceTemplate.getUrlParams(),
				allParamsMap);
		if (!CollectionUtils.isEmpty(urlParameter)) {
			requestMap.put(URL_PARAMETERS, urlParameter);
		}

		// set meta parameters
		Map<String, Object> metaParameters = processParameter(interfaceTemplate.getMetaParameters(),
				allParamsMap);
		if (!CollectionUtils.isEmpty(metaParameters)) {
			requestMap.put(META_PARAMETERS, metaParameters);
		}

		// set parameterLink list
		if (!CollectionUtils.isEmpty(interfaceTemplate.getParameterLinks())) {
			requestMap.put(PARAMETER_LINKS, DeepCopyUtil.deepCopy(interfaceTemplate.getParameterLinks(), List.class));
		}

		// set dependency condition list
		if (!CollectionUtils.isEmpty(interfaceTemplate.getDependencyCondition())) {
			requestMap.put(DEPENDENCY_CONDITIONS,
			               DeepCopyUtil.deepCopy(interfaceTemplate.getDependencyCondition(), List.class));
		}

		// set response filter
		if (!CollectionUtils.isEmpty(interfaceTemplate.getResponseFilters())) {
			requestMap.put(RESPONSE_FILTERS, DeepCopyUtil.deepCopy(interfaceTemplate.getResponseFilters(), List.class));
		}
	}

	private Map<String, Object> getAllParamsForInterface(InterfaceTemplate interfaceTemplate,
														 Map<String, CommonRequestModel> validatedRequest,
														 List<FeatureTemplate> featureList) {
		List<String> featureNameList = getFeatureName(interfaceTemplate, featureList);
		Map<String, Object> allParamsMap = new HashMap<>();
		for (String featureName:featureNameList) {
			CommonRequestModel commonRequestModel = validatedRequest.get(featureName);
			if (Objects.isNull(commonRequestModel)) {
				continue;
			}

			if (MapUtils.isNotEmpty(commonRequestModel.getParams())) {
				allParamsMap.putAll(commonRequestModel.getParams());
			}

			if (MapUtils.isNotEmpty(commonRequestModel.getHeaders())) {
				allParamsMap.putAll(commonRequestModel.getHeaders());
			}
		}
		return allParamsMap;
	}

	private void processBody(InterfaceTemplate interfaceTemplate,
							 Map<String, Object> allParamsMap,
							 Map<String, Object> requestMap) {

		if (Objects.isNull(interfaceTemplate.getBody())) {
			return;
		}

		Map<String, Object> bodyParameter = processParameter(interfaceTemplate.getBody().getParams(), allParamsMap);
		Map<String, String> parameterPath = getParameterPathMap(interfaceTemplate.getBody().getParams());
		if (MapUtils.isNotEmpty(bodyParameter)) {
			Map<String, Object> templateMap =
					DeepCopyUtil.deepCopy(interfaceTemplate.getBody().getTemplate(), Map.class);
			buildBody(templateMap, bodyParameter, parameterPath);
			requestMap.put(BODY, templateMap);
		}
	}

	private void buildBody(Map<String, Object> template, Map<String, Object> bodyParameter,
						   Map<String, String> parameterPath) {
		parameterPath.forEach((param, path) -> MapUtil.putValue(template, path, bodyParameter.get(param)));
	}

	private List<String> getFeatureName(InterfaceTemplate interfaceTemplate,
										List<FeatureTemplate> featureList) {
		List<String> featureNameList=new ArrayList<>();
		for (FeatureTemplate featureTemplate : featureList) {
			for (InterfaceTemplate interfaceTemplate1 : featureTemplate.getInterfacesMap().values()) {
				if (interfaceTemplate.getInterfaceKey().equals(interfaceTemplate1.getInterfaceKey())) {
					featureNameList.add(featureTemplate.getName());
				}
			}
		}

		return featureNameList;
	}

	/**
	 * prepare body/url/header parameter based on client request and call definition config.
	 *
	 * @param parameterList interface parameter list
	 * @return Map<String, Object> - parameter name and value accordingly
	 */
	private Map<String, Object> processParameter(List<Map<String, Object>> parameterList,
												 Map<String, Object> params) {

		if (CollectionUtils.isEmpty(params)) {
			return new HashMap<>();
		}

		Map<String, Object> processedParameterMap = new HashMap<>();
		for (Map<String, Object> parameter : parameterList) {
			String name = (String) parameter.get(BffConstants.INTERFACE_PARAM_NAME);
			if (Objects.isNull(name)) {
				throw SystemException.create(SystemErrorEnum.INTERNAL, SERVICE_API_REPO_PARAM_KEY_MISSING);
			}

			//if property type existz
			if (isPropertyType(parameter)) {
				setPropertyValue(parameter, processedParameterMap, name, params);
			} else {
				String source = (String) parameter.get(BffConstants.INTERFACE_PARAM_SOURCE);
				String key = Objects.nonNull(source) ? source : name;
				Object value = params.get(key);
				if (Objects.nonNull(value)) {
					processedParameterMap.put(name, value);
				}
			}
		}

		return processedParameterMap;
	}

	private Map<String, String> getParameterPathMap(List<Map<String, Object>> parameterList) {
		Map<String, String> parameterPathMap = new HashMap<>();
		parameterList.stream()
				.filter(parameter -> !ObjectUtils.isEmpty(parameter.get(BffConstants.INTERFACE_PARAM_NAME)))
				.forEach((Map<String, Object> parameter) -> {
					String name = (String) parameter.get(BffConstants.INTERFACE_PARAM_NAME);
					String path = (String) parameter.get(BffConstants.INTERFACE_PARAM_PATH);
					if (!StringUtils.isEmpty(path)) {
						parameterPathMap.put(name, path);
					}
				});
		return parameterPathMap;
	}

	/**
	 * Check this parameter is property type or not
	 *
	 * @param parameter parameter map
	 * @return boolean true - if property, false - if not property
	 */
	private boolean isPropertyType(Map<String, Object> parameter) {
		String paramType = (String) parameter.get(BffConstants.INTERFACE_PARAM_TYPE_KEY);
		return Objects.nonNull(paramType) && paramType.equalsIgnoreCase(BffConstants.INTERFACE_PARAM_TYPE_PROPERTY);
	}

	/**
	 * Set property value
	 *
	 * @param parameter             parameter map
	 * @param processedParameterMap processed parameter map where property value will be added
	 * @param name                  parameter key name
	 */
	private void setPropertyValue(Map<String, Object> parameter, Map<String, Object> processedParameterMap,
								  String name, Map<String, Object> params) {
		String paramKey = (String) parameter.get(BffConstants.INTERFACE_PARAM_PROPERTY_DYNAMIC_PARAM_KEY);
		String propKeyPrefix = (String) parameter.get(BffConstants.INTERFACE_PARAM_PROPERTY_KEY_PREFIX);
		String propKeySuffix = (String) parameter.get(BffConstants.INTERFACE_PARAM_PROPERTY_KEY_SUFFIX);
		String propertyKey = (String) parameter.get(BffConstants.INTERFACE_PARAM_PROPERTY_KEY);

		if (StringUtils.isNotBlank(paramKey) && !ObjectUtils.isEmpty(params.get(paramKey))) {
			if (StringUtils.isNotBlank(propKeyPrefix) && StringUtils.isNotBlank(propKeySuffix)) {
				propertyKey = propKeyPrefix + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT +
						params.get(paramKey) + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT + propKeySuffix;
			} else if (StringUtils.isNotBlank(propKeyPrefix)) {
				propertyKey = propKeyPrefix + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT + params.get(paramKey);
			} else if (StringUtils.isNotBlank(propKeySuffix)) {
				propertyKey = params.get(paramKey) + BffConstants.INTERFACE_PARAM_PROPERTY_KEY_DOT + propKeySuffix;
			}
		}

		if (Objects.nonNull(propertyKey)) {
			String propertyValue = env.getProperty(propertyKey);
			if (Objects.isNull(propertyValue)) {
				processedParameterMap.put(name, parameter.get(BffConstants.INTERFACE_PARAM_PROPERTY_DEFAULT));
			} else {
				processedParameterMap.put(name, propertyValue);
			}
		}
	}
}
