package jp.co.rakuten.bff.core.service;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * This component do 3 major task.<br/>
 * <ul>
 *     <li>Create call definition dependency chain.</li>
 *     <li>Feature wise call those call definition based on dependency.</li>
 *     <li>Run each feature's post processor to create feature wise final response from those feature's
 *     call definition response.</li>
 * </ul>
 */
public interface FeatureExecutionService {

	/**
	 * Prepare call definition mono dependency and feature wise execute those mono. After all call definition
	 * execution it will call feature post processor.
	 *
	 * @param clientRequestModel contains user requested data.
	 * @param executionModel     call definition to feature map, requested feature list, call definition list
	 *                           and interface set given here
	 * @param validatedRequest   Validated request - feature name as key and {@link CommonRequestModel} as value
	 * @param apiTemplate        API config file template
	 * @return Response mono map - feature name as key and feature response as value
	 */
	Mono<Map<String, Object>> executeFeatures(ClientRequestModel clientRequestModel, ExecutionModel executionModel,
											  Map<String,
													  CommonRequestModel> validatedRequest, ApiTemplate apiTemplate);
}
