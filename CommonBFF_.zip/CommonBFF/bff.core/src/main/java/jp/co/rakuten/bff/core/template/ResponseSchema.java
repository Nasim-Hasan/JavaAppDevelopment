package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Template Model Class
 * <br>
 * intended for mapping Response schema details for a feature
 */
public class ResponseSchema {
	@JsonProperty("fastforward")
	private Boolean fastForward;
	private List<CommonSchema> parameters = new ArrayList<>();
	private List<CommonSchema> headers = new ArrayList<>();


	public Boolean getFastForward() {
		return fastForward;
	}

	public void setFastForward(Boolean fastForward) {
		this.fastForward = fastForward;
	}

	public List<CommonSchema> getParameters() {
		return this.parameters;
	}

	public void setParameters(List<CommonSchema> parameters) {
		this.parameters = parameters;
	}

	public List<CommonSchema> getHeaders() {
		return headers;
	}

	public void setHeaders(List<CommonSchema> headers) {
		this.headers = headers;
	}

	@Override
	public String toString() {
		return "ResponseSchema{" +
				"fastForward=" + fastForward +
				", parameters=" + parameters +
				", headers=" + headers +
				'}';
	}
}
