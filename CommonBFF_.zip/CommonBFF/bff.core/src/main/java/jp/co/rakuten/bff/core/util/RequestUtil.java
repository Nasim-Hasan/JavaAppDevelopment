package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import org.springframework.util.ObjectUtils;

import java.util.Collection;
import java.util.List;

/**
 * This utility class should contain all the helper methods related to user request.
 */
public class RequestUtil {

	private static final String DELIMITER = ".";

	private RequestUtil() {
		// kept empty
	}

	/**
	 * This utility method will be used to create the api key globally. api key should maintain this following format:<br>
	 * {@code [service].[operation].[version]}<br> sample: {@code shopbookmark.list.v1}
	 *
	 * @param clientRequestModel contains the user requested datas.
	 * @return apiKey in this format: {@code [service].[operation].[version]}
	 */
	public static String buildAPIKey(ClientRequestModel clientRequestModel) {
		return clientRequestModel.getService() + DELIMITER + clientRequestModel.getOperation() + DELIMITER +
				clientRequestModel.getVersion();
	}

	/**
	 * This method generates the hashCode by enabling only the bits in a long which indexs are contains in the provided
	 * {@link java.util.List<Integer>}. We assumed that only the range of each element must not exceed 62.
	 *
	 * @param ids contains the index id which should be enabled.
	 * @return generated hashcode.
	 */
	public static long getHashCode(Collection<Integer> ids) {
		if (ObjectUtils.isEmpty(ids)) {
			return 0;
		}
		long hashCode = 0;
		for (Integer id : ids) {
			hashCode |= (1L << (id - 1));
		}
		return hashCode;
	}

	/**
	 * Responsible to check, whether a flied is present in the provided CommonRequestModel
	 *
	 * @param fieldNames the provided fileds, which will be searched in the data
	 * @param data {@link CommonRequestModel}
	 * @return the new boolean
	 * */
	public static boolean isIncluded(List<String> fieldNames, CommonRequestModel data) {
		for (String fieldName : fieldNames) {
			if (isIncluded(fieldName, data)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Responsible to check, whether a flied is present in the provided CommonRequestModel
	 *
	 * @param fieldName the provided filed, which will be searched in the data
	 * @param data {@link CommonRequestModel}
	 * @return the new boolean
	 * */
	public static boolean isIncluded(String fieldName, CommonRequestModel data) {
		boolean included = true;

		if (!ObjectUtils.isEmpty(data.getInclude())) {
			included = data.getInclude().stream()
					.anyMatch(fields -> fields.equals(fieldName) || fieldName.startsWith(fields + ".") || fields
							.startsWith(fieldName + "."));
		} else if (!ObjectUtils.isEmpty(data.getExclude())) {
			included = data.getExclude().stream()
					.noneMatch(fields -> fields.equals(fieldName) || fieldName.startsWith(fields + "."));
		}
		return included;
	}
}
