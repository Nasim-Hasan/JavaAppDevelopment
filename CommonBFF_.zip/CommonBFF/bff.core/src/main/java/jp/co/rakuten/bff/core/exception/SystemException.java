package jp.co.rakuten.bff.core.exception;


import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;

/**
 * <p>This Exception class is responsible for propagating all the errors related to
 * system failure such as:
 * <ul>
 *     <li>system_error<li/>
 *     <li>short_circuited<li/>
 * </ul>
 * </p>
 */
public class SystemException extends BffException {

	/**
	 * Constructor with cause exception
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param ex        The cause exception
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 */
	private SystemException(SystemErrorEnum errorEnum, Throwable ex, String message, Object... params) {
		super(errorEnum.getErrorCode(), errorEnum.getErrorType(), ex, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 * @return The system exception
	 */
	public static SystemException create(SystemErrorEnum errorEnum, String message, Object... params) {
		return new SystemException(errorEnum, null, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param ex        The cause exception
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 * @return The system exception
	 */
	public static SystemException create(SystemErrorEnum errorEnum, Throwable ex, String message, Object... params) {
		return new SystemException(errorEnum, ex, message, params);
	}
}
