package jp.co.rakuten.bff.core.cache;

import io.micrometer.core.instrument.util.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.time.Duration;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * Helper class for CacheManager that validates and loads cache
 * configuration from CacheConfiguration map for cache manager's
 * convenience of use
 */
public class IchibaCacheConfiguration {
	private CacheTypeEnum cacheType = CacheTypeEnum.LOCAL;
	private boolean enabled;
	private Duration localTimeout = Duration.ofMillis(DEFAULT_LOCAL_CACHE_TIMEOUT_MILLIS);
	private Duration sharedTimeout = Duration.ofMillis(DEFAULT_SHARED_CACHE_TIMEOUT_MILLIS);
	private int localCacheMaxSize = LOCAL_CACHE_MAX_SIZE;
	private boolean staleEnabled;
	private Duration staleTimeout = Duration.ofMillis(DEFAULT_STALE_TIMEOUT_MILLIS);

	private IchibaCacheConfiguration() {
	}

	/**
	 * It fetches data from local and/or shared cache based on configuration
	 *
	 * @param cacheConfigMap  contains cache configurations as string key value pairs
	 *
	 * @return instance of this class that has validated and converted cache configurations
	 */
	public static IchibaCacheConfiguration getInstance(Map<String, String> cacheConfigMap) {
		if (!CollectionUtils.isEmpty(cacheConfigMap)) {
			IchibaCacheConfiguration configuration = new IchibaCacheConfiguration();
			String enabled = cacheConfigMap.get(ENABLED_PROP_KEY);
			String localTimeout = cacheConfigMap.get(LOCAL_TIMEOUT_PROP_KEY);
			String localMaxSize = cacheConfigMap.get(LOCAL_MAX_SIZE_PROP_KEY);
			String sharedTimeout = cacheConfigMap.get(SHARED_TIMEOUT_PROP_KEY);
			String type = cacheConfigMap.get(TYPE_PROP_KEY);
			String staleEnabled = cacheConfigMap.get(STALE_ENABLED_PROP_KEY);
			String staleTimeout = cacheConfigMap.get(STALE_TIMEOUT_PROP_KEY);

			if (StringUtils.isNotBlank(enabled)) {
				configuration.enabled = BooleanUtils.toBoolean(enabled);
			}

			if (configuration.enabled) {
				loadCacheConfiguration(configuration, localTimeout, localMaxSize, sharedTimeout, type, staleEnabled,
						staleTimeout);
				return configuration;
			}
		}
		return null;
	}

	/**
	 * It validates provided configuration values and
	 * loads the cache configuration instance with these values
	 *
	 * @param configuration configuration instance to be loaded
	 * @param localTimeout  local cache timeout
	 * @param localMaxSize  local cache maximum size
	 * @param sharedTimeout shared cache timeout
	 * @param type          cache type
	 * @param staleEnabled  stale cache enable flag
	 * @param staleTimeout  stale cache timeout
	 */
	public static void loadCacheConfiguration(IchibaCacheConfiguration configuration, String localTimeout,
											  String localMaxSize, String sharedTimeout, String type, String staleEnabled, String staleTimeout) {
		loadType(configuration, type);

		if (StringUtils.isNotBlank(localTimeout)) {
			long timeout = NumberUtils.toLong(localTimeout);
			if (timeout > 0) {
				configuration.localTimeout = Duration.ofMillis(timeout);
			}
		}

		if (StringUtils.isNotBlank(localMaxSize)) {
			configuration.localCacheMaxSize = NumberUtils.toInt(localMaxSize);
		}

		if (StringUtils.isNotBlank(sharedTimeout)) {
			long timeout = NumberUtils.toLong(sharedTimeout);
			if (timeout > 0) {
				configuration.sharedTimeout = Duration.ofMillis(timeout);
			}
		}

		if (StringUtils.isNotBlank(staleEnabled)) {
			configuration.staleEnabled = BooleanUtils.toBoolean(staleEnabled);
		}

		if (StringUtils.isNotBlank(staleTimeout)) {
			long timeout = NumberUtils.toLong(staleTimeout);
			if (timeout > 0) {
				configuration.staleTimeout = Duration.ofMillis(timeout);
			}
		}
	}

	/**
	 *
	 * @param configuration configuration instance to be loaded
	 * @param type          cache type
	 */
	private static void loadType(IchibaCacheConfiguration configuration, String type) {
		if (StringUtils.isNotBlank(type)) {
			CacheTypeEnum cacheTypeEnum = CacheTypeEnum.resolve(type);
			if (!ObjectUtils.isEmpty(cacheTypeEnum)) {
				configuration.cacheType = cacheTypeEnum;
			}
		}
	}

	public CacheTypeEnum getCacheType() {
		return cacheType;
	}

	public Duration getLocalTimeout() {
		return localTimeout;
	}

	public Duration getSharedTimeout() {
		return sharedTimeout;
	}

	public int getLocalCacheMaxSize() {
		return localCacheMaxSize;
	}

	public boolean isStaleEnabled() {
		return staleEnabled;
	}

	public Duration getStaleTimeout() {
		return staleTimeout;
	}
}
