package jp.co.rakuten.bff.core.exception;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>This Exception class is the parent exception of all the BFF Exception:
 * This Exception would have below derived Exception classes
 * <ul>
 *     <li>ClientException<li/>
 *     <li>SystemException<li/>
 *     <li>BackendException<li/>
 * </ul>
 * </p>
 */
public abstract class BffException extends RuntimeException {
	/**
	 * Code that will be send to the client
	 */
	private final HttpStatus errorCode;
	/**
	 * Type that will be send to prometheus
	 */
	private final String errorType;

	/**
	 * True Backend Code during an error
	 */
	private final HttpStatus upstreamStatusCode;

	/**
	 * Details that will be used for log
	 */
	private final List<String> details = new ArrayList<>();

	/**
	 * Constructor with optional cause exception
	 * When the Backend StatusCode is not known
	 *
	 * @param errorCode The error code
	 * @param errorType The error type
	 * @param ex        The cause exception
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 */
	BffException(HttpStatus errorCode, String errorType, Throwable ex, String message, Object... params) {
		super(String.format(message, params), ex);
		this.errorCode = errorCode;
		this.errorType = errorType;
		this.upstreamStatusCode=HttpStatus.SERVICE_UNAVAILABLE;
	}

	/**
	 * Constructor with upstreamStatusCode
	 *
	 * @param errorCode          The error code
	 * @param errorType          The error type
	 * @param ex                 The cause exception
	 * @param message            The message
	 * @param params             The optional parameters to insert in the message
	 * @param upstreamStatusCode The true backend statusCode
	 */
	BffException(HttpStatus errorCode, HttpStatus upstreamStatusCode, String errorType, Throwable ex, String message,
				 Object... params) {
		super(String.format(message, params), ex);
		this.errorCode = errorCode;
		this.errorType = errorType;
		this.upstreamStatusCode = upstreamStatusCode;
	}

	/**
	 * Return the error code to send to the client
	 *
	 * @return The error code
	 */
	public HttpStatus getErrorCode() {
		return errorCode;
	}

	/**
	 * Return the error type to display in Grafana
	 *
	 * @return The error type
	 */
	public String getErrorType() {
		return errorType;
	}

	/**
	 * Add an extra message that will be used by the method 'getDetailedMessage'
	 *
	 * @param message The message
	 * @param params  The optional parameters to insert in the message
	 * @return The GatewayException
	 */
	public BffException addDetailForLog(String message, Object... params) {
		details.add(String.format(message, params));
		return this;
	}

	/**
	 * Return the main message with the details
	 *
	 * @return The detailed message
	 */
	public String getDetailedMessage() {
		String detailedMessage = getMessage();
		String separator = ". ";
		if (CollectionUtils.isNotEmpty(details)) {
			detailedMessage += separator + String.join(separator, details);
		}
		return detailedMessage;
	}
	/**
	 * Return the true backend statusCode
	 *
	 * @return The Http statuscode from backend
	 */
	public HttpStatus getUpstreamStatusCode() {
		return upstreamStatusCode;
	}
}
