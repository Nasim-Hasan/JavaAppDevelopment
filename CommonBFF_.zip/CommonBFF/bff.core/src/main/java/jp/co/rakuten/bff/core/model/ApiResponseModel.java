package jp.co.rakuten.bff.core.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.Map;
/**
 * This POJO class will hold the API-level responses. Contains all the headers,
 * feature responses and overall status.
 */
public class ApiResponseModel {
	@JsonIgnore
	private HttpStatus httpStatus;
	@JsonIgnore
	private MultiValueMap<String, String> headers = new HttpHeaders();
	@JsonAlias("status")
	private String status;
	@JsonAlias("body")
	private Map<String, Object> body = new HashMap<>();

	/**
	 * Default constructor
	 */
	public ApiResponseModel() {
		// intentionally kept empty.
	}

	public HttpStatus getHttpStatus() {
		return this.httpStatus;
	}

	public MultiValueMap<String, String> getHeaders() {
		return this.headers;
	}

	public String getStatus() {
		return this.status;
	}

	public Map<String, Object> getBody() {
		return this.body;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public void setHeaders(MultiValueMap<String, String> headers) {
		this.headers = headers;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setBody(Map<String, Object> body) {
		this.body = body;
	}

	public String toString() {
		return "ApiResponseModel(httpStatus=" + this.getHttpStatus() + ", headers=" + this.getHeaders() + ", status=" +
				this.getStatus() + ", body=" + this.getBody() + ")";
	}
}
