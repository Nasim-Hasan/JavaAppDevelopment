package jp.co.rakuten.bff.core.cache;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics;
import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * Helper class for CacheManager that helps with
 * cacheConfiguration, localCacheInstance reload
 * comparison between configurations
 */
@Component
public class IchibaCacheManagerHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(IchibaCacheManagerHelper.class);

	/**
	 * Compares new and existing config map values
	 *
	 * @param newConfigMap      new config map whose values will be compared with existing
	 * @param existingConfigMap existing config map whose values will be compared with new
	 * @return flag to indicate whether config maps are identical
	 */
	public boolean hasDifference(Map<String, String> newConfigMap, Map<String, String> existingConfigMap) {
		return !(newConfigMap.size() == existingConfigMap.size()
				&& existingConfigMap.entrySet().stream()
				.allMatch(e -> e.getValue().equals(newConfigMap.get(e.getKey()))));
	}

	/**
	 * calculates and returns shared cache timeout
	 *
	 * @param cacheConfiguration configuration to be used for caching {@link IchibaCacheConfiguration}
	 * @return shared cache timeout value in Duration
	 */
	public Duration getSharedCacheTimeout(IchibaCacheConfiguration cacheConfiguration) {
		Duration sharedCacheTimeout;
		if (cacheConfiguration.isStaleEnabled()) {
			sharedCacheTimeout = cacheConfiguration.getSharedTimeout()
					.plusMillis(cacheConfiguration.getStaleTimeout().toMillis());
		} else {
			sharedCacheTimeout = cacheConfiguration.getSharedTimeout();
		}
		return sharedCacheTimeout;
	}

	/**
	 * returns IchibaCacheConfiguration instance from existingCacheConfigMap based on interfaceKey
	 *
	 * @param interfaceKey           name of interface
	 * @param existingCacheConfigMap contains existing cache configuration
	 * @return shared cache timeout value in Duration
	 */
	public IchibaCacheConfiguration getIchibaCacheConfiguration(String interfaceKey,
																Map<String, Map<String,
																		String>> existingCacheConfigMap) {
		try {
			Map<String, String> configMap = existingCacheConfigMap.get(interfaceKey);
			return IchibaCacheConfiguration.getInstance(configMap);
		} catch (Exception ex) {
			LOGGER.error(MessageConstants.CACHE_CONFIG_PROCESS_ERROR, interfaceKey, ex);
		}
		return null;
	}

	/**
	 * calculates and returns shared cache timeout
	 *
	 * @param header contains header values from user
	 * @return flag to indicate whether no-store header is set or not
	 */
	public boolean isNoCacheSet(HttpHeaders header) {
		boolean isNoCache = false;
		if (ObjectUtils.isNotEmpty(header)) {
			isNoCache = StringUtils.equalsIgnoreCase(header.getCacheControl(), CACHE_HEADER_NO_CACHE);
		}
		return isNoCache;
	}

	/**
	 * It loads the cache configurations
	 *
	 * @param config                 {@link InterfaceConfig}
	 * @param newCacheConfigMap      new config map that will replace the existing
	 * @param existingCacheConfigMap existing config map where interface wise cache map will be stored
	 */
	public void reloadExistingCacheConfigMap(InterfaceConfig config,
											 Map<String, String> newCacheConfigMap,
											 Map<String, Map<String, String>> existingCacheConfigMap) {
		LOGGER.info(MessageConstants.CACHE_RELOAD_INFO, config.getInterfaceKey());
		existingCacheConfigMap.put(config.getInterfaceKey(), newCacheConfigMap);
	}

	/**
	 * It loads/reloads the local cache instances
	 *
	 * @param config               {@link InterfaceConfig}
	 * @param newCacheConfigMap    config map that has new configurations
	 * @param localCacheHandlerMap map that contains local cache instances
	 * @param meterRegistry        {@link MeterRegistry}
	 * @return  flag indicating whether operation was successful or not
	 */
	public void reloadLocalCache(InterfaceConfig config, Map<String, String> newCacheConfigMap,
									Map<String, Cache<String, Map<String, Object>>> localCacheHandlerMap,
									MeterRegistry meterRegistry) {
		IchibaCacheConfiguration cacheConfiguration = IchibaCacheConfiguration.getInstance(newCacheConfigMap);
		if (!ObjectUtils.isEmpty(cacheConfiguration)) {
			Cache<String, Map<String, Object>> caffeineCache = Caffeine.newBuilder()
					.maximumSize(cacheConfiguration.getLocalCacheMaxSize())
					.expireAfterWrite(cacheConfiguration.getLocalTimeout()).recordStats().build();
			LOGGER.info(MessageConstants.CACHE_HANDLE_CREATE_INFO, config.getInterfaceKey());
			localCacheHandlerMap.put(config.getInterfaceKey(), caffeineCache);
			CaffeineCacheMetrics.monitor(meterRegistry, caffeineCache, config.getInterfaceKey(),
					"name", config.getInterfaceKey());
		}
	}

	/**
	 * Checks if local cache expired. This expiry time was set during syncing local cache with shared cache data
	 * Making sure that local cache doesnt have greater lifetime than shared cache
	 *
	 * @param localCachedData               local cache data
	 * @return  flag indicating whether locale cache has expired
	 */
	public boolean isLocalCacheExpired(Map<String, Object> localCachedData) {
		boolean isExpired = false;
		Object cacheExpiryTime = localCachedData.get("cacheExpiryTime");
		if (cacheExpiryTime instanceof LocalDateTime) {
			isExpired = ((LocalDateTime) cacheExpiryTime).compareTo(LocalDateTime.now()) < 0;
		}
		return isExpired;
	}
}
