package jp.co.rakuten.bff.core.service;


import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;

/**
 * Prepare ExecutionModel for feature execution service
 */
public interface ExecutionPlanService {
	/**
	 * Will prepare execution plan by filtering template from user provided requestModel and apiTemplate.
	 * It will include/exclude features defined in {@link RequestModel#getCommon()}
	 *
	 * @param clientRequestModel user provided clientRequestModel map.
	 * @param templateModel      API template schema from request service.
	 * @return ExecutionModel containing only user request specific features.
	 */
	ExecutionModel prepareExecutionPlan(ClientRequestModel clientRequestModel, ApiTemplate templateModel);
}
