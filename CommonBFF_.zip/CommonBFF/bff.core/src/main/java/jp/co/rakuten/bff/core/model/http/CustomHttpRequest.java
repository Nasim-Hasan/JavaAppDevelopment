package jp.co.rakuten.bff.core.model.http;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * This class encapsulates the HttpRequest related information:
 * requestId        : The id of the request
 * interfaceKey     : The interface key
 * connectionMap    : contains http connection related info
 * headerMap        : contains the request header
 * urlParameterMap  : contains the url params
 * bodyParameterMap : contains the body params
 * bodyMap          : the body in a Map/List/key=value format
 */
public class CustomHttpRequest {
	private String requestId;
	private String interfaceKey;
	private Map<String, String> connectionMap;
	private Map<String, String> headerMap;
	private Map<String, String> urlParameterMap;
	private Map<String, String> metaParameterMap;
	private String circuit;

	CustomHttpRequest(String requestId, String interfaceKey, Map<String, String> connectionMap,
					  Map<String, String> headerMap, Map<String, String> urlParameterMap,
					  Map<String, String> metaParameterMap, String circuit) {
		this.requestId = requestId;
		this.interfaceKey = interfaceKey;
		this.connectionMap = connectionMap;
		this.headerMap = headerMap;
		this.urlParameterMap = urlParameterMap;
		this.metaParameterMap = metaParameterMap;
		this.circuit = circuit;
	}

	/**
	 * CustomHttpRequest builder method
	 *
	 * @return CustomHttpRequestBuilder
	 */
	public static CustomHttpRequestBuilder builder() {
		return new CustomHttpRequestBuilder();
	}

	@Override
	public String toString() {

		return "CustomHttpRequest{" +
				"requestId='" + requestId + '\'' +
				", interfaceKey='" + interfaceKey + '\'' +
				", connectionMap=" + connectionMap +
				", headerMap=" + headerMap +
				", urlParameterMap=" + urlParameterMap +
				", metaParameterMap=" + metaParameterMap +
				", circuit=" + circuit +
				'}';
	}

	public String getRequestId() {
		return this.requestId;
	}

	public String getInterfaceKey() {
		return this.interfaceKey;
	}

	public Map<String, String> getConnectionMap() {
		return this.connectionMap;
	}

	public Map<String, String> getHeaderMap() {
		return this.headerMap;
	}

	public Map<String, String> getUrlParameterMap() {
		return this.urlParameterMap;
	}

	public String getCircuit() {
		return this.circuit;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setHeaderMap(Map<String, String> headerMap) {
		this.headerMap = headerMap;
	}

	public void setUrlParameterMap(Map<String, String> urlParameterMap) {
		this.urlParameterMap = urlParameterMap;
	}

	public Map<String, String> getMetaParameterMap() {
		return metaParameterMap;
	}

	public void setMetaParameterMap(Map<String, String> metaParameterMap) {
		this.metaParameterMap = metaParameterMap;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CustomHttpRequest that = (CustomHttpRequest) o;
		return Objects.equals(requestId, that.requestId) &&
				Objects.equals(interfaceKey, that.interfaceKey) &&
				Objects.equals(connectionMap, that.connectionMap) &&
				Objects.equals(headerMap, that.headerMap) &&
				Objects.equals(urlParameterMap, that.urlParameterMap) &&
				Objects.equals(metaParameterMap, that.metaParameterMap) &&
				Objects.equals(circuit, that.circuit);
	}

	@Override
	public int hashCode() {
		return Objects.hash(requestId, interfaceKey, connectionMap, headerMap, urlParameterMap,
				metaParameterMap, circuit);
	}

	/**
	 * {@link CustomHttpRequest} builder class
	 */
	public static class CustomHttpRequestBuilder {
		private String requestId;
		private String interfaceKey;
		private Map<String, String> connectionMap = new HashMap<>();
		private Map<String, String> headerMap = new HashMap<>();
		private Map<String, String> urlParameterMap = new HashMap<>();
		private Map<String, String> metaParameterMap = new HashMap<>();
		private String circuit;

		CustomHttpRequestBuilder() {
		}

		/**
		 * Set request id
		 *
		 * @param requestId request id
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder requestId(String requestId) {
			this.requestId = requestId;
			return this;
		}

		/**
		 * Set interface key
		 *
		 * @param interfaceKey interface key
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder interfaceKey(String interfaceKey) {
			this.interfaceKey = interfaceKey;
			return this;
		}

		/**
		 * Set connection map
		 *
		 * @param connectionMap connection map
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder connectionMap(Map<String, String> connectionMap) {
			this.connectionMap = connectionMap;
			return this;
		}

		/**
		 * Set header map
		 *
		 * @param headerMap header map
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder headerMap(Map<String, String> headerMap) {
			this.headerMap = headerMap;
			return this;
		}

		/**
		 * Set url parameter map
		 *
		 * @param urlParameterMap url parameter map
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder urlParameterMap(Map<String, String> urlParameterMap) {
			this.urlParameterMap = urlParameterMap;
			return this;
		}

		/**
		 * Set meta parameter map
		 *
		 * @param metaParameterMap meta parameter map
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder metaParameterMap(Map<String, String> metaParameterMap) {
			this.metaParameterMap = metaParameterMap;
			return this;
		}

		/**
		 * Set circuit
		 *
		 * @param circuit circuit
		 * @return CustomHttpRequestBuilder
		 */
		public CustomHttpRequestBuilder circuit(String circuit) {
			this.circuit = circuit;
			return this;
		}

		/**
		 * build method of CustomHttpRequest
		 *
		 * @return CustomHttpRequest
		 */
		public CustomHttpRequest build() {
			return new CustomHttpRequest(requestId, interfaceKey, connectionMap, headerMap, urlParameterMap,
					metaParameterMap, circuit);
		}
	}
}
