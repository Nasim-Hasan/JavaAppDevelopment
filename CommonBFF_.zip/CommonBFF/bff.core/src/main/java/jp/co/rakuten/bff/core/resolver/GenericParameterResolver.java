package jp.co.rakuten.bff.core.resolver;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.constant.ParameterTypeEnum;
import jp.co.rakuten.bff.core.constant.ValidatorTypeEnum;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.exception.ParameterResolveException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.ResponseSchema;
import jp.co.rakuten.bff.core.util.DateUtil;
import jp.co.rakuten.bff.core.util.PropertyReader;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import jp.co.rakuten.bff.core.util.ValueComparatorUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestHeader;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

import static jp.co.rakuten.bff.core.constant.BffConstants.RESPONSE_PREPARATION_ERROR_MSG;


/**
 * This component will be responsible for feature wise request validation and filtration
 * <ul>
 *      <li>resolveRequestParameter - Responsible for request validation and filtration</li>
 *      <li>resolveResponseParameter - Responsible for response validation and filtration</li>
 * </ul>
 */
@Component
public class GenericParameterResolver {
	private static final Logger LOGGER = LoggerFactory.getLogger(GenericParameterResolver.class);

	private static final String DATA = "data";
	private static final String ERROR = "error";
	private final PropertyReader propertyReader;
	private static final String REGEX = "\\d+"; //Number regex
	private static final String ZERO = "0";
	private static final String SPACE = " ";
	/**
	 * Autowired constructor, uses Spring Injection
	 *
	 * @param propertyReader @{@link PropertyReader}
	 */
	@Autowired
	public GenericParameterResolver(PropertyReader propertyReader) {
		this.propertyReader = propertyReader;
	}

	/**
	 * This method will perform the generic request validate and filtration based upon schema
	 *
	 * @param featureTemplateList List<FeatureTemplate>
	 *                            <p>
	 *                            with
	 * @param actualRequest       ClientRequestModel
	 * @return validated and filtered request to send for further processing
	 */
	public Map<String, CommonRequestModel> resolveRequestParameter(List<FeatureTemplate> featureTemplateList,
																   ClientRequestModel actualRequest) {
		if (ObjectUtils.isEmpty(featureTemplateList)) {
			throw ClientException.create(ClientErrorEnum.BAD_REQUEST, (Throwable) null, BffConstants.EMPTY_FEATURES_REQUEST);
		}

		RequestModel request = actualRequest.getRequestModel();
		CommonRequestModel commonParams = request.getCommon();

		Map<String, CommonRequestModel> featureWiseParams = request.getFeatures();
		HttpHeaders header = actualRequest.getHeader();
		Map<String, Object> headerParams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
		if (ObjectUtils.isNotEmpty(header)) {
			headerParams.putAll(header.toSingleValueMap());
			headerParams.put(BffConstants.EASY_ID,getEasyId(header));
		}

		if (commonParams != null) {
			validateExcludeFeatureList(commonParams, featureWiseParams);
		}
		Map<String, CommonRequestModel> resolvedRequestMap = new WeakHashMap<>();
		featureTemplateList.forEach((FeatureTemplate featureTemplateModel) ->
				featureWiseRequestParameterResolve(commonParams, featureWiseParams, headerParams, resolvedRequestMap,
						featureTemplateModel));
		return resolvedRequestMap;
	}

	//This method take care of EasyID when sent as Null or Blank From API-C
	//easyId=0 when sent in different pattern other than number by API-C and number
	private Object getEasyId(@RequestHeader HttpHeaders headers) {
		//Resolve Guest User We will set if Null or Blank or empty Easy ID header or doesn't matches number returned by API C
		String easyIdValue = headers.getFirst(BffConstants.EASY_ID) ;
		if (StringUtils.isBlank(easyIdValue) || !easyIdValue.matches(REGEX)){
			return ZERO;
		} else {
			return easyIdValue;
		}
	}

	@SuppressWarnings("squid:S2259")
	private void featureWiseRequestParameterResolve(CommonRequestModel commonParams,
													Map<String, CommonRequestModel> featureWiseParams,
													Map<String, Object> headerParams,
													Map<String, CommonRequestModel> resolvedRequestMap,
													FeatureTemplate featureTemplateModel) {
		String featureName = featureTemplateModel.getName();
		Set<String> includedParams = null;
		Set<String> excludedParams = null;
		Map<String, Object> requestParams = null;

		CommonRequestModel featureWiseRequestModel = MapUtils.isNotEmpty(featureWiseParams) ?
				featureWiseParams.get(featureName) : null;

		if (ObjectUtils.isNotEmpty(featureWiseRequestModel)) {
			includedParams = featureWiseRequestModel.getInclude();
			excludedParams = featureWiseRequestModel.getExclude();
			requestParams = featureWiseRequestModel.getParams();
			removeAllNull(includedParams);
			removeAllNull(excludedParams);
			if (CollectionUtils.isNotEmpty(includedParams) && CollectionUtils.isNotEmpty(excludedParams)) {
				throw FeatureException.create(featureName, ClientErrorEnum.BAD_REQUEST,
						MessageConstants.PARAM_RESOLVE_INCLUDE_OR_EXCLUDE, featureName);
			}
		}

		if (requestParams == null) {
			requestParams = new HashMap<>();
		}

		try {
			if (commonParams != null) {
				mergeCommonParams(commonParams, requestParams);
			}

			validateRequestAndHeaderParameters(headerParams, resolvedRequestMap, featureTemplateModel, featureName,
					includedParams, excludedParams, requestParams);
		} catch (ParameterResolveException | ClientException ex) {
			throw FeatureException.create(featureName, ClientErrorEnum.BAD_REQUEST, ex, ex.getMessage());
		}
	}

	private void removeAllNull(Set<String> params) {
		if (CollectionUtils.isNotEmpty(params) && params.contains(null)) {
			params.remove(null);
		}
	}

	private void validateRequestAndHeaderParameters(Map<String, Object> headerParams,
													Map<String, CommonRequestModel> resolvedRequestMap,
													FeatureTemplate featureTemplateModel, String featureName,
													Set<String> includedParams, Set<String> excludedParams,
													Map<String, Object> requestParams) {
		Map<String, Object> validatedParams =
				getValidateParameters(requestParams, featureTemplateModel.getRequest().getParameters(),
						ParameterTypeEnum.REQUEST.getType());
		Map<String, Object> validatedHeaders =
				getValidateParameters(headerParams, featureTemplateModel.getRequest().getHeaders(),
						ParameterTypeEnum.HEADER.getType());

		resolvedRequestMap.put(featureName,
				new CommonRequestModel(validatedParams, validatedHeaders, includedParams, excludedParams));
	}

	private Map<String, Object> getValidateParameters(Map<String, Object> userParams,
													  List<CommonSchema> paramsSchema, String parameterType) {
		Map<String, Object> validatedParams = new HashMap<>();
		paramsSchema.forEach((CommonSchema paramSchema) ->
				resolveParameter(paramSchema, userParams, validatedParams, parameterType));
		return validatedParams;
	}

	private void mergeCommonParams(CommonRequestModel common, Map<String, Object> featureParams) {
		Map<String, Object> commonModel = common.getParams();
		if (MapUtils.isNotEmpty(commonModel)) {
			commonModel.forEach((String e, Object k) -> {
				if (!featureParams.containsKey(e)) {
					featureParams.put(e, k);
				}
			});
		}
	}

	private void validateExcludeFeatureList(CommonRequestModel common, Map<String, CommonRequestModel> featureWiseParams) {
		Set<String> excludedFeatures = common.getExclude();
		if (CollectionUtils.isNotEmpty(excludedFeatures)) {
			excludedFeatures.forEach((String featureName) -> {
				CommonRequestModel featureRequestModel = MapUtils.isNotEmpty(featureWiseParams) ?
						featureWiseParams.get(featureName) : null;
				if (ObjectUtils.isNotEmpty(featureRequestModel)) {
					throw FeatureException
							.create(featureName, ClientErrorEnum.BAD_REQUEST, MessageConstants.PARAM_RESOLVE_EXCLUSION_FAILURE_MSG,
									featureName);
				}
			});
		}
	}

	/**
	 * This method will perform the generic response validate and filtration based upon schema
	 *
	 * @param featureModelList List<FeatureTemplate>
	 *                         <p>
	 *                         with
	 * @param responseModel    Map<String, Object> it could have feature-based map
	 * @return validated and filtered response to send for further processing
	 */
	public Map<String, Object> resolveResponseParameter(List<FeatureTemplate> featureModelList,
														Map<String, Object> responseModel) {
		Map<String, Object> finalResponse = new HashMap<>();
		featureModelList.forEach((FeatureTemplate featureTemplateModel) -> {
			ResponseSchema responseSchema = featureTemplateModel.getResponse();
			if (!BooleanUtils.toBoolean(responseSchema.getFastForward()) && CollectionUtils
					.isNotEmpty(responseSchema.getParameters())) {
				validateSchemaWiseResponse(responseModel, finalResponse, featureTemplateModel, responseSchema);
			} else {
				finalResponse.put(featureTemplateModel.getName(), responseModel.get(featureTemplateModel.getName()));
			}
		});
		return finalResponse;
	}

	private void validateSchemaWiseResponse(Map<String, Object> responseModel, Map<String, Object> finalResponse,
											FeatureTemplate featureTemplateModel, ResponseSchema responseSchema) {
		String featureName = featureTemplateModel.getName();
		try {
			// Response Body Validation
			Map featureModelResponse = (Map<String, Object>) responseModel.get(featureName);
			if(MapUtils.isNotEmpty(featureModelResponse)) {
				Map featureResponseData = (Map) featureModelResponse.get(DATA);
				List<CommonSchema> responseSchemaParameters = responseSchema.getParameters();
				if (MapUtils.isNotEmpty(featureResponseData) && CollectionUtils.isNotEmpty(responseSchemaParameters)) {
					Map featureValidatedResponseData = new HashMap<>();
					responseSchemaParameters.forEach((CommonSchema schemaParameter) ->
							resolveParameter(schemaParameter, featureResponseData, featureValidatedResponseData,
									ParameterTypeEnum.RESPONSE.getType())
					);
					// Response Header Validation
					List<CommonSchema> responseSchemaHeaders = responseSchema.getHeaders();
					Map headerData;
					Map featureResponseHeader =
							(Map) featureModelResponse.getOrDefault(BffConstants.HEADER, new HashMap<>());
					if (CollectionUtils.isNotEmpty(responseSchemaHeaders)) {
						Map featureValidatedHeaderData = new HashMap();
						responseSchemaParameters.forEach((CommonSchema schemaParameter) ->
								resolveParameter(schemaParameter, featureResponseHeader, featureValidatedHeaderData,
										ParameterTypeEnum.HEADER.getType())
						);
						headerData = featureValidatedHeaderData;
					} else {
						headerData = featureResponseHeader;
					}
					finalResponse.put(featureName,
							Map.of(DATA, featureValidatedResponseData, BffConstants.HEADER, headerData));
				} else if (ObjectUtils.isNotEmpty(featureModelResponse.get(ERROR))) {
					finalResponse.put(featureName, Map.of(ERROR, featureModelResponse.get(ERROR)));
				} else {
					finalResponse
							.put(featureName, Map.of(DATA, new HashMap<>(), BffConstants.HEADER, new HashMap<>()));
				}
			}else {
				LOGGER.error("Response for feature: {} not found in final response model", featureName);
				finalResponse.put(featureName,
						ResponseUtil.getFeatureErrorResponseMap(RESPONSE_PREPARATION_ERROR_MSG,
								HttpStatus.SERVICE_UNAVAILABLE.value()));
			}
		} catch (ParameterResolveException ex) {
			LOGGER.error("Exception while resolving the response parameter: ", ex);
			finalResponse.put(featureName,
					ResponseUtil.getFeatureErrorResponseMap(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE.value()));
		}
	}

	/**
	 * This method will perform both request and response parameter's validation and filtration
	 *
	 * @param templateMap   CommonSchema
	 * @param parameter     Map<String, Object>
	 * @param parameterType String
	 */
	private void resolveParameter(CommonSchema templateMap, Map<String, Object> parameter,
								  Map<String, Object> validatedMap, String parameterType) {

		String name = templateMap.getName();
		String source = templateMap.getSource();
		String key = ObjectUtils.isNotEmpty(source) ? source : name;
		Object defaultValue = templateMap.getDefaultValue();

		Object value = parameter.get(key);

		if (ObjectUtils.isEmpty(value) && ObjectUtils.isNotEmpty(defaultValue) &&
				!parameterType.equals(ParameterTypeEnum.RESPONSE.getType())) {
			value = defaultValue;
		}

		boolean required = BooleanUtils.toBoolean(templateMap.getRequired());
		String type = templateMap.getType();
		type = type.trim().toLowerCase();
		boolean isValidValue  = ValueComparatorUtil.isValidParameterValue(value, templateMap.getValueComparator());
		if (required && !ValidatorTypeEnum.PROPERTY.getType().equals(type) && (!parameter.containsKey(key) ||
				!isValidValue )) {
			throw new ParameterResolveException(new StringBuilder(key).append(SPACE).append(parameterType).append(MessageConstants.PARAM_RESOLVE_PARAM_REQD_MSG).toString());
		}

		if (ObjectUtils.isNotEmpty(value) || (ValidatorTypeEnum.STRING.getType().equals(type) && isValidValue )) {
			String propType = templateMap.getPropType();
			String propKeyPrefix = templateMap.getPropKeyPrefix();
			String propKeySuffix = templateMap.getPropKeySuffix();
			String dataType = templateMap.getDataType();
			Object validatedValue = validateValue(value, ValidatorTypeEnum.getValidator(type), key, dataType,
					Map.of("propType", Optional.ofNullable(propType).orElse(StringUtils.EMPTY),
							"propKeyPrefix", Optional.ofNullable(propKeyPrefix).orElse(StringUtils.EMPTY),
							"propKeySuffix", Optional.ofNullable(propKeySuffix).orElse(StringUtils.EMPTY)
							),
					templateMap, parameterType);

			validatedMap.put(name, validatedValue);
		}
	}

	/**
	 * Check minValue and maxValue only if minValue and maxValue attributes exists in json file for corresponding field
	 *
	 * @param maxValue   maxValue is the value to be compared with for maximum range
	 * @param minValue   minValue is the value to be compared with for minimum range
	 * @param key        key is the field of the parameter
	 * @param givenValue givenValue which will be compared with
	 */
	private <N extends Number> void checkMaxMinValue(N maxValue, N minValue, String key, N givenValue,
													 String validatorType) {
		if (StringUtils.isNotBlank(validatorType) && validatorType.equals(ParameterTypeEnum.REQUEST.getType())) {
			if (ObjectUtils.isNotEmpty(maxValue) && isNotUnderMaxValue(givenValue, maxValue)) {
				throw new ParameterResolveException(new StringBuilder(key).append(MessageConstants.PARAM_RESOLVE_NUMBER_UNDER_MSG).append(maxValue).toString());
			}

			if (ObjectUtils.isNotEmpty(minValue) && isNotOverMinValue(givenValue, minValue)) {
				throw new ParameterResolveException(new StringBuilder(key).append(MessageConstants.PARAM_RESOLVE_NUMBER_OVER_MSG).append(minValue).toString());
			}
		}
	}

	/**
	 * Check givenValue is over the maxValue or not
	 *
	 * @param givenValue givenValue which will be compared with
	 * @param maxValue   which is the range to check with
	 * @return true if the givenValue is over the maxValue
	 */
	private <N extends Number> boolean isNotUnderMaxValue(N givenValue, N maxValue) {
		return compareGreaterThan(givenValue, maxValue);
	}

	/**
	 * Check givenValue is under the minValue or not
	 *
	 * @param givenValue givenValue which will be compared with
	 * @param minValue   which is the range to check with
	 * @return true if the givenValue is under minValue
	 */
	private <N extends Number> boolean isNotOverMinValue(N givenValue, N minValue) {
		return compareLessThan(givenValue, minValue);
	}

	private static <N extends Number> boolean compareGreaterThan(N firstNumber, N secondNumber) {
		return firstNumber.doubleValue() > secondNumber.doubleValue();
	}

	private static <N extends Number> boolean compareLessThan(N firstNumber, N secondNumber) {
		return firstNumber.doubleValue() < secondNumber.doubleValue();
	}

	private void checkMaxMinStringLength(Integer minLength, Integer maxLength, String key, String givenValue,
										 String validatorType) {
		if (validatorType.equals(ParameterTypeEnum.REQUEST.getType())) {
			if (ObjectUtils.isNotEmpty(maxLength) && givenValue.length() > maxLength) {
				throw new ParameterResolveException(new StringBuilder(key).append(MessageConstants.PARAM_RESOLVE_STRING_LEN_UNDER_MSG).append(maxLength).toString());
			}

			if (ObjectUtils.isNotEmpty(minLength) && givenValue.length() < minLength) {
				throw new ParameterResolveException(new StringBuilder(key).append(MessageConstants.PARAM_RESOLVE_STRING_LEN_OVER_MSG).append(minLength).toString());
			}
		}
	}

	private void checkMaxSize(Integer maxSize, String key, Integer givenSize, String validatorType) {
		if (validatorType.equals(ParameterTypeEnum.REQUEST.getType()) && givenSize > maxSize) {
			throw new ParameterResolveException(new StringBuilder(key).append(MessageConstants.PARAM_RESOLVE_INT_SIZE_UNDER_MSG).append(maxSize).toString());
		}
	}

	private void validatePattern(String name, Object origin, String pattern, String validatorType) {
		if (validatorType.equals(ParameterTypeEnum.REQUEST.getType())) {
			Pattern patternRegx = Pattern.compile(pattern);
			if (!patternRegx.matcher(origin.toString()).matches()) {
				throw new ParameterResolveException(new StringBuilder(name).append(MessageConstants.PARAM_RESOLVE_STRING_PATTERN_FOLLOW_MSG).append(pattern).toString());
			}
		}
	}

	private Object validate(Object valueToValidate, String name, CommonSchema schema, ValidatorTypeEnum type,
							String validatorType) {
		String strValue = valueToValidate != null ? valueToValidate.toString() : null;
		Object value;
		Integer maxValue = null;
		Integer minValue = null;

		if (ObjectUtils.isNotEmpty(schema)) {
			maxValue = schema.getMaxValue();
			minValue = schema.getMinValue();
		}

		switch (type) {
			case BOOLEAN:
				value = validateBoolean(name, strValue);
				break;
			case INTEGER:
				value = validateInteger(name, validatorType, strValue, maxValue, minValue);
				break;
			case LONG:
				value = validateLong(name, validatorType, strValue, maxValue, minValue);
				break;
			case DOUBLE:
				value = validateDouble(name, validatorType, strValue, maxValue, minValue);
				break;
			case DATE:
				value = validateDate(strValue, schema.getName(), schema.getFormat());
				break;
			default:
				if (!(valueToValidate instanceof String)) {
					throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_STRING_MSG);
				}

				value = validateStringRequestParameter(strValue, name, schema, validatorType);
				break;
		}
		return value;
	}

	private Double validateDouble(String name, String validatorType, String strValue, Integer maxValue,
								  Integer minValue) {
		Double value;
		try {
			value = Double.valueOf(strValue);
			checkMaxMinValue(maxValue, minValue, name, value, validatorType);
		} catch (NumberFormatException ex) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_DOUBLE_MSG);
		}
		return value;
	}

	private Long validateLong(String name, String validatorType, String strValue, Integer maxValue, Integer minValue) {
		Long value;
		try {
			value = Long.valueOf(strValue);
			checkMaxMinValue(maxValue, minValue, name, value, validatorType);
		} catch (NumberFormatException ex) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_LONG_MSG);
		}
		return value;
	}

	private Integer validateInteger(String name, String validatorType, String strValue, Integer maxValue,
									Integer minValue) {
		Integer value;
		try {
			value = Integer.valueOf(strValue);
			checkMaxMinValue(maxValue, minValue, name, value, validatorType);
		} catch (NumberFormatException ex) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_INT_MSG);
		}
		return value;
	}

	private Boolean validateBoolean(String name, String valueToValidate) {
		if ("false".equals(valueToValidate) || "true".equals(valueToValidate)) {
			return Boolean.valueOf(valueToValidate);
		} else {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_BOOL_MSG);
		}
	}

	private String validateStringRequestParameter(String valueToValidate, String name, CommonSchema schema,
												  String validatorType) {
		if (ObjectUtils.isNotEmpty(schema)) {
			checkMaxMinStringLength(schema.getMinLength(), schema.getMaxLength(), name, valueToValidate, validatorType);

			String pattern = schema.getPattern();
			if (StringUtils.isNotBlank(pattern)) {
				validatePattern(name, valueToValidate, pattern, validatorType);
			}
		}

		return valueToValidate;
	}

	/**
	 * Validate any object
	 *
	 * @param value         based upon predefined types supported by the system
	 * @param type          with given key
	 * @param name          name of the parameter
	 * @param dataType      dataType for the parameter
	 * @param properties    properties value
	 * @param schema        request, response or header schema
	 * @param validatorType request, response or header
	 * @return validated and filtered value with type
	 */
	private Object validateValue(Object value, ValidatorTypeEnum type, String name, String dataType,
								 Map<String, Object> properties, CommonSchema schema, String validatorType) {
		Object returnValue;
		switch (type) {
			case LIST:
				returnValue = validateList(value, schema, name, dataType, validatorType);
				break;
			case OBJECT:
				returnValue =  resolveObject(schema, value, name, validatorType);
				break;
			case OBJECT_ARRAY:
				returnValue = validateObjectArray(value, name, schema, validatorType);
				break;
			case OPTION:
				returnValue = validateOptions(value, name, dataType, schema, validatorType);
				break;
			case MULTI_OPTION:
				returnValue = validateMultiOption(value, name, dataType, schema);
				break;
			case PROPERTY:
				returnValue = propertyReader.getPropertyValue((String) properties.get("propKeyPrefix"),
						(String) properties.get("propKeySuffix"),  value, (String) properties.get("propType"));
				break;
			default:
				returnValue = validate(value, name, schema, type, validatorType);
		}

		return returnValue;
	}

	private String validateDate(String value, String name, String format) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		if (BffConstants.SYSTEM_DATE.equalsIgnoreCase(value)) {
			value = simpleDateFormat.format(DateUtil.getCurrentDate());
		} else {
			try {
				simpleDateFormat.parse(value);
			} catch(ParseException e){
				throw new ParameterResolveException(new StringBuilder(name).append(MessageConstants.PARAM_RESOLVE_DATE_FORMAT_LIKE_MSG).append(format).append("'").toString());
			}
		}
		return value;
	}

	private Object validateOptions(Object value, String name, String dataType, CommonSchema schema,
								   String validatorType) {
		if ((value instanceof Map) || (value instanceof List)) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_TYPE_NOT_LIST_OR_MAP_MSG);
		}

		List<Object> options = schema.getOptions();
		if (!options.contains(value)) {
			throw new ParameterResolveException(new StringBuilder(MessageConstants.PARAM_RESOLVE_OPTION_SELECT_MSG)
					.append(options).append(" for parameter: ").append(name).toString());
		}

		return validateValue(value, ValidatorTypeEnum.getValidator(dataType), name, null, null, null,
				validatorType);
	}

	private List<Object> validateList(Object value, CommonSchema schema, String name,
									  String dataType, String validatorType) {
		Integer maxSize = schema.getMaxSize();
		if((value instanceof List)) {
			if(CollectionUtils.isNotEmpty((List) value)) {
				Object listValue = ((List) value).get(0);
				if (ObjectUtils.isNotEmpty(maxSize)) {
					checkMaxSize(maxSize, name, ((List) value).size(), validatorType);
				}
				validateValue(listValue, ValidatorTypeEnum.getValidator(dataType), name, null, null, null, null);
			}
			return (List<Object>) value;
		} else {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_LIST_MSG);
		}
	}

	private List<Object> validateMultiOption(Object value, String name, String dataType, CommonSchema schema) {
		if ((value instanceof Map)) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_TYPE_NOT_MAP_MSG);
		}

		List<Object> multiOptionParameterValues = new ArrayList<>();

		if (value instanceof List) {
			multiOptionParameterValues = (List<Object>) value;
		} else {
			multiOptionParameterValues.add(value);
		}

		Integer maxSelectable = schema.getMaxSelectable();
		Integer minSelectable = schema.getMinSelectable();

		if ((ObjectUtils.isNotEmpty(maxSelectable) && multiOptionParameterValues.size() > maxSelectable) ||
				(ObjectUtils.isNotEmpty(minSelectable) && multiOptionParameterValues.size() < minSelectable)) {
			throw new ParameterResolveException(
					new StringBuilder(MessageConstants.PARAM_RESOLVE_VALUE_FOR_PARAM).append(name)
					.append(MessageConstants.PARAM_RESOLVE_VALUE_SELECTION_MSG).append(schema.getOptions())
					.append(MessageConstants.PARAM_RESOLVE_SELECTION_MINIMUM_MSG).append(minSelectable)
					.append(MessageConstants.PARAM_RESOLVE_SELECTION_MAXIMUM_MSG).append(maxSelectable)
					.append(MessageConstants.PARAM_RESOLVE_VALUE_SELECTED_MSG).toString());
		}

		List<Object> resolvedParamValues = new ArrayList<>();
		List<Object> multiOptions = schema.getOptions();
		for (Object multiOptionParameter : multiOptionParameterValues) {
			Object paramValue =
					validate(multiOptionParameter, name, null, ValidatorTypeEnum.getValidator(dataType), null);
			if (!multiOptions.contains(paramValue)) {
				throw new ParameterResolveException(new StringBuilder(MessageConstants.PARAM_RESOLVE_VALUE_FOR_PARAM).append(name)
						.append(MessageConstants.PARAM_RESOLVE_VALUE_SELECTION_MSG).append(multiOptions).toString());
			}
			resolvedParamValues.add(paramValue);
		}
		return resolvedParamValues;
	}

	private List<Map<String, Object>> validateObjectArray(Object value, String name,
														  CommonSchema schema, String validatorType) {
		if (!(value instanceof List)) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_PARAMS_TYPE_LIST_MSG);
		}

		List<Object> parameters = (List<Object>) value;
		List<Map<String, Object>> resolvedParameterList = new ArrayList<>();

		parameters.forEach((Object parameter) -> {
			Map<String, Object> paramMap = resolveObject(schema, parameter, name, validatorType);
			resolvedParameterList.add(paramMap);
		});
		return resolvedParameterList;
	}

	private Map<String, Object> resolveObject(CommonSchema schema, Object value, String name, String validatorType) {
		if (!(value instanceof Map)) {
			throw new ParameterResolveException(name + MessageConstants.PARAM_RESOLVE_VALIDATION_PARAMS_TYPE_MAP_MSG);
		}

		List<CommonSchema> parameters = schema.getParameters();
		Map<String, Object> paramMap = new HashMap<>();
		parameters.forEach(objectCommonSchema ->
				resolveParameter(objectCommonSchema, (Map<String, Object>) value, paramMap, validatorType));
		return paramMap;
	}
}
