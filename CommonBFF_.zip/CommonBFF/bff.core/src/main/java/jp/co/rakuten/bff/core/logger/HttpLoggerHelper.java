package jp.co.rakuten.bff.core.logger;

import jp.co.rakuten.bff.core.constant.BffConstants;
import reactor.util.context.Context;

import java.util.Map;

/**
 * A helper for {@code HttpLogger}
 */
public class HttpLoggerHelper {

	private HttpLoggerHelper() {
	}

	/**
	 * Field Names used in the extra map of {@code LoggerRequest}
	 */
	public static class ExtrasFieldNames {
		public static final String CLIENT_ID = "clientId";
		public static final String HOST = "hostname";
		public static final String REQUEST_PATH = "requestPath";
		public static final String REQUEST_PARAMS = "requestParams";
		public static final String FORWARDED_FOR = "forwardedFor";
		public static final String BFF_ID = "bffId";
		public static final String REQUEST_TYPE = "requestType";

		private ExtrasFieldNames() { }
	}

	/**
	 * Prepare the loggerRequest with additional for the ApiLogger.
	 * @param request the request
	 * @param context the context
	 */
	public static void prepareApiLoggerRequest(HttpLogger.LoggerRequest request, Context context) {
		addExtrasFromContextExcludeRequestUri(request, context, true);
	}


	/**
	 * Prepare the loggerRequest with additional for the ServiceLogger.
	 * @param request the request
	 * @param context the context
	 */
	public static void prepareServiceLoggerRequest(HttpLogger.LoggerRequest request, Context context) {
		addExtrasFromContextExcludeRequestUri(request, context, false);
	}

	private static void addExtrasFromContextExcludeRequestUri(HttpLogger.LoggerRequest request, Context context,
															  boolean excludeRequestUri) {
		if (!context.hasKey(BffConstants.BFF_CONTEXT)) {
			return;
		}
		Map<String, Object> extras = request.getExtras();
		BffContext bffContext = context.get(BffConstants.BFF_CONTEXT);
		extras.put(ExtrasFieldNames.CLIENT_ID, bffContext.getClientId());
		extras.put(ExtrasFieldNames.HOST, bffContext.getHost());
		if (bffContext.getRequestUri() != null) {
			String requestPath = bffContext.getRequestUri().toString().split("\\?")[0];
			if (!excludeRequestUri) {
				extras.put(ExtrasFieldNames.REQUEST_PATH, requestPath);
				extras.put(ExtrasFieldNames.REQUEST_PARAMS, bffContext.getRequestUri().getQuery());
			} else {
				request.setUri(bffContext.getRequestUri());
			}

		}
		extras.put(ExtrasFieldNames.FORWARDED_FOR, bffContext.getForwardedFor());
		extras.put(ExtrasFieldNames.BFF_ID, bffContext.getBffId());
	}

}
