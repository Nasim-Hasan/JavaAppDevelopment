package jp.co.rakuten.bff.core.model;

import java.util.Map;
import java.util.Set;

/**
 * This Model class will be used to hold the user's request parameters data.
 */
public class CommonRequestModel {
	private Map<String, Object> params;
	private Map<String, Object> headers;
	private Set<String> include;
	private Set<String> exclude;

	/**
	 * Default constructor
	 */
	public CommonRequestModel() {
		// intentionally kept it empty. Assuming instance will be created by json libraries.
	}

	/**
	 * This will instantiate the commonRequestModel with given
	 *
	 * @param params  request parameter
	 * @param headers request parameter
	 * @param include included fields
	 * @param exclude excluded fields
	 */
	public CommonRequestModel(Map<String, Object> params, Map<String, Object> headers, Set<String> include,
							  Set<String> exclude) {
		this.params = params;
		this.headers = headers;
		this.include = include;
		this.exclude = exclude;
	}

	public Map<String, Object> getParams() {
		return this.params;
	}

	public Set<String> getInclude() {
		return this.include;
	}

	public Set<String> getExclude() {
		return this.exclude;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public void setInclude(Set<String> include) {
		this.include = include;
	}

	public void setExclude(Set<String> exclude) {
		this.exclude = exclude;
	}

	public Map<String, Object> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, Object> headers) {
		this.headers = headers;
	}

	public String toString() {
		return "CommonRequestModel(params=" + this.getParams() + ", headers=" + this.getHeaders() +
				", include=" + this.getInclude() + ", exclude=" +
				this.getExclude() + ")";
	}
}
