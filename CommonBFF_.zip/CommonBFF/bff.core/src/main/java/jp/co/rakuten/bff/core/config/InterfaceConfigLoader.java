package jp.co.rakuten.bff.core.config;

import io.micrometer.core.instrument.util.StringUtils;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.event.OnInterfacesLoadedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.CompositePropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;


/**
 * This class load the backend's interface related information and keep the map of it.
 * The property has to respect one of the following formats:
 * <p>
 * Add the suffix to the connectionMap:
 * interface_key.connection.suffix
 * group_key.connection.suffix
 * interface_global.connection.suffix
 * <p>
 * Add the suffix to the headerMap:
 * interface_key.headerParameters.suffix
 * group_key.headerParameters.suffix
 * interface_global.headerParameters.suffix
 * <p>
 * Add the suffix to the parameterMap:
 * interface_key.parameter.suffix
 * group_key.parameter.suffix
 * interface_global.parameter.suffix
 * <p>
 * Add the suffix to the metadataMap:
 * interface_key.suffix
 * group_key.suffix
 * interface_global.suffix
 * <p>
 * Add the circuit: (if the circuit is missing, the interfaceKey will be used as the circuit key)
 * interface_key.circuit
 * group_key.circuit
 * <p>
 * Remember that the first priority is 'interface', then 'group' and finally 'global'.
 *
 * @author tony.rouillard
 */
@Component("interfaceConfigLoader")
public class InterfaceConfigLoader {
	private static final Logger LOGGER = LoggerFactory.getLogger(InterfaceConfigLoader.class);

	private static final String UNION = ".";

	private Environment env;
	private ApplicationEventPublisher applicationEventPublisher;
	private InterfaceMapping interfaceMapping;
	private Map<String, InterfaceConfig> interfaceMap = new ConcurrentHashMap<>();

	/**
	 * Constructor for the autowired resources
	 *
	 * @param env                       from the application context. used to fetch environment properties and values.
	 * @param applicationEventPublisher from the application context. used to publish our own event.
	 * @param interfaceMapping          holds the map of interface keys and groups from underlying config properties.
	 */
	@Autowired
	public InterfaceConfigLoader(Environment env,
								 ApplicationEventPublisher applicationEventPublisher,
								 InterfaceMapping interfaceMapping) {
		this.env = env;
		this.applicationEventPublisher = applicationEventPublisher;
		this.interfaceMapping = interfaceMapping;
	}

	@PostConstruct
	private void init() {
		loadInterfaces();
	}

	/**
	 * Refresh handlers for actuator refresh triggering configuration updates
	 *
	 * @param event {@link RefreshScopeRefreshedEvent} is triggered after {@code RefreshScope}
	 */
	@EventListener(RefreshScopeRefreshedEvent.class)
	public void onRefresh(RefreshScopeRefreshedEvent event) {
		LOGGER.info("{} received by {}", event.getClass().getSimpleName(), this.getClass().getSimpleName());
		loadInterfaces();
	}

	/**
	 * Find the proper properties among every property files and load it into InterfaceConfig objects.
	 * The values come from the property that start with the InterfaceKey, CommomKey or 'global' (cf. InterfaceEnum)
	 * The value in the InterfaceKey overrides the GroupKey, which overrides 'global'.
	 */
	private synchronized void loadInterfaces() {
		long startTime = System.currentTimeMillis();

		Map<String, InterfaceConfig> newInterfaceMap = new ConcurrentHashMap<>();

		Collection<IInterface> interfaces = getInterfaces();
		((AbstractEnvironment) env).getPropertySources().forEach((PropertySource propertySource) -> {
			if (propertySource instanceof MapPropertySource) {
				// this is the eventual type of a key-value pair property file
				processMapPropertySource((MapPropertySource) propertySource, interfaces, newInterfaceMap);
			} else if (propertySource instanceof CompositePropertySource) {
				// this is a wrapper if there are multiple property sources
				extractMapPropertySources((CompositePropertySource) propertySource).forEach(
						(MapPropertySource innerPropertySource) -> processMapPropertySource(innerPropertySource,
								interfaces,
								newInterfaceMap));
			}
		});

		completeCircuit(newInterfaceMap.values());


		interfaceMap.putAll(newInterfaceMap);
		long loadDuration = System.currentTimeMillis() - startTime;
		long configLoadingTimeout = Long.parseLong(env.getProperty(CONFIG_LOADING_TIMEOUT_PROP));
		String loadDurationMessage = String.format("Interfaces loaded in %s ms", loadDuration);
		if (loadDuration > configLoadingTimeout) {
			LOGGER.warn(loadDurationMessage);
		} else {
			LOGGER.info(loadDurationMessage);
		}
		newInterfaceMap.values().forEach(interfaceConfig -> LOGGER.info(interfaceConfig.toString()));

		applicationEventPublisher.publishEvent(new OnInterfacesLoadedEvent(this, interfaceMap.values()));

	}

	/**
	 * This method complete the attribute 'circuit' with the interfaceKey if it is missing.
	 *
	 * @param interfaces the list of InterfaceConfig
	 */
	private void completeCircuit(Collection<InterfaceConfig> interfaces) {
		interfaces.forEach(((InterfaceConfig interfaceConfig) -> {
			if (StringUtils.isBlank(interfaceConfig.getCircuit())) {
				interfaceConfig.setCircuit(interfaceConfig.getInterfaceKey());
				LOGGER.info(MessageConstants.CONFIG_INTERFACE_CIRCUIT_INFO,
						interfaceConfig.getInterfaceKey());
			}
		}));
	}

	/**
	 * Add the property to the proper InterfaceConfig if required.
	 *
	 * @param interfaces       The list of interfaces
	 * @param interfaceMapTemp The map to fill
	 * @param propertyKey      The key found in a property file
	 */
	private void compareKeysAndAddValue(Collection<IInterface> interfaces,
										Map<String, InterfaceConfig> interfaceMapTemp,
										String propertyKey) {
		interfaces.forEach((IInterface interfaceGroupKeys) -> {
			if (propertyKey.startsWith(interfaceGroupKeys.getInterfaceKey() + UNION)) {
				addValue(interfaceMapTemp, propertyKey, interfaceGroupKeys.getInterfaceKey(), interfaceGroupKeys);
			} else if (StringUtils.isNotBlank(interfaceGroupKeys.getGroupKey())
					&& propertyKey.startsWith(interfaceGroupKeys.getGroupKey() + UNION)) {
				addValue(interfaceMapTemp, propertyKey, interfaceGroupKeys.getGroupKey(), interfaceGroupKeys);
			} else if (propertyKey.startsWith(GLOBAL_PREFIX)) {
				addValue(interfaceMapTemp, propertyKey, GLOBAL_PREFIX, interfaceGroupKeys);
			}
		});
	}

	private Collection<IInterface> getInterfaces() {
		Map<String, IInterface> interfaces = interfaceMapping.getMapping();
		if (interfaces.isEmpty()) {
			return Collections.emptyList();
		}
		return interfaces.values();
	}

	/**
	 * Add the property to the proper InterfaceConfig.
	 * Some known keys are added to the proper maps, others are added to the metadataMap.
	 *
	 * @param interfaceMapTemp The map to fill
	 * @param propertyKey      The key found in a property file
	 * @param iInterface       The iInterface that contains the interfaceKey and the groupKey
	 */
	private void addValue(Map<String,
			InterfaceConfig> interfaceMapTemp,
						  String propertyKey,
						  String prefix,
						  IInterface iInterface) {
		String interfaceKey = iInterface.getInterfaceKey();
		InterfaceConfig interfaceConfig = interfaceMapTemp.get(interfaceKey);
		if (interfaceConfig == null) {
			interfaceConfig = new InterfaceConfig(interfaceKey);
			interfaceMapTemp.put(interfaceKey, interfaceConfig);
		}
		String propertySuffix = propertyKey.replaceFirst(prefix, "");
		if (propertySuffix.startsWith(".")) {
			propertySuffix = propertySuffix.substring(1);
		}

		if (propertySuffix.startsWith(CONNECTION_PREFIX)) {
			String objectSuffix = propertySuffix.replaceFirst(CONNECTION_PREFIX, "");
			addConnectionValue(interfaceConfig, objectSuffix, propertySuffix, iInterface);
		} else if (propertySuffix.startsWith(URL_PARAMETERS_PREFIX)) {
			String objectSuffix = propertySuffix.replaceFirst(URL_PARAMETERS_PREFIX, "");
			addUrlParameterValue(interfaceConfig, objectSuffix, propertySuffix, iInterface);
		} else if (propertySuffix.startsWith(HEADER_PREFIX)) {
			String objectSuffix = propertySuffix.replaceFirst(HEADER_PREFIX, "");
			addHeaderValue(interfaceConfig, objectSuffix, propertySuffix, iInterface);
		} else if (propertySuffix.equals(CIRCUIT)) {
			interfaceConfig.setCircuit(getCorrectValue(iInterface, propertySuffix));
		} else if (propertySuffix.startsWith(CACHE_PREFIX)) {
			String objectSuffix = propertySuffix.replaceFirst(CACHE_PREFIX, "");
			addCacheConfigValue(interfaceConfig, objectSuffix, propertySuffix, iInterface);
		} else {
			interfaceConfig.putToMetadataMap(propertySuffix, getCorrectValue(iInterface, propertySuffix));
		}
	}

	private void addCacheConfigValue(InterfaceConfig interfaceConfig, String objectSuffix, String propertySuffix,
									 IInterface iInterface) {
		interfaceConfig.putToCacheConfigMap(objectSuffix, getCorrectValue(iInterface, propertySuffix));
	}

	/**
	 * Add the value to the connectionMap.
	 *
	 * @param interfaceConfig The interfaceConfig to fill
	 * @param objectSuffix    The suffix of the key without the CONNECTION_PREFIX. Ex: url
	 * @param propertySuffix  The suffix of the key with the CONNECTION_PREFIX. Ex: connection.url
	 * @param iInterface      The iInterface that contains the interfaceKey and the groupKey
	 */
	private void addConnectionValue(InterfaceConfig interfaceConfig,
									String objectSuffix,
									String propertySuffix,
									IInterface iInterface) {
		String value = getCorrectValue(iInterface, propertySuffix);

		// For the base_url and request_path, we need to concat and put it in the map with the url key
		if (BASE_URL.equals(objectSuffix) || REQUEST_PATH.equals(objectSuffix)) {
			String url = getCorrectValue(iInterface, CONNECTION_PREFIX + URL);

			String baseUrl = getCorrectValue(iInterface, CONNECTION_PREFIX + BASE_URL);
			String requestPath = getCorrectValue(iInterface, CONNECTION_PREFIX + REQUEST_PATH);
			if (StringUtils.isNotBlank(url)) {
				LOGGER.warn(MessageConstants.CONFIG_INTERFACE_WRONG_URL_WARN_MSG,
						iInterface.getInterfaceKey(), url, baseUrl, requestPath);
				return;
			}

			objectSuffix = URL;
			value = baseUrl + requestPath;
		}

		interfaceConfig.putToConnectionMap(objectSuffix, value);
	}

	/**
	 * Add the value to the urlParameterMap.
	 *
	 * @param interfaceConfig The interfaceConfig to fill
	 * @param objectSuffix    The suffix of the key without the URL_PARAMETERS_PREFIX. Ex: shop_id
	 * @param propertySuffix  The suffix of the key with the URL_PARAMETERS_PREFIX. Ex: url_parameter.shop_id
	 * @param iInterface      The iInterface that contains the interfaceKey and the groupKey
	 */
	private void addUrlParameterValue(InterfaceConfig interfaceConfig,
									  String objectSuffix,
									  String propertySuffix,
									  IInterface iInterface) {
		interfaceConfig.putToUrlParameterMap(objectSuffix, getCorrectValue(iInterface, propertySuffix));
	}

	/**
	 * Add the value to the headerMap
	 *
	 * @param interfaceConfig The interfaceConfig to fill
	 * @param objectSuffix    The suffix of the key without the HEADER_PREFIX. Ex: X-Client-Id
	 * @param propertySuffix  The suffix of the key with the HEADER_PREFIX. Ex: headerParameters.X-Client-Id
	 * @param iInterface      The iInterface that contains the interfaceKey and the groupKey
	 */
	private void addHeaderValue(InterfaceConfig interfaceConfig,
								String objectSuffix,
								String propertySuffix,
								IInterface iInterface) {
		interfaceConfig.putToHeaderMap(objectSuffix, getCorrectValue(iInterface, propertySuffix));
	}

	/**
	 * This method get the value from Spring so that we do not need to handle the priority of the property files.
	 * The interface value overrides the group value.
	 *
	 * @param iInterface The iInterface that contains the interfaceKey and the groupKey
	 * @param suffix     The suffix of the property to load
	 * @return The correct value
	 */
	private String getCorrectValue(IInterface iInterface, String suffix) {
		String value = env.getProperty(iInterface.getInterfaceKey() + UNION + suffix);

		if (value == null && StringUtils.isNotBlank(iInterface.getGroupKey())) {
			value = env.getProperty(iInterface.getGroupKey() + UNION + suffix);
		}

		if (value == null) {
			value = env.getProperty(GLOBAL_PREFIX + suffix);
		}
		return value;
	}

	/**
	 * Internal function handling individual MapPropertySource
	 *
	 * @param propertySource   the MapPropertySource holding the key-value pairs of properties
	 * @param interfaces       Collection of runtime interfaces
	 * @param interfaceMapTemp Temporary collection of interfaces according to the refresh/loading
	 */
	private void processMapPropertySource(MapPropertySource propertySource,
										  Collection<IInterface> interfaces,
										  Map<String, InterfaceConfig> interfaceMapTemp) {
		Map<String, Object> propertyMap = propertySource.getSource();
		propertyMap.forEach((String key, Object value) -> compareKeysAndAddValue(interfaces, interfaceMapTemp, key));
	}

	/**
	 * This method recursively extracts the underlying {@code MapPropertySource} inside {@code CompositePropertySource}
	 *
	 * @param compositePropertySource the wrapper that contains multiple MapPropertySources (i.e. local & external)
	 * @return {@code ArrayList<MapPropertySource>} flat list of the sources retained in the same ordering.
	 */
	private Collection<MapPropertySource> extractMapPropertySources(CompositePropertySource compositePropertySource) {
		Collection<MapPropertySource> mapPropertySources = new ArrayList<>();
		compositePropertySource.getPropertySources().forEach((PropertySource innerPropertySource) -> {
			if (innerPropertySource instanceof MapPropertySource) {
				mapPropertySources.add((MapPropertySource) innerPropertySource);
			} else if (innerPropertySource instanceof CompositePropertySource) {
				mapPropertySources.addAll(extractMapPropertySources((CompositePropertySource) innerPropertySource));
			}
		});
		return mapPropertySources;
	}

	/**
	 * Return the list of the interfaces.
	 *
	 * @return The configuration of the interface, extracted from the property files
	 */
	public Collection<InterfaceConfig> getInterfaceConfig() {
		return interfaceMap.values();
	}

	/**
	 * Return the map of the interfaces containing the information extracted from the property files.
	 *
	 * @param interfaceKey The key of the interface we want to get
	 * @return The configuration of the interface, extracted from the property files
	 */
	public InterfaceConfig getInterface(String interfaceKey) {
		return interfaceMap.get(interfaceKey);
	}
}
