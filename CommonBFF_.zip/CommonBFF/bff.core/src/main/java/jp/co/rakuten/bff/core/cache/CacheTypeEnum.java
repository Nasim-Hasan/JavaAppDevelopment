package jp.co.rakuten.bff.core.cache;

import java.util.HashMap;
import java.util.Map;

/**
 * Cache type enum
 */
public enum CacheTypeEnum {
	LOCAL("local"),
	LOCAL_AND_SHARED("local_and_shared"),
	SHARED("shared");

	private static final Map<String, CacheTypeEnum> mappings = new HashMap<>();

	private String cacheType;

	/**
	 * Constructs CacheTypeEnum
	 */
	CacheTypeEnum(String cacheType) {
		this.cacheType = cacheType;
	}

	static {
		for (CacheTypeEnum cacheTypeEnum : values()) {
			mappings.put(cacheTypeEnum.cacheType, cacheTypeEnum);
		}
	}

	/**
	 * Get CacheTypeEnum for a string cacheType
	 * @param name string cacheType for which instance will be returned
	 * @return  CacheTypeEnum instance will be returned
	 */
	public static CacheTypeEnum resolve(String name) {
		return (name != null ? mappings.get(name) : null);
	}
}
