package jp.co.rakuten.bff.core.config.json;

import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.InputStream;

/**
 * The type Local json loader.
 * Load local json file for api, api config and interface
 */
@Component
public class LocalJsonLoader implements JsonLoader {

	@Override
	public <T> Mono<T> load(String path, Class<T> classType) {
		Resource resource = new ClassPathResource(path);
		try (InputStream jsonInStream = resource.getInputStream()) {
			return Mono.just(new ObjectMapper().readValue(jsonInStream, classType));
		} catch (IOException e) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, e, path + MessageConstants.CONFIG_CLOUD_READ_JSON_ERROR_MSG);
		}
	}
}
