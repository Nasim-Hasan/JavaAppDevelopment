package jp.co.rakuten.bff.core.cache;

import com.github.benmanes.caffeine.cache.Cache;
import io.micrometer.core.instrument.MeterRegistry;
import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.event.OnInterfacesLoadedEvent;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static jp.co.rakuten.bff.core.cache.CacheTypeEnum.*;
import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * This component handles the app's caching tasks.
 * It stores and retrieves data from local and shared cache
 * It also has the capability to automatically load cache configuration.
 */
@Service
public class IchibaCacheManager implements ApplicationListener<OnInterfacesLoadedEvent> {
	private static final Logger LOGGER = LoggerFactory.getLogger(IchibaCacheManager.class);

	private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;
	private Map<String, Cache<String, Map<String, Object>>> localCacheHandlerMap = new ConcurrentHashMap<>();
	private Map<String, RedisCacheStats> redisCacheStatsMap = new ConcurrentHashMap<>();
	private Map<String, Map<String, String>> existingCacheConfigMap = new ConcurrentHashMap<>();
	private IchibaCacheManagerHelper ichibaCacheManagerHelper;
	private MeterRegistry meterRegistry;

	/**
	 * Default constructor.
	 *
	 * @param reactiveRedisTemplate 	client to interact with shared cache server
	 * @param ichibaCacheManagerHelper	{@link IchibaCacheManagerHelper}
	 * @param meterRegistry        {@link MeterRegistry}
	 */
	public IchibaCacheManager(ReactiveRedisTemplate<String, Object> reactiveRedisTemplate,
							  IchibaCacheManagerHelper ichibaCacheManagerHelper, MeterRegistry meterRegistry) {
		this.reactiveRedisTemplate = reactiveRedisTemplate;
		this.ichibaCacheManagerHelper = ichibaCacheManagerHelper;
		this.meterRegistry = meterRegistry;
	}

	/**
	 * This is automatically called on actuator refresh or application load.
	 * It loads the local cache instances and cache configurations
	 * It initiates shared cache counters as well
	 *
	 * @param event {@link OnInterfacesLoadedEvent}
	 */
	@Override
	public void onApplicationEvent(OnInterfacesLoadedEvent event) {
		try {
			Collection<InterfaceConfig> interfaceConfigList = event.getInterfaceConfigs();
			for (InterfaceConfig config : interfaceConfigList) {
				Map<String, String> newCacheConfigMap = config.getCacheConfigMap();
				Map<String, String> existingConfigMap = existingCacheConfigMap.get(config.getInterfaceKey());
				if (!redisCacheStatsMap.containsKey(config.getInterfaceKey())) {
					redisCacheStatsMap.put(config.getInterfaceKey(), new RedisCacheStats());
				}
				loadCacheResources(config, newCacheConfigMap, existingConfigMap, localCacheHandlerMap);
			}
		} catch (Exception ex) {
			LOGGER.error(MessageConstants.CACHE_RESOURCES_LOAD_ERROR, ex);
		}
	}

	/**
	 * It loads/reloads the local cache instances and cache configurations
	 *
	 * @param config               {@link InterfaceConfig}
	 * @param newCacheConfigMap    config map that has new configurations
	 * @param existingConfigMap    existing config map whose values will be compared with new
	 * @param localCacheHandlerMap map that contains local cache instances
	 */
	private synchronized void loadCacheResources(InterfaceConfig config, Map<String, String> newCacheConfigMap,
												Map<String, String> existingConfigMap,
												Map<String, Cache<String, Map<String, Object>>> localCacheHandlerMap) {
		// If old and new configurations have difference, there is change
		if ((CollectionUtils.isEmpty(existingConfigMap) || ichibaCacheManagerHelper
				.hasDifference(newCacheConfigMap, existingConfigMap))) {
			// Reload the local cache instance with new configurations
			ichibaCacheManagerHelper.reloadLocalCache(config, newCacheConfigMap, localCacheHandlerMap, meterRegistry);
			// If reload was successful, replace existing cache config map with new one
			ichibaCacheManagerHelper.reloadExistingCacheConfigMap(config, newCacheConfigMap, existingCacheConfigMap);
		}
	}

	/**
	 * It fetches data from local and/or shared cache based on configuration
	 *
	 * @param featureTemplate  {@link FeatureTemplate}
	 * @param validatedRequest contains user provided parameters
	 * @param header           contains header values from user
	 * @param apiKey           api key formed using service, operation and version
	 * @return map response from cache if exists
	 */
	public Mono<CacheDataModel> getFromCache(FeatureTemplate featureTemplate,
											 Map<String, CommonRequestModel> validatedRequest, HttpHeaders header,
											 String apiKey) {
		if (!ichibaCacheManagerHelper.isNoCacheSet(header)) {
			RedisCacheStats redisCacheStats = null;
			IchibaCacheConfiguration cacheConfiguration = ichibaCacheManagerHelper
					.getIchibaCacheConfiguration(featureTemplate.getName(), existingCacheConfigMap);
			if (ObjectUtils.isNotEmpty(cacheConfiguration)) {
				Cache<String, Map<String, Object>> cacheHandler = localCacheHandlerMap.get(featureTemplate.getName());
				if (LOCAL_AND_SHARED == cacheConfiguration.getCacheType() ||
						SHARED == cacheConfiguration.getCacheType()) {
					redisCacheStats = redisCacheStatsMap.get(featureTemplate.getName());
				}
				String cacheKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, apiKey);
				return getFromCache(cacheKey, cacheConfiguration, cacheHandler, redisCacheStats);
			} else {
				LOGGER.info(MessageConstants.CACHE_IS_DISABLED_MSG, featureTemplate.getName());
				return Mono.empty();
			}
		} else {
			LOGGER.info(CACHE_HEADER_NO_CACHE + MessageConstants.NO_CACHE_HEADER_MSG, featureTemplate.getName());
			return Mono.empty();
		}
	}

	/**
	 * It fetches data from local and/or shared cache based on configuration
	 *
	 * @param cacheKey     key with which cache data to be saved
	 * @param interfaceKey name of the feature
	 * @param header       contains header values from user
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<CacheDataModel> getFromCache(String cacheKey, String interfaceKey, HttpHeaders header) {
		RedisCacheStats redisCacheStats = null;
		IchibaCacheConfiguration cacheConfiguration = ichibaCacheManagerHelper
				.getIchibaCacheConfiguration(interfaceKey, existingCacheConfigMap);
		if (ObjectUtils.isNotEmpty(cacheConfiguration)) {
			if (LOCAL_AND_SHARED == cacheConfiguration.getCacheType() ||
					SHARED == cacheConfiguration.getCacheType()) {
				redisCacheStats = redisCacheStatsMap.get(interfaceKey);
			}
			Cache<String, Map<String, Object>> cacheHandler = localCacheHandlerMap.get(interfaceKey);
			return getFromCache(cacheKey, cacheConfiguration, cacheHandler, redisCacheStats);
		} else {
			LOGGER.info(MessageConstants.CACHE_IS_DISABLED_MSG, interfaceKey);
			return Mono.empty();
		}
	}

	/**
	 * It fetches data from local and/or shared cache based on configuration
	 *
	 * @param key                key with which cache data to be saved
	 * @param cacheConfiguration configuration to be used caching {@link IchibaCacheConfiguration}
	 * @param cacheHandler       local cache instance to be used for local caching
	 * @param redisCacheStats    Contains redis cache stats counters
	 * @return   map response from cache if exists
	 */
	public Mono<CacheDataModel> getFromCache(String key, IchibaCacheConfiguration cacheConfiguration,
											 Cache<String, Map<String, Object>> cacheHandler,
											 RedisCacheStats redisCacheStats) {
		Mono<CacheDataModel> cachedData = Mono.empty();
		if (ObjectUtils.isNotEmpty(cacheConfiguration)) {
			if (LOCAL_AND_SHARED == cacheConfiguration.getCacheType() && !ObjectUtils
					.isEmpty(cacheHandler)) {
				Map<String, Object> localCachedData = getFromLocalCache(cacheHandler, key);
				cachedData = processLocalCacheData(key, cacheConfiguration, cacheHandler, localCachedData,
						redisCacheStats);
			} else if (CacheTypeEnum.SHARED == cacheConfiguration.getCacheType()) {
				LOGGER.debug(MessageConstants.CACHE_SHARED_FETCH_INFO, key);
				cachedData = getFromSharedCache(key, cacheConfiguration, cacheHandler, false, redisCacheStats);
			} else if (CacheTypeEnum.LOCAL == cacheConfiguration.getCacheType() && !ObjectUtils.isEmpty(cacheHandler)) {
				LOGGER.debug(MessageConstants.CACHE_LOCAL_FETCH_INFO, key);
				Map<String, Object> fromLocalCache = getFromLocalCache(cacheHandler, key);
				cachedData = fromLocalCache != null ? Mono.just(new CacheDataModel(fromLocalCache)) : Mono.empty();
			}
		}
		return cachedData;
	}

	/**
	 * It validate local cache data and logs status
	 *
	 * @param key                key with which cache data to be saved
	 * @param cacheConfiguration configuration to be used caching {@link IchibaCacheConfiguration}
	 * @param cacheHandler       local cache instance to be used for local caching
	 * @param localCachedData    data got from local cache
	 *
	 * @return   map response from cache if exists
	 */
	private Mono<CacheDataModel> processLocalCacheData(String key, IchibaCacheConfiguration cacheConfiguration,
													   Cache<String, Map<String, Object>> cacheHandler,
													   Map<String, Object> localCachedData,
													   RedisCacheStats redisCacheStats) {
		Mono<CacheDataModel> cachedData;
		if (MapUtils.isEmpty(localCachedData) || ichibaCacheManagerHelper.isLocalCacheExpired(localCachedData)) {
			LOGGER.info(MessageConstants.CACHE_LOCAL_NOT_FOUND_INFO, key);
			cachedData = getFromSharedCache(key, cacheConfiguration, cacheHandler, true, redisCacheStats);
		} else {
			LOGGER.info(MessageConstants.CACHE_LOCAL_DATA_FOUND_INFO, key);
			cachedData = Mono.just(new CacheDataModel(localCachedData));
		}
		return cachedData;
	}

	/**
	 * It fetches data from shared cache based on configuration
	 *  @param key                key with which cache data to be saved
	 * @param cacheConfiguration configuration to be used caching {@link IchibaCacheConfiguration}
	 * @param cacheHandler       local cache instance to be used for local caching
	 * @param syncLocal          indicator whether to sync shared cache with local
	 * @param redisCacheStats    Contains redis cache stats counters
	 */
	private Mono<CacheDataModel> getFromSharedCache(String key, IchibaCacheConfiguration cacheConfiguration,
													Cache<String, Map<String, Object>> cacheHandler, boolean syncLocal,
													RedisCacheStats redisCacheStats) {
		return reactiveRedisTemplate.opsForValue().get(key)
				.flatMap(data -> Mono.just((Map<String, Object>) data))
				.flatMap(
						sharedCacheData -> processSharedCacheData(cacheConfiguration, key, cacheHandler,
								sharedCacheData, syncLocal, redisCacheStats))
				.switchIfEmpty(Mono.defer(() -> {
					LOGGER.info(MessageConstants.CACHE_SHARED_NOT_FOUND_INFO, key);
					if (ObjectUtils.isNotEmpty(redisCacheStats)) {
						redisCacheStats.incrementMissCount();
					}
					return Mono.empty();
				}));
	}

	/**
	 * It sets cache data's stale status and also may sync data with local cache
	 *
	 * @param cacheConfiguration configuration to be used caching {@link IchibaCacheConfiguration}
	 * @param key                key with which cache data to be saved
	 * @param cacheHandler       local cache instance to be used for local caching
	 * @param sharedCacheData    data got from shared cached
	 * @param syncLocal          indicator whether to sync shared cache with local
	 */
	private Mono<CacheDataModel> processSharedCacheData(IchibaCacheConfiguration cacheConfiguration, String key,
														Cache<String, Map<String, Object>> cacheHandler,
														Map<String, Object> sharedCacheData, boolean syncLocal,
														RedisCacheStats redisCacheStats) {
		return getSharedCacheData(cacheConfiguration, key, cacheHandler, sharedCacheData, syncLocal,
				redisCacheStats);
	}

	private Mono<CacheDataModel> getSharedCacheData(IchibaCacheConfiguration cacheConfiguration, String key,
													Cache<String, Map<String, Object>> cacheHandler,
													Map<String, Object> sharedCacheData, boolean syncLocal,
													RedisCacheStats redisCacheStats) {
		return reactiveRedisTemplate.getExpire(key)
				.flatMap((Duration ttl) -> {
					if (cacheConfiguration.isStaleEnabled() && ttl.toMillis() < cacheConfiguration.getStaleTimeout()
							.toMillis()) {
						if (ObjectUtils.isNotEmpty(redisCacheStats)) {
							redisCacheStats.incrementStaleCount();
						}
						LOGGER.info(MessageConstants.CACHE_SHARED_DATA_EXPIRE_INFO, key);
						return Mono.just(new CacheDataModel(true, sharedCacheData));
					} else {
						LOGGER.info(MessageConstants.CACHE_SHARED_DATA_FOUND_INFO, key);
						if (ObjectUtils.isNotEmpty(redisCacheStats)) {
							redisCacheStats.incrementHitCount();
						}
						if (syncLocal) {
							LOGGER.info(MessageConstants.CACHE_LOCAL_SYNC_INFO, key);
							sharedCacheData.put(CACHE_EXPIRY_TIME,
							                    LocalDateTime.now().plus(ttl.toMillis(), ChronoUnit.MILLIS));
							setToLocalCache(cacheHandler, key, sharedCacheData);
						}
						return Mono.just(new CacheDataModel(sharedCacheData));
					}
				});
	}

	/**
	 * It sets data to shared cache based on configuration
	 *
	 * @param featureTemplate  {@link FeatureTemplate}
	 * @param validatedRequest contains user provided parameters
	 * @param data             data to be stored in cache
	 * @param header           contains header values from user
	 * @param apiKey           api key formed using service, operation and version
	 *
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<Boolean> setToCache(FeatureTemplate featureTemplate, Map<String, CommonRequestModel> validatedRequest,
									Map<String, Object> data, HttpHeaders header, String apiKey) {
		if (!ichibaCacheManagerHelper.isNoCacheSet(header)) {
			IchibaCacheConfiguration cacheConfiguration = ichibaCacheManagerHelper
					.getIchibaCacheConfiguration(featureTemplate.getName(), existingCacheConfigMap);
			if (ObjectUtils.isNotEmpty(cacheConfiguration)) {
				Cache<String, Map<String, Object>> cacheHandler = localCacheHandlerMap.get(featureTemplate.getName());
				String cacheKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, apiKey);

				return setToCache(data, cacheKey, cacheConfiguration, cacheHandler);
			} else {
				LOGGER.info(MessageConstants.CACHE_IS_DISABLED_MSG, featureTemplate.getName());
				return Mono.empty();
			}
		} else {
			LOGGER.info(CACHE_HEADER_NO_CACHE + MessageConstants.NO_CACHE_HEADER_MSG, featureTemplate.getName());
			return Mono.empty();
		}
	}

	/**
	 * It sets data to shared cache based on configuration
	 *
	 * @param cacheKey    key with which cache data to be saved
	 * @param data        data to be stored in cache
	 * @param featureName name of the feature
	 * @param header      contains header values from user
	 *
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<Boolean> setToCache(String cacheKey, Map<String, Object> data, String featureName, HttpHeaders header) {
		IchibaCacheConfiguration cacheConfiguration = ichibaCacheManagerHelper
				.getIchibaCacheConfiguration(featureName, existingCacheConfigMap);
		if (ObjectUtils.isNotEmpty(cacheConfiguration)) {
			Cache<String, Map<String, Object>> cacheHandler = localCacheHandlerMap.get(featureName);
			return setToCache(data, cacheKey, cacheConfiguration, cacheHandler);
		} else {
			LOGGER.info(MessageConstants.CACHE_IS_DISABLED_MSG, featureName);
			return Mono.empty();
		}
	}

	/**
	 * It sets data to shared cache based on configuration
	 *
	 * @param data               data to be stored in cache
	 * @param cacheKey           key with which cache data to be saved
	 * @param cacheConfiguration configuration to be used caching {@link IchibaCacheConfiguration}
	 * @param cacheHandler       local cache instance to be used for local caching
	 *
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<Boolean> setToCache(Map<String, Object> data, String cacheKey,
									IchibaCacheConfiguration cacheConfiguration,
									Cache<String, Map<String, Object>> cacheHandler) {
		Mono<Boolean> resultMono = Mono.empty();
		if (!ObjectUtils.isEmpty(cacheConfiguration)) {
			if (LOCAL_AND_SHARED == cacheConfiguration.getCacheType()) {
				LOGGER.info(MessageConstants.CACHE_SAVE_LOCAL_SHARED_INFO, cacheKey);
				Duration sharedCacheTimeout = ichibaCacheManagerHelper.getSharedCacheTimeout(cacheConfiguration);
				Mono<Boolean> localCacheMono = Mono.just(setToLocalCache(cacheHandler, cacheKey, data));
				Mono<Boolean> sharedCacheMono = reactiveRedisTemplate.opsForValue().set(cacheKey, data,
						sharedCacheTimeout);
				resultMono = Mono.zip(localCacheMono, sharedCacheMono).map(Tuple2::getT2);
			} else if (CacheTypeEnum.SHARED == cacheConfiguration.getCacheType()) {
				LOGGER.info(MessageConstants.CACHE_SAVE_SHARED_INFO, cacheKey);
				Duration sharedCacheTimeout = ichibaCacheManagerHelper.getSharedCacheTimeout(cacheConfiguration);
				resultMono = reactiveRedisTemplate.opsForValue().set(cacheKey, data, sharedCacheTimeout);
			} else if (CacheTypeEnum.LOCAL == cacheConfiguration.getCacheType()) {
				LOGGER.info(MessageConstants.CACHE_SAVE_LOCAL_INFO, cacheKey);
				resultMono = Mono.just(setToLocalCache(cacheHandler, cacheKey, data));
			}
		}
		return resultMono;
	}

	/**
	 * It gets data from local cache based on configuration
	 *
	 * @param cacheHandler local cache instance to be used for local caching
	 * @param key          key with which cache data to be saved
	 */
	private Map<String, Object> getFromLocalCache(Cache<String, Map<String, Object>> cacheHandler, String key) {
		return cacheHandler.getIfPresent(key);
	}

	/**
	 * It sets data to shared cache based on configuration
	 *
	 * @param cacheHandler local cache instance to be used for local caching
	 * @param key          key with which cache data to be saved
	 * @param data         data to be stored in cache
	 *
	 * @return flag indicating whether operation was successful or not
	 */
	public boolean setToLocalCache(Cache<String, Map<String, Object>> cacheHandler, String key,
								   Map<String, Object> data) {
		try {
			cacheHandler.put(key, data);
			return true;
		} catch (Exception ex) {
			LOGGER.error(MessageConstants.CACHE_SAVE_LOCAL_ERROR, ex);
		}
		return false;
	}

	/**
	 * It sets activeFlagTimeout flag to shared cache
	 *
	 * @param cacheKey key of the cache that needs to be fetched
	 * @param activeFlagTimeout activeFlagTimeout flag's expiry time in cache
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<Boolean> setStaleActiveFlagToCache(String cacheKey, long activeFlagTimeout) {
		return reactiveRedisTemplate.opsForValue().set(cacheKey, true, Duration.ofMillis(activeFlagTimeout));
	}

	/**
	 * It fetches staleActive Flag from shared cache
	 *
	 * @param cacheKey key of the cache that needs to be fetched
	 * @return staleActive Flag from cache if exists
	 */
	public Mono<Object> getStaleActiveFlagFromCache(String cacheKey) {
		return reactiveRedisTemplate.opsForValue().get(cacheKey);
	}

	/**
	 * It sets activeFlagTimeout flag to shared cache
	 *
	 * @param featureTemplate   {@link FeatureTemplate}
	 * @param validatedRequest  contains user provided parameters
	 * @param apiKey            api key formed using service, operation and version
	 * @param activeFlagTimeout activeFlagTimeout flag's expiry time in cache
	 * @return flag indicating whether operation was successful or not
	 */
	public Mono<Boolean> setStaleActiveFlagToCache(FeatureTemplate featureTemplate,
	                                               Map<String, CommonRequestModel> validatedRequest, String apiKey,
	                                               long activeFlagTimeout) {
		String cacheKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, apiKey);
		return reactiveRedisTemplate.opsForValue().set(cacheKey + STALE_ACTIVE_KEY_SUFFIX, true,
		                                               Duration.ofMillis(activeFlagTimeout));
	}

	/**
	 * It fetches staleActive Flag from shared cache
	 *
	 * @param featureTemplate  {@link FeatureTemplate}
	 * @param validatedRequest contains user provided parameters
	 * @param apiKey           api key formed using service, operation and version
	 * @return staleActive Flag from cache if exists
	 */
	public Mono<Object> getStaleActiveFlagFromCache(FeatureTemplate featureTemplate,
	                                                Map<String, CommonRequestModel> validatedRequest, String apiKey) {
		String cacheKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, apiKey);
		return reactiveRedisTemplate.opsForValue().get(cacheKey + STALE_ACTIVE_KEY_SUFFIX);
	}

	/**
	 * gives shared cache stats
	 *
	 * @return shared cache stats
	 */
	public Map<String, RedisCacheStats> getSharedCacheStats() {
		Map<String, RedisCacheStats> cacheStatsMap = new HashMap<>();
		try {
			for (Map.Entry<String, RedisCacheStats> entry : redisCacheStatsMap.entrySet()) {
				RedisCacheStats value = entry.getValue();
				if (ObjectUtils.isNotEmpty(value)) {
					cacheStatsMap.put(entry.getKey(), new RedisCacheStats(value.getHitCount(), value.getMissCount(),
							value.getStaleCount()));
				}
			}
		} catch (Exception e) {
			LOGGER.error(MessageConstants.CACHE_SHARED_STATS_PROCESS_ERROR, e);
		}
		return cacheStatsMap;
	}
}
