package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This POJO holds -
 * <ul>
 *     <li>Feature name</li>
 *     <li>This feature's interface list</li>
 *     <li>Processor bean - {@link FeatureProcessor}</li>
 *     <li>Feature's related {@link CallDefinitionTemplate} set</li>
 *     <li>{@link RequestSchema} - which holds features list of request parameter map</li>
 *     <li>{@link ResponseSchema} - which holds features list of response parameter map</li>
 * </ul>
 */
public class FeatureTemplate {
	@JsonProperty("processor")
	private String processorName;
	@JsonProperty("interfaces")
	private List<String> interfaceNameList = new ArrayList<>();
	@JsonProperty("subFeatures")
	private Map<String, List<String>> subFeatures = new HashMap<>();

	@JsonIgnore
	private String name;
	@JsonIgnore
	private Integer id;
	@JsonIgnore
	private FeatureProcessor processorBean;
	@JsonIgnore
	private Map<String, InterfaceTemplate> interfacesMap = new HashMap<>();
	@JsonIgnore
	private Set<CallDefinitionTemplate> callDefinitionsSet = new HashSet<>();

	// Used for validation:
	@JsonProperty("request")
	private RequestSchema request;
	@JsonProperty("response")
	private ResponseSchema response;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProcessorName() {
		return this.processorName;
	}

	public List<String> getInterfaceNameList() {
		return this.interfaceNameList;
	}

	public String getName() {
		return this.name;
	}

	public FeatureProcessor getProcessorBean() {
		return this.processorBean;
	}

	public Set<CallDefinitionTemplate> getCallDefinitionsSet() {
		return this.callDefinitionsSet;
	}

	public RequestSchema getRequest() {
		return this.request;
	}

	public ResponseSchema getResponse() {
		return this.response;
	}

	public void setInterfacesMap(Map<String, InterfaceTemplate> interfacesMap) {
		this.interfacesMap = interfacesMap;
	}

	public void setProcessorName(String processorName) {
		this.processorName = processorName;
	}

	public void setInterfaceNameList(List<String> interfaceNameList) {
		this.interfaceNameList = interfaceNameList;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setProcessorBean(FeatureProcessor processorBean) {
		this.processorBean = processorBean;
	}

	public void setCallDefinitionsSet(Set<CallDefinitionTemplate> callDefinitionsSet) {
		this.callDefinitionsSet = callDefinitionsSet;
	}

	public void setRequest(RequestSchema request) {
		this.request = request;
	}

	public void setResponse(ResponseSchema response) {
		this.response = response;
	}

	public Map<String, InterfaceTemplate> getInterfacesMap() {
		return interfacesMap;
	}

	public Map<String, List<String>> getSubFeatures() {
		return subFeatures;
	}

	public void setSubFeatures(Map<String, List<String>> subFeatures) {
		this.subFeatures = subFeatures;
	}

	@Override
	public String toString() {
		return "FeatureTemplate{" +
				"processorName='" + processorName + '\'' +
				", interfaceNameList=" + interfaceNameList +
				", name='" + name + '\'' +
				", id=" + id +
				", processorBean=" + processorBean +
				", interfacesMap=" + interfacesMap +
				", callDefinitionsSet=" + callDefinitionsSet +
				", request=" + request +
				", response=" + response +
				'}';
	}
}
