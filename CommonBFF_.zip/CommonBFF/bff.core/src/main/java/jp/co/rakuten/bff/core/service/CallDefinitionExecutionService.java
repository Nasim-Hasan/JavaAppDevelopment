package jp.co.rakuten.bff.core.service;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * This component do 3 major task.<br/>
 * <ul>
 *     <li>Run generic call definition pre-processor which will prepare generic gateway call parameter based on config
 *     file and client request.</li>
 *     <li>Make decision - this call definition should call or not.</li>
 *     <li>Decide which type of call definition call ( single/parallel/complex ) this is and call call definition client
 *     accordingly.</li>
 * </ul>
 */
public interface CallDefinitionExecutionService {

	/**
	 * First decide provided call definition should call or not, then take the action accordingly.<br/>
	 * If dependent call definition resolved properly then return the call definition response mono. <br/>
	 * Else return pre-define error response mono.
	 *
	 * @param callDefinitionTemplate    CallDefinitionTemplate - holds processor, interface list and dependency list
	 * @param validatedRequest          Validated request - feature name as key and {@link CommonRequestModel} as value
	 * @param apiTemplate               ApiTemplate - holds api specific {@link InterfaceTemplate},
	 *                                  {@link CallDefinitionTemplate}, {@link FeatureTemplate}
	 * @param executionModel            Execution Model
	 * @param callDefinitionResponseMap Map<String, Object> - holds already resolved call definition response.
	 *                                  Key - call definition name, Value - call definition response object
	 * @param headers                   contains header values from user
     * @param mockConnections           contains  connections information for mock backends
	 * @return Mono<Object> - Call definition response mono.
	 */
	Mono<CallDefinitionResponse> getCallDefinitionResponse(CallDefinitionTemplate callDefinitionTemplate,
														   Map<String, CommonRequestModel> validatedRequest,
														   ApiTemplate apiTemplate, ExecutionModel executionModel,
														   Map<String, CallDefinitionResponse> callDefinitionResponseMap,
														   HttpHeaders headers, Map<String,?> mockConnections);
}
