package jp.co.rakuten.bff.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * This utility class helps with deep copying of objects
 *
 */
public class DeepCopyUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeepCopyUtil.class);

	private DeepCopyUtil() {
	}

	/**
	 * Create a deep copy of the data. It means all the sub-elements of the data are copied as well.
	 *
	 * @param source The initial data
	 * @param typeParameterClass class of generic type parameter
	 * @return The deep copy or null in case of error during copying
	 */
	public static <T> T deepCopy(T source, Class<T> typeParameterClass) {
		// Keep a String in the InterfaceConfig VS Copy deeply the map: Run a perf test to decide
		ObjectMapper objectMapper = MapUtil.getObjectMapper();
		try {
			return objectMapper.readValue(objectMapper.writeValueAsString(source), typeParameterClass);
		} catch (IOException e) {
			LOGGER.error("Unable to create a deep copy of the template body", e);
		}
		return null;
	}
}
