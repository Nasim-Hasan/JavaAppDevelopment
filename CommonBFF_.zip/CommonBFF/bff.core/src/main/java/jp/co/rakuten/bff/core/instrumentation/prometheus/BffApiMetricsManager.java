package jp.co.rakuten.bff.core.instrumentation.prometheus;

import com.rakuten.rapid.metrics.core.RapidMetricsManager;
import com.rakuten.rapid.metrics.core.RapidMetricsRegistry;
import com.rakuten.rapid.metrics.core.record.RapidCounter;
import com.rakuten.rapid.metrics.core.record.RapidHistogram;
import com.rakuten.rapid.metrics.core.record.RapidMultiMeter;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *     This  class is responsible for creating metrics for incoming requests
 * </p>
 */
public class BffApiMetricsManager {

	private static RapidMetricsRegistry apiRequestRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.requests", true);
    private static RapidMetricsRegistry apiSlowRequestRegistry=
            RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.slow.requests", true);
	private static RapidMetricsRegistry apiRequestTimeRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.time", true);
	private static RapidMetricsRegistry apiResponseTimeHistogramRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.time.histogram", true);
	private static RapidMetricsRegistry apiRequestHttpStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.httpStatus", true);
	private static RapidMetricsRegistry apiClientRequestsRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.client.requests", true);
	private static RapidMetricsRegistry apiErrorTypeRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.errorType", true);

	private static long slowRequestThreshold;
	private static ConcurrentHashMap<String,RapidCounter> apiRequestMetrics =new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String,RapidCounter> apiSlowRequestMetrics =new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String,RapidCounter> apiRequestTimeMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> apiClientRequestsMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> apiRequestHttpStatusMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> apiErrorTypeMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidHistogram> apiResponseTimeHistogramMetrics=new ConcurrentHashMap<>();


	private BffApiMetricsManager(){}
	/**
	 * Creates metrics at the application Boot Time
	 * @param apiRepository apis map
	 */
	public static void initialize(ApiRepository apiRepository, Environment environment) {
        slowRequestThreshold=environment.getProperty("api.slow.requests.threshold.time",Long.class,2000L);
        Map<String, ApiTemplate> apiTemplateMap=apiRepository.getAllApiTemplates();
		initApiMetrics(apiTemplateMap.keySet());
	}

	/**
	 * init api requestType metrics
	 * @param keySet apiKeys
	 */
	private static void initApiMetrics(Set keySet) {
		for (Object apiKey : keySet) {
			String apiName = String.valueOf(apiKey);
			if (ObjectUtils.isEmpty(apiResponseTimeHistogramMetrics.get(apiName))) {
				apiResponseTimeHistogramMetrics.put(apiName,
						apiResponseTimeHistogramRegistry.histogram(apiName, 1L, TimeUnit.MINUTES));
			}
			if (ObjectUtils.isEmpty(apiRequestMetrics.get(apiName))) {
				apiRequestMetrics.putIfAbsent(apiName, apiRequestRegistry.counter(apiName));
			}
            if (ObjectUtils.isEmpty(apiSlowRequestMetrics.get(apiName))) {
                apiSlowRequestMetrics.putIfAbsent(apiName, apiSlowRequestRegistry.counter(apiName));
            }
			if (ObjectUtils.isEmpty(apiRequestTimeMetrics.get(apiName))) {
				apiRequestTimeMetrics.putIfAbsent(apiName, apiRequestTimeRegistry.counter(apiName));
			}
			if (ObjectUtils.isEmpty(apiClientRequestsMetrics.get(apiName))) {
				apiClientRequestsMetrics.putIfAbsent(apiName, apiClientRequestsRegistry.multiMeter(apiName));
			}
			if (ObjectUtils.isEmpty(apiRequestHttpStatusMetrics.get(apiName))) {
				apiRequestHttpStatusMetrics.putIfAbsent(apiName, apiRequestHttpStatusRegistry.multiMeter(apiName));
			}
			if (ObjectUtils.isEmpty(apiErrorTypeMetrics.get(apiName))) {
				apiErrorTypeMetrics.putIfAbsent(apiName, apiErrorTypeRegistry.multiMeter(apiName));
			}
		}
	}

	/** Called at the start of api HTTP Request execution
	 * @param apiKey hte apiname
	 * @param featureList {@code List<FeatureTemplate>}
	 * @param clientId the clientid
	 */
	public static void markEntry(String apiKey, List<FeatureTemplate> featureList, String clientId){
		if (ObjectUtils.isNotEmpty(apiRequestMetrics.get(apiKey))) {
			apiRequestMetrics.get(apiKey).increment();
		}
		if(ObjectUtils.isNotEmpty(apiRequestMetrics.get(apiKey)) && clientId!=null) {
			apiClientRequestsMetrics.get(apiKey).mark(clientId);
		}
		BffFeatureMetricsManager.markFeatureEntry(apiKey,featureList);
	}

	/** Called at the end of api HTTP Request .
	 *  Marks HttpStatus per apiName. ( This status will come from the api Model )
	 *  Marks errorType per apiName.
	 * @param apiKey the apiKey
	 * @param httpCode the http status code in string
	 * @param errorType the errorType from the exception module.
	 */
	public static void markExit(String apiKey, HttpStatus httpCode, String errorType) {
		if (ObjectUtils.isNotEmpty(apiRequestHttpStatusMetrics.get(apiKey))) {
			apiRequestHttpStatusMetrics.get(apiKey).mark(String.valueOf(httpCode.value()));
		}
		if(ObjectUtils.isNotEmpty(apiRequestHttpStatusMetrics.get(apiKey)) && errorType!=null){
			apiErrorTypeMetrics.get(apiKey).mark(errorType);
		}
	}


	/**
	 Called at the End of mono execution
	 * @param apiKey api Name
	 * @param startTime starttime of mono execution
	 */
	public static void stopExecutionTime(String apiKey,long startTime) {
        long duration=System.currentTimeMillis() - startTime;
		if (ObjectUtils.isNotEmpty(apiRequestTimeMetrics.get(apiKey))
				&& ObjectUtils.isNotEmpty(apiResponseTimeHistogramMetrics.get(apiKey))) {
			apiRequestTimeMetrics.get(apiKey).increment(duration);
			apiResponseTimeHistogramMetrics.get(apiKey).update(duration);
		}
		if(ObjectUtils.isNotEmpty(apiSlowRequestMetrics.get(apiKey)) && duration > slowRequestThreshold){
            apiSlowRequestMetrics.get(apiKey).increment();
        }
	}
}
