package jp.co.rakuten.bff.core.model.http;

import java.util.HashMap;
import java.util.Map;

/**
 * Call definition client response format- holds<br/>
 * <ul>
 *     <li>1. Overall Status</li>
 *     <li>2. {@link CustomHttpResponse} list</li>
 * </ul>
 */
public class MultipleResponses {
	/** The overall status, such as SUCCESS, PARTIAL_FAILURE or FAILURE */
	private String overallStatus;
	/** The list of the responses */
	private Map<String, CustomHttpResponse> responses;

	/**
	 * Default constructor
	 * @param overallStatus overall status
	 * @param responses {@link CustomHttpResponse} list
	 */
	public MultipleResponses(String overallStatus, Map<String, CustomHttpResponse> responses) {
		this.overallStatus = overallStatus;
		this.responses = responses;
	}

	public MultipleResponses() {
	}

	public String getOverallStatus() {
		return this.overallStatus;
	}

	public Map<String, CustomHttpResponse> getResponses() {
		return this.responses != null ? this.responses : new HashMap<>();
	}

	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public void setResponses(Map<String, CustomHttpResponse> responses) {
		this.responses = responses;
	}

	public String toString() {
		return "MultipleResponses(overallStatus=" + this.getOverallStatus() + ", responses=" + this.getResponses() +
				")";
	}
}
