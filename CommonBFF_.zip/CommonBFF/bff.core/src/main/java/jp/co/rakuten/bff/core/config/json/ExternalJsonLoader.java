package jp.co.rakuten.bff.core.config.json;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.util.FileUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static reactor.core.publisher.Mono.*;

/**
 * The type External json loader.
 */
@Component
public class ExternalJsonLoader implements JsonLoader {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExternalJsonLoader.class);

	private String cloudConfigUrlPrefix;
	private Environment env;
	private WebClient.Builder webClientBuilder;

	/**
	 * Constructor for the autowired resources
	 *
	 * @param env              from the application context. used to fetch environment properties and values.
	 * @param webClientBuilder The WebClient builder
	 */
	@Autowired
	ExternalJsonLoader(Environment env, WebClient.Builder webClientBuilder) {
		this.env = env;
		this.webClientBuilder = webClientBuilder;
	}

	/**
	 * Initialization method
	 */
	@PostConstruct
	void init() {
		updateCloudConfigUrlPrefix();
		LOGGER.info(MessageConstants.CONFIG_CLOUD_URL_PREFIX_INFO, cloudConfigUrlPrefix);
	}

	private String updateCloudConfigUrlPrefix() {
		String uri = env.getProperty(SPRING_CLOUD_CONFIG_URI);
		String applicationName = env.getProperty(SPRING_APPLICATION_NAME);
		String profile = env.getProperty(SPRING_PROFILES_ACTIVE);
		String cloudConfigLabel = env.getProperty(SPRING_CLOUD_CONFIG_LABEL);
		if (StringUtils.isNoneBlank(uri, applicationName, profile, cloudConfigLabel)) {
			cloudConfigLabel = cloudConfigLabel.replace(PATH_FRONT_SLASH, "(_)");
			cloudConfigUrlPrefix = uri
					+ PATH_FRONT_SLASH + applicationName
					+ PATH_FRONT_SLASH + profile
					+ PATH_FRONT_SLASH + cloudConfigLabel
					+ PATH_FRONT_SLASH;
		} else {
			LOGGER.error(MessageConstants.CONFIG_CLOUD_PROP_MISSING_ERROR,
					uri, applicationName, cloudConfigLabel, profile);
			cloudConfigUrlPrefix = null;
		}
		return cloudConfigUrlPrefix;
	}

	/**
	 * Load Json from external configuration and convert to target classType object
	 *
	 * @param jsonPath  json path (to be added as cloud config url suffix)
	 * @param classType target class type
	 * @return the mono
	 */
	@Override
	public <T> Mono<T> load(String jsonPath, Class<T> classType) {
		String url = cloudConfigUrlPrefix + jsonPath;
		LOGGER.info(MessageConstants.CONFIG_CLOUD_GET_INFO, url);
		return webClientBuilder
				.baseUrl(url)
				.build()
				.method(HttpMethod.GET)
				.uri(url)
				.accept(MediaType.APPLICATION_STREAM_JSON)
				.exchange()
				.flatMap(clientResponse -> clientResponse.bodyToMono(String.class)
						.flatMap(body -> onResponseReceived(clientResponse, body, classType))
						.switchIfEmpty(defer(() -> onResponseReceived(clientResponse, "", classType))))
				;
	}

	private <T> Mono<T> onResponseReceived(ClientResponse clientResponse, String responseBody, Class<T> classType) {
		HttpStatus status = clientResponse.statusCode();
		if (status != HttpStatus.OK) {
			throw BackendException
					.create(BackendErrorEnum.UNKNOWN, MessageConstants.CONFIG_CLOUD_ERROR_STATUS_MSG,
							status.getReasonPhrase(), status.value(), responseBody);
		}
		if (StringUtils.isBlank(responseBody)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, MessageConstants.CONFIG_CLOUD_EMPTY_JSON_MSG);
		}
		T result = FileUtil.getObjectFromJson(responseBody, classType);
		return Mono.just(result);
	}
}
