package jp.co.rakuten.bff.core.controller;

import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;

/**
 * The configuration controller expose some endpoints to controller the configuration of an instance.
 *
 * @author tony.rouillard
 */
@RestController
public class ConfigController {

	private long lastRefreshTimestamp;

	private Environment env;
	private InterfaceConfigLoader interfaceConfigLoader;
	/**
	 * Constructor with injection
	 *
	 * @param env The spring environment
	 * @param interfaceConfigLoader {@link InterfaceConfigLoader}
	 */
	@Autowired
	public ConfigController(Environment env, InterfaceConfigLoader interfaceConfigLoader) {
		this.env = env;
		this.interfaceConfigLoader = interfaceConfigLoader;
	}

	/**
	 * Provide with the type of configuration currently loaded: 'external' or 'local'
	 *
	 * @return 'external' or 'local'
	 */
	@GetMapping("/api/management/checkconfig")
	public Mono<String> getCheckConfig() {
		return getConfigProperty("config.loadedFrom");
	}

	/**
	 * Return the value of the property according to the key
	 *
	 * @param key The key
	 * @return The value
	 */
	@GetMapping("/api/management/getproperty")
	public Mono<String> getConfigProperty(@RequestParam(value = "key") String key) {
		return Mono.just(String.valueOf(env.getProperty(key)));
	}

	/**
	 * Return the timestamp of the last refresh
	 *
	 * @return The timestamp of the last refresh
	 */
	@GetMapping("/api/management/lastrefresh")
	public Mono<Long> getLastRefreshTimestamp() {
		return Mono.just(lastRefreshTimestamp);
	}


	/**
	 * This method is called after the object is constructed
	 */
	@PostConstruct
	public void postConstruct() {
		onRefresh(null);
	}

	/**
	 * This method is called while a actuator refresh
	 *
	 * @param event The event
	 */
	@EventListener(RefreshScopeRefreshedEvent.class)
	public void onRefresh(RefreshScopeRefreshedEvent event) {
		lastRefreshTimestamp = System.currentTimeMillis();
	}
}