package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Call Definition POJO class - holds following information<br/>
 * <ul>
 *     <li>1. Call definition type</li>
 *     <li>2. Call definition dependency list and map</li>
 *     <li>3. Interface list which are related to this call definition</li>
 * </ul>
 */
public class CallDefinitionTemplate {
	@JsonProperty("type")
	private String type;
	@JsonProperty("depends")
	private List<String> dependsList = new ArrayList<>();
	@JsonProperty("interfaces")
	private List<String> interfacesList = new ArrayList<>();

	@JsonIgnore
	private String name;
	@JsonIgnore
	private Map<String, CallDefinitionTemplate> dependsMap = new HashMap<>();

	public String getType() {
		return this.type;
	}

	public List<String> getDependsList() {
		return this.dependsList;
	}

	public List<String> getInterfacesList() {
		return this.interfacesList;
	}

	public String getName() {
		return this.name;
	}

	public Map<String, CallDefinitionTemplate> getDependsMap() {
		return this.dependsMap;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDependsList(List<String> dependsList) {
		this.dependsList = dependsList;
	}

	public void setInterfacesList(List<String> interfacesList) {
		this.interfacesList = interfacesList;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDependsMap(Map<String, CallDefinitionTemplate> dependsMap) {
		this.dependsMap = dependsMap;
	}

	public String toString() {
		return "CallDefinitionTemplate(type=" + this.getType() + ", dependsList=" + this.getDependsList()
				+ ", interfacesList=" + this.getInterfacesList() + ", name=" + this.getName() + ", dependsMap=" + this
				.getDependsMap() + ")";
	}
}
