package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Interface POJO class which holds interface property<br/>
 * processor, parameter links, dependency condition, exclusions, headers, url params, body params
 */
public class InterfaceTemplate {
	//resolved from apiConfig json files
	@JsonProperty("processor")
	private String processorName;
	@JsonProperty("parameterLinks")
	private List<Map<String, Object>> parameterLinks = new ArrayList<>();
	@JsonProperty("dependencyCondition")
	private List<Map<String, Object>> dependencyCondition = new ArrayList<>();
	@JsonProperty("responseFilters")
	private List<Map<String, Object>> responseFilters = new ArrayList<>();

	//resolved from interface json files
	@JsonProperty("interfaceKey")
	private String interfaceKey;
	@JsonProperty("requestId")
	private String requestId;
	@JsonProperty("headers")
	private List<Map<String, Object>> headers = new ArrayList<>();
	@JsonProperty("urlParams")
	private List<Map<String, Object>> urlParams = new ArrayList<>();
	@JsonProperty("bodyParams")
	private List<Map<String, Object>> bodyParams = new ArrayList<>();
	@JsonProperty("body")
	private BodyTemplate body;
	@JsonProperty("metaParameters")
	private List<Map<String, Object>> metaParameters = new ArrayList<>();
	@JsonProperty("targetResponseMappings")
	private Map<String, List<String>> targetResponseMappings = new HashMap<>();

	//other fields
	@JsonIgnore
	private InterfaceProcessor processorBean;

	/**
	 * Replaces interface template related fields from other model
	 *
	 * @param otherModel {@link InterfaceTemplate}
	 */
	public void mergeWith(InterfaceTemplate otherModel) {
		this.setInterfaceKey(otherModel.getInterfaceKey());
		this.setRequestId(otherModel.getRequestId());
		this.setHeaders(otherModel.getHeaders());
		this.setUrlParams(otherModel.getUrlParams());
		this.setBodyParams(otherModel.getBodyParams());
		this.setMetaParameters(otherModel.getMetaParameters());
		this.setBody(otherModel.getBody());
		this.setTargetResponseMappings(otherModel.getTargetResponseMappings());
	}

	public String getInterfaceKey() {
		return interfaceKey;
	}

	public String getProcessorName() {
		return this.processorName;
	}

	public List<Map<String, Object>> getParameterLinks() {
		return this.parameterLinks;
	}

	public List<Map<String, Object>> getDependencyCondition() {
		return this.dependencyCondition;
	}

	public List<Map<String, Object>> getResponseFilters() {
		return this.responseFilters;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public List<Map<String, Object>> getHeaders() {
		return this.headers;
	}

	public List<Map<String, Object>> getUrlParams() {
		return this.urlParams;
	}

	public List<Map<String, Object>> getBodyParams() {
		return this.bodyParams;
	}

	public List<Map<String, Object>> getMetaParameters() {
		return this.metaParameters;
	}

	public InterfaceProcessor getProcessorBean() {
		return this.processorBean;
	}

	public void setInterfaceKey(String interfaceKey) {
		this.interfaceKey = interfaceKey;
	}

	public void setProcessorName(String processorName) {
		this.processorName = processorName;
	}

	public void setParameterLinks(List<Map<String, Object>> parameterLinks) {
		this.parameterLinks = parameterLinks;
	}

	public void setDependencyCondition(List<Map<String, Object>> dependencyCondition) {
		this.dependencyCondition = dependencyCondition;
	}

	public void setResponseFilters(List<Map<String, Object>> responseFilters) {
		this.responseFilters = responseFilters;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setHeaders(List<Map<String, Object>> headers) {
		this.headers = headers;
	}

	public void setUrlParams(List<Map<String, Object>> urlParams) {
		this.urlParams = urlParams;
	}

	public void setBodyParams(List<Map<String, Object>> bodyParams) {
		this.bodyParams = bodyParams;
	}

	public void setMetaParameters(List<Map<String, Object>> metaParameters) {
		this.metaParameters = metaParameters;
	}

	public void setProcessorBean(InterfaceProcessor processorBean) {
		this.processorBean = processorBean;
	}

	public BodyTemplate getBody() {
		return body;
	}

	public void setBody(BodyTemplate body) {
		this.body = body;
	}

	public Map<String, List<String>> getTargetResponseMappings() {
		return targetResponseMappings;
	}

	public void setTargetResponseMappings(
			Map<String, List<String>> targetResponseMappings) {
		this.targetResponseMappings = targetResponseMappings;
	}

	@Override
	public String toString() {
		return "InterfaceTemplate{" + "interfaceKey='" + interfaceKey + '\'' + ", processorName='" + processorName
				+ '\'' + ", parameterLinks=" + parameterLinks + ", dependencyCondition=" + dependencyCondition
				+ ", responseFilters=" + responseFilters + ", requestId='" + requestId + '\'' + ", headers=" + headers
				+ ", urlParams=" + urlParams + ", bodyParams=" + bodyParams + ", metaParameters=" + metaParameters
				+ ", processorBean=" + processorBean + '}';
	}
}
