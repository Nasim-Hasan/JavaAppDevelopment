package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.core.constant.BffConstants.GG_NOT_CALL_RESPONSE_MSG;
import static jp.co.rakuten.bff.core.constant.BffConstants.PRECONDITION_FAILED_RESPONSE_MSG;
import static jp.co.rakuten.bff.core.exception.type.BackendErrorEnum.*;

/**
 * Interface response utility class
 */
public class InterfaceUtil {

	private InterfaceUtil() {
		//Intentionally kept empty to prevent init
	}

	/**
	 * Get interface response from call definition response map,
	 * but will throw exception with {@link BackendErrorEnum#FAILED_DEPENDENCY}
	 * in case Interface response not found.
	 * This should be used while extracting response of another interface on which the
	 * target interface is dependent. i.e. this should be always used in a feature processor while
	 * extracting mandatory response of an interface from another feature.
	 *
	 * @param callDefinitionResponseMap Call definition response map
	 * @param interfaceName             Interface name
	 * @param callDefinitionName        Call definition name
	 * @return Map
	 */
	public static Map<String, Object> getInterfaceResponseWithDependencyException(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap, String interfaceName,
			String callDefinitionName) {
		return getInterfaceResponseWithDefinedException(
				callDefinitionResponseMap.get(callDefinitionName), interfaceName, callDefinitionName,
				BackendErrorEnum.FAILED_DEPENDENCY, GG_NOT_CALL_RESPONSE_MSG);
	}

	/**
	 * Get interface response from call definition response map,
	 * but will throw defined exception with message
	 * in case Interface response not found
	 *
	 * @param callDefinitionResponse Call definition response
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @param errorEnumIfFailed      {@link BackendErrorEnum} type error enum if failed
	 * @param msgIfFailed            Msg to show if failed to get response
	 * @return Map
	 */
	@SuppressWarnings("squid:S1166") //false positive warning: log or throw exception
	public static Map<String, Object> getInterfaceResponseWithDefinedException(
			CallDefinitionResponse callDefinitionResponse, String interfaceName,
			String callDefinitionName, BackendErrorEnum errorEnumIfFailed, String msgIfFailed) {
		try {
			return getInterfaceResponse(
					callDefinitionResponse, interfaceName, callDefinitionName);
		} catch (Exception e) {
			throw BackendException.create(errorEnumIfFailed, msgIfFailed).addDetailForLog(e.getMessage());
		}
	}

	/**
	 * Get interface response from call definition response map
	 *
	 * @param callDefinitionResponseMap Call definition response map
	 * @param interfaceName             Interface name
	 * @param callDefinitionName        Call definition name
	 * @return Map
	 */
	public static Map<String, Object> getInterfaceResponse(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap,
			String interfaceName, String callDefinitionName) {

		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMap.get(callDefinitionName);
		return getInterfaceResponse(callDefinitionResponse, interfaceName, callDefinitionName);
	}

	/**
	 * Get interface response from call definition response map
	 *
	 * @param callDefinitionResponseMap      Call definition response map
	 * @param interfaceName      Interface name
	 * @param callDefinitionName Call definition name
	 * @return Map
	 */
	public static Map<String, Object> getInterfaceResponseWithoutException(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap, String interfaceName, String callDefinitionName) {
		return getInterfaceResponseWithoutException(callDefinitionResponseMap.get(callDefinitionName), interfaceName);
	}

	/**
	 * Get interface response from call definition response
	 *
	 * @param callDefinitionResponse Call definition response
	 * @param interfaceName          Interface name
	 * @return Map
	 */
	public static Map<String, Object> getInterfaceResponseWithoutException(
			CallDefinitionResponse callDefinitionResponse, String interfaceName) {
		if (callDefinitionResponse != null && callDefinitionResponse.isSuccessful()) {
			CustomHttpResponse customsResponse = callDefinitionResponse.getResponseForSingleCall(interfaceName);
			if (customsResponse != null && customsResponse.getError() == null) {
				return customsResponse.getBodyMap();
			}
		}
		return new HashMap<>();
	}

	/**
	 * Get interface response from call definition response
	 *
	 * @param callDefinitionResponse Call definition response
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @return Map
	 */
	public static Map<String, Object> getInterfaceResponse(CallDefinitionResponse callDefinitionResponse,
														   String interfaceName, String callDefinitionName) {
		CustomHttpResponse customHttpResponse = getInterfaceCustomHttpResponse(callDefinitionResponse,
																			   interfaceName, callDefinitionName);
		if (MapUtils.isNotEmpty(customHttpResponse.getBodyMap())) {
			return customHttpResponse.getBodyMap();
		} else {
			return new HashMap<>();
		}
	}

	/**
	 * Get interface response from call definition response
	 *
	 * @param callDefinitionResponseMap Call definition response map
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @return Map
	 */
	public static Map<String, Map<String, Object>> getInterfaceAllResponses(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap,
			String interfaceName, String callDefinitionName) {
		CallDefinitionResponse callDefinitionResponse =
				getCallDefinitionResponse(callDefinitionResponseMap, interfaceName, callDefinitionName);
		Map<String, CustomHttpResponse> customHttpResponseMap = getCustomHttpResponseMap(callDefinitionResponse);

		List<String> requestIdList = getRequestIdList(callDefinitionResponse, interfaceName);
		Map<String, Map<String, Object>> finalResponse = new HashMap<>();
		for (String requestId : requestIdList) {
			CustomHttpResponse customHttpResponse = customHttpResponseMap.get(requestId);
			if (MapUtils.isNotEmpty(customHttpResponse.getBodyMap())) {
				finalResponse.put(requestId, customHttpResponse.getBodyMap());
			}
		}
		return finalResponse;
	}

	/**
	 * Get interface response from call definition response
	 *
	 * @param callDefinitionResponseMap Call definition response map
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @return Map
	 * @throws BackendException {@link BackendException}
	 */
	public static Map<String, Map<String, Object>> getValidatedAllInterfaceResponses(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap,
			String interfaceName, String callDefinitionName) {
		CallDefinitionResponse callDefinitionResponse =
				getCallDefinitionResponse(callDefinitionResponseMap, interfaceName, callDefinitionName);
		Map<String, CustomHttpResponse> customHttpResponseMap = getCustomHttpResponseMap(callDefinitionResponse);

		List<String> requestIdList = getRequestIdList(callDefinitionResponse, interfaceName);
		Map<String, Map<String, Object>> finalResponse = new HashMap<>();
		if (CollectionUtils.isNotEmpty(requestIdList)) {
			for (String requestId : requestIdList) {
				CustomHttpResponse customHttpResponse = customHttpResponseMap.get(requestId);
				validateCustomHttpResponse(customHttpResponse, interfaceName, callDefinitionName);
				if (MapUtils.isNotEmpty(customHttpResponse.getBodyMap())) {
					finalResponse.put(requestId, customHttpResponse.getBodyMap());
				}
			}
		}
		return finalResponse;
	}

	/**
	 * return CallDefinitionResponse from callDefinitionResponseMap
	 *
	 * @param callDefinitionResponseMap map of callDefinitionResponse
	 * @param interfaceName name of an interface
	 * @param callDefinitionName name of the callDefinition
	 * @return CallDefinitionResponse
	 * */
	public static CallDefinitionResponse getCallDefinitionResponse(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
																   String interfaceName, String callDefinitionName) {
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMap.get(callDefinitionName);
		validateCallDefinitionResponse(callDefinitionResponse, interfaceName, callDefinitionName);
		return callDefinitionResponse;
	}

	/**
	 * return CustomHttpResponse map from callDefinitionResponse
	 *
	 * @param callDefinitionResponse {@link CallDefinitionResponse}
	 * @return map of CustomHttpResponse
	 * */
	public static Map<String, CustomHttpResponse> getCustomHttpResponseMap(CallDefinitionResponse callDefinitionResponse) {
		MultipleResponses multipleResponses = callDefinitionResponse.getMultipleResponses();
		return multipleResponses.getResponses();
	}

	/**
	 * return request id list from callDefinitionResponse
	 *
	 * @param callDefinitionResponse {@link CallDefinitionResponse}
	 * @param interfaceName name of an interface
	 * @return List of requestId
	 * */
	public static List<String> getRequestIdList(CallDefinitionResponse callDefinitionResponse,
															  String interfaceName) {
		Map<String, List<String>> interfaceToRequestIdMap = callDefinitionResponse.getInterfaceToRequestIdMap();
		return interfaceToRequestIdMap.get(interfaceName);
	}

	/**
	 * validate customHttpResponse
	 *
	 * @param customHttpResponse {@link CustomHttpResponse}
	 * @param interfaceName name of an interface
	 * @param callDefinitionName name of the callDefinition
	 * */
	public static void validateCustomHttpResponse(CustomHttpResponse customHttpResponse, String interfaceName,
												  String callDefinitionName) {
		if (Objects.isNull(customHttpResponse)) {
			throw BackendException.create(PRECONDITION_FAILED, PRECONDITION_FAILED_RESPONSE_MSG).addDetailForLog(
					"{} - interface has not been called due to the pre-condition failure", interfaceName);
		}

		if (Objects.nonNull(customHttpResponse.getError())) {
			throwCustomError(customHttpResponse.getError(), interfaceName, callDefinitionName);
		}
	}

	/**
	 * validate callDefinitionResponse
	 *
	 * @param callDefinitionResponse {@link CallDefinitionResponse}
	 * @param interfaceName name of an interface
	 * @param callDefinitionName name of the callDefinition
	 * */
	public static void validateCallDefinitionResponse(CallDefinitionResponse callDefinitionResponse,
													  String interfaceName, String callDefinitionName) {
		if (Objects.isNull(callDefinitionResponse)) {
			throw BackendException.create(BackendErrorEnum.SERVICE_CONDITION, "callDefinitionResponse is null")
					.addDetailForLog("callDefinitionResponse is null - interface {} - call definition {}",
							interfaceName, callDefinitionName);
		}

		if (callDefinitionResponse.isNotSuccessful()) {
			CallDefinitionError callDefinitionError = callDefinitionResponse.getCallDefinitionError();
			throw BackendException.create(BackendErrorEnum.resolve(callDefinitionError), callDefinitionError.getMessage())
					.addDetailForLog("interface {} - call definition {} - status - ",
							interfaceName, callDefinitionName, callDefinitionResponse.getStatus());
		}
	}

	/**
	 * Get interface response body as string from call definition response map
	 *
	 * @param callDefinitionResponseMap Call definition response map
	 * @param interfaceName             Interface name
	 * @param callDefinitionName        Call definition name
	 * @return Map
	 */
	public static String getInterfaceResponseString(
			Map<String, CallDefinitionResponse> callDefinitionResponseMap,
			String interfaceName, String callDefinitionName) {
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMap.get(callDefinitionName);
		return getInterfaceResponseString(callDefinitionResponse, interfaceName, callDefinitionName);
	}

	/**
	 * Get interface response body as string from call definition response
	 *
	 * @param callDefinitionResponse Call definition response
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @return String
	 */
	public static String getInterfaceResponseString(CallDefinitionResponse callDefinitionResponse,
													String interfaceName, String callDefinitionName) {
		CustomHttpResponse customHttpResponse = getInterfaceCustomHttpResponse(callDefinitionResponse,
																			   interfaceName, callDefinitionName);
		return customHttpResponse.getBodyAsString();
	}

	/**
	 * Get interface response as {@link CustomHttpResponse} object
	 * from call definition response map
	 *
	 * @param callDefinitionResponse Call definition response
	 * @param interfaceName          Interface name
	 * @param callDefinitionName     Call definition name
	 * @return Map
	 */
	public static CustomHttpResponse getInterfaceCustomHttpResponse(CallDefinitionResponse callDefinitionResponse,
																	String interfaceName, String callDefinitionName) {

		validateCallDefinitionResponse(callDefinitionResponse, interfaceName, callDefinitionName);
		CustomHttpResponse customHttpResponse = callDefinitionResponse.getResponseForSingleCall(interfaceName);
		validateCustomHttpResponse(customHttpResponse, interfaceName, callDefinitionName);
		return customHttpResponse;
	}

	/**
	 * Extract and throw the exception in CustomHttpResponse error
	 *
	 * @param error              error object from customHttpResponse
	 * @param interfaceName      interface name
	 * @param callDefinitionName call definition name
	 */
	static void throwCustomError(CustomError error, String interfaceName,
			String callDefinitionName) {
		String backedErrorCode = error.getCode();
		HttpStatus backendStatus = HttpStatus.resolve(Integer.valueOf(backedErrorCode));
		BackendErrorEnum errorEnum;
		if (backendStatus.is4xxClientError()) {
			if (HttpStatus.NOT_FOUND == backendStatus) {
				errorEnum = NOT_FOUND;
			} else if (HttpStatus.PRECONDITION_FAILED == backendStatus) {
				errorEnum = PRECONDITION_FAILED;
			} else {
				errorEnum = BAD_REQUEST;
			}
			throw BackendException.create(errorEnum, backendStatus,
					error.getMessage(), backedErrorCode);
		} else {
			throw BackendException.create(BackendErrorEnum.SERVICE_CONDITION, error.getMessage())
					.addDetailForLog("{} - interface response has as error in '{}' call definition",
							interfaceName, callDefinitionName);
		}
	}

	/**
	 * Check this interface should call or not, based on user's request include & exclude
	 *
	 * @param validatedRequest Validated request map
	 * @param featureCheckListMap Map of featureList
	 * @return boolean should call this interface or not
	 */
	public static boolean isCallNeeded(Map<String, CommonRequestModel> validatedRequest,
									   Map<String, List<String>> featureCheckListMap) {
		for (Map.Entry<String, CommonRequestModel> entry : validatedRequest.entrySet()) {
			if (processFeatureCheckList(featureCheckListMap, entry)) {
				return true;
			}
		}

		return false;
	}

	private static boolean processFeatureCheckList(Map<String, List<String>> featureCheckListMap,
			Map.Entry<String, CommonRequestModel> entry) {
		String featureName = entry.getKey();
		CommonRequestModel commonRequestModel = entry.getValue();
		List<String> checkList = featureCheckListMap.get(featureName);
		if(CollectionUtils.isNotEmpty(checkList)) {
			for (String checkKey : checkList) {
				if (RequestUtil.isIncluded(checkKey, commonRequestModel)) {
					return true;
				}
			}
		}
		return false;
	}
}
