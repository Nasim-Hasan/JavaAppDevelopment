package jp.co.rakuten.bff.core.health;

import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.HealthEndpointGroups;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * This extension customizes what we want from the HealthEndpoint.
 * Primarily, when the status is NOT "UP", we want to log.
 */
@Component
@Endpoint(id = "health")
public class CustomHealthEndpoint extends HealthEndpoint {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomHealthEndpoint.class);

    private ObjectMapper objectMapper = MapUtil.getObjectMapper();

    /**
     * Required constructor.
     * For actuator use in instantiating this custom health endpoint.
     * @param registry collection of health contributors
     * @param groups configuration of the health endpoint group
     */
    public CustomHealthEndpoint(HealthContributorRegistry registry, HealthEndpointGroups groups) {
        super(registry, groups);
    }

    /**
     * Override the parent's health read method.
     * We add the logging here when the status is not UP.
     * @return {@link HealthComponent} corresponding to the status from parent.
     */
    @Override
    @ReadOperation
    public HealthComponent health() {
        HealthComponent health = callParentHealth();
        if(Status.UP != health.getStatus()){
            logUnhealthyStatus(health);
        }
        return health;
    }

    /**
     * Exposing this as a method so that the super.health call can be mocked for testing.
     * It can not be mocked by itself. Spring Actuator also doesn't provide runner just for this.
     *
     * @return the aggregated status from the registry and group
     */
    public HealthComponent callParentHealth(){
        return super.health();
    }

    /**
     * Exposing this as a public method so that it can be tested
     * @param health resulting health from the parent
     */
    public void logUnhealthyStatus(HealthComponent health){
        try {
            LOGGER.error("Unhealthy status: {}", objectMapper.writeValueAsString(health));
        } catch (IOException e) {
            LOGGER.error("Unhealthy status and error parsing components. {}", e.getMessage());
        }
    }

    /**
     * This method is exposed for unit testing scenarios relating to writing logs for unhealthy status
     * @param objectMapper jackson object mapper utility in writing object to JSON string
     */
    public void setObjectMapper(ObjectMapper objectMapper){
        this.objectMapper = objectMapper;
    }

}
