package jp.co.rakuten.bff.core.service.upstream.client.impl;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.tcp.TcpClient;

import javax.annotation.PostConstruct;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static jp.co.rakuten.bff.core.constant.BffConstants.SO_TIMEOUT;
import static jp.co.rakuten.bff.core.constant.BffConstants.TIMEOUT;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_TIME_OUT_OCCURRED;

/**
 * Provide webClientBuilder for ecstatic and generic gateway call
 * with required tcp and pool settings
 */
@Service
public class BffWebClientBuilder {
	private WebClient.Builder webClientBuilder;
	private Environment env;

	protected static final String MAX_CONNECTION_KEY = "maximum.http.connection.pool.size";
	protected static final String MAX_IDLE_TIME_KEY = "maximum.connection.idle.time";
	protected static final Integer MAX_CONNECTION_DEFAULT = 2000;
	protected static final Integer MAX_IDLE_TIME_DEFAULT = 30;
	private static final boolean SO_KEEP_ALIVE_STATUS = false;
	protected static final String CONNECTION_POOL_NAME = "ggPool";
	private static final Integer MAX_LIFE_TIME_MINUTE_DEFAULT=1 ;
	private static final String MAX_LIFE_TIME_MINUTE_KEY="maximum.connection.life.time.minutes";
	private static final String KEEP_ALIVE_KEY = "generic.gateway.keep-alive";


	/**
	 * The connection provider that can be updated at the runtime (max connection)
	 */
	protected ConnectionProvider connectionProvider;

	@Autowired
	BffWebClientBuilder(WebClient.Builder webClientBuilder, Environment environment) {
		this.webClientBuilder = webClientBuilder;
		this.env = environment;
	}


	@PostConstruct
	private void init() {
		updateConnectionProvider();
	}

	Duration getTimeoutDuration(Map<String, String> connectionMap) {
		return Duration.ofMillis(Integer.parseInt(connectionMap.get(SO_TIMEOUT)));
	}

	Mono<ClientResponse> getTimeoutException(String interfaceKey) {
		return Mono.error(BackendException
				.create(BackendErrorEnum.TIMEOUT, SERVICE_TIME_OUT_OCCURRED, interfaceKey));
	}

	/**
	 * Create the connection provider and allow runtime update.
	 */
	private void updateConnectionProvider() {
		int maxConnection = env.getProperty(MAX_CONNECTION_KEY, Integer.class, MAX_CONNECTION_DEFAULT);
		int maxLifeTime=env.getProperty(MAX_LIFE_TIME_MINUTE_KEY, Integer.class, MAX_LIFE_TIME_MINUTE_DEFAULT);
//		int maxConnectionIdleTime = env.getProperty(MAX_IDLE_TIME_KEY, Integer.class, MAX_IDLE_TIME_DEFAULT);
		if (connectionProvider == null) {
			this.connectionProvider=ConnectionProvider.builder(CONNECTION_POOL_NAME).maxConnections(maxConnection)
					.pendingAcquireTimeout(Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT))
					.metrics(true)
					.maxLifeTime(Duration.ofMinutes(maxLifeTime))
//					.maxIdleTime(Duration.ofSeconds(maxConnectionIdleTime))
					.build();
		}
	}

	/**
	 * Create the reactive netty WebClient
	 *
	 * @param connectionMap connection map
	 * @return The WebClient to perform reactive web request
	 */
	WebClient getWebClient(Map<String, String> connectionMap) {
		return webClientBuilder.clientConnector(new ReactorClientHttpConnector(getHttpClient(connectionMap))).build();
	}

	/**
	 * Prepare Reactor-Netty HttpClient with Http-Proxy-Settings, Read-Timeout and Write-Timeout.
	 *
	 * @param connectionMap connection map
	 * @return The http client
	 */
	private HttpClient getHttpClient(Map<String, String> connectionMap) {
		return HttpClient.create(connectionProvider).tcpConfiguration(getTcpMapper(connectionMap));
	}

	/**
	 * Initialize tcp client with it's basic ChannelOption settings.
	 * SO_KEEPALIVE         If true then the channel try to keep alive when server allows similar functionality
	 * TCP_NODELAY          improved latency and throughput on a certain workload. Nagle's algorithm was introduced
	 * to reduce the overhead of TCP/IP packets (i.e. smaller a packet, bigger the overhead).
	 * It is basically to prevent a poor user application from generating too many small packets.
	 * AUTO_CLOSE           If true then the Channel is closed automatically and immediately on write failure.
	 *
	 * @param tcpClient     the targeted tcp client
	 * @param connectionMap the key-value pair that keeps all the http connection configuration.
	 * @return the tcp client
	 */
	protected TcpClient initTcpClient(TcpClient tcpClient, Map<String, String> connectionMap) {
		boolean keepAlive=env.getProperty(KEEP_ALIVE_KEY, Boolean.class, SO_KEEP_ALIVE_STATUS);
		return tcpClient
				.option(ChannelOption.SO_KEEPALIVE, keepAlive)
				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS,
						Integer.valueOf(connectionMap.get(TIMEOUT)))
				.doOnConnected(conn -> conn.addHandlerLast(
						new ReadTimeoutHandler(Long.parseLong(connectionMap.get(SO_TIMEOUT)), TimeUnit.MILLISECONDS)));
	}

	protected Function<TcpClient, TcpClient> getTcpMapper(Map<String, String> connectionMap) {
		return (TcpClient tcpClient) -> {
			tcpClient = initTcpClient(tcpClient, connectionMap);
			return tcpClient;
		};
	}
}
