package jp.co.rakuten.bff.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_INVALID_OBJECT_MSG;

/**
 * This utility class helps to manipulate parts of maps.
 *
 */
public class MapUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(MapUtil.class);

	private static final int MAX_DEPTH = 10;
	private static ObjectMapper objectMapper = new ObjectMapper();

	private MapUtil() {}

	public static ObjectMapper getObjectMapper() {
		return objectMapper;
	}

	/**
	 * Manipulate map through the given path & put value into the leaf node
	 *
	 * Example:
	 * body: {"data":{"shopId":""}}
	 * path: data.shopId
	 * value: 1234
	 * after manipulation {"data":{"shopId":1234}}
	 *
	 * @param bodyMap The body map to extract from
	 * @param path    The path of the elements to extract
	 * @param value   leaf node value
	 */
	public static void putValue(Map<String, Object> bodyMap, String path,Object value) {
		String[] keyNames = path.split("\\.");
		putValues(bodyMap, keyNames, 0,  keyNames.length,value);
	}

	@SuppressWarnings("unchecked")
	private static void putValues(Object current, String[] keyNames, int index, int maxDepth,
								  Object value) {
		String keyName = keyNames[index];

		if (current instanceof List) {
			List<Object> items = (List<Object>) current;
			for (Object item : items) {
				putValues(item, keyNames, index,  maxDepth,value);
			}
		} else if (current instanceof Map) {
			Map<String, Object> map = (Map<String, Object>) current;
			if (map.containsKey(keyName)) {
				if (index == keyNames.length - 1) {
					map.put(keyName,value);
				} else if (index < maxDepth - 1) {
					current = ((Map<String,Object>) current).get(keyName);
					putValues(current, keyNames, index + 1, maxDepth,value);
				} else {
					LOGGER.debug("The max depth has been reached");
				}
			} else {
				LOGGER.debug("The key has not been found");
			}
		}else{
			throw SystemException.create(SystemErrorEnum.INTERNAL,
					UTIL_INVALID_OBJECT_MSG)
					.addDetailForLog(UTIL_INVALID_OBJECT_MSG);
		}
	}

	/**
	 * Extract the direct parent of the element.
	 * It allows to edit the map.
	 * As we search a single element, it does not go through lists.
	 *
	 * Example:
	 *  body: {"data":{"shopId":"1111"}}
	 *  path: data.shopId
	 *  return: The map "data"
	 *
	 * @param bodyMap The body map to extract from
	 * @param path The path of the elements to extract
	 * @return The direct parent or null if not found
	 */
	public static Map<String, Object> getDirectParent(Map<String, Object> bodyMap, String path) {
		return getDirectParent(bodyMap, path, MAX_DEPTH);
	}

	/**
	 * Extract the direct parent of the element with a max depth limitation.
	 * It allows to edit the map.
	 * As we search a single element, it does not go through lists.
	 *
	 * Example:
	 *  body: {"data":{"shopId":"1111"}}
	 *  path: data.shopId
	 *  return: The map "data"
	 *
	 * @param bodyMap The body map to extract from
	 * @param path The path of the elements to extract
	 * @param maxDepth The max depth
	 * @return The direct parent or null if not found or max depth reached
	 */
	public static Map<String, Object> getDirectParent(Map<String, Object> bodyMap, String path, int maxDepth) {
		String[] keyNames = path.split("\\.");
		List<Map<String, Object>> directParents = new ArrayList<>();

		findValues(bodyMap, keyNames, 0, directParents, false, maxDepth);

		if (directParents.size() == 1) {
			return directParents.get(0);
		}
		return null;
	}

	/**
	 * Extract the direct parent of the elements.
	 * It allows to edit the map.
	 * This method can find a list of elements through lists.
	 *
	 * Example:
	 *  body: {"data":[{"shopId":"1111"}, {"shopId":"2222"}]}
	 *  path: data.shopId
	 *  return: The list of map {"shopId":"1111"}, {"shopId":"2222"}
	 *
	 * @param bodyMap The body map to extract from
	 * @param path The path of the elements to extract
	 * @return The direct parents or null if not found
	 */
	public static List<Map<String, Object>> getDirectParents(Map<String, Object> bodyMap, String path) {
		return getDirectParents(bodyMap, path, MAX_DEPTH);
	}

	/**
	 * Extract the direct parent of the elements with a max depth limitation.
	 * It allows to edit the map.
	 * This method can find a list of elements through lists.
	 *
	 * Example:
	 *  body: {"data":[{"shopId":"1111"}, {"shopId":"2222"}]}
	 *  path: data.shopId
	 *  return: The list of map {"shopId":"1111"}, {"shopId":"2222"}
	 *
	 * @param bodyMap The body map to extract from
	 * @param path The path of the elements to extract
	 * @param maxDepth The max depth
	 * @return The direct parents or null if not found or max depth reached
	 */
	public static List<Map<String, Object>> getDirectParents(Map<String, Object> bodyMap, String path, int maxDepth) {
		String[] keyNames = path.split("\\.");
		List<Map<String, Object>> directParent = new ArrayList<>();

		findValues(bodyMap, keyNames, 0, directParent, true, maxDepth);

		return CollectionUtils.isNotEmpty(directParent) ? directParent : null;
	}

	private static void findValues(Object current, String[] keyNames, int index,
	                               List<Map<String, Object>> directParents, boolean goThroughLists, int maxDepth) {
		String keyName = keyNames[index];

		if (current instanceof List && goThroughLists) {
			List items = (List) current;
			for (Object item : items) {
				findValues(item, keyNames, index, directParents, true, maxDepth);
			}
		} else if (current instanceof Map) {
			Map<String, Object> map = (Map<String, Object>) current;
			if (map.containsKey(keyName)) {
				if (index == keyNames.length - 1) {
					directParents.add(map);
				} else if (index < maxDepth - 1) {
					current = ((Map) current).get(keyName);
					findValues(current, keyNames, index + 1, directParents, goThroughLists, maxDepth);
				} else {
					LOGGER.debug("The max depth has been reached");
				}
			} else {
				LOGGER.debug("The key has not been found");
			}
		}
	}


	/**
	 * Puts the value in the map only if it is not null and not empty. Else removes the entry from map.
	 *
	 * @param map The map
	 * @param key The key
	 * @param value The value
	 * @return the updated map
	 */
	public static <K, V> Map<K, V> putIfValueNotEmptyOrRemoveKey(Map<K, V> map, K key, V value) {
		if (map != null) {
			if (ObjectUtils.isNotEmpty(value)) {
				map.put(key, value);
			} else {
				map.remove(key);
			}
		}
		return map;
	}

	/**
	 * Extract expected object from the provided map with the given keys. Keys must be separated by {@code "." [DOT]}.
	 * Note that all the intermediate object in that map object
	 * must be a {@link Map} otherwise a {@link ClassCastException} will be thrown <br/>
	 * Example: {@code keys = video.parameters.value}
	 * will return the {@code "<script src= ..."} from the following map:
	 * <pre>
	 * "video": {
	 *             "type": "HTML",
	 *             "parameters": {
	 *                 "value": "<script src="//stream.cms.rakuten.co.jp/gate/play/
	 *                 ?w=320&h=286&mid=1101692986&vid=5792214557001" type="text/javascript"></script>"
	 *             }
	 *       }
	 * </pre>
	 *
	 * @param key  comma separated keys/path to find.
	 * @param data source map from where data will be extracted.
	 * @return corresponding values extracted from {code data} map.
	 * @throws ClassCastException if any intermediate object is not a instance of {@link Map}
	 */
	public static Object getFieldFromMap(String key, Map data) {
		if (StringUtils.isNotBlank(key) && MapUtils.isNotEmpty(data)) {
			String[] keys = key.split("\\.");
			Map currentData;
			Object currentObject = data;
			for (int i = 0; i < keys.length; i++) {
				currentData = (Map) currentObject;
				currentObject = currentData.get(keys[i]);
				if (currentObject == null) {
					return null;
				}
			}
			return currentObject;
		}
		return null;
	}

	/**
	 * Create a deep copy of the Map. It means all the sub-elements of the map are copied as well.
	 *
	 * @param map The initial map
	 * @return The deep copy or the original map in case of error during copying
	 */
	public static <T> Map<String, T> deepCopy(Map<String, T> map) {
		// Keep a String in the InterfaceConfig VS Copy deeply the map: Run a perf test to decide
		return DeepCopyUtil.deepCopy(map, Map.class);
	}
}
