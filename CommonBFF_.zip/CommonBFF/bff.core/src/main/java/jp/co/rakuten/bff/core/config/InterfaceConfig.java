package jp.co.rakuten.bff.core.config;

import java.util.HashMap;
import java.util.Map;

/**
 * This class contains backend's interface related information.
 * It is loaded from the property files.
 *
 * @author tony.rouillard
 */

public class InterfaceConfig {

	private String interfaceKey;

	/**
	 * Connection information such as url, timeout, proxy, etc...
	 */
	private Map<String, String> connectionMap = new HashMap<>();
	/**
	 * Url parameters will be put in the final url.
	 * It will replace the {key} found in the url or put the "key=value" after the "?" mark.
	 */
	private Map<String, String> urlParameterMap = new HashMap<>();

	/**
	 * The headers will be added to the request while building the final request
	 */
	private Map<String, String> headerMap = new HashMap<>();
	/**
	 * The metadata information will be used to load some specific behavior related to several interfaces
	 */
	private Map<String, String> metadataMap = new HashMap<>();
	/**
	 * The circuit name that will be used to secure the upstream
	 */
	private String circuit;

	/**
	 * If the interface is a facade, the related bean will be called (cf. FacadeInterface)
	 */
	private Map<String, String> cacheConfigMap = new HashMap<>();

	/**
	 * The constructor that requires an interfaceKey
	 *
	 * @param interfaceKey The interface key
	 */
	public InterfaceConfig(String interfaceKey) {
		this.interfaceKey = interfaceKey;
	}

	/**
	 * All args constructor
	 *
	 * @param interfaceKey The interface key
	 * @param connectionMap connection related data
	 * @param urlParameterMap url parameters
	 * @param headerMap headers
	 * @param metadataMap metadata
	 * @param circuit circuit name
	 */
	public InterfaceConfig(String interfaceKey, Map<String, String> connectionMap, Map<String, String> urlParameterMap,
						   Map<String, String> headerMap, Map<String,
			String> metadataMap, String circuit) {
		this.interfaceKey = interfaceKey;
		this.connectionMap = connectionMap;
		this.urlParameterMap = urlParameterMap;
		this.headerMap = headerMap;
		this.metadataMap = metadataMap;
		this.circuit = circuit;
	}

	/**
	 * Builder method init point
	 * @return InterfaceConfigBuilder
	 */
	public static InterfaceConfigBuilder builder() {
		return new InterfaceConfigBuilder();
	}

	public String getInterfaceKey() {
		return interfaceKey;
	}

	public void setInterfaceKey(String interfaceKey) {
		this.interfaceKey = interfaceKey;
	}

	public Map<String, String> getPropertiesConnectionMap() {
		return new HashMap<>(connectionMap);
	}

	/**
	 * Puts the cache configuration in cacheConfig Map
	 *
	 * @param key key to add config in the map
	 * @param value value to add
	 */
	public void putToCacheConfigMap(String key, String value) {
		if (value != null) {
			cacheConfigMap.put(key, value);
		}
	}

	public Map<String, String> getCacheConfigMap() {
		return new HashMap<>(cacheConfigMap);
	}

	/**
	 * Add the key and value to the connection map
	 *
	 * @param key   The key
	 * @param value The value
	 */
	public void putToConnectionMap(String key, String value) {
		if (value != null) {
			connectionMap.put(key, value);
		}
	}

	public Map<String, String> getPropertiesUrlParameterMap() {
		return new HashMap<>(urlParameterMap);
	}

	/**
	 * Add the key and value to the url map
	 *
	 * @param key   The key
	 * @param value The value
	 */
	public void putToUrlParameterMap(String key, String value) {
		if (value != null) {
			urlParameterMap.put(key, value);
		}
	}

	public Map<String, String> getPropertiesHeaderMap() {
		return new HashMap<>(headerMap);
	}

	/**
	 * Add the key and value to the headerParameters map
	 *
	 * @param key   The key
	 * @param value The value
	 */
	public void putToHeaderMap(String key, String value) {
		if (value != null) {
			headerMap.put(key, value);
		}
	}

	public Map<String, String> getMetadataMap() {
		return new HashMap<>(metadataMap);
	}

	/**
	 * Add the key and value to the metadata map
	 *
	 * @param key   The key
	 * @param value The value
	 */
	public void putToMetadataMap(String key, String value) {
		if (value != null) {
			metadataMap.put(key, value);
		}
	}

	public String getCircuit() {
		return circuit;
	}

	public void setCircuit(String circuit) {
		if (circuit != null) {
			this.circuit = circuit;
		}
	}

	@Override
	public String toString() {
		return "InterfaceConfig{" +
				"interfaceKey='" + interfaceKey + '\'' +
				", connectionMap=" + connectionMap +
				", urlParameterMap=" + urlParameterMap +
				", headerMap=" + headerMap +
				", metadataMap=" + metadataMap +
				", circuit='" + circuit + '\'' +
				'}';
	}

	/**
	 * InterfaceConfig builder
	 */
	public static class InterfaceConfigBuilder {
		private String interfaceKey;
		private Map<String, String> connectionMap;
		private Map<String, String> urlParameterMap;
		private Map<String, String> headerMap;
		private Map<String, String> metadataMap;
		private String circuit;

		InterfaceConfigBuilder() {
		}

		/**
		 * Set interface key
		 * @param interfaceKey interfaceKey
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder interfaceKey(String interfaceKey) {
			this.interfaceKey = interfaceKey;
			return this;
		}

		/**
		 * Set connection map
		 * @param connectionMap connection map
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder connectionMap(Map<String, String> connectionMap) {
			this.connectionMap = connectionMap;
			return this;
		}

		/**
		 * Set url parameter
		 * @param urlParameterMap url parameter map
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder urlParameterMap(Map<String, String> urlParameterMap) {
			this.urlParameterMap = urlParameterMap;
			return this;
		}

		/**
		 * Set header map
		 * @param headerMap header map
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder headerMap(Map<String, String> headerMap) {
			this.headerMap = headerMap;
			return this;
		}

		/**
		 * Set meta data map
		 * @param metadataMap meta data map
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder metadataMap(Map<String, String> metadataMap) {
			this.metadataMap = metadataMap;
			return this;
		}

		/**
		 * Set circuit name
		 * @param circuit circuit
		 * @return InterfaceConfigBuilder
		 */
		public InterfaceConfigBuilder circuit(String circuit) {
			this.circuit = circuit;
			return this;
		}

		/**
		 * InterfaceConfigBuilder's build method
		 * @return InterfaceConfig
		 */
		public InterfaceConfig build() {
			return new InterfaceConfig(interfaceKey, connectionMap, urlParameterMap, headerMap, metadataMap, circuit);
		}
	}
}
