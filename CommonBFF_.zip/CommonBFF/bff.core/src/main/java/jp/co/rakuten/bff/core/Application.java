package jp.co.rakuten.bff.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import reactor.blockhound.BlockHound;
import reactor.tools.agent.ReactorDebugAgent;

/**
 * Main starting class of BFF Restful application
 *
 * @author Md Ruhul Amin
 * @see <a href="https://confluence.rakuten-it.com/confluence/display/ECSG/Restful+BFF+Design">
 * ApiController Specification
 * </a>
 */
@SpringBootApplication
@EnableEurekaClient
@EnableConfigurationProperties
@SuppressWarnings("squid:S4604")
public class Application {
	/**
	 * Main method gives a place to start with spring application
	 *
	 * @param args spring environment related argument will be passed here.
	 */
	public static void main(String[] args) {
		ReactorDebugAgent.init();
		BlockHound.builder()
				.allowBlockingCallsInside("org.springframework.util.ConcurrentReferenceHashMap",
										  "get")
				.allowBlockingCallsInside("reactor.core.Exceptions",
										  "bubble")
				.install();
		SpringApplication.run(Application.class, args);
	}
}
