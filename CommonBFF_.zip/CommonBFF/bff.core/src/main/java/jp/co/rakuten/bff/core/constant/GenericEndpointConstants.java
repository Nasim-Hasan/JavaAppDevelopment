package jp.co.rakuten.bff.core.constant;


/**
 * List of keywords used by the GenericController
 *
 * @author tony.rouillard
 */
public class GenericEndpointConstants {
	public static final String REQUEST_ID = "requestId";
	public static final String INTERFACE_KEY = "interfaceKey";
	public static final String HEADER_PARAMETERS = "headerParameters";
	public static final String URL_PARAMETERS = "urlParameters";
	public static final String BODY_PARAMETERS = "bodyParameters";
	public static final String META_PARAMETERS = "metaParameters";
	public static final String BODY = "body";
	public static final String RESPONSE_FILTERS = "responseFilters";
	public static final String INCLUSIONS = "inclusions";
	public static final String EXCLUSIONS = "exclusions";
	public static final String PARAMETER_LINKS = "parameterLinks";
	public static final String DEPENDENCY_CONDITIONS = "dependencyConditions";
	public static final String PARENT_REQUEST_ID = "parentRequestId";
	public static final String SOURCE_PATH = "sourcePath";
	public static final String EVALUATION = "evaluation";
	public static final String VALUE_TO_COMPARE_WITH = "valueToCompareWith";
	public static final String TARGET_TYPE = "targetType";
	public static final String TARGET_NAME = "targetName";
	public static final String CONNECTION = "connection";

	public static final String OVERALL_STATUS = "overallStatus";
	public static final String RESPONSES = "responses";
	public static final String ERROR = "error";
	public static final String ERROR_CODE = "code";
	public static final String ERROR_MESSAGE = "message";

	public static final String COMMON_HEADER_TRACEID = "X-TraceId";
	public static final String COMMON_HEADER_BFFID = "X-BffId";
	public static final String COMMON_HEADER_CLIENTID = "X-ClientId";
	public static final String COMMON_HEADER_CACHE_CONTROL = "cache-control";
	public static final String COMMON_HEADER_FORWARDEDFOR = "X-Forwarded-For";
	public static final String COMMON_HEADER_API_KEY = "X-ApiKey";
	// Override config enable
	public static final String OVERRIDE_CONFIG_PWD = "overrideConfig.password";
	public static final String OVERRIDE_CONFIG_ENABLE_KEY = "overrideConfig.enabled";
	public static final String BFF_MOCKING_ENABLED = "bff.mocking.enabled";
	/**
	 * empty constructor
	 */
	private GenericEndpointConstants() {
	}
}
