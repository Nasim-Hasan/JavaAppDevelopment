package jp.co.rakuten.bff.core.model;

import java.util.Map;

/**
 * This class encapsulates cache related information:
 */
public class CacheDataModel {
	private boolean isStaleCache;
	private Map<String, Object> cacheMap;

	public CacheDataModel() {
	}

	/**
	 * To Construct this data model
	 * using following params
	 *
	 * @param isStaleCache denotes if stale cache
	 * @param cacheMap     the cache map
	 */
	public CacheDataModel(boolean isStaleCache, Map<String, Object> cacheMap) {
		this.isStaleCache = isStaleCache;
		this.cacheMap = cacheMap;
	}

	/**
	 * To Construct this data model
	 * using following params
	 *
	 * @param cacheMap cacheMap object
	 */
	public CacheDataModel(Map<String, Object> cacheMap) {
		this.cacheMap = cacheMap;
	}

	public boolean isStaleCache() {
		return isStaleCache;
	}

	public void setStaleCache(boolean staleCache) {
		isStaleCache = staleCache;
	}

	public Map<String, Object> getCacheMap() {
		return cacheMap;
	}

	public void setCacheMap(Map<String, Object> cacheMap) {
		this.cacheMap = cacheMap;
	}
}
