package jp.co.rakuten.bff.core.util;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Post filter helper class.
 * Initially targeted to pack some common utility type method,
 * which will be used by some interface post filter
 */
public final class ResponseFilterHelper {

	private ResponseFilterHelper() {
	}

	/**
	 * get all parents for a field in a path and update locale value for that field.
	 * <p>
	 * Example 1:
	 * <pre>
	 * @code
	 * {
	 *  "categories": [
	 *      {
	 *          "someKey": "some value",
	 *          "title": {
	 *              "ja-JP": "some text 1"
	 *          }
	 *      },
	 *      {
	 *          "someKey": "some value",
	 *          "title": {
	 *              "ja-JP": "some text 2"
	 *          }
	 *      }
	 *  ]
	 * }
	 * </pre>
	 * <p>
	 * Will return:
	 * <pre>
	 * @code
	 * {
	 *   "categories": [
	 *     {
	 *       "someKey": "some value",
	 *       "title":  "some text 1"
	 *     },
	 *     {
	 *       "someKey": "some value",
	 *       "title": "some text 2"
	 *     }
	 *   ]
	 * }
	 * </pre>
	 * <p>
	 * Example 2:
	 * <pre>
	 * @code
	 * {
	 *  "categories": [
	 *      {
	 *          "someKey": "some value",
	 *          "title": {
	 *              "pc": {
	 *                  "ja-JP": "some text 1"
	 *              }
	 *
	 *          }
	 *      },
	 *      {
	 *          "someKey": "some value",
	 *          "title": {
	 *              "pc": {
	 *                  "ja-JP": "some text 2"
	 *              }
	 *          }
	 *      }
	 *  ]
	 * }
	 * </pre>
	 * <p>
	 * Will return:
	 * <pre>
	 * @code
	 * {
	 *   "categories": [
	 *     {
	 *       "someKey": "some value",
	 *       "title": {
	 *            "ja-JP": "some text 1"
	 *        }
	 *     },
	 *     {
	 *       "someKey": "some value",
	 *       "title": {
	 *          "ja-JP": "some text 1"
	 *      }
	 *     }
	 *   ]
	 * }
	 * </pre>
	 *
	 * get all parents for a field in a path and update locale value for that field.
	 * @param bodyMap      total response body map to find parentPath
	 * @param field        which value need to be updated by locale/device,
	 *                     immediate child of parent path, in Examples: "title"
	 * @param requestedKey key to search the value. in Example: ja-JP
	 * @param parentPath   path of parent which immediate child value need to be updated by locale
	 */
	public static void digUpValueAndSet(Map<String, Object> bodyMap, String parentPath, String field,
	                                    String requestedKey) {
		parentPath = StringUtils.isNotEmpty(parentPath) ? parentPath + "." : "";
		List<Map<String, Object>> filedParents = MapUtil.getDirectParents(bodyMap, parentPath + field);
		if (ObjectUtils.isNotEmpty(filedParents)) {
			filedParents.forEach(dataMap -> digUpValueAndSet(dataMap, field, requestedKey));
		}
	}

	/**
	 * get all parents for a field in a path and update locale value for that field.
	 * @param bodyMap      total response body map to find parentPath
	 * @param field        which value need to be updated by locale/device,
	 *                     immediate child of parent path, in Examples: "title"
	 * @param requestedKey key to search the value. in Example: ja-JP
	 */
	public static void digUpValueAndSet(Map<String, Object> bodyMap, String field, String requestedKey) {
		if (bodyMap.get(field) instanceof Map) {
			Map<String, Object> filedMap = (Map<String, Object>) bodyMap.get(field);
			Object targetValue = getValueOrDefaultValue(requestedKey, filedMap);
			MapUtil.putIfValueNotEmptyOrRemoveKey(bodyMap, field, targetValue);
		} else {
			bodyMap.remove(field);
		}
	}

	/**
	 * get all parents for a field in a path and update locale value for that field.
	 * @param bodyMap      total response body map to find parentPath
	 * @param parentPath   path of parent which immediate child value need to be updated by locale
	 * @param field        which value need to be updated by locale/device,
	 *                     immediate child of parent path, in Examples: "title"
	 * @param requestedKey key to search the value. in Example: ja-JP
	 */
	public static void digUpValueAndAdd(Map<String, Object> bodyMap, String parentPath, String field,
	                                    String requestedKey) {
		parentPath = StringUtils.isNotEmpty(parentPath) ? parentPath + "." : "";
		List<Map<String, Object>> filedParents = MapUtil.getDirectParents(bodyMap, parentPath + field);
		if (ObjectUtils.isNotEmpty(filedParents)) {
			filedParents.forEach(dataMap -> digUpValueAndAdd(dataMap, field, requestedKey));
		}
	}

	private static void digUpValueAndAdd(Map<String, Object> dataMap, String field, String requestedKey) {
		if (dataMap.get(field) instanceof List) {
			List<Object> filedList = (List<Object>) dataMap.get(field);
			if (CollectionUtils.isNotEmpty(filedList)) {
				processFieldValues(dataMap, filedList, requestedKey, field);
			}
		} else {
			dataMap.remove(field);
		}
	}

	private static void processFieldValues(Map<String, Object> dataMap, List<Object> filedList,
			String requestedKey, String field) {

		List<Object> updatedList = new ArrayList<>();
		filedList.forEach(value -> {
			if (value instanceof Map) {
				Object targetValue = getValueOrDefaultValue(requestedKey, (Map<String, Object>) value);
				if (ObjectUtils.isNotEmpty(targetValue)) {
					updatedList.add(targetValue);
				}
			}
		});
		if (CollectionUtils.isNotEmpty(updatedList)) {
			dataMap.put(field, updatedList);
		} else {
			dataMap.remove(field);
		}
	}

	/**
	 * if value with field not found, search value with default field
	 *
	 * @param field   first search with this key
	 * @param dataMap dataMap to search
	 * @return search result string/map
	 */
	private static Object getValueOrDefaultValue(String field, Map<String, Object> dataMap) {
		return ResponseFilterHelper.selectValueByKeyPath(field, dataMap);
	}

	/**
	 * retrieves requested locale value from a map with a particular key.
	 * if not found then return the default locale value
	 * Example 1:
	 * <pre>
	 * @code
	 * {
	 *  "ja-JP": "this is the actual value"
	 * }
	 * </pre>
	 * <p>
	 * Result:
	 * <pre>
	 * @code
	 * "this is the actual value"
	 * </pre>
	 * <p>
	 * Example 2:
	 * <pre>
	 * @code
	 * {
	 *     "pc" : {
	 *          "ja-JP": "this is the actual value"
	 *      }
	 *  }
	 * </pre>
	 * Result:
	 *
	 * <pre>
	 * @code
	 * {
	 *   "ja-JP": "this is the actual value"
	 * }
	 * </pre>
	 *
	 * @param fieldName in the example its is "ja-JP"/"pc"
	 * @param dataMap   in the example it is the entire JSON
	 * @return locale map/value
	 */
	private static Object selectValueByKeyPath(String fieldName, Map<String, Object> dataMap) {
		if (ObjectUtils.isNotEmpty(dataMap)) {
			return dataMap.get(fieldName);
		}
		return null;
	}
}
