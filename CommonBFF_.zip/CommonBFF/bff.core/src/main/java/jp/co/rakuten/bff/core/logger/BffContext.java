package jp.co.rakuten.bff.core.logger;

import java.net.URI;

/**
 * This class stores some common fields so that can be retrieved later in the code using {@code Context}
 */
public class BffContext {
	private String clientId;
	private String host;
	private URI requestUri;
	private String forwardedFor;
	private String bffId;
	private String cacheControl;
	private String apiKey;
	private String overridingConfigEnabled;
	private String overridingConfigPassword;

	public String overridingConfigEnabled() {
		return overridingConfigEnabled;
	}

	public String getOverridingConfigPassword() {
		return overridingConfigPassword;
	}

	private BffContext() {
	}

	/**
	 * Creates a new {@code Builder} for {@code BffContext}
	 * @return the new Builder object
	 */
	public static Builder builder() {
		return new Builder();
	}


	public String getClientId() {
		return clientId;
	}

	public String getHost() {
		return host;
	}

	public URI getRequestUri() {
		return requestUri;
	}

	public String getForwardedFor() {
		return forwardedFor;
	}

	public String getBffId() {
		return bffId;
	}

	public String getCacheControl() {
		return cacheControl;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	/**
	 * Builder class for creating a {@code BffContext}
	 */
	public static class Builder {
		private String clientId;
		private String host;
		private URI requestUri;
		private String forwardedFor;
		private String bffId;
		private String cacheControl;
		private String overridingConfigEnabled;
		private String overridingConfigPassword;
		/**
		 * Add isMockEnabled into the bff context object
		 *
		 * @param overridingConfigEnabled {@link boolean}
		 * @return the builder object
		 * */
		public Builder overridingConfigEnabled(String overridingConfigEnabled) {
			this.overridingConfigEnabled = overridingConfigEnabled;
			return this;
		}
		/**
		 * Add overridingPassword into the bff context object
		 *
		 * @param overridingConfigPassword {@link boolean}
		 * @return the builder object
		 * */
		public Builder overridingConfigPassword(String overridingConfigPassword) {
			this.overridingConfigPassword = overridingConfigPassword;
			return this;
		}

		public Builder clientId(String clientId) {
			this.clientId = clientId;
			return this;
		}

		/**
		 * Add host into the bff context object
		 *
		 * @param host {@link String}
		 * @return the builder object
		 * */
		public Builder host(String host) {
			this.host = host;
			return this;
		}

		/**
		 * Add requestUri into the bff context object
		 *
		 * @param requestUri {@link URI}
		 * @return the builder object
		 * */
		public Builder requestUri(URI requestUri) {
			this.requestUri = requestUri;
			return this;
		}

		/**
		 * Add forwardedFor into the bff context object
		 *
		 * @param forwardedFor {@link String}
		 * @return the builder object
		 * */
		public Builder forwardedFor(String forwardedFor) {
			this.forwardedFor = forwardedFor;
			return this;
		}

		/**
		 * Add bffId into the bff context object
		 *
		 * @param bffId {@link String}
		 * @return the builder object
		 * */
		public Builder bffId(String bffId) {
			this.bffId = bffId;
			return this;
		}

		/**
		 * Add cacheControl into the bff context object
		 *
		 * @param cacheControl {@link String}
		 * @return the builder object
		 * */
		public Builder cacheControl(String cacheControl) {
			this.cacheControl = cacheControl;
			return this;
		}

		/**
		 * Build the new object or BffContext
		 *
		 * @return the new BffContext object
		 * */
		public BffContext build() {
			BffContext bffContext = new BffContext();
			bffContext.clientId = clientId;
			bffContext.host = host;
			bffContext.requestUri = requestUri;
			bffContext.forwardedFor = forwardedFor;
			bffContext.bffId = bffId;
			bffContext.cacheControl = cacheControl;
			bffContext.overridingConfigEnabled = overridingConfigEnabled;
			bffContext.overridingConfigPassword = overridingConfigPassword;
			return bffContext;
		}
	}
}
