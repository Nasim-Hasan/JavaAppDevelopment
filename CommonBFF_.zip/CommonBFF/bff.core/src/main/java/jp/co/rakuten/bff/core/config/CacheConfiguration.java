package jp.co.rakuten.bff.core.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * This class contains cache shared cache configurations
 */
@Configuration
public class CacheConfiguration {

	/**
	 * gives client to communicate with shared cache
	 * @param factory ConnectionFactory provided by spring
	 * @return instance of ReactiveRedisTemplate, redis client
	 */
	@Bean
	public ReactiveRedisTemplate<String, Object> reactiveRedisTemplate(ReactiveRedisConnectionFactory factory) {

		StringRedisSerializer keySerializer = new StringRedisSerializer();
		Jackson2JsonRedisSerializer<Object> valueSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
		RedisSerializationContext.RedisSerializationContextBuilder<String, Object> builder = RedisSerializationContext
				.newSerializationContext(valueSerializer);
		RedisSerializationContext<String, Object> context = builder.key(keySerializer).hashKey(keySerializer).build();

		return new ReactiveRedisTemplate<>(factory, context);
	}
}
