package jp.co.rakuten.bff.core.logger;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for Logger
 */
@Configuration
public class LoggerConfiguration {

	/**
	 * Creates a {@code serviceLogger} bean
	 * @return the HttpLogger
	 */
	@Bean
	public HttpLogger serviceLogger() {
		Map<String, String> aliases = new HashMap<>();
		aliases.put(HttpLogger.FieldNames.PATH, "upstreamReqPath");
		aliases.put(HttpLogger.FieldNames.QUERY, "upstreamReqParams");
		return new HttpLogger(LoggerFactory.getLogger("serviceLogger"), aliases);
	}

	/**
	 * Creates a {@code apiLogger} bean
	 * @param throwableMessageConverter the throwableMessageConverter
	 * @return the HttpLogger
	 */
	@Bean
	public HttpLogger apiLogger(ThrowableMessageConverter throwableMessageConverter) {
		Map<String, String> aliases = new HashMap<>();
		aliases.put(HttpLogger.FieldNames.PATH, "requestPath");
		aliases.put(HttpLogger.FieldNames.QUERY, "requestParams");
		return new HttpLogger(LoggerFactory.getLogger("apiLogger"), aliases, throwableMessageConverter);
	}
}
