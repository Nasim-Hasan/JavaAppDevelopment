package jp.co.rakuten.bff.core.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffApiMetricsManager;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.logger.HttpLogger.LoggerRequest;
import jp.co.rakuten.bff.core.logger.HttpLoggerHelper;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.service.ApiExecutionService;
import jp.co.rakuten.bff.core.util.BFFUtil;
import jp.co.rakuten.bff.core.util.ExceptionUtil;
import jp.co.rakuten.bff.core.util.RequestUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

/**
 * Provides the interface of BFF API.
 *
 * @see <a href= "https://confluence.rakuten-it.com/confluence/display/ECSG/%5BDraft%5D%5BFrameworkComponent%5D+ApiController">
 * ApiController Specification
 * </a>
 */
@Validated
@RestController
public class ApiController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiController.class);
	private final ApiExecutionService apiExecutionService;
	private final Environment environment;
	private final HttpLogger apiLogger;
	private final ObjectMapper mapper;
	private final ResponseUtil responseUtil;

	/**
	 * Api controller constructor
	 *
	 * @param environment         spring envinronment.
	 * @param apiExecutionService dependency
	 * @param apiLogger           HttpLogger type apiLogger
	 * @param responseUtil        responseUtil to create response
	 */
	@Autowired
	public ApiController(Environment environment, ApiExecutionService apiExecutionService,
						 @Qualifier("apiLogger") HttpLogger apiLogger, ResponseUtil responseUtil) {
		this.environment = environment;
		this.apiExecutionService = apiExecutionService;
		this.apiLogger = apiLogger;
		this.responseUtil = responseUtil;
		mapper = ResponseUtil.objectMapper;
	}

	/**
	 * This interface is the entry point for client-specific BFF API. It process client request by gathering data from
	 * multiple call definitions then apply validation, filter and business logic to the responses.</br> Responsibility
	 * is to check if the requested {@code service} is in maintenance mode. Other wise it will pass the request to
	 * {@link ApiExecutionService} to process the request and forward responses to client.
	 *
	 * @param headers          all api headers
	 * @param service          name of the corresponding service. value must be provided.
	 * @param operation        name of the operation.  value must be provided.
	 * @param version          version number. optional value.
	 * @param body             String representation of request body
	 * @return response model. gui
	 * @see <a href= "https://confluence.rakuten-it.com/confluence/display/ECSG/%5BDraft%5D%5BFrameworkComponent%5D+ApiController">
	 * ApiController Specification
	 * </a>
	 */
	@PostMapping(value = "${endpoint.uri}",
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public  Mono<ResponseEntity<Map>>api(
			@RequestHeader HttpHeaders headers,
			@PathVariable(value = "service") @NotNull @NotEmpty String service,
			@PathVariable(value = "operation") @NotNull @NotEmpty String operation,
			@PathVariable(value = "version") @Pattern(regexp = "^v\\d{1,2}$",
					message = BffConstants.INVALID_VERSION_FORMAT) String version,
			@RequestBody(required = false) String body) {
		Mono<String> bodyMono = Mono.just(StringUtils.defaultIfBlank(body, "{}"));
		LoggerRequest loggerRequest = getLoggerRequest(service, operation, version, headers, body);
		AtomicReference<String> apiKey = new AtomicReference<>("INITIAL_API");
		AtomicLong startTime= new AtomicLong(System.currentTimeMillis());
		return bodyMono.flatMap((String requestBody) -> {
			RequestModel requestModel;
			try {
				requestModel = mapper.readValue(requestBody, RequestModel.class);
			} catch (JsonProcessingException e) {
				throw ClientException
						.create(ClientErrorEnum.BAD_REQUEST, e, BffConstants.INVALID_REQUEST_BODY)
						.addDetailForLog(MessageConstants.CONTROLLER_PARSE_REQUEST_BODY_ERROR_MSG, body, e.getMessage());
			}
			if (Objects.isNull(requestModel)) {
				return Mono.error(ClientException
						.create(ClientErrorEnum.BAD_REQUEST, BffConstants.INVALID_REQUEST_BODY)
						.addDetailForLog(MessageConstants.CONTROLLER_PARSE_REQUEST_BODY_ERROR_MSG, body,
								BffConstants.INVALID_REQUEST_BODY));
			}
			LOGGER.debug(MessageConstants.CONTROLLER_REQUEST_PROVISIONED_MSG,
					service, operation, version, requestModel, headers);

			// preparing user request data.
			ClientRequestModel clientData = new ClientRequestModel(service, operation, version,
					requestModel, headers.getFirst(BffConstants.X_CLIENT_ID), headers);

			if(clientData!=null){
				apiKey.set(RequestUtil.buildAPIKey(clientData));
			}
			// api execution
			return executeApi(clientData);
		})
		.transform(loggingTransformer(loggerRequest))
		.onErrorResume((Throwable throwable) -> {
			ResponseEntity<Map> responseEntity =
					responseUtil.catchExceptionAndBuildApiResponse(throwable, null);
			BffApiMetricsManager.markExit(apiKey.get(), responseEntity.getStatusCode(),
					ExceptionUtil.getBffException(throwable).getErrorType());
			loggerRequest.setStatus(responseEntity.getStatusCode());
			apiLogger.log(loggerRequest);
			return Mono.just(responseEntity);
		})
		.doOnSuccess((ResponseEntity<Map> mapResponseEntity) -> {
			BffApiMetricsManager.markExit(apiKey.get(), mapResponseEntity.getStatusCode(), null);
			loggerRequest.setStatus(mapResponseEntity.getStatusCode());
			apiLogger.log(loggerRequest);
		})
		.doFinally(t->BffApiMetricsManager.stopExecutionTime(apiKey.get(),startTime.get()));
	}


	private Mono<ResponseEntity<Map>> executeApi(ClientRequestModel clientData) {
		// Check maintenance mode
		checkMaintenance(clientData);

		//Process api
		return apiExecutionService.executeApi(clientData);
		// if the errors are thrown from here, will be processed by global error handler.
	}


	private void checkMaintenance(ClientRequestModel clientRequestModel) {
		// 3. all APIs for that service
		String propertyKey = clientRequestModel.getService();
		throwExceptionIfInMaintenance(new StringBuilder(propertyKey));
		// 2. all versions of that APIwhenApiInMaintenanceMode
		throwExceptionIfInMaintenance(new StringBuilder(propertyKey).append(BffConstants.SEPARATOR_INNER_DOT)
																	.append(clientRequestModel.getOperation()));
		// 1. a particular version of the API
		throwExceptionIfInMaintenance(new StringBuilder(propertyKey).append(BffConstants.SEPARATOR_INNER_DOT)
				                                                    .append(clientRequestModel.getOperation())
				                                                    .append(BffConstants.SEPARATOR_INNER_DOT)
																	.append(clientRequestModel.getVersion()));
	}

	private void throwExceptionIfInMaintenance(StringBuilder propertyKey) {
		StringBuilder msgStrBuilder = new StringBuilder(propertyKey);
		if (BooleanUtils.toBoolean(environment.getProperty(
									propertyKey.append(BffConstants.MAINTENANCE_PROP).toString(), "false"))) {
			throw SystemException.create(SystemErrorEnum.SERVICE_UNAVAILABLE,
					MessageConstants.CONTROLLER_MAINTAIN_MODE_INFO_MSG, msgStrBuilder);
		}
	}

	private LoggerRequest getLoggerRequest(String service, String operation, String version, HttpHeaders headers,
										   String body) {
		StringBuilder requestPath = new StringBuilder(service).append(BffConstants.PATH_FRONT_SLASH).append(operation).append(BffConstants.PATH_FRONT_SLASH).append(version);
		Map<String, Object> loggerDataMap = new HashMap<>();
		loggerDataMap.put("service", service);
		loggerDataMap.put("operation", operation);
		loggerDataMap.put("version", version);
		loggerDataMap.put("headers", headers);
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();
		loggerRequest.setMethod(HttpMethod.POST);
		loggerRequest.setUri(BFFUtil.buildURI(requestPath.toString()));
		loggerRequest.getExtras().putAll(loggerDataMap);
		loggerRequest.setRequestBody(body);
		return loggerRequest;
	}

	private <T> Function<Mono<T>, Mono<T>> loggingTransformer(HttpLogger.LoggerRequest loggerRequest) {
		return responseEntityMono -> responseEntityMono.doOnEach((Signal<T> signal) -> {
			if (signal.isOnNext() || signal.isOnError()) {
				HttpLoggerHelper.prepareApiLoggerRequest(loggerRequest, signal.getContext());
			}
		}).doOnSubscribe(subscription -> loggerRequest.startTimeCounting() );
	}
}
