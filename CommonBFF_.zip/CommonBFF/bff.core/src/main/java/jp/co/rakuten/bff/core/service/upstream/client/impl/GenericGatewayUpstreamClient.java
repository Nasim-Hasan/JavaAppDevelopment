package jp.co.rakuten.bff.core.service.upstream.client.impl;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.GenericEndpointConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffUpstreamMetricsManager;
import jp.co.rakuten.bff.core.logger.BffContext;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.logger.HttpLoggerHelper;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.upstream.client.UpstreamClient;
import jp.co.rakuten.bff.core.util.BFFUtil;
import jp.co.rakuten.bff.core.util.ExceptionUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.reactivestreams.Subscription;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;
import reactor.util.context.Context;
import io.netty.channel.ConnectTimeoutException;


import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.COMMON_HEADER_API_KEY;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.COMMON_HEADER_BFFID;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.BFF_MOCKING_ENABLED;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_REQUEST_TYPE_NOT_FOUND_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_TIME_OUT_OCCURRED;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_UNEXPECTED_RESPONSE_FORMAT_CALL_DEFINITION;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_UNEXPECTED_RESPONSE_FORMAT_GG;
import static jp.co.rakuten.bff.core.exception.type.BackendErrorEnum.*;

/**
 * Generic gateway call definition client.
 */
@Service
public class GenericGatewayUpstreamClient implements UpstreamClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(GenericGatewayUpstreamClient.class);
	private static final String LOG_MSG_GG_RESP_STATUS = "Generic gateway http response status: %s";
	private static final String CONNECTION_TIMEOUT_KEY_SUFFIX = ".gg.call.timeout";
	private static final String DEFAULT_TIMEOUT = "1000";
	private static final String SOCKET_TIMEOUT_KEY_SUFFIX = ".gg.call.soTimeout";
	private static final String DEFAULT_SO_TIMEOUT = "1000";

	private BffWebClientBuilder bffWebClientBuilder;
	private final Environment env;
	private final HttpLogger serviceLogger;

	private String gatewayUri;
	private String singlePath;
	private String parallelPath;
	private String complexPath;

	protected WebClient singleRequestWebClient;
	protected WebClient parallelRequestWebClient;
	protected WebClient complexRequestWebClient;

	/**
	 * Default constructor
	 *
	 * @param bffWebClientBuilder {@link BffWebClientBuilder}
	 * @param env                 {@link Environment}
	 * @param serviceLogger       {@link HttpLogger}
	 */
	@Autowired
	public GenericGatewayUpstreamClient(BffWebClientBuilder bffWebClientBuilder, Environment env,
										HttpLogger serviceLogger) {
		this.bffWebClientBuilder = bffWebClientBuilder;
		this.env = env;
		this.serviceLogger = serviceLogger;
	}

	@PostConstruct
	private void loadUriPath() {
		String systemGatewayUrl = System.getProperty(BffConstants.GATEWAY_URI);
		this.gatewayUri = StringUtils.isNotBlank(systemGatewayUrl) ?
				systemGatewayUrl : env.getProperty(BffConstants.GATEWAY_URI);
		this.singlePath = env.getProperty(BffConstants.SINGLE_REQUEST_PATH);
		this.parallelPath = env.getProperty(BffConstants.PARALLEL_REQUEST_PATH);
		this.complexPath = env.getProperty(BffConstants.COMPLEX_REQUEST_PATH);
		initWebClients();
	}


	@Override
	public Mono<MultipleResponses> execute(String callDefinitionName, Collection<Map<String, Object>> requests,
										   String type) {
		HttpHeaders httpHeaders = new HttpHeaders();
		return Mono.just(callDefinitionName)
				.doOnEach((Signal<String> signal) -> {
					if (signal.isOnNext()) {
						Context context = signal.getContext();
						if (context.hasKey(BFF_CONTEXT)) {
							BffContext bffContext = context.get(BFF_CONTEXT);
							httpHeaders.setCacheControl(bffContext.getCacheControl());
							httpHeaders.set(COMMON_HEADER_BFFID, "Restful");
							httpHeaders.set(COMMON_HEADER_API_KEY, bffContext.getApiKey());
							httpHeaders.set(BffConstants.X_CLIENT_ID, bffContext.getClientId());
							httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
							Boolean isMockEnabled = Boolean.parseBoolean(env.getProperty(BFF_MOCKING_ENABLED,"false"));
							if (isMockEnabled && StringUtils.isNotEmpty(bffContext.getOverridingConfigPassword())
									&& StringUtils.isNotEmpty(bffContext.overridingConfigEnabled())) {
								httpHeaders.set(GenericEndpointConstants.OVERRIDE_CONFIG_PWD, bffContext.getOverridingConfigPassword());
								httpHeaders.set(GenericEndpointConstants.OVERRIDE_CONFIG_ENABLE_KEY, bffContext.overridingConfigEnabled());
							}
						}
					}
				})
				.flatMap(callDefinition -> doRequest(callDefinitionName, requests, type, httpHeaders));
	}

	/**
	 * This method is responsible for webclinet call to generic gateway.
	 *
	 * @param requests    list of request. for http first element of list will be used.
	 * @param requestType type of upstream request. can be single, parallel, complex or
	 *                    direct http for ecstatic
	 * @param httpHeaders
	 * @return Mono of a response map
	 */
	private Mono<MultipleResponses> doRequest(String callDefinitionName,
											  Collection<Map<String, Object>> requests,
											  String requestType, HttpHeaders httpHeaders) {
		Object requestObject = requests;
		String uri = gatewayUri;
		WebClient webClient;
		switch (requestType) {
			case CALL_DEFINITION_TYPE_SINGLE:
				uri += singlePath;
				requestObject = requests.iterator().next();
				webClient = singleRequestWebClient;
				break;
			case CALL_DEFINITION_TYPE_PARALLEL:
				uri += parallelPath;
				webClient = parallelRequestWebClient;
				break;
			case CALL_DEFINITION_TYPE_COMPLEX:
				uri += complexPath;
				webClient = complexRequestWebClient;
				break;
			default:
				throw ClientException.create(ClientErrorEnum.BAD_REQUEST, SERVICE_REQUEST_TYPE_NOT_FOUND_ERROR, requestType);
		}

		AtomicReference<Long> startTime = new AtomicReference<>();
		BffUpstreamMetricsManager.markEntry(requestType);
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();
		loggerRequest.setUri(BFFUtil.buildURI(uri));
		loggerRequest.setMethod(HttpMethod.POST);
		BFFUtil.addCallDefinitionInfoToLoggerRequest(loggerRequest, callDefinitionName, requestType, requests);

		return webClient.post()
				.uri(uri)
				.body(BodyInserters.fromValue(requestObject))
				.headers(getHttpHeaders(httpHeaders))
				.exchange()
				.timeout(bffWebClientBuilder.getTimeoutDuration(getConnectionMap(requestType)),bffWebClientBuilder.getTimeoutException(callDefinitionName))
				.flatMap((ClientResponse response) -> {
					throwExceptionIfAnyError(response, loggerRequest);
					return response.bodyToMono(String.class);
				})
				.flatMap((String responseBody) -> {
					try {
						return prepareMultipleResponse(requestType, responseBody, requests);
					} catch (IOException e) {
						return getMono(callDefinitionName, responseBody, e);
					}
				})
				.doOnEach((Signal<MultipleResponses> signal) -> {
					if (signal.isOnNext() || signal.isOnError()) {
						HttpLoggerHelper.prepareServiceLoggerRequest(loggerRequest, signal.getContext());
					}
				})
				.doOnSubscribe((Subscription r) -> {
					startTime.set(BffUpstreamMetricsManager.startExecutionTime());
					loggerRequest.startTimeCounting();
					LOGGER.info("{} GENERIC_GATEWAY_CALL START", callDefinitionName);
				})
				.doOnSuccess((MultipleResponses r) -> {
					LOGGER.info("{} GENERIC_GATEWAY_CALL END", callDefinitionName);
					BffUpstreamMetricsManager.markExit(requestType, r.getOverallStatus(),
							String.valueOf(HttpStatus.MULTI_STATUS.value()));
					serviceLogger.log(loggerRequest);
				})
				.doOnError((Throwable r) -> {
					BffUpstreamMetricsManager.markExit(requestType, "HTTP_EXCEPTION",
							String.valueOf(ExceptionUtil.getBffException(r).getUpstreamStatusCode().value()));
					if (!((r instanceof TimeoutException) || (r instanceof BackendException))) {
						LOGGER.error("{} GENERIC_GATEWAY_CALL ERROR: requests -> {}", callDefinitionName, requests, r);
					} else {
						LOGGER.info("{} GENERIC_GATEWAY_CALL Timeout or BackendException!!", callDefinitionName);
					}
					writeServiceLog(r, serviceLogger, loggerRequest);
				})
				.onErrorResume((Throwable throwable) -> {
					if (throwable instanceof ConnectTimeoutException || throwable instanceof TimeoutException) {
						throw BackendException
								.create(BackendErrorEnum.TIMEOUT, SERVICE_TIME_OUT_OCCURRED, callDefinitionName);
					}
					throw ExceptionUtil.getBackendException(throwable);
				})
				.doFinally(r -> BffUpstreamMetricsManager.stopExecutionTime(requestType, startTime.get()));
	}

	private Mono<MultipleResponses> prepareMultipleResponse(String requestType, String responseBody,
			Collection<Map<String, Object>> requests) throws IOException{
		if (requestType.equalsIgnoreCase(CALL_DEFINITION_TYPE_SINGLE)) {
			HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
			CustomHttpResponse customHttpResponse = ResponseUtil.objectMapper
					.readValue(responseBody, CustomHttpResponse.class);
			responseMap.put((String) requests.iterator().next().get(BffConstants.REQUEST_ID),
					customHttpResponse);
			MultipleResponses multipleResponses = new MultipleResponses(UPSTREAM_RESPONSE_SUCCESS,
					responseMap);
			return Mono.just(multipleResponses);
		} else {
			return Mono
					.just(ResponseUtil.objectMapper.readValue(responseBody, MultipleResponses.class));
		}
	}

	private void throwExceptionIfAnyError(ClientResponse response, HttpLogger.LoggerRequest loggerRequest) {
		HttpStatus httpStatus = response.statusCode();
		loggerRequest.setStatus(httpStatus);
		if (httpStatus.is4xxClientError()) {
			LOGGER.debug(LOG_MSG_GG_RESP_STATUS, response.rawStatusCode());
			if (HttpStatus.NOT_FOUND == httpStatus) {
				throw BackendException.create(NOT_FOUND, httpStatus,
						LOG_MSG_GG_RESP_STATUS, response.rawStatusCode());
			} else  {
				throw BackendException.create(BAD_REQUEST, httpStatus,
						LOG_MSG_GG_RESP_STATUS, response.rawStatusCode());
			}
		} else if (httpStatus.is5xxServerError()) {
			LOGGER.error(LOG_MSG_GG_RESP_STATUS, response.rawStatusCode());
			throw BackendException.create(SERVICE_CONDITION, httpStatus,
					LOG_MSG_GG_RESP_STATUS, response.rawStatusCode());
		}
	}

	private Mono<? extends MultipleResponses> getMono(String callDefinitionName, String responseBody, IOException e) {
		LOGGER.error("Unexpected response from Generic gateway {}", callDefinitionName);
		throw BackendException.create(SERVICE_CONDITION, e,
				SERVICE_UNEXPECTED_RESPONSE_FORMAT_CALL_DEFINITION, callDefinitionName)
				.addDetailForLog(SERVICE_UNEXPECTED_RESPONSE_FORMAT_GG, callDefinitionName);
	}

	private Map<String, String> getConnectionMap(String timeoutKeyPrefix) {
		Map<String, String> connectionMap = new HashMap<>();
		String connectionTimeoutKey = timeoutKeyPrefix + CONNECTION_TIMEOUT_KEY_SUFFIX;
		String socketTimeoutKey = timeoutKeyPrefix + SOCKET_TIMEOUT_KEY_SUFFIX;
		connectionMap.put(BffConstants.TIMEOUT, env.getProperty(connectionTimeoutKey, DEFAULT_TIMEOUT));
		connectionMap.put(SO_TIMEOUT, env.getProperty(socketTimeoutKey, DEFAULT_SO_TIMEOUT));
		return connectionMap;
	}

	/**
	 * Transfer the request's headers to the http headers compatible with WebClient.
	 *
	 * @param headers the request's headers
	 * @return The http headers
	 */
	private Consumer<HttpHeaders> getHttpHeaders(HttpHeaders headers) {
		return httpHeaders -> headers.forEach((key, value) -> httpHeaders.add(key, String.valueOf(value.get(0))));
	}

	private void initWebClients(){
		singleRequestWebClient = bffWebClientBuilder.getWebClient(getConnectionMap(CALL_DEFINITION_TYPE_SINGLE));
		parallelRequestWebClient = bffWebClientBuilder.getWebClient(getConnectionMap(CALL_DEFINITION_TYPE_PARALLEL));
		complexRequestWebClient = bffWebClientBuilder.getWebClient(getConnectionMap(CALL_DEFINITION_TYPE_COMPLEX));
	}

}
