package jp.co.rakuten.bff.core.service.impl;

import edu.emory.mathcs.backport.java.util.Collections;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.service.ExecutionPlanService;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.RequestUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Prepare ExecutionModel for feature execution service
 */
@Component
public class ExecutionPlanServiceImpl implements ExecutionPlanService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExecutionPlanServiceImpl.class);

	private static final Map<String, ExecutionModel> executionModelHolder = new ConcurrentHashMap<>();
	private static final String TRUE = "true";
	private static final String PROPERTY_KEY_SUFFIX_DISABLED = ".disabled";
	private static final String FEATURE_DISABLED_MSG = "Feature Disabled at configuration layer";
	private static final int FEATURE_DISABLED_CODE = 503;
	private static final String DOT_CONSTANT = ".";
	private Environment env;

	/**
	 * Autowired constructor, uses Spring Injection
	 *
	 * @param env @{@link Environment}
	 */
	@Autowired public ExecutionPlanServiceImpl(Environment env) {
		this.env = env;
	}

	/**
	 * This method is used to clear the caches for each apiExecution model. will be triggered automatically by
	 * {@code actuator#refresh}
	 *
	 * @param event refresh event
	 */
	@EventListener(RefreshScopeRefreshedEvent.class)
	public void onRefresh(RefreshScopeRefreshedEvent event) {
		LOGGER.info("[ExecutionPlanImpl]-[onRefresh]- Refresh triggered:" +
				" cleaning up executionModelHolder cache. Event:{}", event);
		executionModelHolder.clear();
	}

	/**
	 * Responsible to process user request. It will filter {@link ApiTemplate} against {@link RequestModel} </br> to
	 * extract requested feature and create request specific maps with call definitions, features and interfaces.
	 *
	 * @param clientRequestModel user provided parameters map
	 * @param templateModel      Templated API schema for requested service
	 * @return Execution plan which will be used for further execution.
	 */
	@Override
	public ExecutionModel prepareExecutionPlan(final ClientRequestModel clientRequestModel,
											   final ApiTemplate templateModel) {
		// extract feature names
		CommonRequestModel common = clientRequestModel.getRequestModel().getCommon();

		Map<String, FeatureTemplate> requestedFeatures = (common == null) ?
				new HashMap<>(templateModel.getFeaturesMap()) :
				getRequestedList(common, templateModel);

		String key = new StringBuilder(templateModel.getApiKey()).append(BffConstants.SEPARATOR_COLON)
						.append(clientRequestModel.getClientId()).append(BffConstants.SEPARATOR_COLON)
						.append(RequestUtil.getHashCode(requestedFeatures.values().stream().map(FeatureTemplate::getId)
															.collect(Collectors.toList()))).toString();

		return executionModelHolder.computeIfAbsent(key,
				s -> generateExecutionModel(requestedFeatures.keySet(), templateModel, clientRequestModel));
	}

	private ExecutionModel generateExecutionModel(Set<String> requestedFeatures, ApiTemplate templateModel,
												  ClientRequestModel data) {

		// prepare execution plan model.
		ExecutionModel executionModel = new ExecutionModel();

		// Prepare execution map by using requested features.
		Map<String, Object> defaultResponse = executionModel.getDefaultResponse();
		Iterator<String> requestedFeaturesIterator = requestedFeatures.iterator();
		while (requestedFeaturesIterator.hasNext()) {
			String featureName = requestedFeaturesIterator.next();
			if (isFeatureDisabled(featureName, templateModel, data)) {
				defaultResponse.put(featureName,
						ResponseUtil.getFeatureErrorResponseMap(FEATURE_DISABLED_MSG, FEATURE_DISABLED_CODE));
				requestedFeaturesIterator.remove();
				continue;
			}
			FeatureTemplate featureTemplate = templateModel.getFeaturesMap().get(featureName);
			// append feature to executionModel
			executionModel.getFeatureModelList().add(featureTemplate);

			// for each feature find corresponding call definition list and put that map into execution
			// model so that featureExecutor could iterate over those call definitions and prepare
			// necessary backend calls.
			featureTemplate.getCallDefinitionsSet().forEach((CallDefinitionTemplate callDefinitionTemplate) -> {
				// append call definition into existing map.
				List<FeatureTemplate> featureTemplateModels = executionModel.getCallDefinitionToFeatureMap()
						.get(callDefinitionTemplate.getName());
				if (ObjectUtils.isEmpty(featureTemplateModels)) {
					featureTemplateModels = new ArrayList<>();
				}
				featureTemplateModels.add(featureTemplate);
				executionModel.getCallDefinitionToFeatureMap()
						.put(callDefinitionTemplate.getName(), featureTemplateModels);
				// appending to call definitions map
				executionModel.getExecutionMap().put(callDefinitionTemplate.getName(), callDefinitionTemplate);
				// appending to required interfaces.
				executionModel.getRequiredInterfaces().addAll(featureTemplate.getInterfaceNameList());
			});
		}

		// Disable subFeatures
		disableSubFeatures(requestedFeatures, executionModel, templateModel, data);

		return executionModel;
	}

	private void disableSubFeatures(Set<String> featureSet, ExecutionModel executionModel, ApiTemplate templateModel,
	                        ClientRequestModel data) {
		try {
			for (String featureName : featureSet) {
				FeatureTemplate featureTemplate = templateModel.getFeaturesMap().get(featureName);
				Map<String, List<String>> subFeatureList = featureTemplate.getSubFeatures();
				if (MapUtils.isNotEmpty(subFeatureList)) {
					for (Map.Entry<String, List<String>> subFeature : subFeatureList.entrySet()) {
						if (isSubFeatureDisabled(featureTemplate.getName(), subFeature.getKey(), templateModel, data)) {
							executionModel.getRequiredInterfaces().removeAll(subFeature.getValue());
						}
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Error occurred while disabling subfeatures", ex);
		}
	}

	private boolean isSubFeatureDisabled(String featureName, String subFeatureName, ApiTemplate apiTemplate,
	                                     ClientRequestModel data) {
		StringBuilder featureNameKey = new StringBuilder(featureName).append(DOT_CONSTANT);
		StringBuilder apiKey = new StringBuilder(apiTemplate.getApiKey()).append(DOT_CONSTANT);
		String globalSubFeatureKey = new StringBuilder(featureNameKey).append(subFeatureName)
										.append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String apiwiseKey = new StringBuilder(apiKey).append(featureName).append(DOT_CONSTANT).append(subFeatureName)
									.append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String clientwiseKey = new StringBuilder(featureNameKey).append(subFeatureName).append(DOT_CONSTANT)
				                   .append(data.getClientId()).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String apiwiseClientwiseKey = new StringBuilder(apiKey).append(featureNameKey).append(subFeatureName)
										.append(DOT_CONSTANT).append(data.getClientId()).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		return isFeatureOrSubFeatureDisabled(globalSubFeatureKey, apiwiseKey, clientwiseKey, apiwiseClientwiseKey);
	}

	private boolean isFeatureDisabled(String featureName, ApiTemplate apiTemplate,
									  ClientRequestModel data) {
		StringBuilder featureNameKey = new StringBuilder(featureName).append(DOT_CONSTANT);
		StringBuilder apiKey = new StringBuilder(apiTemplate.getApiKey()).append(DOT_CONSTANT);
		String globalFeatureKey = new StringBuilder(featureName).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String apiwiseKey = new StringBuilder(apiKey).append(featureName).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String clientwiseKey = new StringBuilder(featureNameKey).append(data.getClientId()).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		String apiwiseClientwiseKey = new StringBuilder(apiKey).append(featureNameKey).append(data.getClientId()).append(PROPERTY_KEY_SUFFIX_DISABLED).toString();
		return isFeatureOrSubFeatureDisabled(globalFeatureKey, apiwiseKey, clientwiseKey, apiwiseClientwiseKey);
	}

	private boolean isFeatureOrSubFeatureDisabled(String globalFeatureKey, String apiwiseKey, String clientwiseKey,
	                                              String apiwiseClientwiseKey) {
		return (TRUE.equals(env.getProperty(globalFeatureKey)) ||
				TRUE.equals(env.getProperty(apiwiseKey)) ||
				TRUE.equals(env.getProperty(clientwiseKey)) ||
				TRUE.equals(env.getProperty(apiwiseClientwiseKey)));
	}

	/**
	 * This method will extract a subset from provided {@code originalSet}.
	 * Will include only the elements from the {@code originalSet}
	 * if {@link CommonRequestModel#getInclude()} are not empty.
	 * Or else it will return a new set excluding the element from {@code originalSet}
	 * if {@link CommonRequestModel#getExclude()} are not empty.
	 * {@link CommonRequestModel#getInclude()} and {@link CommonRequestModel#getExclude()} must be mutually exclusive.
	 * Will throw {@link @ClientException} in case both are not empty.
	 * In case both are empty {@code java.util.Collections.UnmodifiableSet} or {@code originalSet} will be provided.
	 *
	 * @param common        wrapper class to provide include or exclude info.
	 * @param templateModel Templated API schema for requested service
	 * @return a  {@code java.util.Collections.UnmodifiableSet} subset of {@code originalSet} will be provided.
	 * @throws ClientException if {@link CommonRequestModel#getInclude()}
	 *                         and {@link CommonRequestModel#getExclude()} both are not empty.
	 */
	private Map<String, FeatureTemplate> getRequestedList(CommonRequestModel common, ApiTemplate templateModel) {
		Map<String, FeatureTemplate> features = templateModel.getFeaturesMap();
		Set<String> include = common.getInclude();
		Set<String> exclude = common.getExclude();
		Set<String> defaultFeatures = templateModel.getApiParamsTemplate().getDefaultFeatures();
		if (!ObjectUtils.isEmpty(include)) {
			if (!ObjectUtils.isEmpty(exclude)) {
				throw ClientException.create(ClientErrorEnum.BAD_REQUEST, MessageConstants.SERVICE_INCLUDE_EXCLUDE_EXCLUSIVE);
			}
			include.addAll(defaultFeatures);
			final Map<String, FeatureTemplate> filteredFeatures = new HashedMap<>();
			include.forEach((String name) -> {
				if (!features.containsKey(name)) {
					throw ClientException.create(ClientErrorEnum.BAD_REQUEST,
							MessageConstants.SERVICE_UNKNOWN_PROP_REQUESTED + name);
				}
				filteredFeatures.put(name, features.get(name));
			});
			return filteredFeatures;
		} else if (!ObjectUtils.isEmpty(exclude)) {
			if (!Collections.disjoint(exclude, defaultFeatures)) {
				throw ClientException.create(ClientErrorEnum.BAD_REQUEST,
						MessageConstants.SERVICE_CANNOT_EXCLUDE_DEFAULT_FEATURES, defaultFeatures.toString());
			}
			return features.keySet().stream()
					.filter(s -> !exclude.contains(s))
					.collect(Collectors.toMap(s -> s, features::get, (a, b) -> b, HashedMap::new));
		}
		return new HashedMap<>(features);
	}
}
