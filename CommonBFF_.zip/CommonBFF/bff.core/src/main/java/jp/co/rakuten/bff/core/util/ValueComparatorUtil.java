package jp.co.rakuten.bff.core.util;

import org.apache.commons.lang3.StringUtils;

import static jp.co.rakuten.bff.core.constant.BffConstants.EMPTY_ALLOWED;

/**
 * Centralize the valid value logic
 *
 * @author tony.rouillard
 */
public class ValueComparatorUtil {
	private ValueComparatorUtil() {
	}

	/**
	 * Check if the parameter value is valid
	 *
	 * @param value      Object
	 * @param valueComparator valid null and empty value
	 * @return true if the value is considered as valid
	 */
	public static boolean isValidParameterValue(Object value, String valueComparator) {
		boolean result;
		if (value instanceof String) {
			if (EMPTY_ALLOWED.equals(valueComparator)) {
				result = false;
			} else {
				result = StringUtils.isEmpty((String) value);
			}
		} else {
			result = value == null;
		}
		return !result;
	}
}
