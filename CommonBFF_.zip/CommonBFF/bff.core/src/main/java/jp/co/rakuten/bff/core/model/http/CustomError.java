package jp.co.rakuten.bff.core.model.http;

/**
 * The class contains the error related information.
 */
public class CustomError {
	/** The code of the error */
	private String code;

	/** The message of the error */
	private String message;

	/** All args constructor
	 * @param code error code
	 * @param message error message
	 * */
	public CustomError(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public CustomError() { }

	/**
	 * CustomError builder method
	 *
	 * @return CustomErrorBuilder
	 */
	public static CustomErrorBuilder builder() {
		return new CustomErrorBuilder();
	}

	/**Override to string*/
	@Override
	public String toString() {
		return "CustomError{" +
				"code='" + code + '\'' +
				", message='" + message + '\'' +
				'}';
	}

	public String getCode() {
		return this.code;
	}

	public String getMessage() {
		return this.message;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * CustomErrorBuilder builder class
	 */
	public static class CustomErrorBuilder {
		private String code;
		private String message;

		/**
		 * set error code
		 * @param code error code
		 * @return CustomErrorBuilder
		 */
		public CustomErrorBuilder code(String code) {
			this.code = code;
			return this;
		}

		/**
		 * set error message
		 * @param message error message
		 * @return CustomErrorBuilder
		 */
		public CustomErrorBuilder message(String message) {
			this.message = message;
			return this;
		}

		/**
		 * create CustomError object
		 *
		 * @return CustomError
		 */
		public CustomError build() {
			return new CustomError(code, message);
		}
	}
}
