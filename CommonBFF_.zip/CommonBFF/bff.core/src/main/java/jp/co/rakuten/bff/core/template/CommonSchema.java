package jp.co.rakuten.bff.core.template;


import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.List;

/**
 * CommonSchema is shared by Request and Response schema
 * It will hold all the fields which may and/or should have
 * inside the Request and/or Response schema
 * Mandatory parameters for each schema would be
 * <ul>
 *     <li>name</li>
 *     <li>type</li>
 * </ul>
 * Rest of the parameters are optional but they are dependent on some conditions
 */
public class CommonSchema {
	private String name;
	private String type;
	private Boolean required;
	private String source;
	private String dataType;
	private Integer maxSize;
	private Integer minSize;
	private Integer minLength;
	private Integer maxLength;
	private Integer minValue;
	private Integer maxValue;
	private Integer minSelectable;
	private Integer maxSelectable;
	private String pattern;
	private String propType;
	private String propKeyPrefix;
	private String propKeySuffix;
	private String cacheKey;
	private String format;
	private String valueComparator;
	private List<Object> options;
	private List<CommonSchema> parameters;
	private List<CommonSchema> headers;

	@JsonAlias("default")
	private Object defaultValue;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getRequired() {
		return required;
	}

	public void setRequired(Boolean required) {
		this.required = required;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Integer getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(Integer maxSize) {
		this.maxSize = maxSize;
	}

	public Integer getMinSize() {
		return minSize;
	}

	public void setMinSize(Integer minSize) {
		this.minSize = minSize;
	}

	public Integer getMinLength() {
		return minLength;
	}

	public void setMinLength(Integer minLength) {
		this.minLength = minLength;
	}

	public Integer getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(Integer maxLength) {
		this.maxLength = maxLength;
	}

	public Integer getMinValue() {
		return minValue;
	}

	public void setMinValue(Integer minValue) {
		this.minValue = minValue;
	}

	public Integer getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(Integer maxValue) {
		this.maxValue = maxValue;
	}

	public Integer getMinSelectable() {
		return minSelectable;
	}

	public void setMinSelectable(Integer minSelectable) {
		this.minSelectable = minSelectable;
	}

	public Integer getMaxSelectable() {
		return maxSelectable;
	}

	public void setMaxSelectable(Integer maxSelectable) {
		this.maxSelectable = maxSelectable;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getPropType() {
		return propType;
	}

	public void setPropType(String propType) {
		this.propType = propType;
	}

	public String getPropKeyPrefix() {
		return propKeyPrefix;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public void setPropKeyPrefix(String propKeyPrefix) {
		this.propKeyPrefix = propKeyPrefix;
	}

	public String getCacheKey() {
		return cacheKey;
	}

	public void setCacheKey(String cacheKey) {
		this.cacheKey = cacheKey;
	}

	public List<Object> getOptions() {
		return options;
	}

	public void setOptions(List<Object> options) {
		this.options = options;
	}

	public List<CommonSchema> getParameters() {
		return parameters;
	}

	public void setParameters(List<CommonSchema> parameters) {
		this.parameters = parameters;
	}

	public Object getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(Object defaultValue) {
		this.defaultValue = defaultValue;
	}

	public List<CommonSchema> getHeaders() {
		return headers;
	}

	public void setHeaders(List<CommonSchema> headers) {
		this.headers = headers;
	}

	public String getValueComparator() {
		return valueComparator;
	}

	public void setValueComparator(String valueComparator) {
		this.valueComparator = valueComparator;
	}

	public String getPropKeySuffix() {
		return propKeySuffix;
	}

	public void setPropKeySuffix(String propKeySuffix) {
		this.propKeySuffix = propKeySuffix;
	}
}
