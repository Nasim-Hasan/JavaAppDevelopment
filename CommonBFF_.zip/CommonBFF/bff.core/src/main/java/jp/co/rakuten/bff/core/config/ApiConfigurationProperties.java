package jp.co.rakuten.bff.core.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * This is a ConfigurationProperties representation of the key value pair properties starting with {@code api}
 * As a ConfigurationProperties, this is covered under {@link org.springframework.cloud.context.scope.refresh.RefreshScope}
 */
@Component
@ConfigurationProperties(prefix = "api")
public class ApiConfigurationProperties {

	private Map<String, String> mapping;

	/**
	 * @return the map of key-value pair for properties
	 */
	public Map<String, String> getMapping() {
		return mapping;
	}

	/**
	 * @param mapping set with values from the properties file
	 */
	public void setMapping(Map<String, String> mapping) {
		this.mapping = mapping;
	}
}
