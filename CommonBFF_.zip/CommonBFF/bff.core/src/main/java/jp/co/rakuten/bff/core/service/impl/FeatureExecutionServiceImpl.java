package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.cache.IchibaCacheManager;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffFeatureMetricsManager;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.service.CallDefinitionExecutionService;
import jp.co.rakuten.bff.core.service.FeatureExecutionService;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.BFFUtil;
import jp.co.rakuten.bff.core.util.ExceptionUtil;
import jp.co.rakuten.bff.core.util.RequestUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * This component do 3 major task.<br/>
 * <ul>
 *     <li>Create call definition dependency chain.</li>
 *     <li>Feature wise call those call definition based on dependency.</li>
 *     <li>Run each feature's post processor to create feature wise final response from those feature's
 *     call definition response.</li>
 * </ul>
 */
@Service
public class FeatureExecutionServiceImpl implements FeatureExecutionService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FeatureExecutionServiceImpl.class);

	enum Type {
		CALL_DEFINITION,
		FEATURE
	}

	private CallDefinitionExecutionService callDefinitionExecutionService;
	private GenericFeatureProcessor genericFeatureProcessor;
	private IchibaCacheManager ichibaCacheManager;
	private Environment environment;
	/**
	 * Default constructor.
	 *
	 * @param callDefinitionExecutionService {@link CallDefinitionResponseStatus}
	 * @param genericFeatureProcessor        {@link GenericFeatureProcessor}
	 * @param ichibaCacheManager             {@link IchibaCacheManager}
	 */
	@Autowired
	public FeatureExecutionServiceImpl(CallDefinitionExecutionService callDefinitionExecutionService,
									   GenericFeatureProcessor genericFeatureProcessor,
									   IchibaCacheManager ichibaCacheManager) {
		this.callDefinitionExecutionService = callDefinitionExecutionService;
		this.genericFeatureProcessor = genericFeatureProcessor;
		this.ichibaCacheManager = ichibaCacheManager;
	}

	/**
	 * environment setter
	 *
	 * @param environment {@link Environment}
	 */
	@Autowired
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	/**
	 * Prepare call definition mono dependency and feature wise execute those mono. After all call definition execution
	 * it will call feature post processor.
	 *
	 * @param clientRequestModel contains user requested data.
	 * @param executionModel     call definition to feature map, requested feature list, call definition list
	 *                           and interface set given here
	 * @param validatedClientRequest   Validated request - feature name as key and {@link CommonRequestModel} as value
	 * @param apiTemplate        API config file template
	 * @return Response mono map - feature name as key and feature response as value
	 */
	@Override
	public Mono<Map<String, Object>> executeFeatures(ClientRequestModel clientRequestModel,
													 ExecutionModel executionModel,
													 Map<String, CommonRequestModel> validatedClientRequest,
													 ApiTemplate apiTemplate) {
		return Mono.just(validatedClientRequest).flatMap((Map<String, CommonRequestModel> validatedRequest)-> {
			Map<String, Mono<CallDefinitionResponse>> callDefinitionMonoMap = new ConcurrentHashMap<>();
			Map<String, CallDefinitionResponse> callDefinitionResponseMap = new ConcurrentHashMap<>();

			CallDefinitionTemplate availableCallDefinition;
			//Get available call definition
			Map<String, CallDefinitionTemplate> executionMap = new ConcurrentHashMap<>(executionModel.getExecutionMap());
			while ((availableCallDefinition =
					getAvailableCallDefinition(executionMap, callDefinitionMonoMap)) != null) {
				Mono<CallDefinitionTemplate> currentCallDefinitionMono = Mono.just(availableCallDefinition);
				Mono<CallDefinitionResponse> currentCallDefinitionResponseMono =
						currentCallDefinitionMono.flatMap((CallDefinitionTemplate callDefinitionTemplate) -> {
							Mono<CallDefinitionResponse> callDefinitionResponseMono;
							if (CollectionUtils.isEmpty(callDefinitionTemplate.getDependsList())) {
								//If call definition has no dependency call directly callDefinitionExecutionService
								callDefinitionResponseMono =
										callDefinitionExecutionService.getCallDefinitionResponse(callDefinitionTemplate,
												validatedRequest, apiTemplate, executionModel, callDefinitionResponseMap,
												clientRequestModel.getHeader(),
												clientRequestModel.getRequestModel().getMockConnections())
												.doOnRequest(l -> LOGGER.debug("{} call definition requested------",
														callDefinitionTemplate.getName()));
							} else {
								//if call definition has dependency - ensure all of its dependent call definition call completed
								//then call callDefinitionExecutionService
								Mono<List<CallDefinitionResponse>> parentsPromise =
										getParentsMergedMono(callDefinitionMonoMap,
												callDefinitionTemplate.getDependsList());
								callDefinitionResponseMono = parentsPromise.flatMap(parents ->
										callDefinitionExecutionService.getCallDefinitionResponse(callDefinitionTemplate,
												validatedRequest, apiTemplate, executionModel, callDefinitionResponseMap,
												clientRequestModel.getHeader(),
												clientRequestModel.getRequestModel().getMockConnections()));
							}

							return callDefinitionResponseMono;
						});

				final CallDefinitionTemplate currentCallDefinition = availableCallDefinition;

				// Add call definition response to the callDefinitionResponseMap
				currentCallDefinitionResponseMono = currentCallDefinitionResponseMono
						.flatMap((CallDefinitionResponse callDefinitionResponse) -> {
							LOGGER.info("callDefinition -> {} -> post processor", currentCallDefinition.getName());
							recordForMonitoring(Type.CALL_DEFINITION, currentCallDefinition, null, callDefinitionResponse);
							callDefinitionResponseMap.put(currentCallDefinition.getName(), callDefinitionResponse);
							return Mono.just(callDefinitionResponse);
						}).onErrorResume((Throwable throwable) -> {
							if (throwable instanceof BackendException) {
								LOGGER.info("callDefinition -> {}", currentCallDefinition.getName());
							} else {
								LOGGER.error("callDefinition -> {}", currentCallDefinition.getName(), throwable);
							}
							//If any error occurred in call definition execution service
							CallDefinitionResponse callDefinitionResponse =
									catchExceptionAndBuildCallDefinitionResponse(throwable, currentCallDefinition);
							callDefinitionResponseMap.put(currentCallDefinition.getName(), callDefinitionResponse);
							return Mono.just(callDefinitionResponse);
						});

				// Add call definition response cache to callDefinitionMonoMap
				callDefinitionMonoMap.put(currentCallDefinition.getName(), currentCallDefinitionResponseMono.cache());
			}

			Map<String, Object> finalResponseMap = new HashMap<>();
			List<Mono<Boolean>> featureMonos = new ArrayList<>();
			//Prepare all features mono based on their relevant call definition
			executionModel.getFeatureModelList().forEach((FeatureTemplate featureTemplate) -> {
				List<Mono<CallDefinitionResponse>> callDefinitionMonos = new ArrayList<>();
				//collect all call definition mono for this feature
				featureTemplate.getCallDefinitionsSet().forEach(callDefinitionTemplate ->
						callDefinitionMonos.add(callDefinitionMonoMap.get(callDefinitionTemplate.getName())));

				String apiKey = RequestUtil.buildAPIKey(clientRequestModel);
				Mono<Boolean> mono = executeFeatureWithCache(callDefinitionResponseMap, validatedRequest, finalResponseMap,
						featureTemplate, callDefinitionMonos, clientRequestModel.getHeader(), apiKey);
				featureMonos.add(mono);
			});

			//merge all feature's mono which eventually call all feature's in parallel then features call definition
			//That means our final response prepared and returning it.
			Mono<List<Boolean>> listMono = Flux.merge(featureMonos).collectList();
			return listMono.flatMap( (List<Boolean> booleans) -> {
				return Mono.just(finalResponseMap);
			});
		});
	}

	/**
	 * @param throwable          {@link Throwable}
	 * @param callDefinition Call definition
	 * @return Map<String, Object> call definition error response
	 */
	private CallDefinitionResponse catchExceptionAndBuildCallDefinitionResponse(Throwable throwable,
																				CallDefinitionTemplate callDefinition) {
		BffException bffException = ExceptionUtil.getBffException(throwable);
		recordForMonitoring(Type.CALL_DEFINITION, callDefinition, bffException,null);

		CallDefinitionResponse callDefinitionResponse =
				new CallDefinitionResponse(CallDefinitionResponseStatus.FAILURE);

		CallDefinitionError callDefinitionError = new CallDefinitionError();
		callDefinitionError.setCode(bffException.getErrorCode().value());
		callDefinitionError.setMessage(bffException.getMessage());

		callDefinitionResponse.setCallDefinitionError(callDefinitionError);

		return callDefinitionResponse;
	}

	/**
	 * Get the response from cache if not available Prepare call definition mono dependency and feature wise execute
	 * those mono. After all call definition execution, it will call feature post processor.
	 *
	 * @param callDefinitionResponseMap Call definition name as key and Call definition response as value
	 * @param validatedRequest          Validated request - feature name as key and {@link CommonRequestModel} as value
	 * @param finalResponseMap          Map<String, Object> - holds feature response and interface set given here
	 * @param featureTemplate           API config file template
	 * @param callDefinitionMonos       List of call definition mono reference
	 * @param header                    contains header values from user
	 * @param apiKey                    api key formed using service, operation and version
	 * @return Response mono map - feature name as value
	 */
	private Mono<Boolean> executeFeatureWithCache(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
												  Map<String, CommonRequestModel> validatedRequest,
												  Map<String, Object> finalResponseMap,
												  FeatureTemplate featureTemplate,
												  List<Mono<CallDefinitionResponse>> callDefinitionMonos,
												  HttpHeaders header,
												  String apiKey) {
		return ichibaCacheManager.getFromCache(featureTemplate, validatedRequest, header, apiKey)
				.flatMap((CacheDataModel response) ->
						         onCacheResponseFound(callDefinitionResponseMap, validatedRequest, finalResponseMap,
						                              featureTemplate,
						                              callDefinitionMonos, header, apiKey, response)
				).onErrorResume((Throwable ex) -> {
					LOGGER.error("Error occurred while fetching from cache for feature : {}, calling backend now.",
							featureTemplate.getName());
					return executeFeatureAndHandleError(callDefinitionResponseMap, validatedRequest, finalResponseMap,
							featureTemplate, callDefinitionMonos, header, apiKey);
				}).switchIfEmpty(Mono.defer(() -> {
					LOGGER.debug("Calling backend for {} data.", featureTemplate.getName());
					return executeFeatureAndHandleError(callDefinitionResponseMap, validatedRequest, finalResponseMap,
							featureTemplate, callDefinitionMonos, header, apiKey);
				}));
	}

	private Mono<Boolean> onCacheResponseFound(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
	                                                     Map<String, CommonRequestModel> validatedRequest,
	                                                     Map<String, Object> finalResponseMap,
	                                                     FeatureTemplate featureTemplate,
	                                                     List<Mono<CallDefinitionResponse>> callDefinitionMonos,
	                                                     HttpHeaders header, String apiKey, CacheDataModel response) {
		if (response.isStaleCache()) {
			return onCacheResponseBeingStale(callDefinitionResponseMap, validatedRequest, finalResponseMap,
			                                 featureTemplate,
			                                 callDefinitionMonos, header, apiKey, response);
		} else {
			return getMono(finalResponseMap, featureTemplate, response);
		}
	}

	private Mono<Boolean> onCacheResponseBeingStale(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
	                                                Map<String, CommonRequestModel> validatedRequest,
	                                                Map<String, Object> finalResponseMap,
	                                                FeatureTemplate featureTemplate,
	                                                List<Mono<CallDefinitionResponse>> callDefinitionMonos,
	                                                HttpHeaders header, String apiKey, CacheDataModel response) {
		return ichibaCacheManager.getStaleActiveFlagFromCache(featureTemplate, validatedRequest, apiKey)
				.flatMap(isStaleActive -> {
					if (Boolean.valueOf(String.valueOf(isStaleActive))) {
						finalResponseMap.put(featureTemplate.getName(), response.getCacheMap());
						return Mono.just(true);
					} else {
						LOGGER.info("Cache is stale for feature:{} and StaleActiveFlag is {}, trying to call " +
								            "backend", featureTemplate.getName(), isStaleActive);
						return onCacheBeingStaleAndNotActive(callDefinitionResponseMap, validatedRequest,
						                                     finalResponseMap, featureTemplate, callDefinitionMonos,
						                                     header, apiKey, response);
					}
				})
				.switchIfEmpty(Mono.defer(() -> {
					LOGGER.info("Cache is stale for feature:{} and StaleActiveFlag is not set, trying to call " +
							            "backend", featureTemplate.getName());
					return onCacheBeingStaleAndNotActive(callDefinitionResponseMap, validatedRequest,
					                                     finalResponseMap, featureTemplate, callDefinitionMonos,
					                                     header, apiKey, response);
				}))
				.onErrorResume(error -> {
					LOGGER.error("Exception while reading StaleActiveFlag from cache for feature={}",
					             featureTemplate.getName(), error);
					return onCacheBeingStaleAndNotActive(callDefinitionResponseMap, validatedRequest,
					                                     finalResponseMap, featureTemplate, callDefinitionMonos,
					                                     header, apiKey, response);
				});
	}

	private Mono<Boolean> onCacheBeingStaleAndNotActive(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
	                                                     Map<String, CommonRequestModel> validatedRequest,
	                                                     Map<String, Object> finalResponseMap,
	                                                     FeatureTemplate featureTemplate,
	                                                     List<Mono<CallDefinitionResponse>> callDefinitionMonos,
	                                                     HttpHeaders header, String apiKey, CacheDataModel response) {
		return executeFeaturePostProcessing(callDefinitionResponseMap, validatedRequest,
		                                    finalResponseMap, featureTemplate, callDefinitionMonos, header, apiKey)
				.flatMap((Boolean responseFlag) -> {
					if (BooleanUtils.isFalse(responseFlag)) {
						return processStaleResponse(validatedRequest, finalResponseMap, featureTemplate, apiKey,
						                            response, null);
					}
					return Mono.just(true);
				})
				.onErrorResume(
						ex -> processStaleResponse(validatedRequest, finalResponseMap, featureTemplate, apiKey,
						                           response, ex));
	}

	private Mono<Boolean> getMono(Map<String, Object> finalResponseMap,
			FeatureTemplate featureTemplate, CacheDataModel response) {
		LOGGER.info("Data found in cache for feature: {}.", featureTemplate.getName());
		finalResponseMap.put(featureTemplate.getName(), response.getCacheMap());
		return Mono.just(true);
	}

	private Mono<Boolean> processStaleResponse(Map<String, CommonRequestModel> validatedRequest,
											   Map<String, Object> finalResponseMap, FeatureTemplate featureTemplate,
											   String apiKey, CacheDataModel response, Throwable ex) {
		if (ObjectUtils.isNotEmpty(ex)) {
			LOGGER.error("Error occurred while calling backend for feature: {}, serving stale cached data",
					featureTemplate.getName(), ex);
		} else {
			LOGGER.error("Error occurred while calling backend for feature: {}, serving stale cached data",
					featureTemplate.getName());
		}
		return ichibaCacheManager.setStaleActiveFlagToCache(featureTemplate, validatedRequest, apiKey,
		                                                    BFFUtil.getActiveFlagTimeout(environment))
				.onErrorResume(error -> {
					LOGGER.error("Exception while storing staleActiveFlag for feature:{} to cache: ",
					             featureTemplate.getName(), error);
					return Mono.just(true);
				})
				.flatMap(ignoredValue -> {
					finalResponseMap.put(featureTemplate.getName(), response.getCacheMap());
					return Mono.just(true);
				});
	}

	private Mono<Boolean> setToCacheAndHandleError(Map<String, CommonRequestModel> validatedRequest,
												   FeatureTemplate featureTemplate, HttpHeaders header, String apiKey,
												   Map<String, Object> response) {
		return ichibaCacheManager.setToCache(featureTemplate, validatedRequest, response, header, apiKey)
				.onErrorResume((Throwable throwable) -> {
					LOGGER.error("Error occured while saving data to cache for feature: {}", featureTemplate.getName(),
							throwable);
					return Mono.just(true);
				});
	}

	private Mono<Boolean> executeFeatureAndHandleError(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
													   Map<String, CommonRequestModel> validatedRequest,
													   Map<String, Object> finalResponseMap,
													   FeatureTemplate featureTemplate,
													   List<Mono<CallDefinitionResponse>> callDefinitionMonos,
													   HttpHeaders header,
													   String apiKey) {
		return executeFeaturePostProcessing(callDefinitionResponseMap, validatedRequest, finalResponseMap,
				featureTemplate,
				callDefinitionMonos, header, apiKey)
				.onErrorResume((Throwable throwable) -> {
					handleFeaturePostProcessorError(finalResponseMap, featureTemplate, throwable);
					return Mono.just(true);
				});
	}

	/**
	 * Merge all call definition mono to prepare feature response.
	 *
	 * @param callDefinitionResponseMap Map<String, Object> - holds resolved call definition response
	 *                                  Key - Call definition name, Value - Call definition response object
	 * @param finalResponseMap          Map<String, Object> - holds feature response
	 *                                  Key - Feature name, Value - Feature response object
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionMonos       List of call definition mono reference
	 * @return Mono<String> Feature Mono reference
	 */
	private Mono<Boolean> executeFeaturePostProcessing(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
													   Map<String, CommonRequestModel> validatedRequest,
													   Map<String, Object> finalResponseMap,
													   FeatureTemplate featureTemplate,
													   List<Mono<CallDefinitionResponse>> callDefinitionMonos,
													   HttpHeaders header,
													   String apiKey) {
		return Flux.merge(callDefinitionMonos).collectList()
				.flatMap((List<CallDefinitionResponse> maps) -> {
					//Call definition call completed
					Mono<FeaturePostProcessorResponse> featureResponseMono =
							getProcessedData(validatedRequest.get(featureTemplate.getName()),
									callDefinitionResponseMap, featureTemplate);
					return featureResponseMono
							.flatMap((FeaturePostProcessorResponse featureResponse) -> {
								Mono<Boolean> resultMono;
								Map<String, Object> responseWithDataAndHeader = Map
										.of(BffConstants.DATA, featureResponse.getResponseMap(), BffConstants.HEADER,
												featureResponse.getHeaders());
								if (featureResponse.isCacheable() && MapUtils
										.isNotEmpty(featureResponse.getResponseMap())) {
									resultMono = setToCacheAndHandleError(validatedRequest, featureTemplate, header,
											apiKey, responseWithDataAndHeader);
								} else {
									resultMono = getBooleanMono(featureTemplate);
								}
								finalResponseMap.put(featureTemplate.getName(), responseWithDataAndHeader);
								return resultMono;
							});
				})
				.doOnRequest(l -> LOGGER.debug("{} feature requested------", featureTemplate.getName()));
	}

	private Mono<Boolean> getBooleanMono(FeatureTemplate featureTemplate) {
		Mono<Boolean> resultMono;
		LOGGER.info("Found partial feature response for {} and not storing to cache",
				featureTemplate.getName());
		resultMono = Mono.just(false);
		return resultMono;
	}

	/**
	 * Log feature's post processor error and prepare error response
	 *
	 * @param finalResponseMap Map<String, Object> - holds feature response
	 *                         Key - Feature name, Value - Feature response object
	 * @param featureTemplate  {@link FeatureTemplate}
	 * @param throwable        Feature's post processor's {@link Throwable}
	 */
	private void handleFeaturePostProcessorError(Map<String, Object> finalResponseMap,
												 FeatureTemplate featureTemplate,
												 Throwable throwable) {
		//If any error occurred in feature's generic/custom post processor
		BffException bffException = ExceptionUtil.getBffException(throwable);
		finalResponseMap.put(featureTemplate.getName(), Map.of("error",
				Map.of("code", bffException.getErrorCode().value(),
						"message", bffException.getMessage())));
	}

	/**
	 * Run feature post processor.
	 *
	 * @param callDefinitionResponseMap It holds call definition response.
	 * @param featureTemplate           {@link FeatureTemplate} - feature specific data.
	 * @return Mono<Map < String, Object>> Feature's processed data as mono.
	 */
	private Mono<FeaturePostProcessorResponse> getProcessedData(CommonRequestModel validatedClientData,
																Map<String, CallDefinitionResponse> callDefinitionResponseMap,
																FeatureTemplate featureTemplate) {
		Mono<FeaturePostProcessorResponse> featureResponseMono;
		if (featureTemplate.getProcessorBean() == null) {
			featureResponseMono = genericFeatureProcessor.postProcess(validatedClientData, featureTemplate,
					callDefinitionResponseMap);
		} else {
			featureResponseMono = featureTemplate.getProcessorBean().postProcess(validatedClientData, featureTemplate,
					callDefinitionResponseMap);
		}
		return featureResponseMono;
	}

	/**
	 * Run all the dependent call definition in parallel.
	 *
	 * @param callDefinitionMonoMap Call definition mono map, which holds all call definition for
	 *                              user requested features
	 * @param parentIds             Dependent call definition list
	 * @return List of dependent mono zip result
	 */
	private Mono<List<CallDefinitionResponse>> getParentsMergedMono(
			Map<String, Mono<CallDefinitionResponse>> callDefinitionMonoMap,
			List<String> parentIds) {

		List<Mono<CallDefinitionResponse>> parentCallDefinitionList = new ArrayList<>();
		parentIds.forEach(parentCallDefinition ->
				parentCallDefinitionList.add(callDefinitionMonoMap.get(parentCallDefinition)));

		return Flux.merge(parentCallDefinitionList).collectList();
	}

	/**
	 * Provide an call definition which has no dependency or all dependency resolved.
	 *
	 * @param requestedFeaturesCallDefinitions Requested features call definition
	 * @param callDefinitionMonoMap            Which holds resolved call definition mono
	 * @return Available call definition
	 */
	private CallDefinitionTemplate getAvailableCallDefinition(
			Map<String, CallDefinitionTemplate> requestedFeaturesCallDefinitions,
			Map<String, Mono<CallDefinitionResponse>> callDefinitionMonoMap) {
		CallDefinitionTemplate callDefinitionReadyToCall = null;
		//Iterate all call definitions of client's requested features to find available one
		for (CallDefinitionTemplate callDefinitionTemplate : requestedFeaturesCallDefinitions.values()) {
			boolean parentsAlreadyPrepared = true;
			//if current call definition has any dependency
			if (!CollectionUtils.isEmpty(callDefinitionTemplate.getDependsList())) {
				//check all of its dependent call definition's resolved or not
				parentsAlreadyPrepared = isAllDependencyResolved(callDefinitionTemplate, callDefinitionMonoMap);
			}

			if (parentsAlreadyPrepared) {
				callDefinitionReadyToCall = requestedFeaturesCallDefinitions.remove(callDefinitionTemplate.getName());
				break;
			}
		}
		return callDefinitionReadyToCall;
	}

	/**
	 * Check all of its dependent call definition's resolved or not
	 *
	 * @param callDefinitionTemplate Given {@link CallDefinitionTemplate}
	 * @param callDefinitionMonoMap  Which holds resolved call definition mono
	 * @return boolean true - all dependency resolved, false - one or more dependency not resolved
	 */
	private boolean isAllDependencyResolved(CallDefinitionTemplate callDefinitionTemplate,
											Map<String, Mono<CallDefinitionResponse>> callDefinitionMonoMap) {
		for (String dependentCallDefinition : callDefinitionTemplate.getDependsList()) {
			if (!callDefinitionMonoMap.containsKey(dependentCallDefinition)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Send the metric to prometheus. If the exception is empty, it is a success.
	 * The errorStatus is {BackendStatusCode}.{Exception ErrorType}
	 *
	 * @param type      {@link Type} enum - CALL_DEFINITION or FEATURE
	 * @param callDefinitionTemplate    call definition template
	 * @param exception The exception in case of failure, otherwise null.
	 * @param callDefinitionResponse  the calldefinition response to check for status
	 */
	private void recordForMonitoring(Type type,CallDefinitionTemplate callDefinitionTemplate,
									 BffException exception, CallDefinitionResponse callDefinitionResponse) {
		List<String> interfacesCalled= callDefinitionTemplate.getInterfacesList();
		//check error from backend
		if (exception == null ) {
			//check calldefintionResponseStatus
			if (ObjectUtils.isNotEmpty(callDefinitionResponse)) {
				String callDefinitionResponseStatus =
						String.valueOf(callDefinitionResponse.getStatus());
				LOGGER.info("'{}' {} completed", callDefinitionTemplate.getName(), type.name());
				BffFeatureMetricsManager.markCallDefinitionExit(callDefinitionTemplate.getName(),
						interfacesCalled, callDefinitionResponseStatus);
			} else {
				LOGGER.info("'{}' {} completed", callDefinitionTemplate.getName(), type.name());
				BffFeatureMetricsManager.markCallDefinitionExit(callDefinitionTemplate.getName(),
						interfacesCalled, "200.success");
			}
		} else {
			LOGGER.error("'{}' {} ERROR", callDefinitionTemplate.getName(), type.name());
			String errorStatus;
			if(ObjectUtils.isNotEmpty(exception.getUpstreamStatusCode())) {
				errorStatus=String.valueOf(exception.getUpstreamStatusCode().value())+"."+exception.getErrorType();
			} else {
				errorStatus = "http_exception." + exception.getErrorType();
			}
			BffFeatureMetricsManager.markCallDefinitionExit(
					callDefinitionTemplate.getName(),interfacesCalled,errorStatus);
		}
	}
}
