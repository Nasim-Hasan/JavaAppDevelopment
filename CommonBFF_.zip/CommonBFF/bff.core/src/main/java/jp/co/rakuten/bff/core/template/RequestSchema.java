package jp.co.rakuten.bff.core.template;

import java.util.ArrayList;
import java.util.List;

/**
 * Template Model Class intended for mapping corresponding Json field
 * <br>
 * Holds necessary information for validating client request
 */
public class RequestSchema {
	private List<CommonSchema> parameters = new ArrayList<>();
	private List<CommonSchema> headers = new ArrayList<>();

	public List<CommonSchema> getParameters() {
		return this.parameters;
	}

	public void setParameters(List<CommonSchema> parameters) {
		this.parameters = parameters;
	}

	public List<CommonSchema> getHeaders() {
		return headers;
	}

	public void setHeaders(List<CommonSchema> headers) {
		this.headers = headers;
	}

	@Override
	public String toString() {
		return "RequestSchema{" + "parameters=" + parameters + ", headers=" + headers + '}';
	}
}
