package jp.co.rakuten.bff.core.constant;

/**
 * This enum contains request, headers & response.
 * These is using as key to get and put data into map
 */
public enum ParameterTypeEnum {
	REQUEST("request"),
	HEADER("headers"),
	RESPONSE("response");

	String type;

	ParameterTypeEnum(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}
