package jp.co.rakuten.bff.core.util.inputexchangeutils;

public class KeywordChecker {
    /** NGワード */
    private static final String NG_CHARS = " 、。，．・：；？！゛゜´｀¨"
            + "＾￣＿ヽヾゝゞ〃仝々〆〇ー?‐／" + "＼～?｜…‥‘’“”（）〔〕［］" + "｛｝〈〉《》「」『』【】＋?±×"
            + "÷＝≠＜＞≦≧∞∴♂♀°′″℃￥" + "＄??％＃＆＊＠§☆★○●◎◇" + "◆□■△▲▽▼※〒→←↑↓〓"
            + "∈∋⊆⊇⊂⊃∪∩∧∨?⇒⇔∀" + "∃∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬" + "Å‰♯♭♪†‡¶◯"
            + "０１２３４５６７８９" + "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯ" + "ＰＱＲＳＴＵＶＷＸＹＺ"
            + "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏ" + "ｐｑｒｓｔｕｖｗｘｙｚ" + "ぁあぃいぅうぇえぉおかがきぎくぐけげこご"
            + "さざしじすずせぜそぞただちぢっつづてでとど" + "なにぬねのはばぱひびぴふぶぷへべぺほぼぽ"
            + "まみむめもゃやゅゆょよらりるれろゎわゐゑをん" + "ァアィイゥウェエォオカガキギクグケゲコゴ"
            + "サザシジスズセゼソゾタダチヂッツヅテデトド" + "ナニヌネノハバパヒビピフブプヘベペホボポ"
            + "マミムメモャヤュユョヨラリルレロヮワ" + "ヰヱヲンヴヵヶ" + "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟ"
            + "ΠΡΣΤΥΦΧΨΩ" + "αβγδεζηθικλμνξο" + "πρστυφχψω"
            + "АБВГДЕЁЖЗИЙКЛМНОП" + "РСТУФХЦЧШЩЪЫЬЭЮЯ" + "абвгдеёжзийклмноп"
            + "рстуфхцчшщъыьэюя";

    /**
     * 検索キーワード(1ワード)が適切か判定します。<br>
     * ワードが二文字以上ならOKですが、一文字であった場合には、 ASCII文字またはNG_CHARS内のいずれかの文字なら不適切になります。
     *
     * @param keyword
     *            検索キーワード(1ワード)
     * @return NGワードでは無いなら true
     * @see #NG_CHARS
     */
    public static boolean isOKWord(String keyword) {
        if (keyword == null) {
            return false;
        }
        if (keyword.isEmpty()) {
            return false;
        }

        if (keyword.length() > 1) {
            // 2文字以上ならばOK
            return true;
        } else {
            if (keyword.length() == 1) {
                // 1文字の場合
                char c = keyword.charAt(0);
                if (' ' <= c && c <= '~') {
                    // ASCII1文字だったら
                    return false;
                }
                // NG文字列との比較
                if (NG_CHARS.indexOf(c) != -1) {
                    // NG文字に含まれていた
                    return false;
                }
            }
        }
        return true;
    }
}
