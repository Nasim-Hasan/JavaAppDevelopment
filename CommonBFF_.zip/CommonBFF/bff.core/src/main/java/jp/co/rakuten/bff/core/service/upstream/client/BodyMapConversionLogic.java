package jp.co.rakuten.bff.core.service.upstream.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.text.CaseUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copied from generic gateway
 * This class is helper utility for converting case to camel case from different cases for JSON and XML responses.
 *
 * @author yugansh.bhola
 */
public class BodyMapConversionLogic {
	private static final char[] RESTRICTED_CHARSET = new char[]{'_', '-'};

	private final XmlMapper xmlMapper = new XmlMapper();

	/**
	 * This is a utility method to convert an underlying xml String to equivalent Map based object
	 * that can be used for further processing.
	 *
	 * @param xmlString          the String input to be converted
	 * @param convertToCamelCase Indicate if the map needs to be converted to camelCase
	 * @return the equivalent Map Object.
	 * @throws IOException if a low-level I/O problem (unexpected end-of-input, network error) occurs.
	 */
	public Map<String, Object> xmlToMap(String xmlString, boolean convertToCamelCase) throws IOException {
		Map<String, Object> map = xmlMapper.readValue(xmlString, new TypeReference<>() {
		});
		return convertToCamelCase ? convertMap(map) : map;
	}

	/**
	 * This is a utility method to convert an underlying json String to equivalent Map based object
	 * that can be used for further processing.
	 *
	 * @param jsonString         the String input to be converted
	 * @param convertToCamelCase Indicate if the map needs to be converted to camelCase
	 * @return the equivalent Map Object.
	 * @throws IOException if a low-level I/O problem (unexpected end-of-input, network error) occurs.
	 */
	public Map<String, Object> jsonToMap(String jsonString, boolean convertToCamelCase) throws IOException {
		Map<String, Object> map = MapUtil.getObjectMapper().readValue(jsonString, new TypeReference<>() {
		});
		return convertToCamelCase ? convertMap(map) : map;
	}

	/**
	 * This method is responsible for converting the json object key to camelCase from standard json cases
	 * i.e. Pascal (FirstWorld), Snake (first_world) and Kebab (first-world)
	 *
	 * @param key key to be converted
	 * @return the camelCase converted version of the key
	 */
	public String mapKey(final String key) {
		if (StringUtils.isBlank(key)) {
			return key;
		}
		String convertedKey = key;
		if (convertedKey.contains("-") || convertedKey.contains("_")) {
			convertedKey = CaseUtils.toCamelCase(key, false, RESTRICTED_CHARSET);
		}
		return Character.toLowerCase(convertedKey.charAt(0)) + convertedKey.substring(1);
	}

	//Converting the object type of Map for Json String
	private Map<String, Object> convertMap(Map<String, Object> map) {
		Map<String, Object> result = new HashMap();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			result.put(mapKey(key), convertValue(value));
		}
		return result;
	}

	//Converting the object type of List for Json String
	private List convertList(List<Object> list) {
		List<Object> result = new ArrayList();
		for (Object obj : list) {
			result.add(convertValue(obj));
		}
		return result;
	}

	//Method to recursively update the JSON structure keys (it could be of type Map or List)
	private Object convertValue(Object obj) {
		if (obj instanceof Map) {
			return convertMap((Map<String, Object>) obj);
		} else if (obj instanceof List) {
			return convertList((List<Object>) obj);
		} else {
			return obj;
		}
	}
}
