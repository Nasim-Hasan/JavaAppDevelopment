package jp.co.rakuten.bff.core.logger;

import java.util.function.Function;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.exception.BffException;
import org.springframework.stereotype.Component;

/**
 * This is MessageConverter that is used to convert from a Throwable to a Message.
 * This is used by {@code HttpLogger}.
 */
@Component
public class ThrowableMessageConverter implements Function<Throwable, String> {

	@Override
	public String apply(Throwable throwable) {
		String message;
		if (throwable instanceof BffException) {
			BffException ex = (BffException) throwable;
			message = String.format(MessageConstants.LOGGER_EXCEPTION_MSG_ERROR_CODE_INFO,
					throwable.getClass().getName(), ex.getDetailedMessage(), ex.getErrorCode().value());
		} else {
			message = String.format(MessageConstants.LOGGER_EXCEPTION_MSG_INFO, throwable.getClass().getName(),
					throwable.getMessage());
		}
		return message;
	}
}
