package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.filter.ResponseFilter;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffApiMetricsManager;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffFeatureMetricsManager;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.resolver.GenericParameterResolver;
import jp.co.rakuten.bff.core.service.ApiExecutionService;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.service.ExecutionPlanService;
import jp.co.rakuten.bff.core.service.FeatureExecutionService;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Objects;

/**
 * Responsible to validate requests, extract user requested feature and pass those data to {@link
 * FeatureExecutionService} to get feature-wise responses. It will also validate and filter the responses and calculate
 * overall status.
 *
 * @see <a href= "https://confluence.rakuten-it.com/confluence/display/ECSG/%5BDraft%5D%5BFrameworkComponent%5DApiExecutionService">
 * API Execution Service
 * </a>
 */
@Service
public class ApiExecutionServiceImpl implements ApiExecutionService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiExecutionServiceImpl.class);
	private final ApiRepository apiRepository;
	private final ExecutionPlanService executionPlanService;
	private final FeatureExecutionService featureExecutionService;
	private final GenericParameterResolver genericParameterResolver;
	private final ResponseFilter responseFilter;
	private final ResponseUtil responseUtil;

	/**
	 * This {@link ApiExecutionService} needs {@link ApiRepository}, {@link ExecutionPlanService} and {@link
	 * FeatureExecutionService} to perform api request.
	 *
	 * @param apiRepository            used for finding the template.
	 * @param executionPlanService     used to filter out features and preparing execution plan.
	 * @param featureExecutionService  use to get all feature responses.
	 * @param genericParameterResolver use to validate both request and response parameters.
	 * @param responseFilter           use to filter the response.
	 * @param responseUtil             response util component to prepare responses.
	 */
	@Autowired
	public ApiExecutionServiceImpl(ApiRepository apiRepository, ExecutionPlanService executionPlanService,
								   FeatureExecutionService featureExecutionService,
								   GenericParameterResolver genericParameterResolver,
								   ResponseFilter responseFilter, ResponseUtil responseUtil) {
		this.apiRepository = apiRepository;
		this.executionPlanService = executionPlanService;
		this.featureExecutionService = featureExecutionService;
		this.genericParameterResolver = genericParameterResolver;
		this.responseFilter = responseFilter;
		this.responseUtil = responseUtil;
	}

	/**
	 * This method does the following:
	 * <ul>
	 *     <li>Fetch the template from {@link ApiRepository} for requested service</li>
	 *     <li>Prepare {@link ExecutionModel} using {@link ExecutionPlanService} service</li>
	 *     <li>Validate requests parameters against api-contract {@code repository/api}
	 *         and build feature-wise parameter map</li>
	 *     <li>Execute {@link FeatureExecutionService} to get feature-wise responses.</li>
	 *     <li>Iterate over all the features and calculate overall response body and status.</li>
	 * </ul>
	 *
	 * @param clientData contains user provided data.
	 * @return overall status and feature-wise responses.
	 * @see <a href="https://confluence.rakuten-it.com/confluence/display/ECSG/%5BDraft%5D%5BFrameworkComponent%5DApiExecutionService">
	 * API Execution Service</a>
	 */
	@Override
	public Mono<ResponseEntity<Map>> executeApi(ClientRequestModel clientData) {
		ApiTemplate template = apiRepository.getApiRepositoryTemplate(clientData);
		ExecutionModel executionModel = executionPlanService.prepareExecutionPlan(clientData, template);
		Map<String, CommonRequestModel> featureRequest = genericParameterResolver
				.resolveRequestParameter(executionModel.getFeatureModelList(), clientData);
		if (Objects.nonNull(template.getValidatorBean())) {
			featureRequest = template.getValidatorBean()
					.validate(featureRequest, executionModel.getFeatureModelList(), clientData);
		}
		BffApiMetricsManager.markEntry(
				template.getApiKey(),executionModel.getFeatureModelList(), clientData.getClientId());
		Mono<Map<String, Object>> featureResponseMono = featureExecutionService
				.executeFeatures(clientData, executionModel, featureRequest, template);
		return featureResponseMono.flatMap((Map<String, Object> featureResponse) -> {
			LOGGER.debug(MessageConstants.SERVICE_FEATURE_RESPONSE_MAP_DEBUG_MSG, featureResponse);
			Map<String, Object> validatedResponse = genericParameterResolver
					.resolveResponseParameter(executionModel.getFeatureModelList(), featureResponse);
			responseFilter.filter(clientData, validatedResponse);
			validatedResponse.putAll(executionModel.getDefaultResponse());
			BffFeatureMetricsManager.markFeatureExit(template.getApiKey(),validatedResponse);
			return responseUtil.prepareAPIResponse(validatedResponse, template, clientData);
		})
				.doOnRequest(l -> LOGGER.info(MessageConstants.SERVICE_FEATURE_RESPONSE_START_INFO))
				.doOnError(responseUtil::logResponseError)
				.onErrorResume(throwable ->
						               Mono.just(responseUtil.catchExceptionAndBuildApiResponse(throwable, clientData)));
	}
}
