package jp.co.rakuten.bff.core.exception.type;

import org.springframework.http.HttpStatus;

/**
 * It will have the below error definition which will be later
 * used by BackendException
 * <li>INTERNAL --- 500</li>
 */
public enum SystemErrorEnum {

	INTERNAL("system_error", HttpStatus.INTERNAL_SERVER_ERROR),
	SERVICE_UNAVAILABLE("system_error", HttpStatus.SERVICE_UNAVAILABLE);

	private String errorType;
	private HttpStatus errorCode;

	SystemErrorEnum(String errorType, HttpStatus errorCode) {
		this.errorType = errorType;
		this.errorCode = errorCode;
	}

	public String getErrorType() {
		return errorType;
	}

	public HttpStatus getErrorCode() {
		return errorCode;
	}
}
