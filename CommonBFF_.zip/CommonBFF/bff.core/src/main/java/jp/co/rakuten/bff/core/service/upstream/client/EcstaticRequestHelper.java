package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import jp.co.rakuten.bff.core.constant.GenericEndpointConstants;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import jp.co.rakuten.bff.core.util.DeepCopyUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.CONNECTION;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_INTERFACE_CONFIG_NULL_KEY;

/**
 * EC static request helper
 */
public class EcstaticRequestHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomHttpRequest.class);

	/*private constructor to prevent creating object*/
	private EcstaticRequestHelper() {}

	/**
	 * Convert request map to {@link CustomHttpRequest}
	 * this is deprecated and only for backend compatibility
	 * @param request               object
	 * @param interfaceConfigLoader {@link InterfaceConfigLoader}
	 * @return CustomHttpRequest
	 */
	@Deprecated
	public static CustomHttpRequest getCustomRequest(Map<String, Object> request,
													 InterfaceConfigLoader interfaceConfigLoader,
													 HttpHeaders httpHeaders
													 ) {
		return getCustomRequest(request, interfaceConfigLoader, httpHeaders,"",false);
	}

		/**
		 * Convert request map to {@link CustomHttpRequest}
		 *
		 * @param request               object
		 * @param interfaceConfigLoader {@link InterfaceConfigLoader}
		 * @return CustomHttpRequest
		 */
		public static CustomHttpRequest getCustomRequest(Map<String, Object> request,
				InterfaceConfigLoader interfaceConfigLoader,
				HttpHeaders httpHeaders,
				String pwd, Boolean isMockingEnabled
													 ) {
		String interfaceKey = String.valueOf(request.get(INTERFACE_KEY));
		InterfaceConfig interfaceConfig = interfaceConfigLoader.getInterface(interfaceKey);
		if (interfaceConfig == null) {
			throw SystemException.create(SystemErrorEnum.INTERNAL,
					SERVICE_INTERFACE_CONFIG_NULL_KEY + interfaceKey);
		}
		CustomHttpRequest customHttpRequest = getRequestFromConfiguration(interfaceConfig, request, httpHeaders, pwd,isMockingEnabled);
		Map<String, String> headerMap = new HashMap<>();
		Map<String, String> urlParameterMap = new HashMap<>();

		headerMap.putAll(interfaceConfig.getPropertiesHeaderMap());
		urlParameterMap.putAll(interfaceConfig.getPropertiesUrlParameterMap());

		if (request.get(HEADERS) != null) {
			headerMap.putAll((Map<String, String>) request.get(HEADERS));
		}
		if (request.get(URL_PARAMETERS) != null) {
			urlParameterMap.putAll((Map<String, String>) request.get(URL_PARAMETERS));
		}
		if (request.get(META_PARAMETERS) != null) {
			customHttpRequest.getMetaParameterMap().putAll((Map<String, String>) request.get(META_PARAMETERS));
		}
		customHttpRequest.setHeaderMap(headerMap);
		customHttpRequest.setUrlParameterMap(urlParameterMap);
		customHttpRequest.setRequestId(request.get(REQUEST_ID).toString());

		return customHttpRequest;
	}

	/**
	 * build CustomHttpRequest from InterfaceConfig
	 *
	 * @param interfaceConfig object data is used to build customHttpRequest object
	 * @return request object
	 */
	private static CustomHttpRequest getRequestFromConfiguration(InterfaceConfig interfaceConfig,
	                                                             Map<String, Object> request,
																 HttpHeaders httpHeaders,
																 String pwd,
																 Boolean isMockingEnabled
																 ) {
		LOGGER.info("Building custom http request from interface config > {}", interfaceConfig.toString());
		String interfaceKey = interfaceConfig.getInterfaceKey();
		Map<String, String> connectionMap = interfaceConfig.getPropertiesConnectionMap();
		if (StringUtils.isBlank(connectionMap.get(URL))) {
			String suffixKey = connectionMap.get("url.suffix.key");
			if (StringUtils.isNotBlank(suffixKey)) {
				String suffixValue = getSuffixValue(request, suffixKey);
				if (StringUtils.isNotBlank(suffixValue)) {
					connectionMap.put(URL, connectionMap.get(URL + "_" + suffixValue));
				} else {
					LOGGER.error("URL suffix value is not present in the request, for: {}", interfaceKey);
				}
			} else {
				LOGGER.error("URL prefix is not present in the property files, for: {}", interfaceKey);
			}
		}
		if (isMockingEnabled ) {
			boolean isOverringEnabled = Boolean.parseBoolean(httpHeaders.getFirst(
															GenericEndpointConstants.OVERRIDE_CONFIG_ENABLE_KEY));
			if (isOverringEnabled && pwd.equals(httpHeaders.getFirst(GenericEndpointConstants.OVERRIDE_CONFIG_PWD))
					&& ObjectUtils.isNotEmpty(request.get(CONNECTION))) {
					connectionMap = DeepCopyUtil.deepCopy(interfaceConfig.getPropertiesConnectionMap(), Map.class);
					connectionMap.putAll((Map<String, String>) request.get(CONNECTION));
			}
		}
		return CustomHttpRequest.builder()
				.requestId(UUID.randomUUID().toString())
				.interfaceKey(interfaceConfig.getInterfaceKey())
				.connectionMap(connectionMap)
				.headerMap(interfaceConfig.getPropertiesHeaderMap())
				.urlParameterMap(interfaceConfig.getPropertiesUrlParameterMap())
				.metaParameterMap(interfaceConfig.getMetadataMap())
				.circuit(interfaceConfig.getCircuit())
				.build();
	}

	/**
	 * Transfer the custom request's headers to the http headers compatible with WebClient.
	 *
	 * @param requestHeaders the custom request's headers
	 * @return The http headers
	 */
	public static Consumer<HttpHeaders> getHttpHeaders(Map<String, String> requestHeaders) {
		return httpHeaders -> requestHeaders.forEach((key, value) -> httpHeaders.add(key, String.valueOf(value)));
	}

	private static String getSuffixValue(Map<String, Object> request, String suffixKey) {
		Map<String, Object> requestMap = new HashMap<>();
		if (request.get(URL_PARAMETERS) != null) {
			requestMap.putAll((Map) request.get(URL_PARAMETERS));
		}
		if (request.get(META_PARAMETERS) != null) {
			requestMap.putAll((Map) request.get(META_PARAMETERS));
		}
		if (request.get(HEADERS) != null) {
			requestMap.putAll((Map) request.get(HEADERS));
		}
		return (String) requestMap.get(suffixKey);
	}
}
