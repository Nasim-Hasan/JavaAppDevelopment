package jp.co.rakuten.bff.core.processors;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Endpoint custom processor should implement this interface.
 */
public interface InterfaceProcessor {

	/**
	 * Override this method when you don't need access any reactive stream during pre-processing logic.
	 * Pre processor will modify generically prepared request if this endpoint has any custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	default boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
							   GenericCallDefinitionProcessedData genericCDProcessedData,
							   Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		// Override this method to add a pre-processor
		return true;
	}

	/**Reactive interface pre-processor.
	 * While you need to access any reactive stream during pre-processing logic, you need to override this method.
	 * Pre processor will modify generically prepared request if this endpoint has any custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @param headers It is passed by framework to allow any header field access.
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	default Mono<Boolean> preProcess( Map<String, CommonRequestModel> validatedRequest,
									  GenericCallDefinitionProcessedData genericCDProcessedData,
									  Map<String, CallDefinitionResponse> callDefinitionResponseMap,
									  HttpHeaders headers) {
		// Override this method to add a pre-processor
		try {
			return Mono.just(preProcess(validatedRequest,genericCDProcessedData,callDefinitionResponseMap));
		} catch (Exception ex) {
			return Mono.error(ex);
		}
	}
	/**
	 * Interface post processor
	 * Override this method when you don't need access any reactive stream during post-processing logic.
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param callDefinitionResponse    {@link CallDefinitionResponse }   Generic Gateway call response
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 */
	default void postProcess(Map<String, CommonRequestModel> validatedRequest,
							 CallDefinitionResponse callDefinitionResponse,
							 GenericCallDefinitionProcessedData genericCDProcessedData,
							 Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		// Override this method to add a post-processor
	}
	/**
	 * Reactive Interface post processor
	 * Override this method, when it needs to access reactive stream in interface post processing.
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param callDefinitionResponse    {@link CallDefinitionResponse }   Generic Gateway call response
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @param headers it is being passed by framework to allow to access any header field.
	 */
	default Mono<Boolean> postProcess(Map<String, CommonRequestModel> validatedRequest,
									  CallDefinitionResponse callDefinitionResponse,
									  GenericCallDefinitionProcessedData genericCDProcessedData,
									  Map<String, CallDefinitionResponse> callDefinitionResponseMap,
									  HttpHeaders headers) {
		try{
			postProcess(validatedRequest,callDefinitionResponse,genericCDProcessedData,callDefinitionResponseMap);
			return Mono.just(true);
		} catch (Exception ex) {
			return Mono.error(ex);
		}
	}
}
