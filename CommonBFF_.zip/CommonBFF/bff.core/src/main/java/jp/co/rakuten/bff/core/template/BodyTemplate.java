package jp.co.rakuten.bff.core.template;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Body Template
 * it is used to contain request body
 */
public class BodyTemplate {
	private Map<String, Object> template;
	private List<Map<String, Object>> params;

	public Map<String, Object> getTemplate() {
		return template != null ? template : new HashMap<>();
	}

	public void setTemplate(Map<String, Object> template) {
		this.template = template;
	}

	public List<Map<String, Object>> getParams() {
		return params != null ? params : Collections.emptyList();
	}

	public void setParams(List<Map<String, Object>> params) {
		this.params = params;
	}
}
