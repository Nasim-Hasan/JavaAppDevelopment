package jp.co.rakuten.bff.core.config;

/**
 * Copied from generic gateway
 * <p>
 * The interface is used as an abstraction of the {@link InterfaceGroupKeys}.
 *
 * @author tony.rouillard
 */
public interface IInterface {
	/**
	 * Return the interfaceKey that you can find in the property files
	 *
	 * @return the interfaceKey
	 */
	String getInterfaceKey();

	/**
	 * Return the groupKey that you can find in the property files
	 *
	 * @return the groupKey
	 */
	String getGroupKey();
}
