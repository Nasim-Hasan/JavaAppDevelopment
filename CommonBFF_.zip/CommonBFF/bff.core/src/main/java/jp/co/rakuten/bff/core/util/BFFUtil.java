package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.core.env.Environment;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static jp.co.rakuten.bff.core.constant.BffConstants.STALE_ACTIVE_KEY_DEFAULT_TIMEOUT_STR_VALUE;
import static jp.co.rakuten.bff.core.constant.BffConstants.STALE_ACTIVE_KEY_TIMEOUT_PROP_KEY;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_URI_PREPARE_ERROR;

/**
 * This is the common utility class which will contain scatter
 * utility method.
 *
 * @author BJIT Limited Created by tareq rahman on 11/28/19.
 */
public class BFFUtil {

	/**
	 * Default private constructor
	 * */
	private BFFUtil() {}

	/**
	 * This method convert the string url to URI
	 *
	 * @param url {@link String}
	 * @return the new URI
	 * */
	public static URI buildURI(String url) {
		try {
			return new URI(url);
		} catch (URISyntaxException e) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, e, UTIL_URI_PREPARE_ERROR, url);
		}
	}

	/**
	 * This method sorts the list provided based on the field provided
	 * This sorts List<Map>. So field will be a key in the Map.
	 *
	 * @param targetList     list to be sorted
	 * @param sortFieldInMap field based on which list is to be sorted
	 */
	public static void sortListOfMap(List<Map<String, Object>> targetList, String sortFieldInMap) {
		targetList.sort((Map<String, Object> o1, Map<String, Object> o2) -> {
			if (MapUtils.isEmpty(o1)) {
				return -1;
			}
			if (MapUtils.isEmpty(o2)) {
				return 1;
			}
			return Integer.compare(ResponseUtil.getInteger(o1.get(sortFieldInMap), Integer.MIN_VALUE),
					ResponseUtil.getInteger(o2.get(sortFieldInMap), Integer.MIN_VALUE));
		});
	}

	/**
	 * Get decoded string
	 *
	 * @param bytes - The bytes to be decoded
	 * @param charset to be used to decode the bytes.
	 *
	 * @return String
	 */
	public static String decode(byte[] bytes, String charset) {
		return new String(bytes, Charset.forName(charset));
	}

	/**
	 * fetches staleActiveTimeout from environment provided and converts to long value in null safe manner
	 *
	 * @param environment {@link Environment}
	 * @return String
	 */
	public static long getActiveFlagTimeout(Environment environment) {
		return NumberUtils.toLong(environment.getProperty(STALE_ACTIVE_KEY_TIMEOUT_PROP_KEY,
		                                                  STALE_ACTIVE_KEY_DEFAULT_TIMEOUT_STR_VALUE),
		                          BffConstants.STALE_ACTIVE_KEY_DEFAULT_TIMEOUT_VALUE);
	}

	/**
	 * This method adds call definition related information to loggerRequest
	 * to add to the service logs
	 *
	 * @param loggerRequest      {@link HttpLogger.LoggerRequest}
	 * @param callDefinitionName Name of call definition
	 * @param requestType        Type of request
	 * @param requests           All parameters required for a request
	 */
	public static void addCallDefinitionInfoToLoggerRequest(HttpLogger.LoggerRequest loggerRequest,
	                                                        String callDefinitionName,
	                                                        String requestType,
	                                                        Collection<Map<String, Object>> requests) {
		Map<String, Object> loggerRequestExtras = loggerRequest.getExtras();
		loggerRequestExtras.put("callDefinitionName", callDefinitionName);
		loggerRequestExtras.put("callDefinitionType", requestType);
		if (CollectionUtils.isNotEmpty(requests)) {
			String cdInterfaces = requests.stream()
					.map(request -> String.valueOf(request.get("interfaceKey")))
					.collect(Collectors.joining(","));
			loggerRequestExtras.put("callDefinitionInterfaces", cdInterfaces);
		}
	}
}
