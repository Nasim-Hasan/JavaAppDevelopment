package jp.co.rakuten.bff.core.cache;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.RequestSchema;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;

/**
 * Cache type enum
 */
public class CustomKeyGenerator {
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomKeyGenerator.class);

	private CustomKeyGenerator() {
	}

	/**
	 * generates key that is used as cache key for storing a value to cache
	 *
	 * @param featureTemplate  {@link FeatureTemplate}
	 * @param validatedRequest contains user provided parameters
	 * @param apiKey           api key formed using service, operation and version
	 *
	 * @return string key to be used as cache key
	 */
	public static String generateBffKey(FeatureTemplate featureTemplate,
										Map<String, CommonRequestModel> validatedRequest, String apiKey) {
		try {
			Map<String, Object> paramMap = null;
			String cacheName = apiKey;
			if (ObjectUtils.isNotEmpty(featureTemplate)) {
				cacheName = cacheName + "#" + featureTemplate.getName();
				if (ObjectUtils.isNotEmpty(featureTemplate.getRequest()) && ObjectUtils.isNotEmpty(validatedRequest)) {
					paramMap = loadParamMap(featureTemplate, validatedRequest);
				}
			}
			return generate(cacheName, paramMap);
		}catch (Exception ex){
			LOGGER.error(MessageConstants.CACHE_KEY_GEN_ERROR, featureTemplate.getName(), ex);
		}
		return null;
	}

	private static Map<String, Object> loadParamMap(FeatureTemplate featureTemplate,
													Map<String, CommonRequestModel> validatedRequest) {
		Map<String, Object> paramMap = new TreeMap<>();
		RequestSchema request = featureTemplate.getRequest();
		CommonRequestModel requestModel = validatedRequest.get(featureTemplate.getName());
		List<CommonSchema> parameters = request.getParameters();
		if (CollectionUtils.isNotEmpty(parameters) && ObjectUtils.isNotEmpty(requestModel) && ObjectUtils
				.isNotEmpty(requestModel.getParams())) {
			Map<String, Object> params = requestModel.getParams();
			for (CommonSchema paramSchema : parameters) {
				boolean isCacheKey = BooleanUtils.toBoolean(String.valueOf(paramSchema.getCacheKey()));
				if (isCacheKey) {
					paramMap.put(paramSchema.getName(), params.get(paramSchema.getName()));
				}
			}
		}
		return paramMap;
	}

	/**
	 * generates key that is used as cache key for storing a value to cache
	 *
	 * @param cacheName name of cache
	 * @param params    contains user provided parameters
	 * @return string key to be used as cache key
	 */
	public static String generate(String cacheName, Map<String, Object> params) {
		StringBuilder stringBuilder = new StringBuilder(BUILDER_CAPACITY);
		stringBuilder.append(cacheName);
		if (MapUtils.isNotEmpty(params)) {
			stringBuilder.append(KEY_SEPARATOR_HASH);
			String separator = "";
			for (Map.Entry<String, Object> paramEntry : params.entrySet()) {
				generate(paramEntry, stringBuilder, separator);
				separator = KEY_SEPARATOR_UNDER_SCORE;
			}
		}
		return stringBuilder.toString();
	}

	private static void generate(Map.Entry<String, Object> paramEntry, StringBuilder stringBuilder, String separator) {
		if (paramEntry.getValue() instanceof List) {
			generate((List) paramEntry.getValue(), paramEntry.getKey(), stringBuilder, separator);
		} else if (ObjectUtils.isNotEmpty(paramEntry.getValue())) {
			stringBuilder.append(separator).append(paramEntry.getKey()).append(":").append(paramEntry.getValue());
		}
	}

	private static void generate(List paramEntryList, String entryKey, StringBuilder stringBuilder, String separator) {
		String spInner = "";
		stringBuilder.append(separator).append(entryKey).append(":");
		for (Object innerObject : getSortedList(paramEntryList)) {
			stringBuilder.append(spInner).append(getEscapedValue(innerObject));
			spInner = SEPARATOR_INNER_DOT;
		}
	}

	private static String getEscapedValue(Object value) {
		String valueString = String.valueOf(value);
		return valueString.replaceAll(KEY_SEPARATOR_DOT, KEY_SEPARATOR_SLASH_DOT)
				.replace(KEY_SEPARATOR_UNDER_SCORE, KEY_SEPARATOR_SLASH + KEY_SEPARATOR_UNDER_SCORE);
	}

	/**
	 * sort the provided list
	 *
	 * @param valueList list to be sorted
	 * @return sorted list
	 */
	public static List getSortedList(List valueList) {
		try {
			Collections.sort(valueList);
		} catch (Exception ex) {
			LOGGER.error(MessageConstants.CACHE_KEY_GEN_LIST_SORT_ERROR, ex);
		}
		return valueList;
	}
}
