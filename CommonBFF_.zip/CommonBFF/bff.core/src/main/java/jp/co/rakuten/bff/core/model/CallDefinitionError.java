package jp.co.rakuten.bff.core.model;

/**
 * This class contain the call definition error related information
 */
public class CallDefinitionError {
	/**
	 * The code of the error
	 */
	private int code;

	/**
	 * The message of the error
	 */
	private String message;

	/**
	 * No argument constructor
	 */
	public CallDefinitionError() {
	}

	/**
	 * All argument constructor
	 *
	 * @param code    Error code
	 * @param message Error message
	 */
	public CallDefinitionError(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CallDefinitionError{" +
				"code='" + code + '\'' +
				", message='" + message + '\'' +
				'}';
	}
}
