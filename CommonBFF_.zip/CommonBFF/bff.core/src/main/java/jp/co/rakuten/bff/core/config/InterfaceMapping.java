package jp.co.rakuten.bff.core.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * This class manages the map of {@link IInterface} with interfaceKey as the key
 * The values are taken from the {@link InterfaceConfigurationProperties} to populate the map.
 */
@Component
public class InterfaceMapping {

	private Map<String, IInterface> mappings = new HashMap<>();

	private InterfaceConfigurationProperties interfaceConfigurationProperties;

	@Autowired
	InterfaceMapping(InterfaceConfigurationProperties interfaceConfigurationProperties){
		this.interfaceConfigurationProperties = interfaceConfigurationProperties;
		refreshMapping();
	}

	/**
	 * Ensures that any new interface added in the configuration properties is fetched and added in mappings.
	 */
	private void refreshMapping(){
		Map<String, String> configPropertiesMap = this.interfaceConfigurationProperties.getMapping();
		if(!CollectionUtils.isEmpty(configPropertiesMap)){
			mappings = new HashMap<>();
			configPropertiesMap.forEach((k, v) -> mappings.put(k, new InterfaceGroupKeys(k,v)));
		}
	}

	/**
	 * Returns the mappings of IInterfaces after the map is refreshed.
	 * Refresh ensures that any new interface in the configuration is added into the mapping before being returned.
	 *
	 * @return Map<String, IInterface> updated/refreshed mapping
	 */
	public Map<String, IInterface> getMapping() {
		refreshMapping();
		return mappings;
	}

}
