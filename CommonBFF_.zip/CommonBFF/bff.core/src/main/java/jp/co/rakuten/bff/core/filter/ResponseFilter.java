package jp.co.rakuten.bff.core.filter;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.MessageConstants;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This class is responsible to filter the final validated response.
 * To filter first it build a map from the user
 * provided include/exclude keys then by iterating the map,
 * it make the final operation.
 *
 * @author BJIT Limited. Created by tareq rahman on 11/26/19.
 */
@Component
public class ResponseFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseFilter.class);
	private static final String FIRST_LEVEL_KEYS = "firstLevelKeys";
	private static final String DATA = "data";
	private static final String SPLIT_PATTERN = "\\.";
	private static final int ONE_INDEX = 1;
	private static final int TWO_INDEX = 2;

	/**
	 * Update the provided response map by filtering using the user
	 * provided include or exclude keys.
	 *
	 * @param clientData  {@link ClientRequestModel}
	 * @param responseMap {@link Map}
	 */
	public void filter(ClientRequestModel clientData, Map<String, Object> responseMap) {
		Map<String, CommonRequestModel> featureMap = clientData.getRequestModel().getFeatures();
		if (featureMap != null) {
			featureMap.forEach((String key, CommonRequestModel commonRequestModel) -> {
				Map<String, Object> originalResponse = ((Map<String, Object>) responseMap.get(key));
				if (MapUtils.isNotEmpty(originalResponse)) {
					Map<String, String> originalResponseHeader = (Map) originalResponse.getOrDefault(
							BffConstants.HEADER,
							new HashMap<>());
					originalResponse = (Map<String, Object>) originalResponse.get(DATA);
					performIncludeExcludeFilter(originalResponse, commonRequestModel, responseMap,
							originalResponseHeader, key);
				}
			});
		}
	}

	private void performIncludeExcludeFilter(Map<String, Object> originalResponse,
			CommonRequestModel commonRequestModel, Map<String, Object> responseMap,
			Map<String, String> originalResponseHeader, String key) {
		if (MapUtils.isNotEmpty(originalResponse)) {
			if (!ObjectUtils.isEmpty(commonRequestModel.getInclude())) {
				Map<String, Object> result = new HashMap<>();
				performIncludeFilter(buildFilterTraverseKeysMap(commonRequestModel.getInclude()),
						originalResponse, result);
				responseMap.replace(key, Map.of(DATA, result, BffConstants.HEADER, originalResponseHeader));
			} else if (!ObjectUtils.isEmpty(commonRequestModel.getExclude())) {
				performExcludeFilter(buildFilterTraverseKeysMap(commonRequestModel.getExclude()),
						originalResponse);
			}
		}
	}

	/**
	 * Perform include filtering
	 */
	private void performIncludeFilter(Map<String, Object> filterTraverseMap, Object source, Object destination) {
		if (source instanceof List) {
			performIncludeFilter(filterTraverseMap, source, (List) destination);
		} else {
			Map<String, Object> destinationMap = (Map<String, Object>) destination;
			filterTraverseMap.forEach((key, value) -> performIncludeFiler(key, value, (Map) source, destinationMap));
		}
	}

	private void performIncludeFiler(String key, Object value, Map source, Map<String, Object> destinationMap) {
		if (value instanceof List) {
			appendIntoMap((List) value, source, destinationMap);
		} else if (source.containsKey(key)) {
			Object nextSource = source.get(key);
			if (nextSource instanceof Map || nextSource instanceof List) {
				Object nextObject = getNextObject(nextSource);
				destinationMap.put(key, nextObject);
				performIncludeFilter((Map) value, nextSource, nextObject);
			}
		} else {
			LOGGER.error("Either include contains invalid key or data not found in the response");
		}
	}

	private void performIncludeFilter(Map<String, Object> filterTraverseMap, Object source, List destination) {
		if (filterTraverseMap.size() == 1 && filterTraverseMap.containsKey(FIRST_LEVEL_KEYS)) {
			appendIntoList((List) filterTraverseMap.get(FIRST_LEVEL_KEYS), (List) source, destination);
		} else {
			appendIntoListWithInner(filterTraverseMap, (List) source, destination);
		}
	}

	private Object getNextObject(Object nextSource) {
		Object nextObject;
		if (nextSource instanceof List) {
			nextObject = new ArrayList<>();
		} else {
			nextObject = new HashMap<>();
		}
		return nextObject;
	}

	private void appendIntoListWithInner(Map<String, Object> filterTraverseMap, List<Object> sourceList,
										 List<Map<String, Object>> destination) {
		sourceList.forEach((Object inner) -> {
			if (inner instanceof Map) {
				Map innerMap = (Map) inner;
				Map<String, Object> map = new HashMap<>();
				performIncludeFilter(filterTraverseMap, innerMap, map);
				if (!ObjectUtils.isEmpty(map)) {
					destination.add(map);
				}
			}
		});
	}

	private void appendIntoList(List<String> keys, List<Object> sourceList,
								List<Map<String, Object>> destination) {
		sourceList.forEach((Object inner) -> {
			if (inner instanceof Map) {
				Map innerMap = (Map) inner;
				Map<String, Object> map = new HashMap<>();
				for (String key : keys) {
					if (innerMap.containsKey(key)) {
						map.put(key, innerMap.get(key));
					}
				}
				if (!ObjectUtils.isEmpty(map)) {
					destination.add(map);
				}
			}
		});
	}

	private void appendIntoMap(List<String> keys, Map<String, Object> sourceMap, Map<String, Object> destinationMap) {
		keys.forEach((String key) -> {
			if (sourceMap.containsKey(key)) {
				destinationMap.put(key, sourceMap.get(key));
			}
		});
	}

	/**
	 * Perform exclude filtering
	 */
	private void performExcludeFilter(Map<String, Object> filterTraverseMap, Object source) {
		if (source instanceof List) {
			performExcludeFilter(filterTraverseMap, (List) source);
		} else {
			filterTraverseMap.forEach((key, value) -> performExcludeFilterFor(key, value, (Map) source));
		}
	}

	private void performExcludeFilterFor(String key, Object value, Map source) {
		if (value instanceof List) {
			removeFromMap((List) value, source);
		} else if (source.containsKey(key)) {
			Object nextSource = source.get(key);
			if (nextSource instanceof Map || nextSource instanceof List) {
				performExcludeFilter((Map) value, nextSource);
			}
		} else {
			LOGGER.info(MessageConstants.FILTER_INVALID_KEY_ERROR_MSG, key);
		}
	}

	private void performExcludeFilter(Map<String, Object> filterTraverseMap, List source) {
		if (filterTraverseMap.size() == 1 && filterTraverseMap.containsKey(FIRST_LEVEL_KEYS)) {
			removeFromMapList((List) filterTraverseMap.get(FIRST_LEVEL_KEYS), source);
		} else {
			removeFromMapListWithInner(filterTraverseMap, source);
		}
	}

	private void removeFromMap(List<String> keys, Map<String, Object> sourceMap) {
		keys.forEach(sourceMap::remove);
	}

	private void removeFromMapList(List<String> keys, List<Object> sourceList) {
		sourceList.forEach((Object inner) -> {
			if (inner instanceof Map) {
				removeFromMap(keys, (Map) inner);
			}
		});
	}

	private void removeFromMapListWithInner(Map<String, Object> filterTraverseMap, List<Object> sourceList) {
		sourceList.forEach(inner -> performExcludeFilter(filterTraverseMap, inner));
	}

	/**
	 * Build tree map from the provided dot separated strings
	 */
	private Map<String, Object> buildFilterTraverseKeysMap(Set<String> filterKeys) {
		Map<String, Object> filterTraverseMap = new HashMap<>();
		filterKeys.forEach((String key) -> {
			if (StringUtils.isNotBlank(key)) {
				String[] keys = key.split(SPLIT_PATTERN);
				if (keys.length > 1) {
					appendChildMapKeys(filterTraverseMap, keys, 0);
				} else {
					appendFirstLevelKeys(keys[0], filterTraverseMap);
				}
			}
		});
		return filterTraverseMap;
	}

	private void appendChildMapKeys(Map<String, Object> destinationMap, String[] keys, int currentIndex) {
		String key = keys[currentIndex];
		int nextIndex = currentIndex + ONE_INDEX;
		int previousIndex = currentIndex - ONE_INDEX;
		if (keys.length == nextIndex) {
			appendFirstLevelKeys(key, (Map) destinationMap.get(keys[previousIndex]));
		} else if (keys.length == currentIndex + TWO_INDEX) {
			destinationMap.computeIfAbsent(key, k -> new HashMap<>());
			appendChildMapKeys(destinationMap, keys, nextIndex);
		} else {
			destinationMap.computeIfAbsent(key, k -> new HashMap<>());
			appendChildMapKeys((Map) destinationMap.get(key), keys, nextIndex);
		}
	}

	private void appendFirstLevelKeys(String key, Map destinationMap) {
		if (destinationMap.containsKey(FIRST_LEVEL_KEYS)) {
			((List) destinationMap.get(FIRST_LEVEL_KEYS)).add(key);
		} else {
			List<String> bottomChildList = new ArrayList<>();
			bottomChildList.add(key);
			destinationMap.put(FIRST_LEVEL_KEYS, bottomChildList);
		}
	}
}
