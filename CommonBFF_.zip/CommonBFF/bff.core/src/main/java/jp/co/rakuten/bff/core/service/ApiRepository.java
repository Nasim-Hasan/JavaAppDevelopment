package jp.co.rakuten.bff.core.service;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.template.ApiTemplate;

import java.util.Map;

/**
 * Repository interface for providing @{@link ApiTemplate} objects on demand.
 * <br>Should load and prepare repository collection during Application init.
 */
public interface ApiRepository {
	/**
	 * Provides a Map object containing all loaded {@link ApiTemplate} objects,
	 * mapped against their corresponding apiKey-s
	 *
	 * @return {@code Map<String,ApiTemplate>} object
	 */
	Map<String, ApiTemplate> getAllApiTemplates();

	/**
	 * Provides @{@link ApiTemplate} object for provided apiKey
	 *
	 * @param apiKey consists of service, operation & version
	 * @return corresponding @{@link ApiTemplate} object
	 */
	ApiTemplate getApiRepositoryTemplate(String apiKey);

	/**
	 * Provides @{@link ApiTemplate} object for provided service and operation
	 *
	 * @param model contains all user provided data.
	 * @return corresponding @{@link ApiTemplate} object
	 */
	ApiTemplate getApiRepositoryTemplate(ClientRequestModel model);
}
