package jp.co.rakuten.bff.core.constant;

/**
 * All global platform related to BFF should be kept in here.
 */
public class MessageConstants {

	//Package Wise Constants
	//Cache
	public static final String CACHE_KEY_GEN_ERROR = "Error occurred while generating cache key for {}";
	public static final String CACHE_KEY_GEN_LIST_SORT_ERROR = "Failed sort inner list for key generation";
	public static final String CACHE_RESOURCES_LOAD_ERROR = "Error occurred while reloading cache resources";
	public static final String CACHE_IS_DISABLED_MSG = "Cache is disabled for {}, skipping cache management.";
	public static final String NO_CACHE_HEADER_MSG = " is sent by user, skipping cache management for {}.";
	public static final String CACHE_SHARED_DATA_EXPIRE_INFO = "Data in shared cache for key: {} expired and "
			+ "serving from stale cache";
	public static final String CACHE_SHARED_DATA_FOUND_INFO = "Data found in shared cache for key: {}";
	public static final String CACHE_LOCAL_DATA_FOUND_INFO = "Data found in local cache for key: {}";
	public static final String CACHE_LOCAL_SYNC_INFO = "Syncing with local cache for key: {}";
	public static final String CACHE_SHARED_FETCH_INFO = "Getting Data from shared cache for key: {}";
	public static final String CACHE_LOCAL_FETCH_INFO = "Getting Data from local cache for key: {}";
	public static final String CACHE_LOCAL_NOT_FOUND_INFO = "Data not found in local cache for key: {}";
	public static final String CACHE_SHARED_NOT_FOUND_INFO = "Data not found in shared cache for key: {}";
	public static final String CACHE_SAVE_LOCAL_SHARED_INFO = "Saving data to local and shared cache for key: {}";
	public static final String CACHE_SAVE_SHARED_INFO = "Saving data to shared cache for key: {}";
	public static final String CACHE_SAVE_LOCAL_INFO = "Saving data to local cache for key: {}";
	public static final String CACHE_SAVE_LOCAL_ERROR = "Failed to store data to local cache";
	public static final String CACHE_SHARED_STATS_PROCESS_ERROR = "Error occurred while preparing shared cache stats";
	public static final String CACHE_CONFIG_PROCESS_ERROR = "Error while processing cache configuration for {}";
	public static final String CACHE_RELOAD_INFO = "Cache configuration reloaded for {}";
	public static final String CACHE_HANDLE_CREATE_INFO = "Local cache handler created for interface: {}";

	//Config
	public static final String CONFIG_CLOUD_URL_PREFIX_INFO = "Cloud config url prefix: {}";
	public static final String CONFIG_CLOUD_PROP_MISSING_ERROR = "Properties for spring cloud " +
			"config server call is missing. Found URI:{}; ApplicationName:{}; Label:{}; Profile:{}";
	public static final String CONFIG_CLOUD_GET_INFO = "Getting cloud configuration using url: {}";
	public static final String CONFIG_CLOUD_ERROR_STATUS_MSG = "Unexpected status from config server: %s (%s). Reason: %s";
	public static final String CONFIG_CLOUD_EMPTY_JSON_MSG = "Json exists but is empty";
	public static final String CONFIG_CLOUD_READ_JSON_ERROR_MSG = ": Exception while reading json";
	public static final String CONFIG_CLOUD_LOAD_JSON_ERROR_MSG = ": External json loading failed, trying to load local";
	public static final String CONFIG_INTERFACE_CIRCUIT_INFO = "The interface '{}' has no circuit. "
			+ "circuit=interfaceKey will be used.";
	public static final String CONFIG_INTERFACE_WRONG_URL_WARN_MSG = "Wrong URL configuration interface '{}'." +
			" {}' will be used. base_url: {}, request_path: {}";

	//Controller
	public static final String CONTROLLER_PARSE_REQUEST_BODY_ERROR_MSG = "unable to parse request body:{}, message:{}";
	public static final String CONTROLLER_REQUEST_PROVISIONED_MSG = "Request received: service: {} operation:{}, " +
			"version:{}, param:{}, headers:{}";
	public static final String CONTROLLER_MAINTAIN_MODE_INFO_MSG = "%s is in maintenance mode.";
	public static final String CONTROLLER_EXCEPTION_INFO_MSG = "Exception occurred: {}";
	public static final String CONTROLLER_ERROR_RESPONSE_INFO_MSG = "Final Error Response: status: {}, response: {}";

	//Filter
	public static final String FILTER_INVALID_KEY_ERROR_MSG = "Either exclude contains invalid key " +
			"or no data found to delete, key: {}";//Filter

	//Logger
	public static final String LOGGER_EXCEPTION_MSG_INFO = "exception: %s message: %s";
	public static final String LOGGER_EXCEPTION_MSG_ERROR_CODE_INFO = "exception: %s message: %s errorCode: %s";

	//Validation
	//ParameterResolver
	public static final String PARAM_RESOLVE_INCLUDE_OR_EXCLUDE = "%s Please input includeParams " +
			"or excludeParams, not both";
	public static final String PARAM_RESOLVE_EXCLUSION_FAILURE_MSG = "%s feature can't be excluded";
	public static final String PARAM_RESOLVE_PARAM_REQD_MSG = " parameter is required!";
	public static final String PARAM_RESOLVE_NUMBER_UNDER_MSG = " must be under ";
	public static final String PARAM_RESOLVE_NUMBER_OVER_MSG = " must be over ";
	public static final String PARAM_RESOLVE_STRING_LEN_UNDER_MSG = " length must be under ";
	public static final String PARAM_RESOLVE_STRING_LEN_OVER_MSG = " length must be over ";
	public static final String PARAM_RESOLVE_INT_SIZE_UNDER_MSG = " size must be under ";
	public static final String PARAM_RESOLVE_STRING_PATTERN_FOLLOW_MSG = " must follow ";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_STRING_MSG = " should be type of string";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_DOUBLE_MSG = " should be double!";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_LONG_MSG = " should be long!";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_INT_MSG = " should be integer!";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_BOOL_MSG = " should be boolean!";
	public static final String PARAM_RESOLVE_VALIDATION_PARAMS_TYPE_LIST_MSG =" parameters should be list!";
	public static final String PARAM_RESOLVE_VALIDATION_PARAMS_TYPE_MAP_MSG =" parameters should be map";
	public static final String PARAM_RESOLVE_DATE_FORMAT_LIKE_MSG = " format must be like '";
	public static final String PARAM_RESOLVE_TYPE_NOT_LIST_OR_MAP_MSG = " cannot be type of map or list";
	public static final String PARAM_RESOLVE_OPTION_SELECT_MSG = "Please select the value from ";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_LIST_MSG = " should be type of list";
	public static final String PARAM_RESOLVE_VALIDATION_TYPE_NOT_MAP_MSG = " cannot be type of map";
	public static final String PARAM_RESOLVE_VALUE_SELECTION_MSG = " values must be selected from ";
	public static final String PARAM_RESOLVE_SELECTION_MINIMUM_MSG = ", minimum ";
	public static final String PARAM_RESOLVE_SELECTION_MAXIMUM_MSG = " and maximum ";
	public static final String PARAM_RESOLVE_VALUE_SELECTED_MSG = " values can be selected";
	public static final String PARAM_RESOLVE_VALUE_FOR_PARAM = "For parameter:";

	//SchemaValidator
	public static final String SCHEMA_VALID_FIELD_REQD_MSG = "When the field is required default value cannot be provided";
	public static final String SCHEMA_VALID_OBJECT_NOT_EMPTY_MSG = "When the type is either object/objectarray "
			+ "parameters cannot be empty";
	public static final String SCHEMA_VALID_OPTIONS_NOT_EMPTY_MSG = "options should not be empty";
	public static final String SCHEMA_VALID_OPTIONS_NOT_POSSIBLE_MSG = " cannot have options";
	public static final String SCHEMA_VALID_OPTIONS_TYPE_MULTIOPTIONS_MSG = "options should have multiple options";
	public static final String SCHEMA_VALID_DATA_TYPE_REQD_MSG = "dataType is required when ";
	public static final String SCHEMA_VALID_LIST_OR_OPTIONS_MSG = " is list or options";
	public static final String SCHEMA_VALID_DATA_TYPE_NUM_OR_STR_MSG = "dataType should be either numeric or string";
	public static final String SCHEMA_VALID_FORMAT_REQD_MSG = "Format is required for ";
	public static final String SCHEMA_VALID_TYPE_DATE = " date";
	public static final String SCHEMA_VALID_FORMAT_WRONG_MSG = "Wrong date format given, cause ";
	public static final String SCHEMA_VALID_PROP_TYPE_REQD_MSG = "propType is required when ";
	public static final String SCHEMA_VALID_TYPE_PROPERTY = " is property";
	public static final String SCHEMA_VALID_TYPE_NOT_PROPERTY = " is not property";
	public static final String SCHEMA_VALID_PROP_KEY_PREFIX_REQD_MSG = "propKeyPrefix is required when ";
	public static final String SCHEMA_VALID_PROP_TYPE_DEFINE_MSG = "propType is defined where ";
	public static final String SCHEMA_VALID_PROP_PREFIX_DEFINE_MSG = "propKeyPrefix is defined where ";
	public static final String SCHEMA_VALID_SIZE_LEN_NOT_VALID_MSG = "size and/or length not applicable for ";
	public static final String SCHEMA_VALID_MIN_VALUE_EXCEED_WARN_MSG = "minValue cannot be larger than the maxValue";
	public static final String SCHEMA_VALID_VALUE_LEN_NOT_PROPER_WARN_MSG = "value and/or length not applicable for ";
	public static final String SCHEMA_VALID_MIN_SIZE_EXCEED_WARN_MSG = "minSize cannot be larger than the maxSize";
	public static final String SCHEMA_VALID_MIN_LEN_EXCEED_WARN_MSG = "minLength cannot be larger than the maxLength";
	public static final String SCHEMA_VALID_VALUE_SIZE_NOT_PROPER_WARN_MSG = "value and/or size not applicable for ";
	public static final String SCHEMA_VALID_NAME_REQD_MSG = "name is required";
	public static final String SCHEMA_VALID_IS_REQD_MSG = " is required";
	public static final String SCHEMA_VALID_IS_NOT_SUPPORT_MSG = " is not supported";

	//SERVICE
	public static final String SERVICE_FEATURE_RESPONSE_MAP_DEBUG_MSG = "featureResponse map:{}";
	public static final String SERVICE_FEATURE_RESPONSE_START_INFO = "feature response process started.";
	public static final String SERVICE_FEATURE_EXCEPTION_MSG = "Exception while executing API: {}";
	public static final String SERVICE_API_REPO_LOAD_ERROR_MSG = "Error while loading APIs";
	public static final String SERVICE_API_REPO_LOAD_MAPPING_WARN_MSG = "No api mapping found; "
			+ "Repository will be loaded without any api configuration!";
	public static final String SERVICE_API_REPO_READ_JSON_FILE_MSG = "Reading API Config JSON operationFile for : {}";
	public static final String SERVICE_API_REPO_TEMPLATE_LOAD_INFO = "Loaded %d templates out of %d; "
			+ "Time took in millis: %d";
	public static final String SERVICE_API_REPO_JSON_LOAD_INFO = "{}: External json loaded successfully";
	public static final String SERVICE_API_REPO_JSON_LOAD_FAIL_INFO = ": External json loading failed";
	public static final String SERVICE_API_REPO_JSON_LOAD_LOCAL_INFO ="{}: Local json loaded successfully";
	public static final String SERVICE_API_REPO_JSON_LOAD_LOCAL_FAIL_INFO = ": Local json loading failed";
	public static final String SERVICE_API_REPO_UNABLE_CONFIG_LOAD_INFO = "Unable to load external or local configuration";
	public static final String SERVICE_API_REPO_MAX_OBTAIN_WARN = "Each of the API must not obtain more than ";
	public static final String SERVICE_API_REPO_HASH_FUNC_UPDATE = ". Please consider to change hash generating function"
			+ "in ExecutionServiceImpl";
	public static final String SERVICE_API_REPO_BEAN_NAME_FIND_ISSUE ="Unable to find bean for the name: ";
	public static final String SERVICE_API_REPO_SAME_API_SCOPE = "' must be defined within same api scope";
	public static final String SERVICE_API_REPO_SCHEMA_LOAD_ERROR = "SchemaLoading error: {}";
	public static final String SERVICE_API_REPO_DEFINE_IN_INTERFACE_MAP = "' must be defined in interfaces map";
	public static final String SERVICE_API_REPO_CALL_DEF_DEPENDENCY = "CallDefinition dependency '";
	public static final String SERVICE_API_REPO_PARAM_KEY_MISSING = "parameter key 'name' missing";
	public static final String SERVICE_API_REPO_CALL_DEF_DEFINE = "' defined for callDefinition : ";
	public static final String SERVICE_INCLUDE_EXCLUDE_EXCLUSIVE = "include/exclude must be exclusive";
	public static final String SERVICE_CANNOT_EXCLUDE_DEFAULT_FEATURES = "default features cannot be excluded: %s";
	public static final String SERVICE_UNKNOWN_PROP_REQUESTED = "unknown property requested: ";
	public static final String SERVICE_TIME_OUT_OCCURRED = "Timeout for '%s'";
	public static final String UNEXPECTED_RESPONSE_FORMAT = "Unexpected response format ";
	public static final String SERVICE_UNEXPECTED_RESPONSE_FORMAT = UNEXPECTED_RESPONSE_FORMAT
			+ "from ecstatic endpoints '%s': %s";
	public static final String SERVICE_BACKEND_RESPONSE_STATUS = "Backend call http response status: %s";
	public static final String SERVICE_UNEXPECTED_RESPONSE_FORMAT_CALL_DEFINITION = UNEXPECTED_RESPONSE_FORMAT
			+ "for call definition '%s'";
	public static final String SERVICE_UNEXPECTED_RESPONSE_FORMAT_GG = UNEXPECTED_RESPONSE_FORMAT
			+ "from generic gateway for call definition '%s'";
	public static final String SERVICE_INTERFACE_CONFIG_NULL_KEY = "Interface config is null for the interface key -> ";
	public static final String SERVICE_URI_PREPARE_ERROR = "Error preparing URI for ";
	public static final String SERVICE_CACHE_RESPONSE_ERROR = "Cache response not valid. response: {}";
	public static final String SERVICE_REQUEST_TYPE_NOT_FOUND_ERROR = "Request type not found: %s";

	//UTIL
	public static final String UTIL_URI_PREPARE_ERROR = "Error preparing URI for url '%s'";
	public static final String UTIL_PARSE_REQUEST_BODY_ERROR = "unable to parse request body: %s";
	public static final String UTIL_UNKNOWN_EXCEPTION_ERROR = "unknown exception %s %s";
	public static final String UTIL_BACKEND_UNAVAILABLE_ERROR = "Backend service is unavailable";
	public static final String UTIL_PARSE_JSON_STRING_ERROR = "Unable to parse json string";
	public static final String UTIL_INTERFACE_NULL_RESPONSE = " interface null response";
	public static final String UTIL_INTERFACE_NULL_RESPONSE_DETAIL = "{} - interface response is "
			+ "empty in '{}' call definition";
	public static final String UTIL_INVALID_OBJECT_MSG = "Invalid object";
	public static final String UTIL_PROP_KEY_MISSING_FOR_ERROR = "Property key/property's value is missing from the " +
			"properties for ";
	public static final String UTIL_PROP_INTEGER_CONVERT_ERROR = "Value cannot be converted to integer!";
	public static final String UTIL_PROP_LONG_CONVERT_ERROR = "Value cannot be converted to long!";
	public static final String UTIL_PROP_DOUBLE_CONVERT_ERROR = "Value cannot be converted to double!";
	public static final String UTIL_PROP_BOOL_CONVERT_ERROR = "Value cannot be converted to boolean!";
	public static final String UTIL_PROP_KEY_MISSING_MSG = "Properties key is missing from the properties!";
	private MessageConstants() {
		// constant


	}
}
