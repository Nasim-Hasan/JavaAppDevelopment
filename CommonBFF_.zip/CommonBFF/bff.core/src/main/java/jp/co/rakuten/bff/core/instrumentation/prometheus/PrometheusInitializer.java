package jp.co.rakuten.bff.core.instrumentation.prometheus;

import jp.co.rakuten.bff.core.service.impl.ApiRepositoryImpl;
import org.springframework.core.env.Environment;


/**
 * Initializes the Prometheus registries
 * @author prithviraj.pawar
 */
public class PrometheusInitializer{

	private PrometheusInitializer(){}
	/**
	 * Initializing the promehteus metrics
	 * @param apiRepository ApiRepositoryImpl
	 */
	public static void oninit(ApiRepositoryImpl apiRepository, Environment environment) {
		BffUpstreamMetricsManager.initialize();
		BffApiMetricsManager.initialize(apiRepository,environment);
		BffFeatureMetricsManager.initialize(apiRepository.getAllApiTemplates());
	}


}
