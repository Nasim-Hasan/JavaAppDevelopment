package jp.co.rakuten.bff.core.instrumentation.prometheus;

import com.rakuten.rapid.metrics.core.RapidMetricsManager;
import com.rakuten.rapid.metrics.core.RapidMetricsRegistry;
import com.rakuten.rapid.metrics.core.record.RapidCounter;
import com.rakuten.rapid.metrics.core.record.RapidMultiMeter;
import org.apache.commons.lang3.ObjectUtils;

import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
/**
 <p>
 This  class is responsible for creating metrics for outgoing requests
 </p>
 */
public class BffUpstreamMetricsManager {
	private static final String SINGLE = "single";
	private static final String PARALLEL ="parallel" ;
	private static final String COMPLEX = "complex";
	// The bff name should be injected as a label in prometheus server. This can happen using the service discovery
	private static RapidMetricsRegistry gatewayRequestRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.gateway.requests", true);
	private static RapidMetricsRegistry gatewayRequestTimeRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.gateway.requests.time", true);
	private static RapidMetricsRegistry gatewayRequestOverallStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.gateway.overallStatus", true);
	private static RapidMetricsRegistry gatewayRequestHttpStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.gateway.httpStatus", true);


	private static ConcurrentHashMap<String,RapidCounter> gatewayRequestMetrics=
			new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String,RapidCounter> gatewayRequestTimeMetrics =
			new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String,RapidMultiMeter> gatewayRequestOverallStatusMetrics =
			new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> gatewayRequestHttpStatusMetrics=
			new ConcurrentHashMap<>();


	private BffUpstreamMetricsManager(){ }
	/**
	 * Creates metrics at the application Boot Time
	 */
	public static void initialize(){
		initRequestTypeMetrics();
	}

	/**
	 * init gateway requestType metrics
	 */
	private static void initRequestTypeMetrics() {
		Arrays.asList(SINGLE, COMPLEX, PARALLEL).forEach((String request) ->{
			gatewayRequestMetrics.putIfAbsent
					(request,gatewayRequestRegistry.counter(request));
			gatewayRequestTimeMetrics.putIfAbsent
					(request,gatewayRequestTimeRegistry.counter(request));
			gatewayRequestOverallStatusMetrics.putIfAbsent
					(request,gatewayRequestOverallStatusRegistry.multiMeter(request));
			gatewayRequestHttpStatusMetrics.putIfAbsent
					(request,gatewayRequestHttpStatusRegistry.multiMeter(request));
		});
	}

	/** Called at the start of Gateway HTTP Request execution
	 * @param requestType type of requests to GG
	 */
	public static void markEntry(String requestType){
		if (ObjectUtils.isNotEmpty(gatewayRequestMetrics.get(requestType))) {
			gatewayRequestMetrics.get(requestType).increment();
		}
	}

	/** Called at the end of Gateway HTTP Request per requestType.
	 *  Marks OverallStatus per requestType. ( This status will come from the gateway Model )
	 * @param requestType type of request to gg
	 * @param overallStatusCode status code inside body
	 * @param httpCode the http status code in string
	 */
	public static void markExit(String requestType, String overallStatusCode, String httpCode) {
		if (ObjectUtils.isNotEmpty(gatewayRequestOverallStatusMetrics.get(requestType))
				&& ObjectUtils.isNotEmpty(gatewayRequestHttpStatusMetrics.get(requestType))){
			gatewayRequestOverallStatusMetrics.get(requestType).mark(overallStatusCode);
			gatewayRequestHttpStatusMetrics.get(requestType).mark(httpCode);
		}
	}
	/** Called at the start of mono execution
	 * @return time
	 */
	public static long startExecutionTime(){
		return System.currentTimeMillis();
	}

	/** Called at the End of mono execution
	 * @param requestType type of requestType
	 * @param startTime starttime of mono execution
	 */
	public static void stopExecutionTime(String requestType,long startTime) {
		if (ObjectUtils.isNotEmpty(gatewayRequestTimeMetrics.get(requestType))) {
			gatewayRequestTimeMetrics.get(requestType).increment(System.currentTimeMillis() - startTime);
		}
	}
}
