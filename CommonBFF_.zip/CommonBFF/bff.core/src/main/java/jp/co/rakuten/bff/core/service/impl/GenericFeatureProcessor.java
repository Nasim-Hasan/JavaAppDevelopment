package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.service.upstream.client.UpstreamClient;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Generic feature processor prepare a generic response.<br/>
 * It collects all interface response according to specified feature.
 */
@Component
public class GenericFeatureProcessor implements FeatureProcessor {

	/**
	 * Call definition is a group of interface. Post processor collects all interface's response.
	 *
	 * @param validatedClientData       validated feature specific client / default data.
	 * @param featureTemplate           {@link FeatureTemplate} - which holds interface list
	 * @param callDefinitionResponseMap Call definition name as key and Call definition response as value
	 * @return FeaturePostProcessorResponse
	 */
	@Override
	public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
														  FeatureTemplate featureTemplate,
														  Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		FeaturePostProcessorResponse featurePostProcessorResponse = new FeaturePostProcessorResponse();
		Map<String, Object> interfaceFinalResponseMap = new HashMap<>();

		boolean isCacheable = true;
		//prepare interface set from interface list to avoid linear search
		Set<String> interfaceSet = new HashSet<>(featureTemplate.getInterfaceNameList());
		for (CallDefinitionTemplate callDefinitionTemplate : featureTemplate.getCallDefinitionsSet()) {

			//Get specific Call definition response from callDefinitionResponseMap
			CallDefinitionResponse callDefinitionResponse =
					callDefinitionResponseMap.get(callDefinitionTemplate.getName());
			CallDefinitionResponseStatus callDefinitionResponseStatus = callDefinitionResponse.getStatus();

			//If generic gateway call occurred
			if (callDefinitionResponseStatus == CallDefinitionResponseStatus.SUCCESS) {
				isCacheable &= processSuccessResponse(interfaceFinalResponseMap, interfaceSet, callDefinitionResponse);
			} else {
				isCacheable = false;
				processErrorResponse(interfaceFinalResponseMap, interfaceSet,
						callDefinitionResponse, callDefinitionTemplate);
			}
		}

		featurePostProcessorResponse.setCacheable(isCacheable);
		featurePostProcessorResponse.setResponseMap(interfaceFinalResponseMap);
		return Mono.just(featurePostProcessorResponse);
	}

	/**
	 * Collect specified features interface response from call definition and put it to interfaceResponseMap<br/>
	 * If got any error response from generic gateway make shouldCache variable false and finally return this status.
	 *
	 * @param interfaceFinalResponseMap Key - interface name, Value - interface response
	 * @param interfaceSet              Specified features interface set
	 * @param callDefinitionResponse    Key - call definition name, Value - call definition response
	 * @return boolean should cache or not
	 */
	private boolean processSuccessResponse(Map<String, Object> interfaceFinalResponseMap,
										   Set<String> interfaceSet,
										   CallDefinitionResponse callDefinitionResponse) {
		MultipleResponses multipleResponses = callDefinitionResponse.getMultipleResponses();

		boolean isCacheable = true;
		Map<String, CustomHttpResponse> responses = multipleResponses.getResponses();
		for (Map.Entry<String, List<String>> entry : callDefinitionResponse.getInterfaceToRequestIdMap().entrySet()) {
			String interfaceName = entry.getKey();
			List<String> requestIdList = entry.getValue();

			if (interfaceSet.contains(interfaceName)) {
				for (String requestId : requestIdList) {
					CustomHttpResponse customHttpResponse = responses.get(requestId);
					isCacheable = isCacheable(customHttpResponse, interfaceFinalResponseMap, interfaceName);
				}
			}
		}

		return isCacheable;
	}

	/**
	 * @param customHttpResponse              CustomHttpResponse of the interface
	 * @param interfaceFinalResponseMap       Key - interface name, Value - interface response
	 * @param interfaceName                   name of the interface
	 * @return boolean should cache or not
	 */
	private boolean isCacheable(CustomHttpResponse customHttpResponse, Map<String, Object> interfaceFinalResponseMap,
								String interfaceName) {
		if (Objects.nonNull(customHttpResponse)) {
			return setInterfaceResponse(interfaceFinalResponseMap, interfaceName, customHttpResponse);
		}
		return false;
	}

	/**
	 * Set interface response to interface final response map. <br/>
	 * Interface response can have body or error. Check which part exist and set those portion in
	 * interface final response map. If errors exist then we return false.
	 *
	 * @param interfaceFinalResponseMap interfaceResponseMap   Key - interface name, Value - interface response
	 * @param interfaceName             Interface name
	 * @param interfaceResponse         Interface response
	 * @return boolean should cache or not
	 */
	private boolean setInterfaceResponse(Map<String, Object> interfaceFinalResponseMap, String interfaceName,
										 CustomHttpResponse interfaceResponse) {
		boolean isCacheable = true;
		Object body = interfaceResponse.getBodyMap();
		if (Objects.nonNull(body)) {
			interfaceFinalResponseMap.put(interfaceName, body);
		} else {
			isCacheable = false;
			interfaceFinalResponseMap.put(interfaceName, interfaceResponse.getError());
		}
		return isCacheable;
	}

	/**
	 * Process those call definition which throws exception by {@link UpstreamClient}.
	 * Set those interface response as error in final interface response map.
	 *
	 * @param interfaceFinalResponseMap interfaceResponseMap   Key - interface name, Value - interface response
	 * @param interfaceSet              Specified features interface set
	 * @param callDefinitionResponse    Key - call definition name, Value - call definition response
	 * @param callDefinitionTemplate    {@link CallDefinitionTemplate}
	 */
	private void processErrorResponse(Map<String, Object> interfaceFinalResponseMap,
									  Set<String> interfaceSet,
									  CallDefinitionResponse callDefinitionResponse,
									  CallDefinitionTemplate callDefinitionTemplate) {

		CallDefinitionError callDefinitionError = callDefinitionResponse.getCallDefinitionError();

		callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
			if (interfaceSet.contains(interfaceName)) {
				interfaceFinalResponseMap.put(interfaceName, Map.of(BffConstants.ERROR, callDefinitionError));
			}
		});
	}

}
