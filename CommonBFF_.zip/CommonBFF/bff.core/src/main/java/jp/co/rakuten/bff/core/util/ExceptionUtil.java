package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.server.ServerWebInputException;

import java.io.IOException;

import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_BACKEND_UNAVAILABLE_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_PARSE_REQUEST_BODY_ERROR;
import static jp.co.rakuten.bff.core.constant.MessageConstants.UTIL_UNKNOWN_EXCEPTION_ERROR;
import static jp.co.rakuten.bff.core.exception.type.BackendErrorEnum.SERVICE_CONDITION;

/**
 * Utility class to help the creation and manipulation of GatewayException
 *
 * @author tony.rouillard
 */
public class ExceptionUtil {


	private ExceptionUtil() {
		// utility method
	}

	/**
	 * Create a BffException from a throwable.
	 * If the throwable is already a BffException, it returns the BffException type.
	 * Otherwise, a SystemException is created with a meaningful message.
	 *
	 * @param throwable The throwable to convert if necessary
	 * @return The GatewayException
	 */
	public static BffException getBffException(Throwable throwable) {
		BffException bffException;
		if (throwable instanceof BffException) {
			bffException = (BffException) throwable;
		} else if (throwable instanceof ServerWebInputException) {
			bffException = ClientException
					.create(ClientErrorEnum.BAD_REQUEST, throwable, BffConstants.INVALID_REQUEST_BODY)
					.addDetailForLog(UTIL_PARSE_REQUEST_BODY_ERROR, throwable.getMessage());
		} else {
			bffException = SystemException
					.create(SystemErrorEnum.INTERNAL, throwable, BffConstants.INTERNAL_SERVER_ERROR)
					.addDetailForLog(UTIL_UNKNOWN_EXCEPTION_ERROR, getMeaningfulMessage(throwable), throwable);
		}
		return bffException;
	}


	/**
	 * Create a BffException from a throwable while getting exception while retrieving from backend GG or ecstatic client.
	 * If the throwable is already a BackendException, it returns the BackendException type.
	 * Otherwise, a BackendException is created with a meaningful message.
	 *
	 * @param throwable The throwable to convert if necessary
	 * @return The BackendException
	 */
	public static BffException getBackendException(Throwable throwable) {
		BffException backendException;
		if (throwable instanceof BffException) {
			backendException = (BffException) throwable;
		} else if (throwable instanceof IOException) {
			backendException = BackendException.create(SERVICE_CONDITION,
					UTIL_BACKEND_UNAVAILABLE_ERROR).addDetailForLog(throwable.getMessage(), throwable);
		} else {
			backendException = BackendException.create(SERVICE_CONDITION,
					UTIL_BACKEND_UNAVAILABLE_ERROR).addDetailForLog(throwable.getMessage(), throwable);
		}
		return backendException;
	}

	/**
	 * The method helps to find a good message from an exception.
	 * Priority: message, cause's message, class name.
	 *
	 * @param throwable The exception
	 * @return A message or the class name
	 */
	private static String getMeaningfulMessage(Throwable throwable) {
		String errorMessage = throwable.getMessage();
		if (StringUtils.isEmpty(errorMessage)) {
			errorMessage = getCauseMessage(throwable);
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = throwable.getClass().getSimpleName();
			}
		}
		return errorMessage;
	}

	private static String getCauseMessage(Throwable throwable) {
		Throwable cause = throwable.getCause();
		String causeMessage = null;
		if (cause != null) {
			causeMessage = cause.getMessage();
		}
		return causeMessage;
	}

}
