package jp.co.rakuten.bff.core.logger;

import static net.logstash.logback.argument.StructuredArguments.kv;

import java.net.URI;
import java.time.Clock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import jp.co.rakuten.bff.core.constant.MessageConstants;
import net.logstash.logback.argument.StructuredArgument;
import org.slf4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

/**
 * <p>HttpLogger is responsible for logging HttpRequests either incoming request or outgoing requests.
 * <p>Useful when you want to measure how much time it took and what was the result of the operation.
 * @author alfredo.osorio
 */
public class HttpLogger {

	private Logger logger;
	private Map<String, String> aliases;
	private Clock clock;
	private Function<Throwable, String> throwableMessageConverter = DEFAULT_THROWABLE_MESSAGE_CONVERTER;

	public static final Function<Throwable, String> DEFAULT_THROWABLE_MESSAGE_CONVERTER =
			throwable -> String.format(MessageConstants.LOGGER_EXCEPTION_MSG_INFO, throwable.getClass().getName(),
					throwable.getMessage());

	/**
	 * The minimal constructor that uses the default names for the properties.
	 * @param logger the logger
	 */
	public HttpLogger(Logger logger) {
		this(logger, new HashMap<>());
	}

	/**
	 * This constructor allows you to also pass a Map of aliases to be able to configure the property names.
	 * @param logger the logger
	 * @param aliases the aliases where clients can map a field name from {@code FieldNames} to a custon name.
	 */
	public HttpLogger(Logger logger, Map<String, String> aliases) {
		this(logger, aliases, DEFAULT_THROWABLE_MESSAGE_CONVERTER);
	}

	/**
	 * Constructor with throwableMessageConverter
	 * @param logger the logger
	 * @param aliases the aliases
	 * @param throwableMessageConverter the throwableMessageConverter
	 */
	public HttpLogger(Logger logger, Map<String, String> aliases,
					  Function<Throwable, String> throwableMessageConverter) {
		this(logger, aliases, throwableMessageConverter, Clock.systemUTC());
	}

	/**
	 * Full parameters constructor
	 * @param logger the logger
	 * @param aliases the aliases
	 * @param throwableMessageConverter the throwableMessageConverter
	 * @param clock the clock
	 */
	public HttpLogger(Logger logger, Map<String, String> aliases,
					  Function<Throwable, String> throwableMessageConverter, Clock clock) {
		this.logger = logger;
		this.aliases = aliases;
		this.throwableMessageConverter = throwableMessageConverter;
		this.clock = clock;
	}


	/**
	 * Includes the filed names that can be used in {@code aliases}
	 */
	public static class FieldNames {

		public static final String RESPONSE_TIME = "responseTime";
		public static final String METHOD = "method";
		public static final String PATH = "path";
		public static final String QUERY = "query";
		public static final String EXCEPTION = "exception";
		public static final String STATUS = "status";
		public static final String REQUEST_BODY = "requestBody";
		public static final String RESPONSE_BODY = "responseBody";

		private FieldNames() { }

	}


	/**
	 * Logs the request and captures the time that it took to complete.
	 * @param loggerRequest the loggerRequest
	 */
	public void log(LoggerRequest loggerRequest) {
		if (!logger.isInfoEnabled()) {
			return;
		}

		List<StructuredArgument> arguments = new ArrayList<>();
		arguments.add(kv(aliases.getOrDefault(FieldNames.RESPONSE_TIME, FieldNames.RESPONSE_TIME),
				clock.millis() - loggerRequest.getStartTime()));
		arguments.add(kv(aliases.getOrDefault(FieldNames.METHOD, FieldNames.METHOD),
				loggerRequest.getMethod()));

		String path = null;
		String query = null;
		if (loggerRequest.getUri() != null) {
			path = loggerRequest.getUri().toString().split("\\?")[0];
			query = loggerRequest.getUri().getQuery();
		}

		arguments.add(kv(aliases.getOrDefault(FieldNames.PATH, FieldNames.PATH), path));
		arguments.add(kv(aliases.getOrDefault(FieldNames.QUERY, FieldNames.QUERY), query));
		if (loggerRequest.getRequestBody() != null) {
			arguments.add(kv(aliases.getOrDefault(FieldNames.REQUEST_BODY, FieldNames.REQUEST_BODY),
					loggerRequest.getRequestBody()));
		}

		HttpStatus status = loggerRequest.getStatus();
		arguments.add(kv(aliases.getOrDefault(FieldNames.STATUS, FieldNames.STATUS),
				status != null ? status.value(): null));

		if (logger.isDebugEnabled() && loggerRequest.getResponseBody() != null) {
			arguments.add(kv(aliases.getOrDefault(FieldNames.RESPONSE_BODY, FieldNames.RESPONSE_BODY),
					loggerRequest.getResponseBody()));
		}

		for (Map.Entry<String, Object> e : loggerRequest.getExtras().entrySet()) {
			arguments.add(kv(e.getKey(), e.getValue()));
		}

		String exceptionType = null;
		String message = "OK";
		if (loggerRequest.getThrowable() != null) {
			Throwable throwable = loggerRequest.getThrowable();
			exceptionType = throwable.getClass().getName();
			message = throwableMessageConverter.apply(throwable);
		}

		arguments.add(kv(aliases.getOrDefault(FieldNames.EXCEPTION, FieldNames.EXCEPTION), exceptionType));

		logger.info(message, arguments.toArray());
	}

	/**
	 * This is used as a DTO. Clients should be responsible to populate this object according to its
	 * needs. If there is an error then the client should provide the {@code Throwable}.
	 */
	public static class LoggerRequest {

		private long startTime;
		private HttpMethod method;
		private URI uri;
		private String requestBody;
		private HttpStatus status;
		private String responseBody;
		private Throwable throwable;
		private Map<String, Object> extras = new HashMap<>();
		private Clock clock;

		/**
		 * Parameterless constructor
		 */
		public LoggerRequest() {
			this(Clock.systemUTC());
		}

		/**
		 * Constructor with clock
		 * @param clock the clock
		 */
		public LoggerRequest(Clock clock) {
			this.clock = clock;
		}

		/**
		 * Clients should call this to mark the start of the Http Request.
		 */
		public void startTimeCounting() {
			this.startTime = clock.millis();
		}

		/**
		 * Retrieves the the time after start
		 * @return the start time in millis
		 */
		public long getStartTime() {
			return startTime;
		}

		public HttpMethod getMethod() {
			return method;
		}

		public void setMethod(HttpMethod method) {
			this.method = method;
		}

		public URI getUri() {
			return uri;
		}

		public void setUri(URI uri) {
			this.uri = uri;
		}

		public String getRequestBody() {
			return requestBody;
		}

		public void setRequestBody(String requestBody) {
			this.requestBody = requestBody;
		}

		public HttpStatus getStatus() {
			return status;
		}

		/**
		 * The response status of the request
		 * @param status
		 */
		public void setStatus(HttpStatus status) {
			this.status = status;
		}

		public String getResponseBody() {
			return responseBody;
		}

		public void setResponseBody(String responseBody) {
			this.responseBody = responseBody;
		}

		public Throwable getThrowable() {
			return throwable;
		}

		/**
		 * The {@code throwable} of either the incoming request or the outgoing request.
		 */
		public void setThrowable(Throwable throwable) {
			this.throwable = throwable;
		}


		public Map<String, Object> getExtras() {
			return extras;
		}

		public void setExtras(Map<String, Object> extras) {
			this.extras = extras;
		}
	}

}
