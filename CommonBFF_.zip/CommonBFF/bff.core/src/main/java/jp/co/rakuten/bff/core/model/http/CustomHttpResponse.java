package jp.co.rakuten.bff.core.model.http;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * This class encapsulates the HttpResponse related information:
 * requestId    : The id of the related request
 * interfaceKey : The interface key
 * body         : The body returned by the interface
 * error        : The error if there is
 */
public class CustomHttpResponse {
	private String interfaceKey;
	@JsonProperty("body")
	private Map<String, Object> bodyMap;
	private String bodyAsString;
	private CustomError error;
	private Map<String, String> header;

	/**
	 * All args constructor
	 *
	 * @param interfaceKey interface key
	 * @param bodyMap      map object of body
	 * @param bodyAsString string object of body
	 * @param error        CustomError object
	 * @param header       header parameter map
	 * @return
	 */
	public CustomHttpResponse(String interfaceKey, Map<String, Object> bodyMap, String bodyAsString,
							  CustomError error, Map<String, String> header) {
		this.interfaceKey = interfaceKey;
		this.bodyMap = bodyMap;
		this.bodyAsString = bodyAsString;
		this.error = error;
		this.header = header;
	}

	public CustomHttpResponse() {
	}

	/**
	 * CustomHttpResponse builder method
	 *
	 * @return CustomHttpResponseBuilder
	 */
	public static CustomHttpResponseBuilder builder() {
		return new CustomHttpResponseBuilder();
	}

	@Override
	public String toString() {
		return "CustomHttpResponse{" +
				"interfaceKey='" + interfaceKey + '\'' +
				", bodyMap=" + bodyMap +
				", bodyAsString='" + bodyAsString + '\'' +
				", error=" + error +
				", header=" + header +
				'}';
	}

	public String getInterfaceKey() {
		return this.interfaceKey;
	}

	public Map<String, Object> getBodyMap() {
		return this.bodyMap;
	}

	public String getBodyAsString() {
		return bodyAsString;
	}

	public CustomError getError() {
		return this.error;
	}

	public void setInterfaceKey(String interfaceKey) {
		this.interfaceKey = interfaceKey;
	}

	public void setBodyMap(Map<String, Object> bodyMap) {
		this.bodyMap = bodyMap;
	}

	public void setBodyAsString(String bodyAsString) {
		this.bodyAsString = bodyAsString;
	}

	public void setError(CustomError error) {
		this.error = error;
	}

	public Map<String, String> getHeader() {
		return header;
	}

	public void setHeader(Map<String, String> header) {
		this.header = header;
	}

	/**
	 * CustomHttpResponse Builder class
	 */
	public static class CustomHttpResponseBuilder {
		private String interfaceKey;
		private Map<String, Object> bodyMap;
		private String bodyAsString;
		private CustomError error;
		private Map<String, String> header;

		CustomHttpResponseBuilder() {
		}

		/**
		 * Set request id
		 *
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder requestId() {
			return this;
		}

		/**
		 * Set interface key
		 *
		 * @param interfaceKey interface key
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder interfaceKey(String interfaceKey) {
			this.interfaceKey = interfaceKey;
			return this;
		}

		/**
		 * Set body map
		 *
		 * @param bodyMap body map
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder bodyMap(Map<String, Object> bodyMap) {
			this.bodyMap = bodyMap;
			return this;
		}

		/**
		 * Set body string
		 *
		 * @param bodyAsString body as string
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder bodyAsString(String bodyAsString) {
			this.bodyAsString = bodyAsString;
			return this;
		}

		/**
		 * Set {@link CustomError}
		 *
		 * @param error {@link CustomError}
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder error(CustomError error) {
			this.error = error;
			return this;
		}

		/**
		 *  This method invokes CustomHttpResponse Builder.
		 * @param header header
		 * @return CustomHttpResponseBuilder
		 */
		public CustomHttpResponseBuilder header(Map<String, String> header) {
			this.header = header;
			return this;
		}

		/**
		 * This method returns CustomHttpResponse HTTP response object.
		 * @return CustomHttpResponse
		 */
		public CustomHttpResponse build() {
			return new CustomHttpResponse(interfaceKey, bodyMap,
					bodyAsString, error, header);
		}
	}
}
