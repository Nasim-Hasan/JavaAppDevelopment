package jp.co.rakuten.bff.core.exception;


import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import org.springframework.http.HttpStatus;

/**
 * <p>This Exception class is responsible for propagating all the errors related to
 * backend failure such as:
 * <ul>
 *     <li>not_found<li/>
 *     <li>unauthorized<li/>
 *     <li>unknown_status<li/>
 *     <li>service_condition<li/>
 *     <li>timeout<li/>
 * </ul>
 * </p>
 */
public class BackendException extends BffException {


	/**
	 * Constructor with cause exception
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param ex        The cause exception
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 */
	public BackendException(BackendErrorEnum errorEnum, Throwable ex, String message, Object... params) {
		super(errorEnum.getErrorCode(), errorEnum.getErrorType(), ex, message, params);
	}

	/**
	 * Constructor when backend throws an errorCode
	 *
	 * @param errorEnum          The error enum that contains code and type
	 * @param ex                 The cause exception
	 * @param upstreamStatusCode the true backend status code
	 * @param message            The message
	 * @param params             The optional parameters to insert in the message
	 */
	public BackendException(BackendErrorEnum errorEnum, HttpStatus upstreamStatusCode, Throwable ex,
							String message, Object... params) {
		super(errorEnum.getErrorCode(), upstreamStatusCode, errorEnum.getErrorType(), ex, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 * @return The backend exception
	 */
	public static BackendException create(BackendErrorEnum errorEnum, String message, Object... params) {
		return new BackendException(errorEnum, null, message, params);
	}

	/**
	 * Build the exception without cause exception. Use the backend Http status
	 *
	 * @param errorEnum  The error enum that contains code and type
	 * @param httpStatus The Http statusCode returned from backend.
	 * @param message    The message
	 * @param params     The optional parameters to insert in the message
	 * @return The backend exception
	 */
	public static BackendException create(BackendErrorEnum errorEnum, HttpStatus httpStatus, String message,
										  Object... params) {
		return new BackendException(errorEnum, httpStatus, null, message, params);
	}

	/**
	 * Build the exception without cause exception. Use addExtraMessages to add detailed information.
	 *
	 * @param errorEnum The error enum that contains code and type
	 * @param ex        The cause exception
	 * @param message   The message
	 * @param params    The optional parameters to insert in the message
	 * @return The backend exception
	 */
	public static BackendException create(BackendErrorEnum errorEnum, Throwable ex, String message, Object... params) {
		return new BackendException(errorEnum, ex, message, params);
	}
}
