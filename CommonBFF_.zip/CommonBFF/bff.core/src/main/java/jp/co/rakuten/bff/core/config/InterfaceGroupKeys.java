package jp.co.rakuten.bff.core.config;

/**
 * This holds the interfaceKey to groupKey association.
 * In other words, this class simply tells which group an interface belongs.
 */
public class InterfaceGroupKeys implements IInterface {

	private String interfaceKey;
	private String groupKey;

	InterfaceGroupKeys(String interfaceKey, String groupKey){
		this.interfaceKey = interfaceKey;
		this.groupKey = groupKey;
	}

	@Override
	public String getInterfaceKey() {
		return interfaceKey;
	}

	public void setInterfaceKey(String interfaceKey) {
		this.interfaceKey = interfaceKey;
	}

	@Override
	public String getGroupKey() {
		return groupKey;
	}

	public void setGroupKey(String groupKey) {
		this.groupKey = groupKey;
	}
}
