package jp.co.rakuten.bff.core.exception.type;

import org.springframework.http.HttpStatus;

/**
 * It will have the below error definition which will be later
 * used by BackendException
 * <li>BAD_REQUEST --- 400</li>
 */
public enum ClientErrorEnum {
	BAD_REQUEST("bad_request", HttpStatus.BAD_REQUEST);

	private String errorType;
	private HttpStatus errorCode;

	ClientErrorEnum(String errorType, HttpStatus errorCode) {
		this.errorType = errorType;
		this.errorCode = errorCode;
	}

	public String getErrorType() {
		return errorType;
	}

	public HttpStatus getErrorCode() {
		return errorCode;
	}
}
