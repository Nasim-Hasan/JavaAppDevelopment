package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generically prepared request DTO for Generic Gateway
 */
public class GenericCallDefinitionProcessedData {

	/**
	 * RequestId to request map
	 */
	private Map<String, Map<String, Object>> preparedRequest;

	/**
	 * Interface name to requestId map
	 */
	private Map<String, List<String>> interfaceToRequestIdMap;

	/**
	 * Interface response map to use during pre process, in cases backend call not required
	 */
	private Map<String, CustomHttpResponse> interfaceResponses;

	public Map<String, Map<String, Object>> getPreparedRequest() {
		return preparedRequest != null ? preparedRequest : new HashMap<>();
	}

	public void setPreparedRequest(Map<String, Map<String, Object>> preparedRequest) {
		this.preparedRequest = preparedRequest;
	}

	public Map<String, List<String>> getInterfaceToRequestIdMap() {
		return interfaceToRequestIdMap;
	}

	public void setInterfaceToRequestIdMap(Map<String, List<String>> interfaceToRequestIdMap) {
		this.interfaceToRequestIdMap = interfaceToRequestIdMap;
	}

	public Map<String, CustomHttpResponse> getInterfaceResponses() {
		if(this.interfaceResponses == null){
			this.interfaceResponses = new HashMap<>();
		}
		return this.interfaceResponses;
	}

	public void setInterfaceResponses(Map<String, CustomHttpResponse> interfaceResponses) {
		this.interfaceResponses = interfaceResponses;
	}

	/**
	 * Remove generically prepared request by interface name. Return null if not exist.
	 *
	 * @param interfaceName Interface name
	 * @return Map<String, Object>
	 */
	public Map<String, Object> removeRequestByInterface(String interfaceName) {
		Map<String, Object> request = null;
		if (MapUtils.isNotEmpty(this.interfaceToRequestIdMap) && MapUtils.isNotEmpty(this.preparedRequest)) {
			List<String> requestIdList = this.interfaceToRequestIdMap.get(interfaceName);
			if (CollectionUtils.isNotEmpty(requestIdList)) {
				for (String requestId : requestIdList) {
					request = preparedRequest.remove(requestId);
				}
			}
		}
		return request;
	}

	/**
	 * Extracts requestId of an interface, for cases with single request for an interface, otherwise null if not found.
	 * Will throw exception in case multiple request ids found. Such cases should not use this method.
	 *
	 * @param interfaceName Interface name
	 * @return String
	 */
	public String getRequestId(String interfaceName) {
		String requestId = null;
		if (MapUtils.isNotEmpty(this.interfaceToRequestIdMap)) {
			List<String> requestIdList = this.interfaceToRequestIdMap.get(interfaceName);
			if (requestIdList.size() > 1) {
				throw SystemException.create(SystemErrorEnum.INTERNAL,
						"Found multiple requestIds while retrieving single request " + interfaceName);
			}
			requestId = requestIdList.iterator().next();
		}
		return requestId;
	}

	/**
	 * Get generically prepared request by interface name. Return null if not exist.
	 *
	 * @param interfaceName Interface name
	 * @return Map<String, Object>
	 */
	public Map<String, Object> getRequestByInterface(String interfaceName) {
		if (MapUtils.isEmpty(this.interfaceToRequestIdMap)) {
			return null;
		}

		String requestId = this.getRequestId(interfaceName);
		if (requestId != null && MapUtils.isNotEmpty(this.preparedRequest)) {
			return this.preparedRequest.get(requestId);
		} else {
			return null;
		}
	}

	/**
	 * Returns true if call definition should run
	 * (i.e. when there are remaining requests after pre processing)
	 *
	 * @return boolean
	 */
	public boolean shouldCDRun() {
		return this.getPreparedRequest().size() > 0;
	}

	/**
	 * Sets a customHttpResponse against interface request id.
	 * To be used during pre-process if response can be prepared without calling backend,
	 * i.e. in case a custom error or cached data
	 *
	 * @param interfaceName      name of interface
	 * @param customHttpResponse response to set
	 */
	public void setInterfaceResponse(String interfaceName, CustomHttpResponse customHttpResponse) {
		String requestId = getRequestId(interfaceName);
		if (StringUtils.isBlank(requestId)) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, "Error getting requestId for " + interfaceName);
		}
		if (customHttpResponse != null) {
			getInterfaceResponses().put(requestId, customHttpResponse);
		}
	}

	/**
	 * Gets interfaceName stored against interface name
	 * i.e. for cases with single response for an interface
	 *
	 * @param interfaceName interface name
	 * @return CustomHttpResponse
	 */
	public CustomHttpResponse getInterfaceResponse(String interfaceName) {
		Map<String, CustomHttpResponse> responses = this.getInterfaceResponses();
		if (MapUtils.isNotEmpty(responses)) {
			String requestId = this.getRequestId(interfaceName);
			if (requestId != null) {
				return responses.get(requestId);
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "GenericCallDefinitionProcessedData{" +
				"preparedRequest=" + preparedRequest +
				", interfaceToRequestIdMap=" + interfaceToRequestIdMap +
				", interfaceResponses=" + interfaceResponses +
				'}';
	}
}
