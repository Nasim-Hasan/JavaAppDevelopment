package jp.co.rakuten.bff.core.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.validators.CustomValidator;

import java.util.HashMap;
import java.util.Map;

/**
 * Api template POJO class - holds the following information<br/>
 * <ul>
 *     <li>1. Property key</li>
 *     <li>2. {@link InterfaceTemplate} map</li>
 *     <li>3. {@link CallDefinitionTemplate} map</li>
 *     <li>4. {@link FeatureTemplate} map</li>
 * </ul>
 */
public class ApiTemplate {
	@JsonProperty("validator")
	private String validatorName;
	@JsonProperty("interfaces")
	private Map<String, InterfaceTemplate> interfacesMap = new HashMap<>();
	@JsonProperty("callDefinitions")
	private Map<String, CallDefinitionTemplate> callDefinitionsMap = new HashMap<>();
	@JsonProperty("features")
	private Map<String, FeatureTemplate> featuresMap = new HashMap<>();

	@JsonIgnore
	private CustomValidator validatorBean;
	@JsonIgnore
	private ApiDetail apiDetail;
	@JsonIgnore
	private boolean isFromExternal;
	@JsonIgnore
	private ApiParamsTemplate apiParamsTemplate; //contains the Api Json

	public String getValidatorName() {
		return validatorName;
	}

	public void setValidatorName(String validatorName) {
		this.validatorName = validatorName;
	}

	public CustomValidator getValidatorBean() {
		return validatorBean;
	}

	public void setValidatorBean(CustomValidator validatorBean) {
		this.validatorBean = validatorBean;
	}

	public Map<String, InterfaceTemplate> getInterfacesMap() {
		return this.interfacesMap;
	}

	public Map<String, CallDefinitionTemplate> getCallDefinitionsMap() {
		return this.callDefinitionsMap;
	}

	public Map<String, FeatureTemplate> getFeaturesMap() {
		return this.featuresMap;
	}

	public void setInterfacesMap(Map<String, InterfaceTemplate> interfacesMap) {
		this.interfacesMap = interfacesMap;
	}

	public void setCallDefinitionsMap(Map<String, CallDefinitionTemplate> callDefinitionsMap) {
		this.callDefinitionsMap = callDefinitionsMap;
	}

	public void setFeaturesMap(Map<String, FeatureTemplate> featuresMap) {
		this.featuresMap = featuresMap;
	}

	public void setApiDetail(ApiDetail apiDetail) {
		this.apiDetail = apiDetail;
	}

	public String getApiKey() {
		return this.apiDetail.getApiKey();
	}

	public String getService() {
		return this.apiDetail.getService();
	}

	public String getOperation() {
		return this.apiDetail.getOperation();
	}

	public String getVersion() {
		return this.apiDetail.getVersion();
	}

	public String getPath() {
		return this.apiDetail.getPath();
	}

	public boolean isFromExternal() {
		return isFromExternal;
	}

	public void setFromExternal(boolean fromExternal) {
		isFromExternal = fromExternal;
	}

	public ApiParamsTemplate getApiParamsTemplate() {
		return apiParamsTemplate;
	}

	public void setApiParamsTemplate(ApiParamsTemplate apiParamsTemplate) {
		this.apiParamsTemplate = apiParamsTemplate;
	}

	@Override
	public String toString() {
		return "ApiTemplate{" +
				"interfacesMap=" + interfacesMap +
				", callDefinitionsMap=" + callDefinitionsMap +
				", featuresMap=" + featuresMap +
				", apiDetail=" + apiDetail +
				", isFromExternal=" + isFromExternal +
				", apiParamsTemplate=" + apiParamsTemplate +
				", validatorName=" + validatorName +
				", validatorBean=" + validatorBean +
				'}';
	}
}
