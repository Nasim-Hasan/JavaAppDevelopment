package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.REQUEST_CHARSET;
import static jp.co.rakuten.bff.core.constant.BffConstants.URL;
import static jp.co.rakuten.bff.core.constant.MessageConstants.SERVICE_URI_PREPARE_ERROR;

/**
 * This class contains the logic that builds the URI of a custom request.
 *
 * @author tony.rouillard
 */
public class UrlParameterLogic {
	private static final String DEFAULT_REQUEST_CHARSET = "UTF-8";

	/*private constructor to prevent creating object*/
	private UrlParameterLogic() {}

	/**
	 * Build the URI with URLEncoding support.
	 *
	 * @param request the custom request
	 * @return The URI
	 */
	public static URI buildUri(CustomHttpRequest request) {
		StringBuilder queryParams = new StringBuilder();
		String url = String.valueOf(request.getConnectionMap().get(URL));
		Map<String, String> urlMapCopy = new HashMap<>(request.getUrlParameterMap());

		url = insertParameterInUrl(request.getUrlParameterMap(), url, urlMapCopy);

		queryParams.append(url.contains("?") ? "&" : "?");

		try {
			appendQueryParams(queryParams, urlMapCopy, request);
			return new URI(url + queryParams.substring(0, queryParams.length() - 1));
		} catch (URISyntaxException | UnsupportedEncodingException e) {
			throw SystemException.create(SystemErrorEnum.INTERNAL, e, SERVICE_URI_PREPARE_ERROR + url);
		}
	}

	/**
	 * Insert the parameter in the url and remove from the urlMapCopy
	 *
	 * @param urlParameterMap The initial url parameters
	 * @param url             The url to complete
	 * @param urlMapCopy      The map that need to be filtered after insertion
	 * @return The completed url
	 */
	private static String insertParameterInUrl(Map<String, String> urlParameterMap, String url,
											   Map<String, String> urlMapCopy) {
		for (Map.Entry entry : urlParameterMap.entrySet()) {
			Object key = entry.getKey();
			Object value = entry.getValue();
			String urlKey = String.format("{%s}", key);
			if (url.contains(urlKey)) {
				url = url.replace(urlKey, String.valueOf(value));
				urlMapCopy.remove(key);
			}
		}
		return url;
	}

	/**
	 * Append query parameters to the StringBuilder
	 *
	 * @param queryParams      main query parameter instance
	 * @param urlParametersMap the url parameters to append
	 * @param request          The request
	 * @throws UnsupportedEncodingException while any unsupported character found at query parameter value
	 */
	private static void appendQueryParams(StringBuilder queryParams, Map<String, String> urlParametersMap,
										  CustomHttpRequest request) throws UnsupportedEncodingException {
		String requestCharset = StringUtils.defaultString(
				request.getConnectionMap().get(REQUEST_CHARSET), DEFAULT_REQUEST_CHARSET);
		for (Map.Entry<String, String> entry : urlParametersMap.entrySet()) {
			String key = String.valueOf(entry.getKey());
			String value = entry.getValue();
			appendQueryParam(queryParams, key, value, requestCharset);
		}
	}

	/**
	 * Append a query parameter to the StringBuilder
	 *
	 * @param queryParams    main query parameter instance
	 * @param key            to be used as query parameter key
	 * @param value          to be used as query parameter value
	 * @param requestCharset is used as query parameter encoding type
	 * @throws UnsupportedEncodingException while any unsupported character found at query parameter value
	 */
	protected static void appendQueryParam(StringBuilder queryParams, String key, Object value, String requestCharset)
			throws UnsupportedEncodingException {
		queryParams.append(URLEncoder.encode(key, requestCharset));
		queryParams.append("=");
		queryParams.append(value != null ? URLEncoder.encode(String.valueOf(value), requestCharset) : null);
		queryParams.append("&");
	}
}
