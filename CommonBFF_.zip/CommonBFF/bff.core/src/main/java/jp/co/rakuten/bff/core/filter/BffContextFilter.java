package jp.co.rakuten.bff.core.filter;

import jp.co.rakuten.bff.core.constant.GenericEndpointConstants;
import jp.co.rakuten.bff.core.logger.BffContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ReactiveHttpInputMessage;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import static jp.co.rakuten.bff.core.constant.BffConstants.BFF_CONTEXT;

/**
 * Filter used to set the BffContext in the {@code Context}
 * so that upstream operators can retrieve it.
 */
@Component
@Order(1)
public class BffContextFilter implements WebFilter {
	@Override
	public Mono<Void> filter(
			ServerWebExchange exchange,
			WebFilterChain chain) {
		return chain.filter(exchange)
				.subscriberContext(ctx -> addRequestHeadersToContext(exchange.getRequest(), ctx, exchange));
	}

	private Context addRequestHeadersToContext(ReactiveHttpInputMessage request, Context ctx, ServerWebExchange exchange) {
		HttpHeaders headers = request.getHeaders();

		BffContext gatewayContext = BffContext.builder()
				.clientId(headers.getFirst(GenericEndpointConstants.COMMON_HEADER_CLIENTID))
				.host(headers.getFirst(HttpHeaders.HOST))
				.requestUri(exchange.getRequest().getURI())
				.forwardedFor(headers.getFirst(GenericEndpointConstants.COMMON_HEADER_FORWARDEDFOR))
				.bffId(headers.getFirst(GenericEndpointConstants.COMMON_HEADER_BFFID))
				.cacheControl(headers.getFirst(GenericEndpointConstants.COMMON_HEADER_CACHE_CONTROL))
				.overridingConfigEnabled(headers.getFirst(GenericEndpointConstants.OVERRIDE_CONFIG_ENABLE_KEY))
				.overridingConfigPassword(headers.getFirst(GenericEndpointConstants.OVERRIDE_CONFIG_PWD))
				.build();

		return ctx.put(BFF_CONTEXT, gatewayContext);
	}
}
