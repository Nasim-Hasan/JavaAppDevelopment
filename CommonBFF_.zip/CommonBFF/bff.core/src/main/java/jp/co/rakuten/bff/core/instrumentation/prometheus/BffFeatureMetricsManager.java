package jp.co.rakuten.bff.core.instrumentation.prometheus;

import com.rakuten.rapid.metrics.core.RapidMetricsManager;
import com.rakuten.rapid.metrics.core.RapidMetricsRegistry;
import com.rakuten.rapid.metrics.core.record.RapidCounter;
import com.rakuten.rapid.metrics.core.record.RapidMultiMeter;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Metrics Manager for BFF Feature
 *
 * @author prithviraj.pawar
 */
public class BffFeatureMetricsManager {

	private static RapidMetricsRegistry apiFeatureRequestRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.feature.requests", true);
	private static RapidMetricsRegistry apiFeatureStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.api.feature.status", true);
	private static RapidMetricsRegistry featureRequestRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.feature.requests", true);
	private static RapidMetricsRegistry featureStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.feature.status", true);
	private static RapidMetricsRegistry featureInterfaceRequestRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.feature.interface.requests", true);
	private static RapidMetricsRegistry featureInterfaceStatusRegistry=
			RapidMetricsManager.getDefault().getRegistry("ichiba.bff.feature.interface.status", true);

	private static ConcurrentHashMap<String, RapidMultiMeter> apiFeatureRequestMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> apiFeatureStatusMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> featureStatusMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> featureInterfaceRequestMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidMultiMeter> featureInterfaceStatusMetrics =new ConcurrentHashMap<>();
	private static ConcurrentHashMap<String, RapidCounter> featureRequestMetrics =new ConcurrentHashMap<>();

	private BffFeatureMetricsManager(){}

	/**
	 * Initializes the Feature metrics
	 * @param apiTemplateMap the api list
	 **/
	public static void initialize(Map<String, ApiTemplate> apiTemplateMap) {
		apiTemplateMap.keySet().forEach((String api) ->{
			String apiKey=String.valueOf(api);
			if(ObjectUtils.isEmpty(apiFeatureRequestMetrics.get(apiKey))){
				apiFeatureRequestMetrics.put(apiKey,apiFeatureRequestRegistry.multiMeter(apiKey));
			}
		});
	}

	/**
	 * marks the feature wise metrics
	 * @param apiKey name of ECSG API
	 * @param featureList names of features inside the API
	 **/
	public static void markFeatureEntry(String apiKey, List<FeatureTemplate> featureList) {
		if(CollectionUtils.isNotEmpty(featureList)) {
			featureList.forEach((FeatureTemplate featureTemplate) -> {
				List<String> interfaceKeys = featureTemplate.getInterfaceNameList();
				String featureName=featureTemplate.getName();
				//Marking features of an API using a multimeter
				apiFeatureRequestMetrics.get(apiKey).mark(featureName);

				//Marking counter for request to features
				featureRequestMetrics.putIfAbsent(featureName,
						featureRequestRegistry.counter(featureName));
				featureRequestMetrics.get(featureName).increment();

				//Marking interfaces of a feature using a multimeter
				featureInterfaceRequestMetrics.putIfAbsent(featureName,
						featureInterfaceRequestRegistry.multiMeter(featureName));
				interfaceKeys.forEach(interfaceKey ->
						featureInterfaceRequestMetrics.get(featureName).mark(interfaceKey));
			});
		}
	}
	/**
	 * marks feature wise metrics for statusCode
	 * @param apiKey api name
	 * @param validatedResponse response per feature
	 **/
	public static void markFeatureExit(String apiKey, Map<String, Object> validatedResponse) {
		if(!MapUtils.isEmpty(validatedResponse)){
			validatedResponse.keySet().forEach((String featureName) ->{
				//For instance : room.feed.v1-roomfeedInfo
				String apiFeatureKey=apiKey+"-"+featureName;
				apiFeatureStatusMetrics.putIfAbsent(apiFeatureKey,apiFeatureStatusRegistry.multiMeter(apiFeatureKey));
				featureStatusMetrics.putIfAbsent(featureName,featureStatusRegistry.multiMeter(featureName));
				String errorCode = parseValidatedResponse(validatedResponse, featureName);
				if (!ObjectUtils.isEmpty(apiFeatureStatusMetrics.get(apiFeatureKey))) {
					apiFeatureStatusMetrics.get(apiFeatureKey).mark(errorCode);
				}
				if (!ObjectUtils.isEmpty(featureStatusMetrics.get(featureName))) {
					featureStatusMetrics.get(featureName).mark(errorCode);
				}
			});
		}
	}

	/**
	 * marks metrics for interfaces and features at the upstream call level
	 * @param name featureName or calldefinition name
	 * @param interfacesCalled interfaces inside the feature
	 * @param status Custom status for the calldefinition
	 **/
	public static void markCallDefinitionExit(String name, List<String> interfacesCalled, String status) {
		if(CollectionUtils.isNotEmpty(interfacesCalled)) {
			interfacesCalled.forEach((String interfaceKey) -> {
				String metricName = name + "-" + interfaceKey;
				featureInterfaceStatusMetrics
						.putIfAbsent(metricName, featureInterfaceStatusRegistry.multiMeter(metricName));
				featureInterfaceStatusMetrics.get(metricName).mark(status);
			});
		}
	}

	/**
	 * method to extract the status from feature response
	 * @param validatedResponse feature response
	 * @param featureName featurename
	 * @return the status for each feature
	 **/
	private static String parseValidatedResponse(Map<String, Object> validatedResponse,String featureName) {
		Map<String, Object> featureMap = (Map<String, Object>) validatedResponse.get(featureName);
		if (featureMap.containsKey("error")) {
			Map<String, Object> errorMap = (Map<String, Object>) featureMap.get("error");
			if (errorMap.containsKey("code")) {
				return String.valueOf(errorMap.get("code"));
			}
		}
		return "SUCCESS";
	}
}
