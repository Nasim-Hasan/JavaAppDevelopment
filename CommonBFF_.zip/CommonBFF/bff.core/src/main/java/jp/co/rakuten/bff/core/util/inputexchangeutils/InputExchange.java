package jp.co.rakuten.bff.core.util.inputexchangeutils;

public abstract class InputExchange {
    /** パラメータのキー文字列 */
    protected String key = null;

    /**
     * パラメータのキー文字列を登録します。
     * @param key (String)
     */
    public final void setKey(String key)
    {
        this.key=key;
    }

    /**
     * パラメータのキー文字列を返します。
     * @return パラメータのキー文字列
     */
    public final String getKey()
    {
        return this.key;
    }

}