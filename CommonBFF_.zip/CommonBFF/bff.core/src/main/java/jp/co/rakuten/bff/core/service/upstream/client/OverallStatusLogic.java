package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * This class contains the logic for the overall status.
 * The overall status is computed depending on the error in the responses.
 *
 * @author tony.rouillard
 */
@Component
public class OverallStatusLogic {

	private static final String SUCCESS = "SUCCESS";
	private static final String PARTIAL_FAILURE = "PARTIAL_FAILURE";
	private static final String FAILURE = "FAILURE";

	/**
	 * Compute the overall status depending on the error in the responses
	 *
	 * @param responses The responses
	 * @return the overall status
	 */
	public String computeOverallStatus(List<CustomHttpResponse> responses) {
		boolean atLeastOneFailure = false;
		boolean atLeastOneSuccess = false;
		for (CustomHttpResponse response : responses) {
			if (response.getError() == null) {
				atLeastOneSuccess = true;
			} else {
				atLeastOneFailure = true;
			}
		}
		String overallStatus;
		if (atLeastOneSuccess && !atLeastOneFailure) {
			overallStatus = SUCCESS;
		} else if (!atLeastOneSuccess && atLeastOneFailure) {
			overallStatus = FAILURE;
		} else {
			overallStatus = PARTIAL_FAILURE;
		}
		return overallStatus;
	}
}
