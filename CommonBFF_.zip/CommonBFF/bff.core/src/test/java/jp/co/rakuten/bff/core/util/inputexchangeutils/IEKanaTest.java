package jp.co.rakuten.bff.core.util.inputexchangeutils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class IEKanaTest {
    private IEKana ieKana;

    @BeforeEach
    void setUp() {
        ieKana = new IEKana("key-999") {};
    }

    @ParameterizedTest
    @ValueSource(strings = {"key-200"})
    @DisplayName("Test IEKana")
    public void testIEKana(String keyword)  {
        ieKana.setKey(keyword);
        assertEquals("key-200", ieKana.getKey());
    }
}
