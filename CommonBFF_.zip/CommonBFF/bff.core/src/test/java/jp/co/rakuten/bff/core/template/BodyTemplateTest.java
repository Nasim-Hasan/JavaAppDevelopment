package jp.co.rakuten.bff.core.template;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class BodyTemplateTest {
    private BodyTemplate bodyTemplate = new BodyTemplate();

    @Test
    void getTemplateTest(){
        Map<String, Object> responseMap =  bodyTemplate.getTemplate();
        assertEquals(new HashMap<>(), responseMap);
    }

    @Test
    void getParamsTest(){
        List<Map<String, Object>> responseList = bodyTemplate.getParams();
        assertEquals(Collections.emptyList(), responseList);
    }
}
