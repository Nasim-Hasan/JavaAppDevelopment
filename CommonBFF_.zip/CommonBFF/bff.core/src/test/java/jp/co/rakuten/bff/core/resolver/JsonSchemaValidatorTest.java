package jp.co.rakuten.bff.core.resolver;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.resolver.provider.CommonSchemaArgumentProvider;
import jp.co.rakuten.bff.core.template.CommonSchema;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
public class JsonSchemaValidatorTest {

	@Autowired
	private JsonSchemaValidator schemaValidator;

	@DisplayName("Generic request and response schema validation for success")
	@ParameterizedTest
	@ArgumentsSource(CommonSchemaArgumentProvider.class)
	void requestAndResponseSchemaSuccessValidator(Map<String, Object> testData) {
		List<CommonSchema> requestSchemas = (List<CommonSchema>) testData.get("requestSchema");
		List<CommonSchema> responseSchemas = (List<CommonSchema>) testData.get("responseSchema");
		List<CommonSchema> headerSchemas = (List<CommonSchema>) testData.get("headerSchemas");
		String errorMessage = (String) testData.get("errorMessage");
		if (StringUtils.isEmpty(errorMessage)) {
			assertDoesNotThrow(() -> schemaValidator.validate(requestSchemas, responseSchemas, headerSchemas));
		}
	}

	@DisplayName("Generic request and response schema validation for failure")
	@ParameterizedTest
	@ArgumentsSource(CommonSchemaArgumentProvider.class)
	void requestAndResponseSchemaFailureValidator(Map<String, Object> testData) {
		List<CommonSchema> requestSchemas = (List<CommonSchema>) testData.get("requestSchema");
		List<CommonSchema> responseSchemas = (List<CommonSchema>) testData.get("responseSchema");
		List<CommonSchema> headerSchemas = (List<CommonSchema>) testData.get("headerSchemas");
		String errorMessage = (String) testData.get("errorMessage");
		if (StringUtils.isNotEmpty(errorMessage)) {
			SystemException exception = assertThrows(SystemException.class,
													 () -> schemaValidator
															 .validate(requestSchemas, responseSchemas, headerSchemas));
			assertEquals(exception.getMessage(), errorMessage);
		}
	}
}
