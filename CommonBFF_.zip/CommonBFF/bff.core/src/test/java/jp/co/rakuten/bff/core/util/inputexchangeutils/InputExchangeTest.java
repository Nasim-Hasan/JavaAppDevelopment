package jp.co.rakuten.bff.core.util.inputexchangeutils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class InputExchangeTest {
    private InputExchange inputExchange;

    @BeforeEach
    void setUp() {
        inputExchange = new InputExchange() {};
        inputExchange.setKey("key-100");
    }

    @ParameterizedTest
    @ValueSource(strings = {"key-200"})
    @DisplayName("test InputExchange getter")
    public void testGetter(String keyword)  {
        assertEquals("key-100", inputExchange.getKey());
    }

    @ParameterizedTest
    @ValueSource(strings = {"key-200"})
    @DisplayName("test InputExchange setter")
    public void testSetter(String keyword)  {
        inputExchange.setKey(keyword);
        assertEquals("key-200", inputExchange.getKey());
    }
}
