package jp.co.rakuten.bff.core;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import java.util.concurrent.ThreadLocalRandom;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ApplicationTest {
	@DisplayName("Application should not run if endpoint.uri properties is not exists")
	@Test
	public void main() {
		int randPort = ThreadLocalRandom.current().nextInt(10000) + 40000;
		BeanCreationException exception = assertThrows(BeanCreationException.class,
													   () -> Application.main(new String[]{
															   "--server.port=" + randPort,
															   "--spring.config.location=classpath:/application_without_enpoint_uri.properties"
													   }));
		assertEquals("Could not resolve placeholder 'endpoint.uri' in value \"${endpoint.uri}\"",
					 exception.getCause().getCause().getMessage());
	}

	@DisplayName("Application should run successfully with endpoint.uri properties set ")
	@Test
	public void main_success() {
		int randPort = ThreadLocalRandom.current().nextInt(10000) + 40000;
		assertDoesNotThrow(
				() -> Application.main(new String[]{
						"--server.port=" + randPort,
						"--endpoint.uri=/mobile-bff/{service}/{operation}/{version}",
						"--spring.config.location=classpath:/application_without_enpoint_uri.properties"
				}));
	}
}
