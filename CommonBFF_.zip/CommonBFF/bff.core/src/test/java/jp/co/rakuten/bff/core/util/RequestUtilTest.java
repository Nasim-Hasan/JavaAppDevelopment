package jp.co.rakuten.bff.core.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;


class RequestUtilTest {

	private static final int MAX_NUMBER_OF_FEATURE = 62;

	private static final Logger LOGGER = LoggerFactory.getLogger(RequestUtilTest.class);
	private Random random = new Random(System.currentTimeMillis());

	@Test
	void testBuildAPIKey() {
		//given:
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService("service");
		requestModel.setOperation("operation");
		requestModel.setVersion("version");
		requestModel.setClientId("client");

		// when:
		String apiKey = RequestUtil.buildAPIKey(requestModel);

		// then:
		assertEquals("service.operation.version", apiKey);
	}

	@DisplayName("Check hashcode generation")
	@ParameterizedTest(name = "when [{0}] bits are enabled output should be={1} ")
	@CsvSource(value = {"1,2,3|7", "1,3|5", "1,2,3,4|15", "3|4"}, delimiter = '|')
	void testGetHashCode(String intValues, long expected) {
		List<Integer> integers = Stream.of(intValues.split(",")).map(Integer::valueOf).collect(Collectors.toList());
		long result = RequestUtil.getHashCode(integers);
		assertEquals(expected, result);
	}

	@DisplayName("Check hashcode generation")
	@Test
	void testGetHashCodeNull() {
		List<Integer> integersNUll = new ArrayList<>();
		long resultNull = RequestUtil.getHashCode(integersNUll);
		assertEquals(0, resultNull);
	}
	@DisplayName("Include/exclude checking.")
	@ParameterizedTest(name = "{index} when: field name =''{0}'' include=''{1}'' and exclude=''{2}'' should return {3}")
	@CsvSource(value = {
			"header                         |header,contents,others      |                       | true",
			"header                         |header.abc                  |                       | true",
			"header.xyz                     |header.xyz.xzy              |                       | true",
			"header                         |headersabc                  |                       | false",
			"header.xyz                     |header.pages                |                       | false",
			"header                         |heade                       |                       | false",
			"shop                           |common, headers             |                       | false",
			"header                         |                            | heade                 | true",
			"header                         |                            | headers               | true",
			"heade                          |                            | header.xyz            | true",
			"header                         |                            | common, header        | false",
			"header.xyz                     |                            | common, header        | false",
			"header.xyz                     |                            | common, header.abc    | true",
			"header.xyz                     |                            | common, header.xyz.abc| true",
			"any                            |                            | header.xyz.agc        | true",
			"shopbookmark.coupon.id         |                            | shopbookmark          | false",
			"shopbookmark.coupon            |                            | shopbookmark.coupon   | false",
			"shopbookmark.coupon            |                            | shopbookmark.coupon.id| true",
			"shopbookmark.coupon.id         |shopbookmark.coupon         |                       | true",
			"shopbookmark.coupon            |shopbookmark.coupon.id      |         					     | true",
			"shopbookmark                   |shopbookmark.coupon.id      |                       | true",
			"shopbookmark                   |                            |shopbookmark.coupon.id | true"
	}, delimiter = '|')
	void preProcessAndValidate(String fieldName, String include, String exclude, Boolean expected) {
		//given:
		CommonRequestModel requestModel = new CommonRequestModel();
		requestModel.setInclude(new HashSet<>(TestUtil.splitAndTrim(include)));
		requestModel.setExclude(new HashSet<>(TestUtil.splitAndTrim(exclude)));

		// when:
		final boolean result = RequestUtil.isIncluded(fieldName, requestModel);
		// then:
		Assertions.assertEquals(expected, result);
	}

	@DisplayName("Include/exclude checking.")
	@Test
	void preProcessAndValidate2() throws JsonProcessingException {
		//given:
		CommonRequestModel requestModel = new CommonRequestModel();
		Set<String> included=new HashSet<>();
		included.add("data.shopId");
		included.add("data.other");
		requestModel.setInclude(included);
		Map map1 = MapUtil.getObjectMapper().readValue("{\"data\":{\"shopId\":1, \"other\": 0}}", Map.class);
		requestModel.setParams(map1);
		List<String> fields=new ArrayList<>();
		fields.addAll(included);
		// when:
		final boolean result = RequestUtil.isIncluded(fields, requestModel);
		// then:
		//Assertions.assertEquals(expected, result);
	}

	private void addOrRemove(List<Integer> shuffled) {
		if (shuffled.size() > 30) {
			int removed = 4;
			while (removed >= 0) {
				int x = random.nextInt(MAX_NUMBER_OF_FEATURE);
				if (shuffled.contains(x)) {
					shuffled.remove((Object) x);
					removed--;
				}
			}
		} else {
			int removed = 4;
			while (removed >= 0) {
				int x = random.nextInt(MAX_NUMBER_OF_FEATURE);
				if (!shuffled.contains(x)) {
					shuffled.add(x);
					removed--;
				}
			}
		}
	}


}