package jp.co.rakuten.bff.core.cache;

import com.fasterxml.jackson.core.type.TypeReference;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.RequestSchema;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CustomKeyGeneratorTest {
	private static final String SHOPBOOKMARK_LIST = "shopbookmark_list";
	private Map<String, CommonRequestModel> validatedRequest;

	@BeforeEach
	void setUp() {
		TypeReference<HashMap<String, CommonRequestModel>> typeRef = new TypeReference<>() {
		};
		String fileContents = TestUtil
				.getFileContents("mockfiles/validated_schema/GUP_shopbookmark_list_all_feature.json");
		validatedRequest = TestUtil.getObjectFromTypeReference(fileContents, typeRef);
	}

	@AfterEach
	void tearDown() {
	}

	@DisplayName("When there are no params and only feature name is used for cacheKey generation")
	@Test
	void generateBffKey_OnlyFeatureName() {
		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(SHOPBOOKMARK_LIST);

		// When
		String bffKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, SHOPBOOKMARK_LIST);

		// Then
		assertNotNull(bffKey);
		assertEquals(SHOPBOOKMARK_LIST + "#" + SHOPBOOKMARK_LIST, bffKey);
	}

	@DisplayName("When feature name and params all available for cacheKey generation")
	@Test
	void generateBffKey_FeatureNameAndParams() {
		// Given
		CommonSchema commonSchema = new CommonSchema();
		commonSchema.setName("version");
		commonSchema.setCacheKey("true");
		CommonSchema commonSchema2 = new CommonSchema();
		commonSchema2.setName("easyId");
		commonSchema2.setCacheKey("true");
		RequestSchema requestSchema = new RequestSchema();
		requestSchema.setParameters(List.of(commonSchema, commonSchema2));

		FeatureTemplate featureTemplate = getFeatureTemplate(SHOPBOOKMARK_LIST);
		featureTemplate.setRequest(requestSchema);

		// When
		String bffKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, SHOPBOOKMARK_LIST);

		// Then
		assertNotNull(bffKey);
		assertEquals("shopbookmark_list#shopbookmark_list#easyId:1234_version:v1", bffKey);
	}

	@DisplayName("When there are no params and only cacheName is used for cacheKey generation")
	@ParameterizedTest
	@ValueSource(strings = {
			"validatedRequest", "featureTemplateInner",})
	void generateBffKey_EmptyArguments(
			String target) {
		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(SHOPBOOKMARK_LIST);
		featureTemplate.setRequest(new RequestSchema());
		if (target.equalsIgnoreCase("validatedRequest")) {
			validatedRequest = null;
		} else if (target.equalsIgnoreCase("featureTemplateInner")) {
			featureTemplate.setRequest(new RequestSchema());
		}

		// When
		String bffKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, SHOPBOOKMARK_LIST);

		// Then
		assertNotNull(bffKey);
		assertEquals(SHOPBOOKMARK_LIST + "#" + SHOPBOOKMARK_LIST, bffKey);
	}

	@DisplayName("When there are no params and no feature name and only apiKey is used for cacheKey generation")
	@Test
	void generateBffKey_EmptyFeatureTemplate() {
		// Given
		FeatureTemplate featureTemplate = null;

		// When
		String bffKey = CustomKeyGenerator.generateBffKey(featureTemplate, validatedRequest, SHOPBOOKMARK_LIST);

		// Then
		assertNotNull(bffKey);
		assertEquals(SHOPBOOKMARK_LIST, bffKey);
	}

	@DisplayName("Feature name and params are present")
	@Test
	void generate_FeatureNameAndParamsPresent() {
		// Given
		FeatureTemplate featureTemplate = null;

		// When
		String bffKey = CustomKeyGenerator.generate("testName", Map.of("value1", "value2"));

		// Then
		assertNotNull(bffKey);
		assertEquals("testName#value1:value2", bffKey);

		// When
		List<String> list = Arrays.asList("value3", "value2");
		Map<String, Object> params = new HashMap<>();
		params.put("key1", "value1");
		params.put("key2", list);
		bffKey = CustomKeyGenerator.generate("testName", params);

		// Then
		assertNotNull(bffKey);
		assertEquals("testName#key1:value1_key2:value2.value3", bffKey);
	}

	@DisplayName("getSortedList sorts successfully")
	@Test
	void generate_getSortedListSuccess() {
		List<Integer> bffList = Arrays.asList(1, 5, 2);
		bffList = CustomKeyGenerator.getSortedList(bffList);

		// Then
		assertNotNull(bffList);
		assertEquals(List.of(1, 2, 5), bffList);
	}

	@DisplayName("getSortedList sorts fails")
	@Test
	void generate_getSortedListFailure() {
		List<Integer> bffList = List.of(1, 5, 2);
		bffList = CustomKeyGenerator.getSortedList(bffList);

		// Then
		assertNotNull(bffList);
		assertEquals(List.of(1, 5, 2), bffList);
	}

	private FeatureTemplate getFeatureTemplate(String templateName) {
		FeatureTemplate featureTemplate = new FeatureTemplate();
		featureTemplate.setName(templateName);
		return featureTemplate;
	}
}
