package jp.co.rakuten.bff.core.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class InterfaceGroupKeysTest {

	private final String SAMPLE_INTERFACE_KEY_1 = "shopbookmark_list";
	private final String SAMPLE_GROUP_KEY_1 = "shopbookmark";
	private final String SAMPLE_INTERFACE_KEY_2 = "shopbiz_shopmaster";
	private final String SAMPLE_GROUP_KEY_2 = "shopbiz";

	@Test
	public void testConstructor() throws Exception {
		// Setup:

		// Given:

		// When: Instantiated by constructor
		InterfaceGroupKeys interfaceGroupKeys = new InterfaceGroupKeys(SAMPLE_INTERFACE_KEY_1, SAMPLE_GROUP_KEY_1);

		// Verify Response:

		// Verify Mock: Assert values through getters
		assertEquals(SAMPLE_INTERFACE_KEY_1, interfaceGroupKeys.getInterfaceKey());
		assertEquals(SAMPLE_GROUP_KEY_1, interfaceGroupKeys.getGroupKey());

	}

	@Test
	public void testSetters() throws Exception {
		// Setup: N/A

		// Given: dummy values

		// When: Instantiated by constructor but overriden by through setters
		InterfaceGroupKeys interfaceGroupKeys = new InterfaceGroupKeys(SAMPLE_INTERFACE_KEY_1, SAMPLE_GROUP_KEY_1);
		interfaceGroupKeys.setInterfaceKey(SAMPLE_INTERFACE_KEY_2);
		interfaceGroupKeys.setGroupKey(SAMPLE_GROUP_KEY_2);

		// Verify Response: verify dummy values by getters
		assertEquals(SAMPLE_INTERFACE_KEY_2, interfaceGroupKeys.getInterfaceKey());
		assertEquals(SAMPLE_GROUP_KEY_2, interfaceGroupKeys.getGroupKey());

		// Verify Mock: N/A

	}
}