package jp.co.rakuten.bff.core.service.upstream.client.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.cache.IchibaCacheManager;
import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.logger.HttpLogger.LoggerRequest;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.upstream.client.OverallStatusLogic;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.resources.ConnectionProvider;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static jp.co.rakuten.bff.core.service.upstream.client.impl.EcstaticClientBuilder.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
class EcstaticUpstreamClientTest {
	private static final String BASE_PATH = "mockfiles/feature/shopbookmarkList/";
	@Mock
	private InterfaceConfigLoader interfaceConfigLoader;
	@Mock
	private Environment env;
	@Autowired
	private OverallStatusLogic overallStatusLogic;
	@Mock
	private WebClient.Builder builderMock;
	@Mock
	private WebClient webClientMock;
	@Mock
	private WebClient.RequestHeadersUriSpec getRequestHeadersUriMock;
	@Mock
	private WebClient.RequestHeadersSpec requestHeadersMock;
	@Mock
	private HttpLogger serviceLogger;
	@Mock
	private IchibaCacheManager ichibaCacheManager;
	@InjectMocks
	private EcstaticClientBuilder ecWebClientBuilder;


	@Spy
	@InjectMocks
	ClientResponse clientResponse = ClientResponse.create(HttpStatus.OK).build();

	InterfaceConfig interfaceConfig = InterfaceConfig.builder()
			.interfaceKey("testKey")
			.connectionMap(Map.of("url", "https://dummyurl.com/.doozer.json", "method", "GET",
					TIMEOUT, "100", SO_TIMEOUT, "1000","retry","1"))
			.urlParameterMap(Map.of("x", "1"))
			.headerMap(Map.of("x-rakuten-id-serviceid", "ECSG_RAEEC_001"))
			.metadataMap(new HashMap<>())
			.circuit("sample_circuit")
			.build();

	InterfaceConfig interfaceConfig2 = InterfaceConfig.builder()
			.interfaceKey("testKey")
			.connectionMap(Map.of("url", "https://dummyurl2.com/.doozer.json", "method", "GET",
					TIMEOUT, "100", SO_TIMEOUT, "1000","retry","1"))
			.urlParameterMap(Map.of("x", "1"))
			.headerMap(Map.of("x-rakuten-id-serviceid", "ECSG_RAEEC_001"))
			.metadataMap(new HashMap<>())
			.circuit("sample_circuit")
			.build();


	InterfaceConfig interfaceConfig1 = InterfaceConfig.builder()
			.interfaceKey("testKey")
			.connectionMap(Map.of("url", "https://dummyurl1.com/.doozer.json", "method", "GET",
					TIMEOUT, "100", SO_TIMEOUT, "1000","retry","1"))
			.urlParameterMap(Map.of("x", "1"))
			.headerMap(Map.of("x-rakuten-id-serviceid", "ECSG_RAEEC_001"))
			.metadataMap(new HashMap<>())
			.circuit("sample_circuit")
			.build();

	InterfaceConfig interfaceConfig3 = InterfaceConfig.builder()
			.interfaceKey("testKey")
			.connectionMap(Map.of("url", "https://dummyurl3.com/.doozer.json", "method", "GET",
					TIMEOUT, "100", SO_TIMEOUT, "1000","retry","1"))
			.urlParameterMap(Map.of("x", "1"))
			.headerMap(Map.of("x-rakuten-id-serviceid", "ECSG_RAEEC_001"))
			.metadataMap(new HashMap<>())
			.circuit("sample_circuit")
			.build();

	private Map<String, Object> mockRequest = Map.of(REQUEST_ID, "shopbookmark", INTERFACE_KEY, "shopbookmark_list",
			URL_PARAMETERS, Map.of("easy_id", "1"), HEADERS, Map.of("x-rakuten-id-serviceid", "ECSG_RAEEC_001"));

	@BeforeEach
	void tearDown() {

	}

	@ParameterizedTest
	@CsvSource(
			value = {"json,{\"key\": \"value\"}", "xml,{key: value\"}"})
	void directHttpRequestJsonCheck(String format, String value) {
		interfaceConfig2.putToMetadataMap(RESPONSE_FORMAT, format);
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value.getBytes())));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);
		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig2).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		if (format.equals("xml")) {
			assertThrows(BackendException.class, () ->
					ecstaticUpstreamClient
							.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC)
							.block());
		} else {
			MultipleResponses response =
					ecstaticUpstreamClient
							.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC)
							.block();
			Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();
			assertEquals("value", bodyMap.get("key"));
		}
	}

	@Test
	@DisplayName("response not available in cache, backend called for response")
	void testDirectCallTo_DoRequest() {
		CustomHttpRequest request = CustomHttpRequest.builder()
				.requestId(UUID.randomUUID().toString())
				.interfaceKey(interfaceConfig2.getInterfaceKey())
				.connectionMap(interfaceConfig2.getPropertiesConnectionMap())
				.headerMap(interfaceConfig2.getPropertiesHeaderMap())
				.urlParameterMap(interfaceConfig2.getPropertiesUrlParameterMap())
				.circuit(interfaceConfig2.getCircuit())
				.build();
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig2.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));

		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
																				   overallStatusLogic, serviceLogger,
																				   ichibaCacheManager,
				ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig2).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		CustomHttpResponse response =
				ecstaticUpstreamClient.doRequest("callDefinitionName", request).block();
		Map<String, Object> bodyMap = response.getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("response not available in cache, backend called for response")
	void ecstaticTypeCallWithCacheTest_CacheEmpty() {
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("response not available in cache, backend called with invalid response")
	void ecstaticTypeCallWithCacheTest_CacheEmpty_InvalidBackendResponse() {
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionInvalidResponse.json").getBytes();
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		assertThrows(BackendException.class, () -> ecstaticUpstreamClient
				.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block());
		}

	@Test
	@DisplayName("response available in cache but stale and staleActiveFlag is false, so backend called for response")
	void ecstaticTypeCallWithCacheTest_FromStaleCache() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig1.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(true, new String(value), interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(false))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(anyString());

		MultipleResponses response =
				(MultipleResponses) ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("cache response is stale and staleActiveFlag is not found in cache, so backend called for " +
			"response")
	void ecstaticTypeCallWithCacheTest_FromStaleCacheAndStaleActiveFlagNotFound() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig1.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
																				   overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(true, new String(value), interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(anyString());

		MultipleResponses response =
				(MultipleResponses) ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("cache response is stale and Error while fetching staleActiveFlag from cache, so backend called for " +
			"response")
	void ecstaticTypeCallWithCacheTest_FromStaleCacheAndStaleActiveFlagError() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
																				   overallStatusLogic, serviceLogger,
																				   ichibaCacheManager,
				ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(true, new String(value), interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("test error")))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(anyString());

		MultipleResponses response =
				(MultipleResponses) ecstaticUpstreamClient
						.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC)
						.block();
		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("response available in cache and not stale, so backend not called for response")
	void ecstaticTypeCallWithCacheTest_FromCache() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		String value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json");
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.error(new RuntimeException("Test Error")));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(false, value, interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get(interfaceKey).getBodyMap();

		executeAssertions(bodyMap);
	}

	@ParameterizedTest
	@DisplayName("response available in cache but not valid")
	@CsvSource(value = {
			"true",
			"false"
	})
	void cachedResponseIsNotValid(boolean isBodyMapNull) throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		CustomHttpRequest request = CustomHttpRequest.builder()
				.requestId(UUID.randomUUID().toString())
				.interfaceKey(interfaceConfig1.getInterfaceKey())
				.connectionMap(interfaceConfig1.getPropertiesConnectionMap())
				.headerMap(interfaceConfig1.getPropertiesHeaderMap())
				.urlParameterMap(interfaceConfig1.getPropertiesUrlParameterMap())
				.circuit(interfaceConfig1.getCircuit())
				.build();
		String value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json");
		interfaceConfig1.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.error(new RuntimeException("Test Error")));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getErrorResponse(isBodyMapNull, value, interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		assertThrows(BackendException.class, () -> ecstaticUpstreamClient
				.doRequest("callDefinitionName", request).block());
	}

	@Test
	@DisplayName("error occurs while setting backend response to cache")
	void ecstaticTypeCallWithCacheTest_ErrorSettingCache() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		String value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json");
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.error(new RuntimeException("Test Error")));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(false, value, interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("test error"))).when(ichibaCacheManager)
				.setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get(interfaceKey).getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("cache response is stale and StaleActiveFlag is true and error occurs while calling backend")
	void ecstaticTypeCallWithCacheTest_ErrorCallingBackend() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		String value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json");
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.error(new RuntimeException("Test Error")));
		when(env.getProperty(any(), anyString())).thenReturn("10000");
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		ecstaticUpstreamClient.setEnvironment(env);
		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(getResponse(true, value, interfaceKey)))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("test error"))).when(ichibaCacheManager)
				.setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(anyString());

		MultipleResponses response =
				ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get(interfaceKey).getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("error occurs while getting response from cache and then backend is called")
	void ecstaticTypeCallWithCacheTest_GetCacheError() throws JsonProcessingException {
		String interfaceKey = "shopbookmark";
		byte[] value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json").getBytes();
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig1).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("Test Error")))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("test error"))).when(ichibaCacheManager)
				.setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block();
		Map<String, Object> bodyMap = response.getResponses().get(interfaceKey).getBodyMap();

		executeAssertions(bodyMap);
	}

	@Test
	@DisplayName("error occurs while getting response from cache and then backend also errors")
	void ecstaticTypeCallWithCacheTest_GetCacheErrorAndBackendError() {
		String interfaceKey = "shopbookmark";
		String value = TestUtil
				.getFileContents(BASE_PATH + "shopbookmarkListCallDefinitionResponse.json");
		interfaceConfig.putToMetadataMap(RESPONSE_FORMAT, "json");
		Mono<String> responseMono = Mono.just(value);
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.error(new RuntimeException("Test Error")));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("Test Error")))
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.error(new RuntimeException("test error"))).when(ichibaCacheManager)
				.setToCache(any(String.class), any(), any(String.class), any());

		assertThrows(BffException.class, () -> ecstaticUpstreamClient
				.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block());
	}

	private void executeAssertions(Map<String, Object> bodyMap) {
		assertEquals("SUCCESS", bodyMap.get("overallStatus"));
		assertNotNull(bodyMap.get("responses"));
		for (Object entryObject : ((Map)bodyMap.get("responses")).entrySet()) {
			Map.Entry entry = (Map.Entry) entryObject;
			System.out.println("");
			Map response = (Map) entry.getValue();
			assertNull(response.get("requestId"));
			assertEquals("shopbookmarkList", response.get("interfaceKey"));
			Map shopbookmarkList = (Map) response.get("body");
			assertNotNull(shopbookmarkList);
			assertNull(shopbookmarkList.get("error"));
			assertNotNull(shopbookmarkList.get("data"));
			assertNotNull(shopbookmarkList.get("meta"));
			assertNotNull(shopbookmarkList.get("status"));
		}
	}

	private CacheDataModel getResponse(boolean isStaleCache, String value, String interfaceKey) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		customHttpResponse.setInterfaceKey(interfaceKey);
		customHttpResponse.setBodyMap(mapper.readValue(value, HashMap.class));
		return new CacheDataModel(isStaleCache, Map.of(ECATATIC_RESPONSE_KEY, customHttpResponse));
	}

	private CacheDataModel getErrorResponse(boolean bodyMapNotNull, String value, String interfaceKey) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		customHttpResponse.setInterfaceKey(interfaceKey);
		if (bodyMapNotNull) {
			customHttpResponse.setBodyMap(mapper.readValue(value, HashMap.class));
		}
		return new CacheDataModel(true, Map.of("wrong", customHttpResponse));
	}

	@Test
	void direct_http_request_no_header_url_parameter() {
		Map<String, Object> mockRequest = Map.of(REQUEST_ID, "shopbookmark", INTERFACE_KEY, "shopbookmark_list");
		byte[] value = "{\"key\": \"value\"}".getBytes();
		when(clientResponse.bodyToMono(ByteArrayResource.class)).thenReturn(Mono.just(new ByteArrayResource(value)));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient
						.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC)
						.block();

		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();
		assertEquals("value", bodyMap.get("key"));
	}

	@Test
	void response_error_503() {
		when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		assertThrows(BffException.class, () -> ecstaticUpstreamClient
				.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC).block());
	}

	//@Test ignored
	void null_interface_config() {
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);
		ecstaticUpstreamClient.setEnvironment(env);

		doReturn(null).when(interfaceConfigLoader).getInterface(any());

		assertThrows(SystemException.class, () -> {
			ecstaticUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), any()).block();
		});
	}


	@Test
	void testWriteErrorLog() {
		EcstaticUpstreamClient client = new EcstaticUpstreamClient(null, null, null, null, null);
		CustomHttpRequest request = mock(CustomHttpRequest.class);
		Map<String, String> connMapValid = new HashMap();
		Map<String, String> connMapInvalid = new HashMap();
		client.setEnvironment(env);

		connMapValid.put(METHOD, "GET");
		connMapInvalid.put(METHOD, "FOO");
		doReturn(connMapValid, connMapInvalid).when(request).getConnectionMap();
		assertDoesNotThrow(() -> {
			HttpLogger serviceLogger = mock(HttpLogger.class);
			LoggerRequest loggerRequest = mock(LoggerRequest.class);
			Throwable error = BackendException.create(BackendErrorEnum.SERVICE_CONDITION, "testMsg");
			client.writeServiceLog(error, serviceLogger, loggerRequest);
			error = SystemException.create(SystemErrorEnum.INTERNAL, "testMsg");
			client.writeServiceLog(error, serviceLogger, loggerRequest);
		});
	}

	@DisplayName("Test Gson Custom adapter is converting numbers properly")
	@Test
	void gsonNumberConversionCheck() {
		String fileName = "sampleJson/benefit_status_ecstatic.json";
		String contents = TestUtil.getFileContents(fileName);
		interfaceConfig3.putToMetadataMap(RESPONSE_FORMAT, "json");
		when(clientResponse.bodyToMono(ByteArrayResource.class))
				.thenReturn(Mono.just(new ByteArrayResource(contents.getBytes())));
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
																				   overallStatusLogic, serviceLogger,
																				   ichibaCacheManager,
				ecWebClientBuilder);
		ecWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		ecstaticUpstreamClient.ecstaticWebClient = webClientMock;
		ecstaticUpstreamClient.setEnvironment(env);

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(interfaceConfig3).when(interfaceConfigLoader).getInterface(any());
		when(builderMock.clientConnector(any())).thenReturn(builderMock);
		when(builderMock.build()).thenReturn(webClientMock);
		when(webClientMock.get()).thenReturn(getRequestHeadersUriMock);
		when(getRequestHeadersUriMock.uri((URI) any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.headers(any())).thenReturn(requestHeadersMock);
		when(requestHeadersMock.exchange()).thenReturn(monoResponse);
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(String.class), any(String.class), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(String.class), any(), any(String.class), any());

		MultipleResponses response =
				ecstaticUpstreamClient
						.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_ECSTATIC)
						.block();
		Map<String, Object> bodyMap = response.getResponses().get("shopbookmark").getBodyMap();
		assertNotNull(bodyMap);
		Map data = (Map) ((List) bodyMap.get("data")).get(0);
		Map innerData = (Map) ((List) ((Map) ((List) bodyMap.get("data")).get(0)).get("items")).get(0);
		assertEquals(1, data.get("section_type"));
		assertEquals("totalRate", innerData.get("id"));
		assertEquals(1, innerData.get("type"));
		assertEquals(2147483649L, innerData.get("title_item"));
		assertEquals("あなたはポイント", innerData.get("title_non_item"));
		assertEquals(20.5, innerData.get("point_rate_prefix"));
		assertEquals(2147483649.544, innerData.get("point_rate_suffix"));
		assertTrue(data.get("section_type") instanceof Integer);
		assertTrue(innerData.get("id") instanceof String);
		assertTrue(innerData.get("type") instanceof Integer);
		assertTrue(innerData.get("title_item") instanceof Long);
		assertTrue(innerData.get("title_non_item") instanceof String);
		assertTrue(innerData.get("point_rate_prefix") instanceof Double);
		assertTrue(innerData.get("point_rate_suffix") instanceof Double);
	}

	@DisplayName("Test validateAndGetHttpResponse with different reference properly")
	@Test
	void validateAndGetHttpResponseTest() {
		//set
		EcstaticUpstreamClient ecstaticUpstreamClient = new EcstaticUpstreamClient(interfaceConfigLoader,
				overallStatusLogic, serviceLogger, ichibaCacheManager, ecWebClientBuilder);

		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		customHttpResponse.setInterfaceKey("InterfaceName");
		customHttpResponse.setBodyAsString("{\r\n \"status\": \"SUCCESS\"}");
		customHttpResponse.setBodyMap(Map.of("status","SUCCESS"));

		CacheDataModel response = new CacheDataModel();
		response.setCacheMap(Map.of(BffConstants.ECATATIC_RESPONSE_KEY,customHttpResponse));
		response.setStaleCache(false);

		CustomHttpResponse customHttpResponse_Returned = ecstaticUpstreamClient
				.validateAndGetHttpResponse(response);

		assertNotSame(customHttpResponse.getBodyMap(), customHttpResponse_Returned.getBodyMap());
		assertNotSame(customHttpResponse, customHttpResponse_Returned);
	}
}
