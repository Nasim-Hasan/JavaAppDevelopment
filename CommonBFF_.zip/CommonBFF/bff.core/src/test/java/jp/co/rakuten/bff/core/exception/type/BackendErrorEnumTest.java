package jp.co.rakuten.bff.core.exception.type;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BackendErrorEnumTest {

	@ParameterizedTest()
	@CsvSource(value = {
			"400:400:BAD_REQUEST",
			"404:404:NOT_FOUND",
			"424:424:FAILED_DEPENDENCY",
			"503:503:SERVICE_UNAVAILABLE",
			"41864156:503:SERVICE_UNAVAILABLE",
	}, delimiter = ':')
	void testResolveLogic(int code, int resultCode, String resulName) {
		BackendErrorEnum result = BackendErrorEnum.resolve(code);

		assertEquals(resultCode, result.getErrorCode().value());
		assertEquals(resulName, result.getErrorCode().name());
	}
}
