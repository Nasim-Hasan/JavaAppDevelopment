package jp.co.rakuten.bff.core.config;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.env.CompositePropertySource;
import org.springframework.core.env.MapPropertySource;
import org.springframework.mock.env.MockEnvironment;

import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.CONFIG_LOADING_TIMEOUT_PROP;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
class InterfaceConfigLoaderTest {
	private final String SAMPLE_INTERFACE_KEY_1 = "shopbookmark_list";
	private final String SAMPLE_GROUP_KEY_1 = "shopbookmark";
	private final String SAMPLE_INTERFACE_KEY_2 = "shopbiz_shopmaster";
	private final String SAMPLE_GROUP_KEY_2 = "shopbiz";
	private final String SAMPLE_MAP_SOURCE = "mapProperties";
	private final String SAMPLE_COMPOSITE_SOURCE = "compositeProperties";
	private final String SAMPLE_PROPERTY_KEY_1 = "interface.mapping.shopbookmark_list";
	private final String SAMPLE_PROPERTY_VALUE_1 = SAMPLE_GROUP_KEY_1;
	private final String SAMPLE_PROPERTY_KEY_2 = "interface.mapping.shopbiz_shopmaster";
	private final String SAMPLE_PROPERTY_VALUE_2 = SAMPLE_GROUP_KEY_2;
	private final String CONFIG_TIMEOUT = "1000";
	// Declaring in this way as Test class can only have 1 constructor and it requires a default
	@Autowired
	private InterfaceConfigLoader interfaceConfigLoader;
	@Mock
	private ApplicationEventPublisher applicationEventPublisher;

	/**
	 * Equivalent of @RunWith(MockitoJUnitRunner.class)
	 * Doing this instead as we already call SpringRunner to RunWith
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	private InterfaceMapping writeDummyInterfaceMapping() {
		Map interfaces = Map.of(SAMPLE_INTERFACE_KEY_1, SAMPLE_GROUP_KEY_1, SAMPLE_INTERFACE_KEY_2, SAMPLE_GROUP_KEY_2);
		InterfaceConfigurationProperties iCp = new InterfaceConfigurationProperties();
		iCp.setMapping(interfaces);
		return new InterfaceMapping(iCp);
	}

	private MockEnvironment writeDummyEnvironment() {
		Map configMap = Map
				.of(SAMPLE_PROPERTY_KEY_1, SAMPLE_PROPERTY_VALUE_1, SAMPLE_PROPERTY_KEY_2, SAMPLE_PROPERTY_VALUE_2);
		MapPropertySource mapPropertySource = new MapPropertySource(SAMPLE_MAP_SOURCE, configMap);
		CompositePropertySource compositePropertySource = new CompositePropertySource(SAMPLE_COMPOSITE_SOURCE);
		compositePropertySource.addPropertySource(mapPropertySource);
		CompositePropertySource innerComposite = new CompositePropertySource(SAMPLE_COMPOSITE_SOURCE);
		compositePropertySource.addPropertySource(innerComposite);
		MockEnvironment mockEnvironment = new MockEnvironment();
		mockEnvironment.getPropertySources().addFirst(mapPropertySource);
		mockEnvironment.getPropertySources().addLast(compositePropertySource);
		mockEnvironment.setProperty(CONFIG_LOADING_TIMEOUT_PROP, CONFIG_TIMEOUT);
		return mockEnvironment;
	}

	@Test
	public void testOnRefreshPropertySources() {
		// Setup: pre-requisite resources and mocks
		InterfaceMapping interfaceMapping = writeDummyInterfaceMapping();
		MockEnvironment mockEnvironment = writeDummyEnvironment();
		RefreshScopeRefreshedEvent refreshScopeRefreshedEvent = new RefreshScopeRefreshedEvent();

		// Given: instantiated by constructor and set a spy
		InterfaceConfigLoader interfaceConfigLoader = new InterfaceConfigLoader(mockEnvironment,
																				applicationEventPublisher,
																				interfaceMapping);
		InterfaceConfigLoader spyInterfaceConfigLoader = Mockito.spy(interfaceConfigLoader);

		// When: refresh triggered
		interfaceConfigLoader.onRefresh(refreshScopeRefreshedEvent);

		// Verify Response: N/A because this is method is void

		// Verify Mock: verifying mock calls through spy
		Mockito.atMostOnce();
	}

	@Test
	public void testGetInterfaces() {
		// Setup: setup done by SpringRunner and SpringBootTest

		// Given: SAMPLE_INTERFACE_KEY_1 and Autowired interfaceConfigLoader

		// When: getInterface triggered
		InterfaceConfig testInterface = interfaceConfigLoader.getInterface(SAMPLE_INTERFACE_KEY_1);

		// Verify Response: Assert from getter
		assertEquals(SAMPLE_INTERFACE_KEY_1, testInterface.getInterfaceKey());

		// Verify Mock: N/A

	}
}