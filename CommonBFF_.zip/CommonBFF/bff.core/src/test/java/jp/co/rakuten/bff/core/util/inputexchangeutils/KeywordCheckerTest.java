package jp.co.rakuten.bff.core.util.inputexchangeutils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class KeywordCheckerTest {
    @ParameterizedTest
    @ValueSource(strings = {"こんにちは", "山"})
    @DisplayName("test with OK keywords")
    public void testOKWords(String keyword)  {
        boolean isOK = KeywordChecker.isOKWord(keyword);
        assertTrue(isOK);
    }

    @ParameterizedTest
    @ValueSource(strings = {"a", ""})
    @DisplayName("test with NG keywords")
    public void testNGWords(String keyword)  {
        boolean isOK = KeywordChecker.isOKWord(keyword);
        assertFalse(isOK);
    }
}
