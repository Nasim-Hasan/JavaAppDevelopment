package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import static org.junit.jupiter.api.Assertions.*;

public class PropertyReaderTest {
	@InjectMocks
	PropertyReader propertyReader;
	@Mock
	Environment env;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		TestUtil.mockEnv(env, "spring.application.name", "ichiba.gateway");

		TestUtil.mockEnv(env, "benefits.calculation.aid.default", "2");
		TestUtil.mockEnv(env, "x.request.id.somevalue", "1");
		TestUtil.mockEnv(env, "gsp.lv1.search.url.default",
						 "http://jp2s-gsp-adm-401.stg.hnd2.bdd.local/search/v2/jp_mall_lv1_search/item.json");
		TestUtil.mockEnv(env, "hybrid.search.clients.refresh.time.default", "6000000");
		TestUtil.mockEnv(env, "spu7.scv.acc.default", "101.36");
		TestUtil.mockEnv(env, "spux.log.enabled.default", "true");
		TestUtil.mockEnv(env, "spux.log.disabled.default", "false");
		TestUtil.mockEnv(env, "spux.cache_type.default", "LocalAndMemcache");

		TestUtil.mockEnv(env, "benefits.calculation.test", "something");
		TestUtil.mockEnv(env, "hybrid.search.clients.refresh.test", "something");
		TestUtil.mockEnv(env, "spu7.scv.test", "something");
		TestUtil.mockEnv(env, "spux.log.test", "something");
	}

	@AfterEach
	void tearDown() {
		propertyReader = null;
		env = null;
	}

	@DisplayName("Default value success check in properties")
	@ParameterizedTest
	@CsvSource(value = {
			"benefits.calculation.aid           | integer",
			"gsp.lv1.search.url                 | string",
			"hybrid.search.clients.refresh.time | long",
			"spu7.scv.acc                       | double",
			"spux.log.enabled                   | boolean",
			"spux.log.disabled                  | boolean",
			"spux.cache_type                    | string",
	}, delimiter = '|')
	void propertyDefaultSuccessCheck(String propKey, String type) {
		Object propertyValues = propertyReader.getPropertyValue(propKey, StringUtils.EMPTY, StringUtils.EMPTY, type);

		assertEquals(StringUtils.capitalize(type), propertyValues.getClass().getSimpleName());
	}

	@DisplayName("Property missing default value success check in properties")
	@Test
	void propertyMissingDefaultCheck() {
		Object propertyValues = propertyReader.getPropertyValue("benefits.calculation.aid", StringUtils.EMPTY, StringUtils.EMPTY, "integer");

		assertNotNull(propertyValues);
		assertEquals("Integer", propertyValues.getClass().getSimpleName());
	}

	@DisplayName("Default value missing failure check in properties")
	@ParameterizedTest
	@CsvSource(value = {
			"something.test| benefits.calc.aid                      | integer   | Property key/property's value is missing from the properties for benefits.calc.aid.something.test",
			"something.test| gsp.lv1.search.uri                     | string    | Property key/property's value is missing from the properties for gsp.lv1.search.uri.something.test",
			"something.test| hybrid.search.client.refresh.time      | long      | Property key/property's value is missing from the properties for hybrid.search.client.refresh.time.something.test",
			"something.test| spu7.scv.ac                            | double    | Property key/property's value is missing from the properties for spu7.scv.ac.something.test",
			"something.test| spux.log.enable                        | boolean   | Property key/property's value is missing from the properties for spux.log.enable.something.test",
			"something.test| spux.cache_typ                         | string    | Property key/property's value is missing from the properties for spux.cache_typ.something.test",
	}, delimiter = '|')
	void propertyMissingFailureCheck(String dynamicKey, String propKeyPrefix, String type, String errorMessage) {
		SystemException exception = assertThrows(SystemException.class,
												 () -> propertyReader.getPropertyValue(propKeyPrefix,StringUtils.EMPTY, dynamicKey, type));
		assertEquals(errorMessage,exception.getMessage());
	}

	@DisplayName("Default value failure check in properties")
	@ParameterizedTest
	@CsvSource(value = {
			"benefits.calculation           | integer   | Property key/property's value is missing from the properties for benefits.calculation",
			"gsp.lv1.search                 | string    | Property key/property's value is missing from the properties for gsp.lv1.search",
			"hybrid.search.clients.refresh  | long      | Property key/property's value is missing from the properties for hybrid.search.clients.refresh",
			"spu7.scv                       | double    | Property key/property's value is missing from the properties for spu7.scv",
			"spux.log                       | boolean   | Property key/property's value is missing from the properties for spux.log",
			"spux.cacheType                 | string    | Property key/property's value is missing from the properties for spux.cacheType",
	}, delimiter = '|')
	void propertyDefaultFailureCheck(String propKey, String type, String errorMessage) {

		SystemException exception = assertThrows(SystemException.class,
												 () -> propertyReader
														 .getPropertyValue(propKey, StringUtils.EMPTY,StringUtils.EMPTY, type));
		assertEquals(exception.getMessage(), errorMessage);
	}

	@DisplayName("Default value failure check in properties")
	@ParameterizedTest
	@CsvSource(value = {
			"test| benefits.calculation         | integer   | Value cannot be converted to integer!",
			"test| hybrid.search.clients.refresh| long      | Value cannot be converted to long!",
			"test| spu7.scv                     | double    | Value cannot be converted to double!",
			"test| spux.log                     | boolean   | Value cannot be converted to boolean!"
	}, delimiter = '|')
	void propertyDataTypeFailureCheck(String value, String propKey, String type, String errorMessage) {
		SystemException exception = assertThrows(SystemException.class,
												 () -> propertyReader.getPropertyValue(propKey,StringUtils.EMPTY, value, type));
		assertEquals(exception.getMessage(), errorMessage);
	}

	@DisplayName("Default value failure check in properties")
	@ParameterizedTest
	@CsvSource(value = {
			"benefit.calculation    | integer   | Properties key is missing from the properties!",
			"hybrid.search          | long      | Properties key is missing from the properties!",
			"spu7.scv               | double    | Properties key is missing from the properties!"
	}, delimiter = '|')
	void propertyKeyMissing(String propKey, String type, String errorMessage) {
		SystemException exception = assertThrows(SystemException.class,
												 () -> propertyReader.getPropertyValue(propKey, type));
		assertEquals(exception.getMessage(), errorMessage);
	}
}
