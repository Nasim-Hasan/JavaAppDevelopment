package jp.co.rakuten.bff.core.service.upstream.client;


import com.fasterxml.jackson.core.JsonProcessingException;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BodyMapConversionLogicTests {
	private static final Logger LOGGER = LoggerFactory.getLogger(BodyMapConversionLogicTests.class);
	private static final BodyMapConversionLogic bodyMapConversionLogic = new BodyMapConversionLogic();

	/**
	 * This is a utility method which takes Map as an input and convert the same equivalent jsonString
	 * it would return null , in case any exception occurs during the conversion process.
	 *
	 * @param jsonMap the Map object to be converted
	 * @return the equivalent json String.
	 */
	public static String getJsonStringFromMap(Map jsonMap) {
		try {
			return MapUtil.getObjectMapper().writeValueAsString(jsonMap);
		} catch (JsonProcessingException ex) {
			LOGGER.error("Unable to resolve to Json String cause :: {}", ex.getMessage(), ex);
			return null;
		}
	}

	@Test
	public void mapKey() {
		//kebab case key conversion
		assert "donkeyKong".equals(bodyMapConversionLogic.mapKey("donkey-kong"));
		//snake case
		assert "donkeyKong".equals(bodyMapConversionLogic.mapKey("donkey_kong"));
		//Pascal case
		assert "donkeyKong".equals(bodyMapConversionLogic.mapKey("DonkeyKong"));
		//kebab-Snake
		assert "donkeyKongGorilla".equals(bodyMapConversionLogic.mapKey("donkey-kong_Gorilla"));
		//snake_kebab
		assert "donkeyKongGorilla".equals(bodyMapConversionLogic.mapKey("donkey_kong-Gorilla"));
		//Pascalkebab_Snake
		assert "monkeyKongGorilla".equals(bodyMapConversionLogic.mapKey("Monkey-kong_Gorilla"));
		//Camel case
		assert "donkeyKong".equals(bodyMapConversionLogic.mapKey("donkeyKong"));
		//Unusal start case
		assert "monkeybling".equals(bodyMapConversionLogic.mapKey("_monkeyBling"));
		//Random Cases for different scenarios
		assert "b".equals(bodyMapConversionLogic.mapKey("_B_"));
		assert "bAad".equals(bodyMapConversionLogic.mapKey("_B_aad"));
		assert "a".equals(bodyMapConversionLogic.mapKey("A"));
		assert "bAb".equals(bodyMapConversionLogic.mapKey("BAb"));
		//as there is single word post processing of _ then its is converted to all Small as per the existing utility.
		//Empty value
		assert bodyMapConversionLogic.mapKey("").equals("");
		//null value
		assert bodyMapConversionLogic.mapKey(null) == null;
	}

	@Test
	public void jsonToMapWithCamelConversion() throws IOException, URISyntaxException, NullPointerException {
		Map<String, Object> responseMap;
		String jsonString = readFile("/util/Response.json");
		responseMap = bodyMapConversionLogic.jsonToMap(jsonString, true);
		assert responseMap != null;
		Map apiHeaderMap = (Map) responseMap.get("apiHeader");
		assert apiHeaderMap != null;
		assert apiHeaderMap.containsKey("status");
		assert apiHeaderMap.containsKey("message");
		assert apiHeaderMap.containsKey("variation");
		Map responseHeaderMap = (Map) responseMap.get("responseHeader");
		assert responseHeaderMap != null;
		assert responseHeaderMap.containsKey("status");
		assert responseHeaderMap.containsKey("qTime");
		Map response = (Map) responseMap.get("response");
		assert response != null;
		assert response.containsKey("numFound");
		assert response.containsKey("start");
		assert response.containsKey("maxScore");
		assert response.containsKey("docs");
		List docsList = (List) response.get("docs");
		assert docsList != null;
		assert docsList.size() == 1;
		Map docsMap = (Map) docsList.get(0);
		assert docsMap != null;
		assert docsMap.containsKey("itemImageUrl1");
		assert docsMap.containsKey("updateDate");
		assert docsMap.containsKey("isFreeShipping");
		assert docsMap.containsKey("searchFilterLevel");
		assert docsMap.containsKey("shopId");
		assert docsMap.containsKey("shortDescription");
		assert docsMap.containsKey("rakutenProductCategoryId3");
		assert docsMap.containsKey("rakutenProductCategoryId2");
		assert docsMap.containsKey("rakutenProductCategoryId1");
		assert docsMap.containsKey("updateTime");
		assert docsMap.containsKey("sortScore");
		assert docsMap.containsKey("liveEndTime");
		assert docsMap.containsKey("itemName");
		assert docsMap.containsKey("isInventoryExist");
		assert docsMap.containsKey("mallId");
		assert docsMap.containsKey("isTest");
		assert docsMap.containsKey("liveStartTime");
		assert docsMap.containsKey("shopStatus");
		assert docsMap.containsKey("baseSku");
		assert docsMap.containsKey("description");
		assert docsMap.containsKey("merchantId");
		assert docsMap.containsKey("isRepresentative");
		assert docsMap.containsKey("isBase");
		assert docsMap.containsKey("shopUrl");
		assert docsMap.containsKey("itemId");
		assert docsMap.containsKey("searchId");
		assert docsMap.containsKey("itemPointRate");
		assert docsMap.containsKey("calcActivePriceMin");
		assert docsMap.containsKey("calcActivePriceMax");
		assert docsMap.containsKey("timeFrames");
		List timeFrameList = (List) docsMap.get("timeFrames");
		assert timeFrameList != null;
		assert timeFrameList.size() == 1;
		Map timeFrameMap = (Map) timeFrameList.get(0);
		assert timeFrameMap != null;
		assert timeFrameMap.containsKey("frameIsPrivate");
		assert timeFrameMap.containsKey("frameStartTime");
		assert timeFrameMap.containsKey("frameEndTime");
	}

	@Test
	public void jsonToMapWithoutCamelConversion() throws IOException, URISyntaxException, NullPointerException {
		String jsonString = readFile("/util/Response.json");
		Map<String, Object> responseMap = bodyMapConversionLogic.jsonToMap(jsonString, false);
		assert responseMap != null;
		Map response = (Map) responseMap.get("response");
		assert response != null;
		List docsList = (List) response.get("docs");
		assert docsList != null;
		assert docsList.size() == 1;
		Map docsMap = (Map) docsList.get(0);
		assert docsMap != null;
		assert docsMap.containsKey("item_image_url1");
	}

	@Test
	public void testNullExpectedExceptionFail() {

		//Given:
		Map<String, String> jsonMap = new HashMap<>();
		jsonMap.put(null, "value1");
		//Verify Result:
		assertEquals(null, getJsonStringFromMap(jsonMap));

	}

	@Test
	public void xmlToMapWithCamelConversion() throws IOException, URISyntaxException {
		Map<String, Object> responseMap;
		String xmlString = readFile("/util/XMLResponse.xml");
		responseMap = bodyMapConversionLogic.xmlToMap(xmlString, true);
		assert responseMap != null;
		assert responseMap.containsKey("code");
		Map itemMap = (Map) responseMap.get("item");
		assert itemMap != null;
		assert itemMap.containsKey("isAskButtonOn");
		assert itemMap.containsKey("depot");
		assert itemMap.containsKey("caption");
		assert itemMap.containsKey("deliverySetId");
		assert itemMap.containsKey("noshiEnable");
		assert itemMap.containsKey("type");
		assert itemMap.containsKey("availableForMobile");
		assert itemMap.containsKey("price");
		assert itemMap.containsKey("timeSale");
		assert itemMap.containsKey("layoutStyle");
		assert itemMap.containsKey("shopId");
		assert itemMap.containsKey("displayMakerContents");
		assert itemMap.containsKey("isPasswordSet");
		assert itemMap.containsKey("includedCashOnDeliveryPostage");
		assert itemMap.containsKey("includedTax");
		assert itemMap.containsKey("sizeLink");
		assert itemMap.containsKey("dualPrice");
		assert itemMap.containsKey("isPanfButtonOn");
		assert itemMap.containsKey("limited");
		assert itemMap.containsKey("mobileCatchCopy");
		assert itemMap.containsKey("isAskButtonOn");
		assert itemMap.containsKey("maxUnits");
		assert itemMap.containsKey("detailSellType");
		assert itemMap.containsKey("isStockNotifyButtonOn");
		assert itemMap.containsKey("itemId");
		assert itemMap.containsKey("postage");
		assert itemMap.containsKey("catchCopy");
		assert itemMap.containsKey("itemInventory");
		assert itemMap.containsKey("includedPostage");
		assert itemMap.containsKey("manageNumber");
		assert itemMap.containsKey("overseasDelvId");
		assert itemMap.containsKey("isSaleButtonOn");
		assert itemMap.containsKey("asurakuDelvId");
		String jsonString = getJsonStringFromMap(responseMap);
		String xmlJsonString = readFile("/util/XmlJsonString");
		assert jsonString != null;
		assert jsonString.equals(xmlJsonString);
	}

	@Test
	public void xmlToMapWithoutCamelConversion() throws IOException, URISyntaxException {
		Map<String, Object> responseMap;
		String xmlString = readFile("/util/XMLResponse.xml");
		responseMap = bodyMapConversionLogic.xmlToMap(xmlString, false);
		assert responseMap != null;
		assert responseMap.containsKey("code");
		Map itemMap = (Map) responseMap.get("item");
		assert itemMap != null;
		assert itemMap.containsKey("is-ask-button-on");
	}

	//Utiltiy function to read json files
	String readFile(String fileName) throws URISyntaxException, IOException, NullPointerException {
		File inputFile = new File(this.getClass().getResource(fileName).toURI());
		return FileUtils.readFileToString(inputFile);
	}
}