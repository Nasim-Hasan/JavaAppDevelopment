package jp.co.rakuten.bff.core.logger;

import net.logstash.logback.argument.StructuredArgument;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import java.net.URI;
import java.time.Clock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.logstash.logback.argument.StructuredArguments.kv;
import static org.mockito.Mockito.*;

public class HttpLoggerTest {

	@Mock
	private Logger logger;
	@Mock
	private Clock clock;

	private HttpLogger.LoggerRequest loggerRequest;
	private HttpLogger httpLogger;
	private Map<String, Object> extras;
	private String query = "param1=val1&param2=val2";
	private String path = "http://example.com";
	private String requestBody = "some body";
	private String responseBody = "another body";

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);

		loggerRequest = new HttpLogger.LoggerRequest(clock);
		loggerRequest.setMethod(HttpMethod.GET);
		query = "param1=val1&param2=val2";
		path = "http://example.com";
		loggerRequest.setUri(URI.create(path + "?" + query));
		loggerRequest.setStatus(HttpStatus.OK);
		loggerRequest.setRequestBody(requestBody);
		loggerRequest.setResponseBody(responseBody);
		loggerRequest.setExtras(new HashMap<>());
		extras = loggerRequest.getExtras();
		extras.put("clientId", "iphone_long");

		httpLogger = new HttpLogger(logger, new HashMap<>(), HttpLogger.DEFAULT_THROWABLE_MESSAGE_CONVERTER,
									clock);

		when(logger.isInfoEnabled()).thenReturn(true);
		when(clock.millis()).thenReturn(1l, 2l);
	}

	@Test
	public void testLog() {
		loggerRequest.startTimeCounting();
		httpLogger.log(loggerRequest);
		List<StructuredArgument> arguments = createStructuredArguments(null);
		verify(logger).info("OK", arguments.toArray());
	}


	@Test
	public void testLogWithException() {
		IllegalArgumentException exception = new IllegalArgumentException("the argument was incorrect.");
		loggerRequest.setThrowable(exception);
		loggerRequest.startTimeCounting();
		httpLogger.log(loggerRequest);

		verify(logger).info(String.format("exception: %s message: %s", exception.getClass().getName(),
										  exception.getMessage()), createStructuredArguments(exception).toArray());
	}

	@Test
	public void testLogWithInfoDisabled() {
		when(logger.isInfoEnabled()).thenReturn(false);
		loggerRequest.startTimeCounting();
		httpLogger.log(loggerRequest);
		verify(logger, never()).info(anyString(), (Object[]) any());
	}

	@Test
	public void testLogWithDebugEnabled() {
		when(logger.isDebugEnabled()).thenReturn(true);

		loggerRequest.startTimeCounting();
		httpLogger.log(loggerRequest);

		List<StructuredArgument> arguments = createStructuredArguments(null);
		arguments.add(6, (kv("responseBody", loggerRequest.getResponseBody())));
		verify(logger).info("OK", arguments.toArray());
	}


	private List<StructuredArgument> createStructuredArguments(Throwable exception) {
		List<StructuredArgument> arguments = new ArrayList<>();
		arguments.add(kv("responseTime", 1l));
		arguments.add(kv("method", loggerRequest.getMethod()));
		arguments.add(kv("path", path));
		arguments.add(kv("query", query));
		arguments.add(kv("requestBody", requestBody));
		arguments.add(kv("status", loggerRequest.getStatus().value()));
		arguments.add(kv("clientId", extras.get("clientId")));
		arguments.add(kv("exception", exception != null ? exception.getClass().getName() : null));
		return arguments;
	}

}
