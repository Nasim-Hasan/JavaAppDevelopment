package jp.co.rakuten.bff.core.controller;

import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import java.io.IOException;


import static jp.co.rakuten.bff.core.testUtil.TestUtil.mockEnv;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class ConfigControllerTest {

	private static final String TEST_INTERFACE = "test_interface";
	@InjectMocks
	ConfigController configController;

	@Mock
	Environment env;

	@Mock
	InterfaceConfigLoader interfaceConfigLoader;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		mockEnv(env, "a_key", "the_value");
		mockEnv(env, "config.loadedFrom", "local");
	}

	@AfterEach
	void tearDown() {
		configController = null;
		env = null;
	}

	@Test
	void testGetConfig() {
		// Setup: NA
		// Given: NA

		// When:
		String loadedFrom = configController.getCheckConfig().block();

		// Verify response:
		assertNotNull(loadedFrom);
		assertEquals("local", loadedFrom);

		// Verify mocks:
		verify(env, times(1)).getProperty(any());
	}

	@Test
	void testGetConfigProperty() throws IOException {
		// Setup: NA
		// Given: NA

		// When:
		String loadedFrom = configController.getConfigProperty("a_key").block();

		// Verify response:
		assertNotNull(loadedFrom);
		assertEquals("the_value", loadedFrom);

		// Verify mocks:
		verify(env, times(1)).getProperty(any());
	}

	@Test
	void testGetLastRefreshTimestamp() {
		// Setup:
		long initialTimeStamp = configController.getLastRefreshTimestamp().block();
		// Given: NA

		// When:
		configController.onRefresh(null);

		// Verify response:
		long lastTimeStamp = configController.getLastRefreshTimestamp().block();
		assertTrue(initialTimeStamp < lastTimeStamp);

		// Verify mocks: NA
	}
}