package jp.co.rakuten.bff.core.testUtil;

public enum ResponseFormatEnum {
	JSON,
	XML,
	TEXT
}
