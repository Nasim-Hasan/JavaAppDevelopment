package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus.FAILURE;
import static jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus.SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class CallDefinitionResponseTest {

    private CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(FAILURE);

    @Test
    void setStatusTest(){
        assertEquals(FAILURE, callDefinitionResponse.getStatus());
        CallDefinitionResponseStatus status = SUCCESS;
        callDefinitionResponse.setStatus(status);
        assertEquals(status, callDefinitionResponse.getStatus());
    }

    @Test
    void getInterfaceToRequestIdMapTest(){
        Map<String, List<String>>  response  = callDefinitionResponse.getInterfaceToRequestIdMap();
        assertEquals(new HashMap<>(), response);
    }

    @Test
    void getResponseForSingleCallTest(){
        Map<String, List<String>> map = new HashMap<>();
        List<String> list = new ArrayList<>();
        map.put("test", list);
        callDefinitionResponse.setInterfaceToRequestIdMap(map);
        CustomHttpResponse response = callDefinitionResponse.getResponseForSingleCall("test");
        assertNull(response);
    }
}
