package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.exception.BffException;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.web.server.ServerWebInputException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ExceptionUtilTests {

	@ParameterizedTest
	@CsvSource(value = {
			"message  | causeMessage | internal server error",
			"         | causeMessage | internal server error",
			"         |              | internal server error",
			"         | absent       | internal server error",
	}, delimiter = '|')
	void exceptionWithoutMessage(String message, String cause, String expectedMessage) {
		// Setup: NA
		// Given:
		RuntimeException exception;
		if (StringUtils.equals(cause, "absent")) {
			exception = new RuntimeException(message);
		} else {
			RuntimeException causeException = new RuntimeException(cause);
			exception = new RuntimeException(message, causeException);
		}

		// When:
		BffException gatewayException = ExceptionUtil.getBffException(exception);

		// Verify response:
		assertNotNull(gatewayException);
		assertEquals(expectedMessage, gatewayException.getMessage());
		// Verify mocks: NA
	}

	@Test
	void getBffExceptionTestForServerWebInputException(){
		// Given:
		ServerWebInputException serverWebInputException = new ServerWebInputException("test");

		// When:
		BffException gatewayException = ExceptionUtil.getBffException(serverWebInputException);

		// Verify response:
		assertNotNull(gatewayException);
	}
}
