package jp.co.rakuten.bff.core.config.json;

import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.testUtil.JsonLoaderTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.env.Environment;
import org.springframework.web.reactive.function.client.WebClient;

import static org.junit.jupiter.api.Assertions.*;

class RepositoryJsonLoaderTest {

	private static final String externalDir = "repoJsonLoaderTest/repo_external/";
	private static final String localDir = "repoJsonLoaderTest/repo_local/";
	private Environment env;
	private LocalJsonLoader localLoader;
	private ExternalJsonLoader externalLoader;
	private RepositoryJsonLoader loader;

	@BeforeEach
	void setup() {
		env = JsonLoaderTestUtil.getMockEnv(externalDir, localDir);
	}

	@AfterEach
	void cleanup() {
		externalLoader = null;
		localLoader = null;
		loader = null;
	}

	@DisplayName("Test loadApiTemplate from external")
	@Test
	public void testLoadApiTemplateFromExternal() {
		String apiKey = "repoTestApi.success.v12";
		ApiDetail apiDetail = new ApiDetail(apiKey);
		String mockApiConfigResponse = TestUtil.getFileContents(externalDir + "apiConfig/" + apiDetail.getPath());
		String mockApiResponse = TestUtil.getFileContents(externalDir + "api/" + apiDetail.getPath());
		WebClient.Builder webClientBuilderMock = JsonLoaderTestUtil
				.getMockWebClientBuilder(mockApiConfigResponse, mockApiResponse, 200);
		externalLoader = new ExternalJsonLoader(env, webClientBuilderMock);
		externalLoader.init();
		loader = new RepositoryJsonLoader(env, externalLoader, localLoader);
		assertDoesNotThrow(() -> {
			ApiTemplate shopBookMarkListModel = loader.loadApiTemplate(apiDetail, true).block();
			assertNotNull(shopBookMarkListModel);
			assertEquals(apiKey, shopBookMarkListModel.getApiKey());
			assertEquals(apiDetail.getPath(), shopBookMarkListModel.getPath());
			assertNotNull(shopBookMarkListModel.getApiParamsTemplate());
			assertEquals(2, shopBookMarkListModel.getFeaturesMap().size());
			assertEquals(2, shopBookMarkListModel.getApiParamsTemplate().getFeaturesParamsMap().size());
			assertEquals(4, shopBookMarkListModel.getInterfacesMap().size());
		});
	}

	@DisplayName("Test loadInterfaceTemplate when external fails")
	@Test
	public void testLoadInterfaceTemplateWhenExternalFails() {
		String interfaceKey = "shopbookmark_list";
		String interfacePath = interfaceKey + ".json";
		String mockInterfaceResponse = TestUtil.getFileContents(externalDir + "interface/" + interfacePath);
		WebClient.Builder webClientBuilderMock = JsonLoaderTestUtil.getMockWebClientBuilder("error", 400);
		externalLoader = new ExternalJsonLoader(env, webClientBuilderMock);
		externalLoader.init();
		localLoader = new LocalJsonLoader();
		loader = new RepositoryJsonLoader(env, externalLoader, localLoader);
		assertDoesNotThrow(() -> {
			InterfaceTemplate template = loader.loadInterfaceTemplate("shopbookmark_list.json").block();
			assertNotNull(template);
			assertEquals(interfaceKey, template.getInterfaceKey());
		});
	}

	@Test
	void testGetSet() {
		loader = new RepositoryJsonLoader(env, externalLoader, localLoader);
		assertDoesNotThrow(() -> {
			loader.setEnv(env);
			loader.setExternalJsonLoader(externalLoader);
			loader.setLocalJsonLoader(localLoader);
		});
		assertAll(
				() -> assertEquals(env, loader.getEnv()),
				() -> assertEquals(localLoader, loader.getLocalJsonLoader()),
				() -> assertEquals(externalLoader, loader.getExternalJsonLoader())
		);
	}
}