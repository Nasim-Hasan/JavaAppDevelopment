package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.cache.IchibaCacheManager;
import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.service.CallDefinitionExecutionService;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.apache.commons.lang3.time.StopWatch;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.core.env.Environment;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.*;

class FeatureExecutionServiceImplTest {

	@Mock
	CallDefinitionExecutionService callDefinitionExecutionService;

	@Spy
	GenericFeatureProcessor genericFeatureProcessor;

	@Mock InterfaceConfigLoader interfaceConfigLoader;

	@Mock IchibaCacheManager ichibaCacheManager;

	@Mock
	Environment environment;

	@InjectMocks
	FeatureExecutionServiceImpl featureExecutionService;

	private static ExecutionPlanServiceImpl executionPlan;
	private static String requestRepoDir;
	private static Map<String, CommonRequestModel> validatedRequest;
	private ApiRepository apiRepository;
	private static Environment env;

	@BeforeAll
	static void setUpAll() {
		env = mock(Environment.class);
		executionPlan = new ExecutionPlanServiceImpl(env);
		requestRepoDir = "mockfiles/user_request";
		validatedRequest = new HashMap<>();
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		apiRepository = ApiRepositoryTestUtil.getRepository();
		executionPlan.onRefresh(null);
		when(ichibaCacheManager.getFromCache(any(FeatureTemplate.class), any(), any(), any()))
				.thenAnswer(invocation -> Mono.empty());
	}

	@AfterEach
	void tearDown() {
		apiRepository = null;
		callDefinitionExecutionService = null;
		genericFeatureProcessor = null;
		featureExecutionService = null;
	}

	@Test
	@DisplayName("for all features if every features run successfully then every feature should return data")
	void testFeatureLengthForAllRequestedFeature() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));

		// upstreamExecutionService should call 2 times because of total 2 unique upstream
		verify(callDefinitionExecutionService, times(2)).getCallDefinitionResponse(any(), any(), any(),
				any(), any(), any(), any());

		// genericFeatureProcessor should call 2 times because of total 2 feature
		verify(genericFeatureProcessor, times(2)).postProcess(any(), any(), any());
		;

	}

	@Test
	@DisplayName("for partial features if requested features run successfully then requested feature should return data")
	void testFeatureLengthForSomeRequestedFeature() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_some_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when

		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel, validatedRequest,
				apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list"), response.keySet());
		executionModel.getFeatureModelList().forEach(featureTemplate ->
				assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));

		// upstreamExecutionService should call 2 times because of total 2 unique upstream
		verify(callDefinitionExecutionService, times(2)).getCallDefinitionResponse(any(), any(), any(),
				any(), any(), any(), any());

		// genericFeatureProcessor should call 1 times because of total 1 feature
		verify(genericFeatureProcessor, times(1)).postProcess(any(), any(), any());
		;

	}

	@Test
	@DisplayName("upstream should run in parallel")
	void testParallelUpstreamCall() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("parallelUpstreamCall.list.v1");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());
		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		Map<String, Long> upstreamDelayMap = new HashMap<>();
		upstreamDelayMap.put("shopbookmark_list", 1L);
		upstreamDelayMap.put("pointinfo_gspinfo", 2L);
		upstreamDelayMap.put("coupon", 1L);

		//when
		upstreamDelayMap.forEach((upstream, duration) -> when(callDefinitionExecutionService.getCallDefinitionResponse(
				eq(apiTemplate.getCallDefinitionsMap().get(upstream)), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap<>()).delayElement(Duration.ofSeconds(duration))));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;

		//then
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		featureExecutionService.executeFeatures(requestModel, executionModel, validatedRequest, apiTemplate)
				.block();
		stopWatch.stop();

		//verify
		assertEquals(3L, stopWatch.getTime(TimeUnit.SECONDS));
	}

	@Test
	@DisplayName("dependency upstream should run in parallel")
	void testParallelDependencyUpstreamCall() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("parallelDependencyCall.list.v1");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		Map<String, Long> upstreamDelayMap = new HashMap<>();
		upstreamDelayMap.put("shopbookmark_list", 1L);
		upstreamDelayMap.put("pointinfo_gspinfo", 2L);
		upstreamDelayMap.put("coupon", 2L);

		//when
		upstreamDelayMap.forEach((upstream, duration) -> when(callDefinitionExecutionService.getCallDefinitionResponse(
				eq(apiTemplate.getCallDefinitionsMap().get(upstream)), any(), any(), any(), any(),any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap<>()).delayElement(Duration.ofSeconds(duration))));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;

		//then
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		featureExecutionService.executeFeatures(requestModel, executionModel, validatedRequest, apiTemplate)
				.block();
		stopWatch.stop();

		//verify
		assertEquals(4L, stopWatch.getTime(TimeUnit.SECONDS));
	}

	@Test
	@DisplayName("if callDefinitionExecutionService has an exception then features should return data")
	void testUpstreamExecutionServiceException() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		apiTemplate.getFeaturesMap().forEach((featureName, featureTemplate) -> {
			featureTemplate.setProcessorBean((validatedClientData, featureTemplate1, upstreamResponseMap) ->
					new GenericFeatureProcessor()
							.postProcess(validatedClientData, featureTemplate1, upstreamResponseMap));
		});
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.fromCallable(() -> {
					throw SystemException.create(SystemErrorEnum.INTERNAL, "UT error");
				}));

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel, validatedRequest,
				apiTemplate).block();

		//verify
		assertNotNull(response);
		assertTrue(response.get("shopbookmark_list") instanceof Map);
		assertTrue(((Map<String, Object>) response.get("shopbookmark_list")).containsKey("data"));
	}


	@Test
	@DisplayName("cache has data for features, backend not called")
	void testCacheForAllRequestedFeature() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(false)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());
		executionModel.getFeatureModelList().forEach(featureTemplate ->
				assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));
		assertEquals(200, ((Map)((Map)((Map)response.get("shopbookmark_list")).get("data")).get("body")).get("code"));
		assertEquals("test response",
				((Map)((Map)((Map)response.get("shopbookmark_list")).get("data")).get("body")).get("message"));

		verify(callDefinitionExecutionService, times(0)).getCallDefinitionResponse(any(), any(), any(),
				any(), any(), any(), any());
	}

	@Test
	@DisplayName("response not available in cache, backend called for response")
	void testCacheForAllRequestedFeature_cacheNotFound() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		processorResponse.setCacheable(true);
		processorResponse.setResponseMap(getResponse(false).getCacheMap());

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("", "")));
		doReturn(Mono.just(processorResponse))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class), any(), any(), any());
		doReturn(Mono.error(new RuntimeException("test error")))
				.when(ichibaCacheManager).setToCache(any(), any(), any(), any(), any());

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
		                                                                       validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				                                             assertTrue(((Map<String, Object>) response
						                                             .get(featureTemplate.getName()))
						                                                        .containsKey("data")));

		verify(callDefinitionExecutionService, times(2)).getCallDefinitionResponse(any(), any(), any(),
		                                                                           any(), any(), any(), any());
	}

	@Test
	@DisplayName("backend gives response but error occurs while setting to cache")
	void testCacheForAllRequestedFeature_error() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		processorResponse.setCacheable(true);
		processorResponse.setResponseMap(getResponse(false).getCacheMap());

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("","")));
		doReturn(Mono.just(processorResponse))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());
		doReturn(Mono.error(new RuntimeException("test error")))
				.when(ichibaCacheManager).setToCache(any(),any(),any(),any(),any());

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));

		verify(callDefinitionExecutionService, times(2)).getCallDefinitionResponse(any(), any(), any(),
				any(), any(), any(), any());
	}

	@Test
	@DisplayName("backend gives response but error occurs while setting to cache")
	void testCacheForAllRequestedFeature_error2() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		FeaturePostProcessorResponse processorResponseSpy = Mockito.spy(processorResponse);


		//when
		doThrow(new RuntimeException("test error")).when(processorResponseSpy).isCacheable();
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("","")));
		doReturn(Mono.just(processorResponseSpy))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());
		doReturn(Mono.error(new RuntimeException("test setToCache error")))
				.when(ichibaCacheManager).setToCache(any(),any(),any(),any(),any());
		doReturn(Mono.just(false))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(any(), any(), anyString());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setStaleActiveFlagToCache(any(), any(), anyString(), anyLong());
		when(environment.getProperty(any(), anyString())).thenReturn("10000");
		featureExecutionService.setEnvironment(environment);

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));
	}

	@Test
	@DisplayName("cache response is stale and staleActiveFlag is not found in cache, so backend called for response")
	void testCacheForAllRequestedFeature_cacheStaleAndStaleAtiveFlagNotFound() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		FeaturePostProcessorResponse processorResponseSpy = Mockito.spy(processorResponse);


		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("","")));
		doReturn(Mono.just(processorResponseSpy))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(),any(),any(),any(),any());
		doReturn(Mono.empty())
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(any(), any(), anyString());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setStaleActiveFlagToCache(any(), any(), anyString(), anyLong());
		when(environment.getProperty(any(), anyString())).thenReturn("10000");
		featureExecutionService.setEnvironment(environment);

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
		                                                                       validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				                                             assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));
	}

	@Test
	@DisplayName("cache response is stale and staleActiveFlag is false in cache, so backend called for response")
	void testCacheForAllRequestedFeature_cacheStaleAndStaleAtiveFlagFlase() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		FeaturePostProcessorResponse processorResponseSpy = Mockito.spy(processorResponse);


		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("","")));
		doReturn(Mono.just(processorResponseSpy))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(),any(),any(),any(),any());
		doReturn(Mono.just(false))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(any(), any(), anyString());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setStaleActiveFlagToCache(any(), any(), anyString(), anyLong());
		when(environment.getProperty(any(), anyString())).thenReturn("10000");
		featureExecutionService.setEnvironment(environment);

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
		                                                                       validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				                                             assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));
	}

	@Test
	@DisplayName("cache response is stale and getting staleActiveFlag gives error, so backend called for response")
	void testCacheForAllRequestedFeature_cacheStaleAndStaleAtiveFlagError() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);
		FeaturePostProcessorResponse processorResponse = new FeaturePostProcessorResponse();
		FeaturePostProcessorResponse processorResponseSpy = Mockito.spy(processorResponse);


		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(Map.of("", "")));
		doReturn(Mono.just(processorResponseSpy))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		;
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class), any(), any(), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(), any(), any(), any(), any());
		doReturn(Mono.error(new RuntimeException("test error")))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(any(), any(), anyString());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setStaleActiveFlagToCache(any(), any(), anyString(), anyLong());
		when(environment.getProperty(any(), anyString())).thenReturn("10000");
		featureExecutionService.setEnvironment(environment);

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
		                                                                       validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());

		executionModel.getFeatureModelList().forEach(featureTemplate ->
				                                             assertTrue(((Map<String, Object>) response
						                                             .get(featureTemplate.getName()))
						                                                        .containsKey("data")));
	}

	@Test
	@DisplayName("cache response is stale and staleActiveFlag is true,so backend not called and stale cache returned")
	void testCacheForAllRequestedFeature_cacheStaleAndStaleAtiveFlagTrue() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setVersion(UUID.randomUUID().toString());
		requestModel.setRequestModel(request);

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));
		doReturn(Mono.just(new FeaturePostProcessorResponse()))
				.when(genericFeatureProcessor).postProcess(any(), any(), any());
		doReturn(Mono.just(getResponse(true)))
				.when(ichibaCacheManager).getFromCache(any(FeatureTemplate.class),any(),any(),any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setToCache(any(), any(), any(), any(), any());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).getStaleActiveFlagFromCache(any(), any(), anyString());
		doReturn(Mono.just(true))
				.when(ichibaCacheManager).setStaleActiveFlagToCache(any(), any(), anyString(), anyLong());
		when(environment.getProperty(any(), anyString())).thenReturn("10000");
		featureExecutionService.setEnvironment(environment);

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
		                                                                       validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list", "coupon"), response.keySet());
		executionModel.getFeatureModelList().forEach(featureTemplate ->
				                                             assertTrue(((Map<String, Object>) response.get(featureTemplate.getName())).containsKey("data")));
		assertEquals(200, ((Map)((Map)((Map)response.get("shopbookmark_list")).get("data")).get("body")).get("code"));
		assertEquals("test response",
		             ((Map)((Map)((Map)response.get("shopbookmark_list")).get("data")).get("body")).get("message"));

		verify(callDefinitionExecutionService, times(0)).getCallDefinitionResponse(any(), any(), any(),
		                                                                           any(), any(), any(), any());
	}

	@Test
	@DisplayName("if feature post processor has an exception inside Mono then features should return proper error code")
	void testFeaturePostProcessorMonoException() {
		//given

		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		apiTemplate.getFeaturesMap().forEach((featureName, featureTemplate) -> {
			featureTemplate.setProcessorBean((validatedClientData, feature, responseMap) ->
					Mono.fromCallable(() -> {
						throw SystemException.create(SystemErrorEnum.INTERNAL, "UT error");
					}));
		});
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(),any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertTrue(response.get("shopbookmark_list") instanceof Map);

		Object error = ((Map<String, Object>) response.get("shopbookmark_list")).get("error");
		assertEquals(SystemErrorEnum.INTERNAL.getErrorCode().value(), ((Map<String, Object>) error).get("code"));
	}

	@Test
	@DisplayName("if feature post processor has an exception in runtime then features should return proper error code")
	void testFeaturePostProcessorRuntimeException() {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		apiTemplate.getFeaturesMap().forEach((featureName, featureTemplate) -> {
			featureTemplate.setProcessorBean((validatedClientData, feature, responseMap) -> {
				throw new RuntimeException();
			});
		});
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_all_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(new HashMap()));

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertTrue(response.get("shopbookmark_list") instanceof Map);

		Object error = ((Map<String, Object>) response.get("shopbookmark_list")).get("error");
		assertEquals(SystemErrorEnum.INTERNAL.getErrorCode().value(), ((Map<String, Object>) error).get("code"));
	}

	@ParameterizedTest
	@DisplayName("check with multiple request")
	@CsvSource(value = {"100", "200", "300"})
	void multipleRequestTest(String easyId) {
		//given
		ApiTemplate apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		RequestModel request = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_some_feature.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setRequestModel(request);
		requestModel.setVersion(UUID.randomUUID().toString());

		ExecutionModel executionModel = executionPlan.prepareExecutionPlan(requestModel, apiTemplate);

		//when
		when(callDefinitionExecutionService.getCallDefinitionResponse(any(), any(), any(), any(), any(),any(), any()))
				.thenAnswer(invocation -> {
					Map<String, Object> response = new HashMap<>();
					response.put("easyId", easyId);

					CustomHttpResponse customHttpResponse = CustomHttpResponse.builder()
							.interfaceKey("shopbookmark_list")
							.bodyMap(response).build();

					MultipleResponses multipleResponses = new MultipleResponses();
					multipleResponses.setOverallStatus(SUCCESS);
					HashMap<String, CustomHttpResponse> responseIdMap = new HashMap<>();
					responseIdMap.put("test", customHttpResponse);
					multipleResponses.setResponses(responseIdMap);

					CallDefinitionResponse callDefinitionResponse =
							new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
					callDefinitionResponse.setMultipleResponses(multipleResponses);
					callDefinitionResponse.setInterfaceToRequestIdMap(
							Map.of("shopbookmark_list", Collections.singletonList("test")));
					return Mono.just(callDefinitionResponse);
				});
		when(ichibaCacheManager.setToCache(any(FeatureTemplate.class), any(), any(), any(), any()))
				.thenAnswer(invocation -> Mono.just(true));

		//then
		Map<String, Object> response = featureExecutionService.executeFeatures(requestModel, executionModel,
				validatedRequest, apiTemplate).block();

		//verify
		assertNotNull(response);
		assertEquals(executionModel.getFeatureModelList().size(), response.size());
		assertEquals(Set.of("shopbookmark_list"), response.keySet());

		Object data = ((Map<String, Object>) response.get("shopbookmark_list")).get("data");
		Map<String, Object> dataMap = (Map<String, Object>) data;
		Object responseEasyId = ((Map<String, Object>) dataMap.get("shopbookmark_list")).get("easyId");
		assertEquals(easyId, responseEasyId);

		// upstreamExecutionService should call 2 times because of total 2 unique upstream
		verify(callDefinitionExecutionService, times(2)).getCallDefinitionResponse(any(), any(), any(),
				any(), any(), any(), any());

	}

	private static CacheDataModel getResponse(boolean isStaleCache) {
		Map<String, Object> body =
				Map.of("code", 200, "message", "test response");
		Map<String, Object> responseMap = Map.of(BffConstants.DATA, Map.of("body", body));
		return new CacheDataModel(isStaleCache, responseMap);
	}
}
