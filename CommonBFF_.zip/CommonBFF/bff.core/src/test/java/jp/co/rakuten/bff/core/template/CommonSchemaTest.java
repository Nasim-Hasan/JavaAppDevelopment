package jp.co.rakuten.bff.core.template;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CommonSchemaTest {

	@Test
	void testBoilerplates() {
		CommonSchema schema = new CommonSchema();
		List headers = List.of(new CommonSchema());
		schema.setHeaders(headers);
		assertEquals(headers, schema.getHeaders());
	}
}
