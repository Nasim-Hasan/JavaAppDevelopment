package jp.co.rakuten.bff.core.resolver.provider;

import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.testUtil.CommonValidatorUtil;
import jp.co.rakuten.bff.core.testUtil.ImmutableMap;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class CommonSchemaArgumentProvider implements ArgumentsProvider {

	Map<String, Object> buildTestData(List<CommonSchema> requestSchemas, List<CommonSchema> responseSchemas,
									  String errorMessage) {
		return ImmutableMap
				.of("requestSchema", requestSchemas, "responseSchema", responseSchemas, "errorMessage", errorMessage);
	}


	@Override
	public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws Exception {
		return Stream.of(
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("username", "string", false, "user", null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, "taroshinchi", null),
						CommonValidatorUtil.commonSchemaBuilder("maxPrice", "integer", false, "user", null,
																null, null, null, null, 0,
																999999, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("maxPrice", "integer", false, "user", null,
																null, null, null, null, 0,
																999999, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("genreId", "integer", false, null, null,
																null, null, null, null, 0, 999999,
																null, null, null, null,
																null, null, null, 0, null)
				), List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("username", "string", false, "user", null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), ""),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("username", "string", false, "user", null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "name is required"),
				buildTestData(Collections.emptyList(), List.of(
						CommonValidatorUtil.commonSchemaBuilder("", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("username", "string", false, "user", null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), "name is required"),
				buildTestData(Collections.emptyList(), List.of(
						CommonValidatorUtil.commonSchemaBuilder(null, "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), "name is required"),
				buildTestData(Collections.emptyList(), List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), "type is required"),
				buildTestData(Collections.emptyList(), List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", null, true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), "type is required"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder(null, "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null),
						CommonValidatorUtil.commonSchemaBuilder("username", "string", false, "user", null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), "name is required"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "type is required"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", null, true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "type is required"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "sometype", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "sometype is not supported"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("easyId", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, 123, null)
				), Collections.emptyList(), "When the field is required default value cannot be provided"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "object", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "When the type is either object/objectarray parameters cannot be empty"),
				buildTestData(Collections.emptyList(),
							  List.of(
									  CommonValidatorUtil.commonSchemaBuilder("item", "objectarray", true, null, null,
																			  null, null, null, null, null,
																			  null, null, null, null,
																			  null, null, null,
																			  null, null, null)
							  ), "When the type is either object/objectarray parameters cannot be empty"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, "integer",
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), null),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, "integer",
																null, null, null, null, null,
																null, null, null, null,
																null, null, Arrays.asList(1, 2, 3, 4),
																null, null, null)
				), Collections.emptyList(), null),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Arrays.asList(1, 2, 3, 4),
																null, null, null)
				), Collections.emptyList(), "dataType is required when type is list or options"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Arrays.asList(1, 2, 3, 4),
																null, null, null)
				), Collections.emptyList(), "dataType is required when type is list or options"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, "list",
																null, null, null, null, null,
																null, null, null, null,
																null, null, Arrays.asList(1, 2, 3, 4),
																null, null, null)
				), Collections.emptyList(), "dataType should be either numeric or string"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, "option",
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "dataType should be either numeric or string"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "integer", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Arrays.asList(1, 2, 3, 4),
																null, null, null)
				), Collections.emptyList(), "integer cannot have options"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Collections.emptyList(),
																null, null, null)
				), Collections.emptyList(), "options should not be empty"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "options should not be empty"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "multioption", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Collections.emptyList(),
																null, null, null)
				), Collections.emptyList(), "options should not be empty"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "multioption", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "options should not be empty"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "option", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, Collections.singletonList(1),
																null, null, null)
				), Collections.emptyList(), "options should have multiple options"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "property", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "propType is required when type is property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "property", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																"", null, null,
																null, null, null)
				), Collections.emptyList(), "propType is required when type is property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "property", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																"integer", null, null,
																null, null, null)
				), Collections.emptyList(), "propKeyPrefix is required when type is property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "property", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																"integer", "", null,
																null, null, null)
				), Collections.emptyList(), "propKeyPrefix is required when type is property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "integer", true, null, null,
																null, null, 5, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for integer type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "long", true, null, null,
																null, null, null, 6, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for long type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "double", true, null, null,
																null, null, 5, 6, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for double type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "integer", true, null, null,
																null, 10, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for integer type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "long", true, null, null,
																5, null, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for long type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "double", true, null, null,
																5, 10, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "size and/or length not applicable for double type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "integer", true, null, null,
																null, null, null, null, 5,
																1, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "minValue cannot be larger than the maxValue"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, 5, 4, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "minLength cannot be larger than the maxLength"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, null,
																null, null, null, null, 5,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or length not applicable for list type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, null,
																null, null, null, null, null,
																6, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or length not applicable for list type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, null,
																null, null, 5, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or length not applicable for list type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, null,
																null, null, null, 7, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or length not applicable for list type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "list", true, null, null,
																5, 7, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "minSize cannot be larger than the maxSize"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, 8, 5, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "minLength cannot be larger than the maxLength"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																5, null, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or size not applicable for string type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																5, null, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or size not applicable for string type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, 6, null, null, null,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or size not applicable for string type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, null, null, 5,
																null, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or size not applicable for string type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, null, null, null,
																7, null, null, null,
																null, "", null,
																null, null, null)
				), Collections.emptyList(), "value and/or size not applicable for string type"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																"integer", "", null,
																null, null, null)
				), Collections.emptyList(), "propType is defined where type is not property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "string", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, "abc.xyz", null,
																null, null, null)
				), Collections.emptyList(), "propKeyPrefix is defined where type is not property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("user", "property", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, "abc.xyz", null,
																null, null, null)
				), Collections.emptyList(), "propType is required when type is property"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "Format is required for type date"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, null)
				), Collections.emptyList(), "Format is required for type date"),
				buildTestData(List.of(
						CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, "YYYY-MM-DD")
				), Collections.emptyList(), null),
				buildTestData(Collections.emptyList(), List.of(
						CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																null, null, null, null, null,
																null, null, null, null,
																null, null, null,
																null, null, "YYYY-MM-DD")
				), null),
				buildTestData(Collections.emptyList(),
							  List.of(CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																			  null, null, null, null, null,
																			  null, null, null, null,
																			  null, null, null,
																			  null, null, null)),
							  "Format is required for type date"),
				buildTestData(Collections.emptyList(),
							  List.of(CommonValidatorUtil.commonSchemaBuilder("userDate", "date", true, null, null,
																			  null, null, null, null, null,
																			  null, null, null, null,
																			  null, null, null,
																			  null, null, "ABCDEFG")),
							  "Wrong date format given, "
									  + "cause Illegal pattern character 'A'")
		).map(Arguments::of);
	}
}
