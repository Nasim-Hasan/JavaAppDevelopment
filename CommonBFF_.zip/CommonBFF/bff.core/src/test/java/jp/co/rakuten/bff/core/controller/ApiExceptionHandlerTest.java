package jp.co.rakuten.bff.core.controller;

import jp.co.rakuten.bff.core.constant.BffConstants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

@AutoConfigureWebTestClient
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
class ApiExceptionHandlerTest {

	@Autowired
	private WebTestClient webTestClient;

	@Value("${endpoint.uri-prefix}")
	private String BASE_URI_PREFIX;

	@DisplayName("should return 400 while request body is not provided.")
	@Test
	public void shouldReturn400WhileRequestBodyIsNotProvided() {

		webTestClient.post().uri(BASE_URI_PREFIX + "/shopbookmark/list/v1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.bodyValue("{")
				.exchange()
				.expectStatus().is4xxClientError()
				.expectBody()
				.jsonPath("$.error.message").isEqualTo("invalid request body")
				.jsonPath("$.error.code").isEqualTo("400")
				.jsonPath("$.status").isEqualTo(BffConstants.UPSTREAM_RESPONSE_FAILURE)
		;
	}


	@DisplayName("should return 400 while request Method is other than POST")
	@Test
	public void shouldReturn400WhileRequestMethodIsOtherThanPost() {
		webTestClient.get().uri(BASE_URI_PREFIX + "/shopbookmark/list/v1")
				.accept(MediaType.APPLICATION_JSON)
				.exchange()
				.expectStatus().is4xxClientError()
				.expectBody()
				.json("{\"error\":{\"code\":400,\"message\":\"Request method 'GET' not supported\"},"
							  + "\"status\":\"FAILURE\"}");
	}

	@DisplayName("should return 400 when versioning is not proper format")
	@Test
	public void shouldReturn400WhenVersioningIsNotProperFormat() {
		webTestClient.post().uri(BASE_URI_PREFIX + "/shopbookmark/list/vv1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.bodyValue("{}")
				.exchange()
				.expectStatus().is4xxClientError()
				.expectBody()
				.json("{\"error\":{\"code\":400,\"message\":\"api.version: " + BffConstants.INVALID_VERSION_FORMAT
							  + "\"},\"status\":\"FAILURE\"}");
	}


	@DisplayName("should return 404 when invalid url provided.")
	@Test
	public void shouldReturn404WhenCommonNotProvided() {
		webTestClient.post().uri(BASE_URI_PREFIX + "-other/shopbookmark/list/v1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.bodyValue("{}")
				.exchange()
				.expectStatus().is4xxClientError()
				.expectBody().json("{\"error\":{\"code\":404,\"message\":\"Not Found\"},\"status\":\"FAILURE\"}");
	}

	@DisplayName("when api in maintenance mode.")
	@Test
	public void whenApiInMaintenanceMode() {
		webTestClient.post().uri(BASE_URI_PREFIX + "/shopbookmark/list_1/v1")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.bodyValue("{}")
				.exchange()
				.expectStatus().is5xxServerError()
				.expectBody()
				.json("{\"error\":{\"code\":503,\"message\":\"shopbookmark.list_1.v1 is in maintenance mode.\"}" +
							  ",\"status\":\"FAILURE\"}");
	}

}
