package jp.co.rakuten.bff.core.util.inputexchangeutils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class IEHankanaToZenkanaUtilTest {

    @ParameterizedTest
    @ValueSource(strings = {"ｱｲｳｴｵｶﾞｷﾞｸﾞｹﾞｺﾞﾊﾟﾋﾟﾌﾟﾍﾟﾎﾟうどん饂飩udon"})
    @DisplayName("Test IEHankanaToZenkanaUtil exec")
    public void testExecute(String inputString)  {
        String formatString = IEHankanaToZenkanaUtil.exec(inputString);
        assertEquals("アイウエオガギグゲゴパピプペポうどん饂飩udon", formatString);
    }
}
