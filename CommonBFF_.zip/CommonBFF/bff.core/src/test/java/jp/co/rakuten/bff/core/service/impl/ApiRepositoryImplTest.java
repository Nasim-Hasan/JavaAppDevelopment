package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.config.ApiConfigurationProperties;
import jp.co.rakuten.bff.core.config.json.RepositoryJsonLoader;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.resolver.JsonSchemaValidator;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApiRepositoryImplTest {

	private ApplicationContext context;
	private Environment environment;
	@Mock
	private JsonSchemaValidator schemaValidator;
	private ApiRepositoryImpl repository;
	private String repoDir = ApiRepositoryTestUtil.DEFAULT_REPO_DIR;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
		environment = ApiRepositoryTestUtil.getMockEnv(repoDir);
		context = mock(ApplicationContext.class);
		repository = new ApiRepositoryImpl(environment, context, schemaValidator,
										   ApiRepositoryTestUtil.getMockApiConfigurationProperties(repoDir),
										   ApiRepositoryTestUtil.getRepoJsonLoader(repoDir));
	}

	@AfterEach
	void cleanup() {
		repository = null;
	}

	@DisplayName("Check load")
	@Test
	void checkLoad() {
		assertDoesNotThrow(() -> repository.load());

		String apiKey = "repoTestApi.success.v12";
		ApiTemplate shopBookMarkListModel = repository.getApiRepositoryTemplate(apiKey);
		assertNotNull(shopBookMarkListModel);
		assertEquals(apiKey, shopBookMarkListModel.getApiKey());

		Map<String, FeatureTemplate> featuresMap = shopBookMarkListModel.getFeaturesMap();
		assertNotNull(featuresMap);
		assertFalse(featuresMap.isEmpty());
		assertEquals(2, featuresMap.size());
		assertNotNull(featuresMap.get("coupon"));
		featuresMap.forEach((name, featureModel) -> {
			assertFalse(featureModel.getInterfaceNameList().isEmpty());
			assertFalse(featureModel.getCallDefinitionsSet().isEmpty());
		});

		Map<String, CallDefinitionTemplate> callDefinitionsMap = shopBookMarkListModel.getCallDefinitionsMap();
		assertNotNull(callDefinitionsMap);
		assertFalse(callDefinitionsMap.isEmpty());
		assertEquals(4, callDefinitionsMap.size());
		callDefinitionsMap.forEach((name, callDefinitionModel) -> {
			assertFalse(callDefinitionModel.getInterfacesList().isEmpty());
		});

		Map<String, InterfaceTemplate> interfacesMap = shopBookMarkListModel.getInterfacesMap();
		assertNotNull(interfacesMap);
		assertFalse(interfacesMap.isEmpty());
		assertEquals(4, interfacesMap.size());

		apiKey = "defaultFeaturesTestApi.df.v1";
		ApiTemplate defaultFeaturesApiTemplate = repository.getApiRepositoryTemplate(apiKey);
		assertNotNull(defaultFeaturesApiTemplate);
		assertEquals(apiKey, defaultFeaturesApiTemplate.getApiKey());

		featuresMap = defaultFeaturesApiTemplate.getFeaturesMap();
		assertNotNull(featuresMap);
		assertFalse(featuresMap.isEmpty());
		assertEquals(5, featuresMap.size());

		Set<String> defaultFeaturesSet = defaultFeaturesApiTemplate.getApiParamsTemplate().getDefaultFeatures();
		assertEquals(2, defaultFeaturesSet.size());

		apiKey = "defaultFeaturesTestApi.df_wont_load.v1";
		ApiTemplate shouldNoLoadTemplate = repository.getAllApiTemplates().get(apiKey);
		assertNull(shouldNoLoadTemplate);
	}

	@DisplayName("Check onRefresh")
	@Test
	void checkOnRefresh() {
		RefreshScopeRefreshedEvent event = new RefreshScopeRefreshedEvent("testEvent");
		assertDoesNotThrow(() -> repository.onRefresh(event));

		String apiKey = "repoTestApi.success.v12";
		ApiTemplate shopBookMarkListModel = repository.getApiRepositoryTemplate(apiKey);
		assertNotNull(shopBookMarkListModel);
		assertEquals(apiKey, shopBookMarkListModel.getApiKey());

		Map<String, FeatureTemplate> featuresMap = shopBookMarkListModel.getFeaturesMap();
		assertNotNull(featuresMap);
		assertFalse(featuresMap.isEmpty());
		assertEquals(2, featuresMap.size());
		assertNotNull(featuresMap.get("coupon"));
		featuresMap.forEach((name, featureModel) -> {
			assertFalse(featureModel.getInterfaceNameList().isEmpty());
			assertFalse(featureModel.getCallDefinitionsSet().isEmpty());
		});

		Map<String, CallDefinitionTemplate> callDefinitionsMap = shopBookMarkListModel.getCallDefinitionsMap();
		assertNotNull(callDefinitionsMap);
		assertFalse(callDefinitionsMap.isEmpty());
		assertEquals(4, callDefinitionsMap.size());
		callDefinitionsMap.forEach((name, callDefinitionModel) -> {
			assertFalse(callDefinitionModel.getInterfacesList().isEmpty());
		});

		Map<String, InterfaceTemplate> interfacesMap = shopBookMarkListModel.getInterfacesMap();
		assertNotNull(interfacesMap);
		assertFalse(interfacesMap.isEmpty());
		assertEquals(4, interfacesMap.size());
	}

	@DisplayName("Check load when mapping is null")
	@Test
	void checkLoadWhenMappingNull() {
		ApiConfigurationProperties apiConfigProperties = mock(ApiConfigurationProperties.class);
		doReturn(null).when(apiConfigProperties).getMapping();
		repository = new ApiRepositoryImpl(environment, context, schemaValidator, apiConfigProperties,
										   ApiRepositoryTestUtil
												   .getRepoJsonLoader(repoDir));
		assertDoesNotThrow(() -> repository.load());

		assertTrue(repository.getAllApiTemplates().isEmpty());
	}

	@DisplayName("Check load when mapping is empty")
	@Test
	void checkLoadWhenMappingEmpty() {
		ApiConfigurationProperties apiConfigProperties = mock(ApiConfigurationProperties.class);
		Map<String, String> emptyMapping = new HashMap<>();
		doReturn(emptyMapping).when(apiConfigProperties).getMapping();
		repository = new ApiRepositoryImpl(environment, context, schemaValidator, apiConfigProperties,
										   ApiRepositoryTestUtil
												   .getRepoJsonLoader(repoDir));
		assertDoesNotThrow(() -> repository.load());

		assertTrue(repository.getAllApiTemplates().isEmpty());
	}

	@DisplayName("Check load when templates loading encounters error during interface loading")
	@Test
	void checkLoadWhenTemplateLoadingError() {
		assertDoesNotThrow(() -> repository.load());
		String apiKey = "repoTestApi.success.v12";
		ApiTemplate shopBookMarkListModel = repository.getApiRepositoryTemplate(apiKey);
		assertNotNull(shopBookMarkListModel);

		RepositoryJsonLoader repoJsonLoaderMock = mock(RepositoryJsonLoader.class);
		when(repoJsonLoaderMock.loadApiTemplate(any(ApiDetail.class), anyBoolean()))
				.thenReturn(Mono.just(shopBookMarkListModel));
		when(repoJsonLoaderMock.loadInterfaceTemplate(anyString(), anyBoolean()))
				.thenReturn(Mono.error(SystemException.create(SystemErrorEnum.INTERNAL, "testErr")));
		assertThrows(SystemException.class, () ->
				repoJsonLoaderMock.loadInterfaceTemplate("TestInterface", false).block()
		);

		repository = new ApiRepositoryImpl(environment, context, schemaValidator,
										   ApiRepositoryTestUtil.getMockApiConfigurationProperties(repoDir),
										   repoJsonLoaderMock);
		assertDoesNotThrow(() -> repository.load());
		assertTrue(repository.getAllApiTemplates().isEmpty());
	}
}
