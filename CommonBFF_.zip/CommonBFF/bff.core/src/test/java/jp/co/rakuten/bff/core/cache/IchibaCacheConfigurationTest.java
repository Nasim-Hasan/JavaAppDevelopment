package jp.co.rakuten.bff.core.cache;

import jp.co.rakuten.bff.core.config.InterfaceConfig;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class IchibaCacheConfigurationTest {

	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	@ParameterizedTest
	@ValueSource(strings = {LOCAL_TIMEOUT_PROP_KEY, SHARED_TIMEOUT_PROP_KEY,
			LOCAL_MAX_SIZE_PROP_KEY, TYPE_PROP_KEY, STALE_ENABLED_PROP_KEY,
			STALE_TIMEOUT_PROP_KEY})
	void getInstance(String propKey) {
		// Given
		Map<String, String> interfaceConfig = getInterfaceConfig();
		interfaceConfig.put(propKey, null);

		// When
		IchibaCacheConfiguration instance = IchibaCacheConfiguration.getInstance(interfaceConfig);

		// Then
		assertNotNull(instance);
	}

	private Map<String, String> getInterfaceConfig() {
		InterfaceConfig testInterface = new InterfaceConfig("TEST_INTERFACE");
		testInterface.putToCacheConfigMap(ENABLED_PROP_KEY, "true");
		testInterface.putToCacheConfigMap(LOCAL_TIMEOUT_PROP_KEY, "50000");
		testInterface.putToCacheConfigMap(SHARED_TIMEOUT_PROP_KEY, "120000");
		testInterface.putToCacheConfigMap(LOCAL_MAX_SIZE_PROP_KEY, "100");
		testInterface.putToCacheConfigMap(TYPE_PROP_KEY, "local_and_shared");
		testInterface.putToCacheConfigMap(STALE_ENABLED_PROP_KEY, "true");
		testInterface.putToCacheConfigMap(STALE_TIMEOUT_PROP_KEY, "160000");
		return testInterface.getCacheConfigMap();
	}
}