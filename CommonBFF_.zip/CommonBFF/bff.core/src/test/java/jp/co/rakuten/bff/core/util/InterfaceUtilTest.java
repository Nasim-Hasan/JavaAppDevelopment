package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class InterfaceUtilTest {
	private static final String BASE_PATH = "util/interfaceUtilResponse/";
	private static final String INTERFACE_NAME = "rfBrandList";
	private static final String CALL_DEFINITION = "makerListInfo";
	@Autowired
	Environment environment;

	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private Map<String, CallDefinitionResponse> callDefinitionResponse;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
	}

	@Test
	void getInterfaceResponseTest() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		Map<String, Object> response = InterfaceUtil.getInterfaceResponse(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertNotNull(response);
	}

	@Test
	void getInterfaceAllResponsesSuccess() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		Map<String,Map<String, Object>> response = InterfaceUtil.getInterfaceAllResponses(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertNotNull(response);
	}

	@Test
	void getInterfaceAllResponsesFailed() {

		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceAllResponses(
						new HashMap<>(),
						INTERFACE_NAME,
						CALL_DEFINITION));
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.put(CALL_DEFINITION, callDefinitionResponseUtil.getCallDefinitionResponseFailed());
		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceAllResponses(callDefinitionResponseMap,
						INTERFACE_NAME,
						CALL_DEFINITION));
	}

	@Test
	void getInterfaceResponseTestNull() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListNullUpstreamResponse.json");
		Map<String, Object> response = InterfaceUtil.getInterfaceResponse(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertEquals(0, response.size());
	}

	@Test
	void getInterfaceResponseWithoutExceptionTest() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		Map<String, Object> response = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertNotNull(response);
	}

	@Test
	void getInterfaceResponseWithoutExceptionTestNull() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListNullUpstreamResponse.json");
		Map<String, Object> response = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertEquals(0, response.size());
	}

	@Test
	void getInterfaceResponseWithoutExceptionNullResponseTest() {
		callDefinitionResponse = prepareCallDefinitionResponseFail();
		Map<String, Object> response = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertTrue(MapUtils.isEmpty(response));
	}


	@Test
	void getInterfaceResponseStringTest() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		String response = InterfaceUtil.getInterfaceResponseString(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertNotNull(response);
	}

	@Test
	void isCallNeededTest() {
		CommonRequestModel validatedClientData = new CommonRequestModel();
		Map<String, CommonRequestModel> requestModelMap = new HashMap<>();
		validatedClientData.setParams(Map.of("a", 1,
				"b", 2));
		requestModelMap.put("bookmark", validatedClientData);
		requestModelMap.put("shop", validatedClientData);
		List<String> featureList = new ArrayList<>();
		featureList.add("a");
		Map<String, List<String>> featureMap = new HashMap<>();
		featureMap.put("bookmark", featureList);
		boolean response = InterfaceUtil.isCallNeeded(requestModelMap, featureMap);
		assertNotNull(response);
		assertFalse(InterfaceUtil.isCallNeeded(requestModelMap, Map.of("shop", new ArrayList<>())));
		List<String> featureList1 = new ArrayList<>();
		featureList1.add("d");
		assertFalse(InterfaceUtil.isCallNeeded(requestModelMap, Map.of("top", featureList1)));
	}

	@Test
	void getInterfaceCustomHttpResponseTest() {
		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceCustomHttpResponse(callDefinitionResponseUtil.getCallDefinitionResponseFailed(),
						INTERFACE_NAME,
						CALL_DEFINITION));

		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceCustomHttpResponse(
						null,
						INTERFACE_NAME,
						CALL_DEFINITION));

		callDefinitionResponse=prepareCallDefinitionResponseError("nullIterfaceResponse.json");

		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceCustomHttpResponse(callDefinitionResponse.get(CALL_DEFINITION),
						INTERFACE_NAME,
						CALL_DEFINITION));
	}

	@Test
	void getInterfaceCustomHttpResponseCustomHttpResponseTest() {
		callDefinitionResponse=prepareCallDefinitionResponseError("errorResponse.json");

		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceCustomHttpResponse(callDefinitionResponse.get(CALL_DEFINITION),
						INTERFACE_NAME,
						CALL_DEFINITION));
	}

	@Test
	void getInterfaceCustomHttpResponseCustomHttpResponseTest2() {
		callDefinitionResponse=prepareCallDefinitionResponseError("errorResponse2.json");

		assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceCustomHttpResponse(callDefinitionResponse.get(CALL_DEFINITION),
						INTERFACE_NAME,
						CALL_DEFINITION));
	}

	@ParameterizedTest
	@CsvSource(value = {
			"400|400",
			"412|412",
			"404|404",
			"402|400",
			"407|400",
			"500|503",
			"501|503",
			"503|503"
	}, delimiter = '|')
	@DisplayName("test throwCustomError method")
	void testThrowCustomError(String code, int resultCode) {
		String interfaceName = "testInterface";
		String callDefName = "test_call_def";
		String msg = "test msg";
		CustomError error = new CustomError(code, msg);
		BackendException e = assertThrows(BackendException.class, () ->
				InterfaceUtil.throwCustomError(error, interfaceName, callDefName));
		assertEquals(msg, e.getMessage());
		assertEquals(resultCode, e.getErrorCode().value());
	}

	private Map<String, CallDefinitionResponse> prepareCallDefinitionResponse(String path) {
		Map<String, CallDefinitionResponse> cdResponse =
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEFINITION,
						INTERFACE_NAME,
						BASE_PATH + path);

		Map<String, CallDefinitionResponse> finalMap = new HashMap<>();
		finalMap.put(CALL_DEFINITION,
				cdResponse.get(CALL_DEFINITION));

		return finalMap;
	}

	private Map<String, CallDefinitionResponse> prepareCallDefinitionResponseFail() {
		Map<String, CallDefinitionResponse> cdResponse =
				callDefinitionResponseUtil.getUpstreamResponseFailed(CALL_DEFINITION);
		Map<String, CallDefinitionResponse> finalMap = new HashMap<>();
		finalMap.put(CALL_DEFINITION, cdResponse.get(CALL_DEFINITION));

		return finalMap;
	}

	private Map<String, CallDefinitionResponse> prepareCallDefinitionResponseError(String filename) {
		MultipleResponses sb = prepareMultipleResponses(filename);

		CallDefinitionResponse callDefResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
		callDefResponse.setMultipleResponses(sb);
		callDefResponse.setInterfaceToRequestIdMap(
				Map.of(INTERFACE_NAME, Collections.singletonList("ff855422-6b8f-4977-b1a6-91e676b98675")));

		Map<String, CallDefinitionResponse> finalMap = new HashMap<>();
		finalMap.put(CALL_DEFINITION, callDefResponse);

		return finalMap;
	}

	public static MultipleResponses prepareMultipleResponses(String fileName) {
		String callDefinitionResponseFileContents = TestUtil.getFileContents(BASE_PATH + fileName);
		return TestUtil.getObjectFromString(callDefinitionResponseFileContents, MultipleResponses.class);
	}

	@Test
	void getValidatedAllInterfaceResponsesSuccess() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		Map<String,Map<String, Object>> response = InterfaceUtil.getValidatedAllInterfaceResponses(callDefinitionResponse,
				INTERFACE_NAME,
				CALL_DEFINITION);
		assertNotNull(response);
	}

	@Test
	void getInterfaceResponseWithDependencyExceptionTest() {
		callDefinitionResponse = prepareCallDefinitionResponse("fashionMakerListUpstreamResponse.json");
		BackendException exception =assertThrows(BackendException.class, () ->
				InterfaceUtil.getInterfaceResponseWithDependencyException(callDefinitionResponse,
						"rfList",
						CALL_DEFINITION));
		assertNotNull(exception);
		assertEquals("Failed Dependency", exception.getMessage());
	}


}
