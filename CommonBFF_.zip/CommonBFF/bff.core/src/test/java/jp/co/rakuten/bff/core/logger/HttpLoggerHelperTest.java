package jp.co.rakuten.bff.core.logger;

import jp.co.rakuten.bff.core.constant.BffConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import reactor.util.context.Context;

import java.net.URI;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class HttpLoggerHelperTest {

	BffContext bffContext;

	@BeforeEach
	public void setUp() {
		bffContext = BffContext.builder()
				.clientId("iphone_long")
				.host("example.com")
				.requestUri(URI.create("http://example.com?param=123"))
				.forwardedFor("200.33.123.21")
				.bffId("aBffId")
				.build();
	}

	@Test
	public void testPrepareServiceLoggerRequest() {
		Context context = Context.of(BffConstants.BFF_CONTEXT, bffContext);
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();

		HttpLoggerHelper.prepareServiceLoggerRequest(loggerRequest, context);

		Map<String, Object> extras = loggerRequest.getExtras();
		assertNull(loggerRequest.getUri());
		assertEquals(6, loggerRequest.getExtras().size());
		assertEquals(bffContext.getClientId(), extras.get(HttpLoggerHelper.ExtrasFieldNames.CLIENT_ID));
		assertEquals(bffContext.getHost(), extras.get(HttpLoggerHelper.ExtrasFieldNames.HOST));
		assertEquals(bffContext.getRequestUri().toString().split("\\?")[0],
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.REQUEST_PATH));
		assertEquals(bffContext.getRequestUri().getQuery(),
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.REQUEST_PARAMS));
		assertEquals(bffContext.getForwardedFor(),
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.FORWARDED_FOR));
		assertEquals(bffContext.getBffId(),
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.BFF_ID));
	}

	@Test
	public void testPrepareApiLoggerRequest() {
		Context context = Context.of(BffConstants.BFF_CONTEXT, bffContext);
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();

		HttpLoggerHelper.prepareApiLoggerRequest(loggerRequest, context);

		Map<String, Object> extras = loggerRequest.getExtras();
		assertEquals(4, loggerRequest.getExtras().size());
		assertEquals(bffContext.getRequestUri(), loggerRequest.getUri());
		assertEquals(bffContext.getClientId(), extras.get(HttpLoggerHelper.ExtrasFieldNames.CLIENT_ID));
		assertEquals(bffContext.getHost(), extras.get(HttpLoggerHelper.ExtrasFieldNames.HOST));
		assertEquals(bffContext.getForwardedFor(),
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.FORWARDED_FOR));
		assertEquals(bffContext.getBffId(),
					 extras.get(HttpLoggerHelper.ExtrasFieldNames.BFF_ID));
	}

	@Test
	public void testPrepareApiLoggerRequestDoNothing() {
		Context context = Context.empty();
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();

		HttpLoggerHelper.prepareApiLoggerRequest(loggerRequest, context);

		assertEquals(0, loggerRequest.getExtras().size());
		assertNull(loggerRequest.getUri());
	}

	@Test
	public void testPrepareServiceLoggerRequestDoNothing() {
		Context context = Context.empty();
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();

		HttpLoggerHelper.prepareServiceLoggerRequest(loggerRequest, context);

		assertEquals(0, loggerRequest.getExtras().size());
	}

}
