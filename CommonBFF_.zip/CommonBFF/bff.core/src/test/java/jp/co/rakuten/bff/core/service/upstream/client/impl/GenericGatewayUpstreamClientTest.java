package jp.co.rakuten.bff.core.service.upstream.client.impl;

import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.resources.ConnectionProvider;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static jp.co.rakuten.bff.core.service.upstream.client.impl.BffWebClientBuilder.CONNECTION_POOL_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableConfigurationProperties
class GenericGatewayUpstreamClientTest {

	@Mock
	private Environment env;
	@Mock
	private WebClient.Builder builderMock;
	@Mock
	private WebClient webClientMock;
	@Mock
	private WebClient.RequestHeadersSpec requestHeadersMock;
	@Mock
	private HttpLogger serviceLogger;

	@Spy
	@InjectMocks
	ClientResponse clientResponse = ClientResponse.create(HttpStatus.OK).build();

	//post
	@Mock
	private WebClient.RequestBodyUriSpec requestBodyUriSpec;
	@Mock
	private WebClient.RequestBodySpec requestBodySpec;
	@Spy
	@InjectMocks
	private BffWebClientBuilder bffWebClientBuilder;

	@ParameterizedTest
	@CsvSource({CALL_DEFINITION_TYPE_COMPLEX + ",http.response/genericResponse.json",
			CALL_DEFINITION_TYPE_PARALLEL + ",http.response/genericResponse.json",
			CALL_DEFINITION_TYPE_PARALLEL + ",http.response/genericResponsePartialError.json",
			CALL_DEFINITION_TYPE_SINGLE + ",http.response/singleResponse.json"})
	void generic_gateway_http_request(String type, String responseLocation) throws IOException {
		String responseString = FileUtils.readFileToString(TestUtil.getFile(responseLocation), StandardCharsets.UTF_8);
		when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(responseString));
		GenericGatewayUpstreamClient genericGatewayRequestClient = new GenericGatewayUpstreamClient(bffWebClientBuilder, env,
				serviceLogger);
		genericGatewayRequestClient.singleRequestWebClient = webClientMock;
		genericGatewayRequestClient.parallelRequestWebClient = webClientMock;
		genericGatewayRequestClient.complexRequestWebClient = webClientMock;
		bffWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		Map<String, Object> mockRequest = Map.of(INTERFACE_KEY, "shopbiz_pointinfo", REQUEST_ID, "shopbiz_point_info");

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(webClientMock).when(bffWebClientBuilder).getWebClient(any());
		doReturn(builderMock).when(builderMock).clientConnector(any());
		doReturn(webClientMock).when(builderMock).build();
		doReturn(requestBodyUriSpec).when(webClientMock).post();
		doReturn(requestBodySpec).when(requestBodyUriSpec).uri(anyString());
		doReturn(requestHeadersMock).when(requestBodySpec).body(any());
		doReturn(requestHeadersMock).when(requestHeadersMock).headers(any());
		doReturn(monoResponse).when(requestHeadersMock).exchange();

		doReturn("1000").when(env).getProperty(any(), anyString());

		MultipleResponses response =  genericGatewayRequestClient.execute("callDefinitionName",
				Arrays.asList(mockRequest), type).block();
		if (responseLocation.contains("genericResponsePartialError")) {
			assertEquals(UPSTREAM_RESPONSE_PARTIAL_FAILURE, response.getOverallStatus());
			assertNotNull(response.getResponses().get("shopbiz_point_info").getError());
			assertEquals("404", response.getResponses().get("shopbiz_point_info").getError().getCode());
		} else {
			assertEquals(UPSTREAM_RESPONSE_SUCCESS, response.getOverallStatus());
			assertNull(response.getResponses().get("shopbiz_point_info").getError());
			assertNotNull(response.getResponses().get("shopbiz_point_info").getBodyMap());
		}
	}

	@Test
	void generic_gateway_http_request_no_request_type_expect_exception() {
		GenericGatewayUpstreamClient genericGatewayRequestClient = new GenericGatewayUpstreamClient(bffWebClientBuilder, env,
				serviceLogger);
		bffWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);

		Map<String, Object> mockRequest = Map.of(INTERFACE_KEY, "testKey", REQUEST_ID, "1");

		assertThrows(ClientException.class, () -> {
			genericGatewayRequestClient.execute("callDefinitionName", Arrays.asList(mockRequest), "").block();
		});
	}

	@Test
	void generic_gateway_400() {
		when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		GenericGatewayUpstreamClient genericGatewayUpstreamClient = new GenericGatewayUpstreamClient(bffWebClientBuilder, env,
				serviceLogger);
		bffWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		genericGatewayUpstreamClient.singleRequestWebClient = webClientMock;
		genericGatewayUpstreamClient.parallelRequestWebClient = webClientMock;
		genericGatewayUpstreamClient.complexRequestWebClient = webClientMock;

		Map<String, Object> mockRequest = Map.of(INTERFACE_KEY, "testKey", REQUEST_ID, "1");

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(webClientMock).when(bffWebClientBuilder).getWebClient(any());
		doReturn(builderMock).when(builderMock).clientConnector(any());
		doReturn(webClientMock).when(builderMock).build();
		doReturn(requestBodyUriSpec).when(webClientMock).post();
		doReturn(requestBodySpec).when(requestBodyUriSpec).uri(anyString());
		doReturn(requestHeadersMock).when(requestBodySpec).body(any());
		doReturn(requestHeadersMock).when(requestHeadersMock).headers(any());
		doReturn(monoResponse).when(requestHeadersMock).exchange();

		doReturn("1000").when(env).getProperty(any(), anyString());

		assertThrows(BackendException.class, () ->
				genericGatewayUpstreamClient.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_SINGLE).block());
	}

	@Test
	void generic_gateway_http_wrong_response_string_expect_error() {
		when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("{\"key\": \"value\"}"));
		GenericGatewayUpstreamClient genericGatewayUpstreamClient = new GenericGatewayUpstreamClient(bffWebClientBuilder, env,
				serviceLogger);
		bffWebClientBuilder.connectionProvider = ConnectionProvider.fixed(CONNECTION_POOL_NAME, 200);
		genericGatewayUpstreamClient.singleRequestWebClient = webClientMock;
		genericGatewayUpstreamClient.parallelRequestWebClient = webClientMock;
		genericGatewayUpstreamClient.complexRequestWebClient = webClientMock;

		Map<String, Object> mockRequest = Map.of(INTERFACE_KEY, "testKey", REQUEST_ID, "1");

		Mono monoResponse = Mono.just(clientResponse);
		doReturn(webClientMock).when(bffWebClientBuilder).getWebClient(any());
		doReturn(builderMock).when(builderMock).clientConnector(any());
		doReturn(webClientMock).when(builderMock).build();
		doReturn(requestBodyUriSpec).when(webClientMock).post();
		doReturn(requestBodySpec).when(requestBodyUriSpec).uri(anyString());
		doReturn(requestHeadersMock).when(requestBodySpec).body(any());
		doReturn(requestHeadersMock).when(requestHeadersMock).headers(any());
		doReturn(monoResponse).when(requestHeadersMock).exchange();

		doReturn("1000").when(env).getProperty(any(), anyString());

		assertThrows(BackendException.class, () ->
				genericGatewayUpstreamClient
						.execute("callDefinitionName", Arrays.asList(mockRequest), CALL_DEFINITION_TYPE_SINGLE).block());
	}
}
