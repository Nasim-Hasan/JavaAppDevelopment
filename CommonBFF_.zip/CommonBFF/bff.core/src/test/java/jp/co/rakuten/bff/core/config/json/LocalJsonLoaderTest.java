package jp.co.rakuten.bff.core.config.json;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class LocalJsonLoaderTest {

    private LocalJsonLoader localLoader;

    @DisplayName("Test load from local")
    @Test
    void testLoadMethodForException() {
        localLoader = new LocalJsonLoader();
        assertThrows(SystemException.class, () -> localLoader.load("sp.json", ApiTemplate.class));
    }
}
