package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.service.ExecutionPlanService;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.core.env.Environment;
import org.springframework.mock.env.MockEnvironment;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExecutionPlanServiceImplTest {

	private Environment env;
	private ExecutionPlanService executionPlanService;
	private ApiRepository apiRepository;

	@BeforeEach
	void setup() {
		env = TestUtil.getMockEnvironment();
		executionPlanService = new ExecutionPlanServiceImpl(env);
		apiRepository = ApiRepositoryTestUtil.getRepository();
	}

	@DisplayName("Dynamic conditional response check with parameterized test")
	@ParameterizedTest
	@CsvSource(value = {"shopbookmark.list.v1|mockfiles/user_request/shopbookmark_list_request_all_feature.json|mockfiles/executionPlan/shopbookmark_List_all_feature.json"}, delimiter = '|')
	void prepareExecutionPlan(String template, String request, String expected) {
		// given: gather api template, user request and expected execution plan from the file.
		ApiTemplate apiRepositoryTemplate = apiRepository.getApiRepositoryTemplate(template);
		RequestModel requestModel = TestUtil.getObjectFromFilename(request, RequestModel.class);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);
		ExecutionModel expectedOutput = TestUtil.getObjectFromFilename(expected, ExecutionModel.class);
		// when:
		ExecutionModel resultExecutionModel = executionPlanService
				.prepareExecutionPlan(clientRequestModel, apiRepositoryTemplate);
		// Then: should contain only the features and endpoints user requested.
		//check resulted endpoints
		assertEquals(expectedOutput.getRequiredInterfaces(), resultExecutionModel.getRequiredInterfaces());
		//check features
		// check upstreams

	}

	@DisplayName("Feature toggle service test")
	@ParameterizedTest
	@CsvSource(value = {
			"featureTogglingTestApi.ft.v1║mockfiles/user_request/feature_toggle_test1.json║mockfiles/executionPlan/feature_toggle_test1_expected.json",
	}, delimiter = '║')
	void FEATURE_TOGGLE_TEST(String apiKey, String requestFilename, String expectedFilename) {
		ApiTemplate apiRepositoryTemplate = apiRepository.getApiRepositoryTemplate(apiKey);
		RequestModel requestModel = TestUtil.getObjectFromFilename(requestFilename, RequestModel.class);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);
		clientRequestModel.setClientId("android");

		// when:
		ExecutionModel resultExecutionModel = executionPlanService
				.prepareExecutionPlan(clientRequestModel, apiRepositoryTemplate);
		assertEquals(3, resultExecutionModel.getDefaultResponse().size());
		assertEquals("[f2, f3, f4]", resultExecutionModel.getDefaultResponse().keySet().toString());
		assertEquals(1, ((Map) resultExecutionModel.getDefaultResponse().get("f2")).size());
		assertEquals(1, ((Map) resultExecutionModel.getDefaultResponse().get("f3")).size());
		assertEquals(1, ((Map) resultExecutionModel.getDefaultResponse().get("f4")).size());
	}

	@DisplayName("Default features should be included test")
	@ParameterizedTest
	@CsvSource(value = {
			"defaultFeaturesTestApi.df.v1║mockfiles/user_request/default_features_test1.json",
	}, delimiter = '║')
	void DEFAULT_FEATURES_TEST(String apiKey, String requestFilename) {
		ApiTemplate apiRepositoryTemplate = apiRepository.getApiRepositoryTemplate(apiKey);
		RequestModel requestModel = TestUtil.getObjectFromFilename(requestFilename, RequestModel.class);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);
		clientRequestModel.setClientId("android");

		// when:
		assertEquals(1, requestModel.getCommon().getInclude().size());
		ExecutionModel resultExecutionModel = executionPlanService
				.prepareExecutionPlan(clientRequestModel, apiRepositoryTemplate);
		assertEquals(3, resultExecutionModel.getFeatureModelList().size());
	}

	@DisplayName("Default features should not be excluded test")
	@Test
	void DEFAULT_FEATURES_NOT_EXLUCDED_TEST() {
		String apiKey = "defaultFeaturesTestApi.df.v1";
		String requestFilename = "mockfiles/user_request/default_features_test1.json";
		ApiTemplate apiRepositoryTemplate = apiRepository.getApiRepositoryTemplate(apiKey);
		RequestModel requestModel = TestUtil.getObjectFromFilename(requestFilename, RequestModel.class);
		requestModel.getCommon().setExclude(new HashSet<>(Set.of("f3")));
		requestModel.getCommon().setInclude(null);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);
		clientRequestModel.setClientId("android");

		// when:
		ClientException ex = Assertions.assertThrows(ClientException.class, () -> executionPlanService
				.prepareExecutionPlan(clientRequestModel, apiRepositoryTemplate));
		assertEquals("default features cannot be excluded: [f3, f5]", ex.getMessage());
	}

	@DisplayName("Interface is removed if connected subfeature is configued in props to be disabled")
	@ParameterizedTest
	@CsvSource(value = {
			"f1.shopList.disabled                                         | false    | true",
			"f2.shopList.disabled                                         | true     | false",
			"featureTogglingTestApi.ft.v1.f3.shopList.disabled            | true     | false",
			"f4.shopList.test.disabled                                    | true     | false",
			"f4.shopList.test.disabled                                    | true     | false",
			"f4.shopList.iphone.disabled                                  | true     | true",
			"f4.shopList.iphone.disabled                                  | true     | true",
			"featureTogglingTestApi.ft.v1.f5.shopList.test.disabled       | true     | false",
			"featureTogglingTestApi.ft.v1.f5.shopList.iphone.disabled     | true     | true",
	}, delimiter = '|')
	void SUB_FEATURE_TOGGLE_TEST(String subFeatureConfig, String configValue, boolean result) {
		String apiKey = "featureTogglingTestApi.ft.v1";
		String requestFilename = "mockfiles/user_request/feature_toggle_test1.json";

		MockEnvironment mockEnvironment = new MockEnvironment();
		mockEnvironment.setProperty(subFeatureConfig, configValue);

		ExecutionPlanServiceImpl executionPlanService = new ExecutionPlanServiceImpl(mockEnvironment);
		executionPlanService.onRefresh(null);
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate apiRepositoryTemplate = apiRepository.getApiRepositoryTemplate(apiKey);
		RequestModel requestModel = TestUtil.getObjectFromFilename(requestFilename, RequestModel.class);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);
		clientRequestModel.setClientId("test");
		apiRepositoryTemplate.getFeaturesMap().forEach((featureName, template) -> {
			template.setSubFeatures(Map.of("shopList", List.of("shopbookmark_list")));
		});

		// when:
		ExecutionModel resultExecutionModel = executionPlanService
				.prepareExecutionPlan(clientRequestModel, apiRepositoryTemplate);
		assertEquals(result, resultExecutionModel.getRequiredInterfaces().contains("shopbookmark_list"));
	}
}
