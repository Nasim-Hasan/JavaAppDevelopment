package jp.co.rakuten.bff.core.instrumentation.prometheus;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * @author prithviraj.pawar
 */
public class BffGatewayMetricsManagerTest {
	private MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void initSuccess() throws MalformedObjectNameException {
		//When:
		BffUpstreamMetricsManager.initialize();

		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests:name=single,type=counters")), true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests.time:name=single,type=counters")),
					 true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests:name=complex,type=counters")), true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests.time:name=complex,type=counters")),
					 true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests:name=parallel,type=counters")), true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.gateway.requests.time:name=parallel,type=counters")),
					 true);

	}

	@Test
	public void markEntry() {
		//No error
		BffUpstreamMetricsManager.markEntry("single");
	}

	@Test
	public void markExit() {
		//given:
		String requestType = "single";
		String overallStatusCode = "PARTIAL_FAILURE";
		String httpCode = "404";

		//No error
		BffUpstreamMetricsManager.markExit(requestType, overallStatusCode, httpCode);

		BffUpstreamMetricsManager.markExit(requestType, null, httpCode);

		BffUpstreamMetricsManager.markExit(requestType, null, null);

		BffUpstreamMetricsManager.markExit(requestType, overallStatusCode, null);


	}

}
