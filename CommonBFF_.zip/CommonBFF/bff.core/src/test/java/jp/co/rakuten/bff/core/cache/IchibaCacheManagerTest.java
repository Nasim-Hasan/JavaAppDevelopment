package jp.co.rakuten.bff.core.cache;

import com.github.benmanes.caffeine.cache.Cache;
import io.micrometer.core.instrument.MeterRegistry;
import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.event.OnInterfacesLoadedEvent;
import jp.co.rakuten.bff.core.model.CacheDataModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.RequestSchema;
import org.apache.commons.lang3.BooleanUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveValueOperations;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

class IchibaCacheManagerTest {
	private static final String TEST_INTERFACE = "test_interface";
	private static final String TEST_INTERFACE2 = "test_interface_2";
	@InjectMocks
	IchibaCacheManager ichibaCacheManager;
	Map<String, CommonRequestModel> validatedRequest;
	@Mock
	private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;
	@Mock
	private ReactiveValueOperations reactiveValueOperations;
	@Mock
	private OnInterfacesLoadedEvent event;
	@Spy
	private IchibaCacheManagerHelper ichibaCacheManagerHelper;
	@Mock
	private MeterRegistry meterRegistry;
	private HttpHeaders headers;
	private ApiTemplate apiTemplate;
	private InterfaceConfig interfaceConfig;

	private static Map<String, Object> getCallDefinitionResponse() {
		Map<String, Object> response = new HashMap();
		response.put("body", Map.of("code", 200, "message", "test response"));
		return response;
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		headers = new HttpHeaders();
		headers.setCacheControl(BffConstants.CACHE_HEADER_NO_CACHE);
		interfaceConfig = getInterfaceConfig();
		validatedRequest = Map.of("test", new CommonRequestModel());
	}

	@AfterEach
	void tearDown() {

	}

	@DisplayName("getFromCache Test: cache contains data")
	@Test
	void testGetFromCache() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNotNull(resultData);
		assertNotNull(resultData.getCacheMap());
		assertEquals("test response", ((Map) (resultData.getCacheMap().get("body"))).get("message"));
		assertFalse(BooleanUtils.toBoolean(String.valueOf(resultData.getCacheMap().get("isStaleCache"))));
	}

	@DisplayName("getFromCache Test: cache contains data")
	@Test
	void testGetFromCacheOverload() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData =
				ichibaCacheManager.getFromCache("testKey", featureTemplate.getName(), null)
						.block();

		// Then
		assertNotNull(resultData);
		assertNotNull(resultData.getCacheMap());
		assertEquals("test response", ((Map) (resultData.getCacheMap().get("body"))).get("message"));
		assertFalse(BooleanUtils.toBoolean(String.valueOf(resultData.getCacheMap().get("isStaleCache"))));
	}

	@DisplayName("getFromCache Test: Cache doesnt contain data")
	@Test
	void testProcessingModelValidationSuccess() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.empty()).when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNull(resultData);
	}

	@DisplayName("getFromCache Test: Cache contains stale data")
	@Test
	void testGetFromCache_Stale()
			throws IOException {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNotNull(resultData);
		assertNotNull(resultData.getCacheMap());
		assertEquals("test response", ((Map) (resultData.getCacheMap().get("body"))).get("message"));
		assertTrue(resultData.isStaleCache());
	}

	@DisplayName("getFromCache Test: Exception during caching process")
	@Test
	void testGetFromCache_Exception() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.error(new RuntimeException("test error"))).when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		Exception e = assertThrows(RuntimeException.class, () -> {
			ichibaCacheManager.
					getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		});
		assertEquals("test error", e.getMessage());
	}

	@DisplayName("getFromCache Test: cache-control header is 'no-cache'")
	@Test
	void testGetFromCache_CacheControlHeader() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse().entrySet().stream().findFirst().get()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		doReturn(true).when(ichibaCacheManagerHelper).isNoCacheSet(any());

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel result = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, headers, featureTemplate.getName()).block();

		// Then
		assertNull(result);
	}

	@DisplayName("getFromCache Test: cache-control header is 'no-cache' and is ignored in ecstatic method")
	@Test
	void testGetFromCache_CacheControlOverloadHeader() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel result =
				ichibaCacheManager.getFromCache("testKey", featureTemplate.getName(), headers).block();

		// Then
		assertNotNull(result);
	}

	@DisplayName("setToCache Test: cache type is local")
	@Test
	void testGetFromCache_LocalCache() {
		// Setup
		interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "local");
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When: set data to local cache
		boolean resultData = ichibaCacheManager
				.setToCache(featureTemplate, validatedRequest, getCallDefinitionResponse(), null,
							featureTemplate.getName()).block();

		// Then
		assertTrue(resultData);

		// When: get data from local cache
		CacheDataModel result = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNotNull(result);
		assertNotNull(result.getCacheMap().get("body"));
		assertEquals("test response", ((Map) result.getCacheMap().get("body")).get("message"));
		assertEquals(200, ((Map) result.getCacheMap().get("body")).get("code"));
	}

	@DisplayName("setToCache Test: cache type is local")
	@Test
	void testsetToCacheOverload_LocalCache() {
		// Setup
		interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "local");
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When: set data to local cache
		boolean resultData = ichibaCacheManager
				.setToCache("testKey", getCallDefinitionResponse(),
							featureTemplate.getName(), null).block();

		// Then
		assertTrue(resultData);

		// When: get data from local cache
		CacheDataModel result =
				ichibaCacheManager.getFromCache("testKey", featureTemplate.getName(), null)
						.block();

		// Then
		assertNotNull(result);
		assertNotNull(result.getCacheMap().get("body"));
		assertEquals("test response", ((Map) result.getCacheMap().get("body")).get("message"));
		assertEquals(200, ((Map) result.getCacheMap().get("body")).get("code"));
	}

	@DisplayName("setToCache Test: cache type is shared")
	@Test
	void testGetFromCache_SharedCache() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(true)).when(reactiveValueOperations).set(any(), any(), any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Mono.just(true)).when(reactiveRedisTemplate).expire(any(), any());
		interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "shared");
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When: set data to shared cache
		boolean resultData = ichibaCacheManager
				.setToCache(featureTemplate, validatedRequest, getCallDefinitionResponse(), null,
							featureTemplate.getName()).block();

		// Then
		assertTrue(resultData);

		// When: get data from shared cache
		CacheDataModel result = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNotNull(result);
		assertNotNull(result.getCacheMap().get("body"));
		assertEquals("test response", ((Map) result.getCacheMap().get("body")).get("message"));
		assertEquals(200, ((Map) result.getCacheMap().get("body")).get("code"));
	}

	@DisplayName("setToCache Test: Cache type is localAndShared, local cache has data and shared cache is empty")
	@Test
	void testGetFromCache_SharedCacheEmpty() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.empty()).when(reactiveValueOperations).get(any());
		doReturn(Mono.just(true)).when(reactiveValueOperations).set(any(), any(), any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Mono.just(true)).when(reactiveRedisTemplate).expire(any(), any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When: set data to shared cache
		boolean resultData = ichibaCacheManager
				.setToCache(featureTemplate, validatedRequest, getCallDefinitionResponse(), null,
							featureTemplate.getName()).block();

		// Then
		assertTrue(resultData);

		// When: get data from shared cache
		CacheDataModel result = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();

		// Then
		assertNotNull(result);
		assertNotNull(result.getCacheMap().get("body"));
		assertEquals("test response", ((Map) result.getCacheMap().get("body")).get("message"));
		assertEquals(200, ((Map) result.getCacheMap().get("body")).get("code"));
	}

	@DisplayName("getFromCache Test: error getting data from local cache")
	@Test
	void testGetFromCache_error() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(Collections.singletonMap("testKey", "testValue").entrySet().stream().findFirst().get()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		boolean result = ichibaCacheManager.setToLocalCache(null, "test", new HashMap<>());

		// Then
		assertFalse(result);
	}

	@DisplayName("getFromCache Test: cache configuration is unavailable")
	@Test
	void testGetFromCache_EmptyConfig() {
		// Given
		Cache<String, Map<String, Object>> cacheHandler = null;

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache("key", null, cacheHandler, new RedisCacheStats()).block();

		// Then
		assertNull(resultData);
	}

	@DisplayName("getFromCache Test: cache disabled via http cache-control header")
	@Test
	void testGetFromCache_CacheOff() {
		// When
		CacheDataModel resultData =
				ichibaCacheManager.getFromCache("key", "", headers).block();

		// Then
		assertNull(resultData);
	}

	@DisplayName("setToCache Test: cache disabled via http cache-control header")
	@Test
	void testsetToCache_CacheOff() {
		// When
		Boolean apiKey = ichibaCacheManager
				.setToCache(new FeatureTemplate(), new HashMap<>(), new HashMap<>(), headers, "apiKey").block();

		// Then
		assertNull(apiKey);
	}

	@DisplayName("setToCache Test: cache disabled via http cache-control header and is ignored in ecstatic method")
	@Test
	void testsetToCacheOverload_CacheOff() {
		// Setup
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(true)).when(reactiveValueOperations).set(any(), any(), any());
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Mono.just(true)).when(reactiveRedisTemplate).expire(any(), any());
		interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "shared");
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
		applyHelperMock();

		// Given
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		Boolean apiKey =
				ichibaCacheManager
						.setToCache("cacheKey", new HashMap<>(), featureTemplate.getName(), headers).block();

		// Then
		assertNotNull(apiKey);
		assertTrue(apiKey);
	}

	@DisplayName("setToCache Test: cache disabled via http cache-control header")
	@Test
	void testMainSetToCacheOverload_CacheOff() {
		// Given
		Cache<String, Map<String, Object>> cacheHandler = null;

		// When
		Boolean apiKey =
				ichibaCacheManager
						.setToCache(new HashMap<>(), "cacheKey", null, cacheHandler).block();

		// Then
		assertNull(apiKey);
	}

	@DisplayName("cacheStats Test: fetch shared cache hit count")
	@Test
	void testSharedCacheHitCount() {
		// Setup
		applyStatsMock(TEST_INTERFACE);
		applyHelperMock();

		// Given
		long limit = 5;
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		Map<String, RedisCacheStats> sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		RedisCacheStats redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getHitCount());

		// Setup
		applyStatsMock(TEST_INTERFACE2);
		applyHelperMock();

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE2);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE2);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getHitCount());

		// Setup
		applyStatsMock(TEST_INTERFACE);
		applyHelperMock();

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		for (int i = 1; i < limit; i++) {
			ichibaCacheManager.
					getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		}
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(limit, redisCacheStats.getHitCount());
		assertEquals(1, sharedCacheStats.get(TEST_INTERFACE2).getHitCount());
	}

	@DisplayName("cacheStats Test: fetch shared cache miss count")
	@Test
	void testSharedCacheMissCount() {
		// Setup
		applyStatsMissMock(TEST_INTERFACE);
		applyHelperMock();

		// Given
		long limit = 5;
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		Map<String, RedisCacheStats> sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		RedisCacheStats redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getMissCount());

		// Setup
		applyStatsMissMock(TEST_INTERFACE2);
		applyHelperMock();

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE2);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE2);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getMissCount());

		// Setup
		applyStatsMissMock(TEST_INTERFACE);
		applyHelperMock();

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		for (int i = 1; i < limit; i++) {
			ichibaCacheManager.
					getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		}
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(limit, redisCacheStats.getMissCount());
		assertEquals(1, sharedCacheStats.get(TEST_INTERFACE2).getMissCount());

	}

	@DisplayName("cacheStats Test: fetch shared cache stale count")
	@Test
	void testSharedCacheStaleCount() {
		// Setup
		applyStatsMock(TEST_INTERFACE);
		applyHelperMock();
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());

		// Given
		long limit = 5;
		FeatureTemplate featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		CacheDataModel resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		Map<String, RedisCacheStats> sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		RedisCacheStats redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getStaleCount());

		// Setup
		applyStatsMock(TEST_INTERFACE2);
		applyHelperMock();
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE2);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		resultData = ichibaCacheManager
				.getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE2);
		assertNotNull(redisCacheStats);
		assertEquals(1, redisCacheStats.getStaleCount());

		// Setup
		applyStatsMock(TEST_INTERFACE);
		applyHelperMock();
		doReturn(Mono.just(Duration.ofMillis(30000))).when(reactiveRedisTemplate).getExpire(any());

		// Given
		featureTemplate = getFeatureTemplate(TEST_INTERFACE);
		ichibaCacheManager.onApplicationEvent(event);

		// When
		for (int i = 1; i < limit; i++) {
			ichibaCacheManager.
					getFromCache(featureTemplate, validatedRequest, null, featureTemplate.getName()).block();
		}
		sharedCacheStats = ichibaCacheManager.getSharedCacheStats();

		// Then
		redisCacheStats = sharedCacheStats.get(TEST_INTERFACE);
		assertNotNull(redisCacheStats);
		assertEquals(limit, redisCacheStats.getStaleCount());
		assertEquals(1, sharedCacheStats.get(TEST_INTERFACE2).getStaleCount());
	}

	@DisplayName("onApplicationEvent Test: onApplicationEvent throws error and it is consumed")
	@Test
	void testLocalCacheStatsException() {
		// Given
		IchibaCacheManager ichibaCacheManager = new IchibaCacheManager(null, null, null);

		// When
		ichibaCacheManager.onApplicationEvent(null);
	}

	@DisplayName("getFromCache Test: cache disabled")
	@Test
	void testGetFromCache_CacheDisabled() {
		// When
		CacheDataModel cacheData = ichibaCacheManager
				.getFromCache(new FeatureTemplate(), null, null, null).block();

		// Then
		assertNull(cacheData);
	}

	@DisplayName("getFromCache Test: cache disabled")
	@Test
	void testGetFromCacheOverload_CacheDisabled() {
		// When
		CacheDataModel cacheData = ichibaCacheManager
				.getFromCache(null, null, null).block();

		// Then
		assertNull(cacheData);
	}

	@DisplayName("setToCache Test: cache disabled")
	@Test
	void testSetToCache_CacheDisabled() {
		// When
		Boolean cacheData = ichibaCacheManager
				.setToCache(new FeatureTemplate(), null, null, null, null).block();

		// Then
		assertNull(cacheData);
	}

	@DisplayName("setToCache Test: cache disabled")
	@Test
	void testSetToCacheOverload_CacheDisabled() {
		// When
		Boolean cacheData = ichibaCacheManager
				.setToCache(null, null, null, new HttpHeaders()).block();

		// Then
		assertNull(cacheData);
	}

	private FeatureTemplate getFeatureTemplate(String templateName) {
		FeatureTemplate featureTemplate = new FeatureTemplate();
		featureTemplate.setName(templateName);
		CommonSchema commonSchema = new CommonSchema();
		commonSchema.setName("version");
		commonSchema.setCacheKey("true");
		CommonSchema commonSchema2 = new CommonSchema();
		commonSchema2.setName("easyId");
		commonSchema2.setCacheKey("true");
		RequestSchema requestSchema = new RequestSchema();
		requestSchema.setParameters(List.of(commonSchema, commonSchema2));

		featureTemplate.setRequest(requestSchema);
		return featureTemplate;
	}

	private InterfaceConfig getInterfaceConfig() {
		return getInterfaceConfig(TEST_INTERFACE);
	}

	private InterfaceConfig getInterfaceConfig(String interfaceName) {
		InterfaceConfig testInterface = new InterfaceConfig(interfaceName);
		testInterface.putToCacheConfigMap(ENABLED_PROP_KEY, "true");
		testInterface.putToCacheConfigMap(LOCAL_TIMEOUT_PROP_KEY, "50000");
		testInterface.putToCacheConfigMap(SHARED_TIMEOUT_PROP_KEY, "120000");
		testInterface.putToCacheConfigMap(LOCAL_MAX_SIZE_PROP_KEY, "100");
		testInterface.putToCacheConfigMap(TYPE_PROP_KEY, "local_and_shared");
		testInterface.putToCacheConfigMap(STALE_ENABLED_PROP_KEY, "true");
		testInterface.putToCacheConfigMap(STALE_TIMEOUT_PROP_KEY, "160000");
		return testInterface;
	}

	private void applyHelperMock() {
		doReturn(false).when(ichibaCacheManagerHelper).hasDifference(any(), any());
		doReturn(IchibaCacheConfiguration.getInstance(interfaceConfig.getCacheConfigMap()))
				.when(ichibaCacheManagerHelper).getIchibaCacheConfiguration(any(), any());
	}

	private void applyStatsMock(String interfaceName) {
		InterfaceConfig interfaceConfig = getInterfaceConfig(interfaceName);
		this.interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "shared");
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.just(getCallDefinitionResponse()))
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
	}

	private void applyStatsMissMock(String interfaceName) {
		InterfaceConfig interfaceConfig = getInterfaceConfig(interfaceName);
		interfaceConfig.putToCacheConfigMap(TYPE_PROP_KEY, "shared");
		doReturn(reactiveValueOperations).when(reactiveRedisTemplate).opsForValue();
		doReturn(Mono.empty())
				.when(reactiveValueOperations).get(any());
		doReturn(Mono.just(Duration.ofMillis(200000))).when(reactiveRedisTemplate).getExpire(any());
		doReturn(Collections.singletonList(interfaceConfig)).when(event).getInterfaceConfigs();
	}
}
