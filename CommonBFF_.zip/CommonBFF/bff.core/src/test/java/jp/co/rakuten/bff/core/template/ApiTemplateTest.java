package jp.co.rakuten.bff.core.template;

import jp.co.rakuten.bff.core.model.ApiDetail;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;


public class ApiTemplateTest {

    private  ApiTemplate apiTemplate = new ApiTemplate();
    private ApiDetail apiDetail = new ApiDetail("a.b.c");


    @Test
    void setValidatorNameTest(){
        apiTemplate.setValidatorName("testValidator");
        assertEquals("testValidator", apiTemplate.getValidatorName());
    }

    @Test
    void getServiceOperationVersionTest(){

        apiTemplate.setApiDetail(apiDetail);
        apiTemplate.getService();
        apiTemplate.getOperation();
        apiTemplate.getVersion();
        assertEquals("a", apiTemplate.getService());
        assertEquals("b", apiTemplate.getOperation());
        assertEquals("c", apiTemplate.getVersion());
    }

    @Test
    void isFromExternalTest(){

        apiTemplate.setFromExternal(false);
        apiTemplate.isFromExternal();
        assertEquals(false, apiTemplate.isFromExternal());
    }

}
