package jp.co.rakuten.bff.core.processors;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class InterfaceProcessorTest implements InterfaceProcessor {

   Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
   GenericCallDefinitionProcessedData genericCallDefinitionProcessedData = new GenericCallDefinitionProcessedData();
   Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

    @DisplayName("test the preProcess method")
    @Test
    void testPreProcess(){
        boolean response = InterfaceProcessor.super.preProcess(validatedRequest,genericCallDefinitionProcessedData,callDefinitionResponseMap);
        assertTrue(response);
    }
}
