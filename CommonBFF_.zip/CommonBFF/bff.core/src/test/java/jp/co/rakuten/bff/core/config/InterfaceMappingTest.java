package jp.co.rakuten.bff.core.config;

import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class InterfaceMappingTest {


	private final String SAMPLE_INTERFACE_KEY_1 = "shopbookmark_list";
	private final String SAMPLE_GROUP_KEY_1 = "shopbookmark";
	private final String SAMPLE_INTERFACE_KEY_2 = "shopbiz_shopmaster";
	private final String SAMPLE_GROUP_KEY_2 = "shopbiz";

	@Test
	public void testAllMethods() throws Exception {
		// Setup:

		// Given:
		Map interfaces = Map.of(SAMPLE_INTERFACE_KEY_1, SAMPLE_GROUP_KEY_1, SAMPLE_INTERFACE_KEY_2, SAMPLE_GROUP_KEY_2);
		InterfaceConfigurationProperties interfaceConfigurationProperties = new InterfaceConfigurationProperties();
		interfaceConfigurationProperties.setMapping(interfaces);

		// When:
		InterfaceMapping interfaceMapping = new InterfaceMapping(interfaceConfigurationProperties);

		// Verify Response: Assert values through getter
		IInterface firstInterface = interfaceMapping.getMapping().get(SAMPLE_INTERFACE_KEY_1);
		assertNotNull(firstInterface);
		assertEquals(SAMPLE_INTERFACE_KEY_1, firstInterface.getInterfaceKey());
		assertEquals(SAMPLE_GROUP_KEY_1, firstInterface.getGroupKey());

		IInterface secondInterface = interfaceMapping.getMapping().get(SAMPLE_INTERFACE_KEY_2);
		assertNotNull(secondInterface);
		assertEquals(SAMPLE_INTERFACE_KEY_2, secondInterface.getInterfaceKey());
		assertEquals(SAMPLE_GROUP_KEY_2, secondInterface.getGroupKey());

		// Verify Mock: N/A

	}

	@Test
	public void testEmptyInterfaceMap() throws Exception {
		// Setup:

		// Given: InterfaceConfigProperties with empty map
		Map interfaces = Map.of();
		InterfaceConfigurationProperties interfaceConfigurationProperties = new InterfaceConfigurationProperties();
		interfaceConfigurationProperties.setMapping(interfaces);

		// When: Instantiated by constructor and refreshMapping()
		InterfaceMapping interfaceMapping = new InterfaceMapping(interfaceConfigurationProperties);

		// Verify Response:  Assert that map is empty too
		assertTrue(MapUtils.isEmpty(interfaceMapping.getMapping()));

		// Verify Mock: N/A
	}

}