package jp.co.rakuten.bff.core.util;

import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.NotAcceptableStatusException;
import org.springframework.web.server.UnsupportedMediaTypeStatusException;

import javax.validation.ValidationException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.core.exception.type.ClientErrorEnum.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ResponseUtilTest {

	@Mock
	Tracer tracer;
	ResponseUtil responseUtil;
	ApiRepositoryTestUtil apiRepositoryTestUtil;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
		responseUtil = new ResponseUtil(tracer);
		apiRepositoryTestUtil = new ApiRepositoryTestUtil();
	}

	@DisplayName("prepare error responses when message is not empty")
	@ParameterizedTest
	@CsvSource(value = {"empty| |unknown error", "||unknown error", "error1|error2|error1",
			"error;abc||error"}, delimiter = '|')
	void prepareErrorResponsesWhenMessageIsNotEmpty(String message, String errorMessage, String expected) {
		//given:
		if ("empty".equals(message)) {
			message = " ";
		}
		Map error = TestUtil.mapOf("message", message, "error", errorMessage);
		int code = 400;
		// when:
		Map errorResponses = ResponseUtil.prepareErrorResponses(error, code);
		//then:
		assertEquals(expected, ((Map) errorResponses.get(BffConstants.ERROR)).get(BffConstants.MESSAGE));
		assertEquals(code, ((Map) errorResponses.get(BffConstants.ERROR)).get(BffConstants.CODE));
		assertEquals(BffConstants.UPSTREAM_RESPONSE_FAILURE, errorResponses.get(BffConstants.STATUS));
	}

	@DisplayName("extract error code from exception")
	@Test
	void extractErrorCodeFromException() {
		//given:
		int status = 555;
		Map error = TestUtil.mapOf("message", "", "error", null, "status", status);
		SystemException exception =
				SystemException.create(SystemErrorEnum.INTERNAL, new NullPointerException("null"), "error");
		// when:
		int result = ResponseUtil.extractStatus(error, exception);
		//then:
		assertEquals(SystemErrorEnum.INTERNAL.getErrorCode().value(), result);

		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);

		//given:
		status = HttpStatus.NOT_FOUND.value();
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		ClientException clientException =
				ClientException.create(BAD_REQUEST, new NullPointerException("null"), "error");
		// when:
		result = ResponseUtil.extractStatus(error, clientException);
		//then:
		assertEquals(BAD_REQUEST.getErrorCode().value(), result);


		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		// when:
		result = ResponseUtil.extractStatus(error, new Exception("exception"));
		//then:
		assertEquals(status, result);

		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		// when:
		result = ResponseUtil.extractStatus(error, new ValidationException("invalid data"));
		//then:
		assertEquals(HttpStatus.BAD_REQUEST.value(), result);

		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		// when:
		result = ResponseUtil.extractStatus(error, new UnsupportedMediaTypeStatusException("Unsupported data"));
		//then:
		assertEquals(HttpStatus.BAD_REQUEST.value(), result);

		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		// when:
		result = ResponseUtil.extractStatus(error, new NotAcceptableStatusException("Not acceptable"));
		//then:
		assertEquals(HttpStatus.BAD_REQUEST.value(), result);

		//given:
		status = 123;
		error = TestUtil.mapOf("message", null, "error", null, "status", status);
		// when:
		result = ResponseUtil.extractStatus(error, new MethodNotAllowedException("Method not allowed", null));
		//then:
		assertEquals(HttpStatus.BAD_REQUEST.value(), result);

	}

	@DisplayName("test catch exception and build api response")
	@Test
	void catchExceptionAndBuildApiResponseTest() {
		FeatureException exception = FeatureException.create("test", BAD_REQUEST, "from test");

		ResponseEntity<Map> entity = responseUtil.catchExceptionAndBuildApiResponse(exception, null);

		assertNotNull(entity);
		assertEquals(400, entity.getStatusCode().value());
		assertEquals("FAILURE", entity.getBody().get("status"));

		assertEquals(400, ((Map) ((Map) ((Map) entity.getBody().get("body")).get("test")).get("error")).get("code"));
		assertEquals("from test",
					 ((Map) ((Map) ((Map) entity.getBody().get("body")).get("test")).get("error")).get("message"));
	}

	@DisplayName("Test getFeatureErrorResponseMap format")
	@Test
	void getFeatureErrorResponseMapTest() {
		//given
		String message = "message";
		int code = HttpStatus.BAD_REQUEST.value();
		Map expected = Map.of(BffConstants.ERROR, Map.of(BffConstants.CODE, code, BffConstants.MESSAGE, message));
		//when:
		Map<String, Object> result = ResponseUtil.getFeatureErrorResponseMap(message, code);
		assertEquals(expected, result);
	}

	@DisplayName("Check if x-traceId appended in responseheader")
	@Test
	void catchExceptionAndBuildApiResponseWithTraceId() {
		String traceId = appendTraceIdToTracer();

		FeatureException exception = FeatureException.create("test", BAD_REQUEST, "from test");
		ResponseEntity<Map> entity = responseUtil.catchExceptionAndBuildApiResponse(exception, null);

		assertNotNull(entity);
		assertEquals(400, entity.getStatusCode().value());
		assertEquals("FAILURE", entity.getBody().get("status"));

		assertEquals(400, ((Map) ((Map) ((Map) entity.getBody().get("body")).get("test")).get("error")).get("code"));
		assertEquals("from test",
					 ((Map) ((Map) ((Map) entity.getBody().get("body")).get("test")).get("error")).get("message"));

		assertEquals(traceId, entity.getHeaders().get(BffConstants.X_TRACE_ID).get(0));
	}

	@DisplayName("Check if x-traceId appended in prepareAPIResponse-single")
	@Test
	void prepareAPIResponseTestWithTraceIdAndProperValues() {
		//given:
		String traceId = appendTraceIdToTracer();
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate roomFeedTemplateSingle = apiRepository.getApiRepositoryTemplate("room.feed.v1");
		Map data = Map.of("header", Map.of("one", "two"),
						  "contents", Map.of("other", "contents"));
		Map header = Map.of("header1", "v1", "header2", "v2");
		Map<String, Object> responseMap = Map.of("roomFeedInfo",
												 Map.of(BffConstants.DATA, data, BffConstants.HEADER, header));
		// when:
		ResponseEntity<Map> responseEntity =
				responseUtil.prepareAPIResponse(responseMap, roomFeedTemplateSingle, null).block();
		// then:
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(BffConstants.UPSTREAM_RESPONSE_SUCCESS, responseEntity.getBody().get(BffConstants.STATUS));
		Map body = (Map) responseEntity.getBody().get(BffConstants.BODY);
		// should contain only one feature
		assertEquals(1, body.size());
		// feature response success:
		Map featureResponse = (Map) body.get("roomFeedInfo");
		// will only contain data/error (this will also check header will not include accidentally)
		assertEquals(1, featureResponse.size());
		// as success should only contain DATA.
		assertEquals(data, featureResponse.get(BffConstants.DATA));

		// check if all headers included.
		header.forEach((o, o2) -> {
			assertEquals(o2, responseEntity.getHeaders().get(o).get(0));
		});
		// also check if traceId included.
		assertEquals(traceId, responseEntity.getHeaders().get(BffConstants.X_TRACE_ID).get(0));
	}


	@DisplayName("Check if x-traceId appended in prepareAPIResponse-multi feature")
	@Test
	void prepareAPIResponseTestWithTraceIdAndProperValuesMultiFeature() {
		//given:
		String traceId = appendTraceIdToTracer();
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate roomFeedTemplateSingle = apiRepository.getApiRepositoryTemplate("shopbookmark.list_1.v1");
		Map dataCoupon = Map.of("coupon", Map.of("one", "two"),
								"contents", Map.of("other", "contents"));
		Map headerCoupon = Map.of("header1", "v1", "header2", "v2");
		Map errorShopbookmarkList = ResponseUtil.getFeatureErrorResponseMap("unable to find data", 404);

		Map<String, Object> responseMap = Map.of("coupon",
												 Map.of(BffConstants.DATA, dataCoupon, BffConstants.HEADER,
														headerCoupon),
												 "shopbookmark_list", errorShopbookmarkList);
		// when:
		ResponseEntity<Map> responseEntity = responseUtil.prepareAPIResponse(responseMap, roomFeedTemplateSingle, null)
				.block();
		// then:
		assertEquals(HttpStatus.MULTI_STATUS, responseEntity.getStatusCode());
		assertEquals(BffConstants.UPSTREAM_RESPONSE_PARTIAL_FAILURE, responseEntity.getBody().get(BffConstants.STATUS));
		Map body = (Map) responseEntity.getBody().get(BffConstants.BODY);
		// should contain only one feature
		assertEquals(2, body.size());
		// feature response success:
		Map featureResponseCoupon = (Map) body.get("coupon");
		// will only contain data/error (this will also check header will not include accidentally)
		assertEquals(1, featureResponseCoupon.size());
		// as success should only contain DATA.
		assertEquals(dataCoupon, featureResponseCoupon.get(BffConstants.DATA));


		// feature response success:
		Map featureResponseSBList = (Map) body.get("shopbookmark_list");
		// will only contain data/error (this will also check header will not include accidentally)
		assertEquals(1, featureResponseCoupon.size());
		// as success should only contain DATA.
		assertEquals(errorShopbookmarkList, featureResponseSBList);

		// check if all headers included.
		headerCoupon.forEach((o, o2) -> {
			assertEquals(o2, responseEntity.getHeaders().get(o).get(0));
		});
		// also check if traceId included.
		assertEquals(traceId, responseEntity.getHeaders().get(BffConstants.X_TRACE_ID).get(0));
	}


	@DisplayName("Check if x-traceId appended in prepareAPIResponse-multi feature with same header keys")
	@Test
	void prepareAPIResponseTestWithTraceIdAndProperValuesMultiFeatureWithSameHeaderKey() {
		//given:
		String traceId = appendTraceIdToTracer();
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate roomFeedTemplateSingle = apiRepository.getApiRepositoryTemplate("shopbookmark.list_1.v1");
		Map dataCoupon = Map.of("coupon", Map.of("one", "two"),
								"contents", Map.of("other", "contents"));
		Map headerCoupon = Map.of("header1", "v1", "header2", "v2", "header3", "h3");
		Map errorShopbookmarkList = new HashMap(ResponseUtil.getFeatureErrorResponseMap("unable to find data", 404));
		Map headerShopBookmark = Map.of("header11", "v11", "header2", "v3", "header3", "h3");
		errorShopbookmarkList.put(BffConstants.HEADER, headerShopBookmark);

		Map<String, Object> responseMap = Map.of("coupon",
												 Map.of(BffConstants.DATA, dataCoupon, BffConstants.HEADER,
														headerCoupon),
												 "shopbookmark_list", errorShopbookmarkList);
		// when:
		ResponseEntity<Map> responseEntity = responseUtil.prepareAPIResponse(responseMap, roomFeedTemplateSingle, null)
				.block();
		// then:
		assertEquals(HttpStatus.MULTI_STATUS, responseEntity.getStatusCode());
		assertEquals(BffConstants.UPSTREAM_RESPONSE_PARTIAL_FAILURE, responseEntity.getBody().get(BffConstants.STATUS));
		Map body = (Map) responseEntity.getBody().get(BffConstants.BODY);
		// should contain only one feature
		assertEquals(2, body.size());
		// feature response success:
		Map featureResponseCoupon = (Map) body.get("coupon");
		// will only contain data/error (this will also check header will not include accidentally)
		assertEquals(1, featureResponseCoupon.size());
		// as success should only contain DATA.
		assertEquals(dataCoupon, featureResponseCoupon.get(BffConstants.DATA));


		// feature response success:
		Map featureResponseSBList = (Map) body.get("shopbookmark_list");
		// will only contain data/error (this will also check header will not include accidentally)
		assertEquals(1, featureResponseCoupon.size());
		// as success should only contain DATA.
		assertEquals(errorShopbookmarkList.get(BffConstants.ERROR), featureResponseSBList.get(BffConstants.ERROR));

		// check if all headers included.
		headerCoupon.forEach((o, o2) -> {
			assertTrue(responseEntity.getHeaders().get(o).contains(o2));
		});

		headerShopBookmark.forEach((o, o2) -> {
			assertTrue(responseEntity.getHeaders().get(o).contains(o2));
		});
		// Check multiple values for same key but different values.
		assertEquals(2, responseEntity.getHeaders().get("header2").size());
		// had same key and same value
		assertEquals(2, responseEntity.getHeaders().get("header3").size());

		// also check if traceId included.
		assertEquals(traceId, responseEntity.getHeaders().get(BffConstants.X_TRACE_ID).get(0));
	}

	@DisplayName("extractBodyAndHeader when cacheControl is no-cache and any other")
	@Test
	void extractBodyAndHeaderTest(){

		//given
		FeatureException exception = FeatureException.create("test", BAD_REQUEST, "from test");
		HttpHeaders headers = new HttpHeaders();
		headers.setCacheControl(BffConstants.CACHE_HEADER_NO_CACHE);
		ClientRequestModel clientRequestModel = new ClientRequestModel("a","b","c",new RequestModel(),"client", headers);

		//when
		ResponseEntity<Map> entity = responseUtil.catchExceptionAndBuildApiResponse(exception, clientRequestModel);

		//then
		assertEquals("no-store",entity.getHeaders().getCacheControl());

		//given
		headers.remove(BffConstants.CACHE_HEADER_NO_CACHE);
		headers.setCacheControl("cache");
		clientRequestModel = new ClientRequestModel("a","b","c",new RequestModel(),"client", headers);

		//when
		entity = responseUtil.catchExceptionAndBuildApiResponse(exception, clientRequestModel);

		//then
		assertEquals(null,entity.getHeaders().getCacheControl());

	}

	@DisplayName("prepareAPIResponse with empty response")
	@Test
	void prepareAPIResponseTest(){
		//when
		responseUtil.prepareAPIResponse(new HashMap<>(), new ApiTemplate(), new ClientRequestModel());

		//given
		ApiTemplate apiTemplate = new ApiTemplate();
		Map<String, FeatureTemplate> featureMap = new HashMap<>();
		featureMap.put("testFeature", new FeatureTemplate());
		apiTemplate.setFeaturesMap(featureMap);

		//when
		responseUtil.prepareAPIResponse(new HashMap<>(), apiTemplate, new ClientRequestModel());

	}

	@DisplayName("CopyCustomHttpResponse test with DeepCopy")
	@Test
	void CopyCustomHttpResponseTest(){
		//when
		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		customHttpResponse.setInterfaceKey("InterfaceName");
		customHttpResponse.setBodyAsString("{\r\n \"status\": \"SUCCESS\"}");
		customHttpResponse.setBodyMap(Map.of("status","SUCCESS"));
		CustomHttpResponse customHttpResponse_Returned = ResponseUtil.copyCustomHttpResponse(customHttpResponse);

		assertNotSame(customHttpResponse, customHttpResponse_Returned);
		assertNotSame(customHttpResponse.getBodyMap(), customHttpResponse_Returned.getBodyMap());
	}

	private String appendTraceIdToTracer() {
		String traceId = UUID.randomUUID().toString();
		TraceContext traceContext = mock(TraceContext.class);
		doReturn(traceId).when(traceContext).traceIdString();
		Span mockSpan = mock(Span.class);
		doReturn(traceContext).when(mockSpan).context();
		doReturn(mockSpan).when(tracer).currentSpan();
		return traceId;
	}
}