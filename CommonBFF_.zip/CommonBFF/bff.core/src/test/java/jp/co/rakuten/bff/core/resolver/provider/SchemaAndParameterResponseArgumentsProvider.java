package jp.co.rakuten.bff.core.resolver.provider;

import edu.emory.mathcs.backport.java.util.Collections;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.CommonValidatorUtil;
import jp.co.rakuten.bff.core.testUtil.ImmutableMap;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class SchemaAndParameterResponseArgumentsProvider implements ArgumentsProvider {

	private Map<String, Object> setSchemaAndParameter(List<FeatureTemplate> schemaLoader, Map<String, Object> response,
													  boolean isError, String errorMessage) {
		if (isError) {
			return ImmutableMap.of(
					"actualResponse", response,
					"responseTemplateMap", schemaLoader,
					"errorMessage", errorMessage);
		} else {
			return ImmutableMap.of(
					"actualResponse", response,
					"responseTemplateMap", schemaLoader);
		}
	}

	private Map<String, Object> shopbookmarkResponse() {
		return ImmutableMap.of("shopBookmarkInfo",
							   ImmutableMap.of("data",
											   ImmutableMap.of("shopBookmarkList",
															   List.of(
																	   ImmutableMap.of("id", 213860, "shopId", 304291),
																	   ImmutableMap.of("id", 213863, "shopId", 304292)
															   ))));
	}

	@Override
	public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws Exception {
		return Stream.of(
				setSchemaAndParameter(CommonValidatorUtil.getShopbookmarkSchema(), ImmutableMap.of("shopBookmarkInfo",
																								   ImmutableMap
																										   .of("data",
																											   ImmutableMap
																													   .of("shopBookmarkList",
																														   Collections
																																   .emptyList())))
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.getShopbookmarkSchema(), ImmutableMap.of("shopBookmarkInfo",
																								   ImmutableMap
																										   .of("data",
																											   ImmutableMap
																													   .of("shopBookmarkList",
																														   List.of(
																																   ImmutableMap
																																		   .of("id",
																																			   213860),
																																   ImmutableMap
																																		   .of("id",
																																			   213863,
																																			   "shopId",
																																			   304292)
																														   ))))
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.getShopbookmarkSchema(), ImmutableMap.of("shopBookmarkInfo",
																								   ImmutableMap
																										   .of("data",
																											   ImmutableMap
																													   .of("shopBookmarkList",
																														   List.of(
																																   ImmutableMap
																																		   .of("id",
																																			   213860,
																																			   "shopId",
																																			   304291),
																																   ImmutableMap
																																		   .of("id",
																																			   213863,
																																			   "shopId",
																																			   304292)
																														   )))),
									  false, null),
				setSchemaAndParameter(CommonValidatorUtil.getShopbookmarkSchema(), ImmutableMap.of("shopBookmarkInfo",
																								   ImmutableMap
																										   .of("data",
																											   ImmutableMap
																													   .of("shopBookmarkList",
																														   List.of(
																																   ImmutableMap
																																		   .of("id",
																																			   "dgd",
																																			   "shopId",
																																			   304291),
																																   ImmutableMap
																																		   .of("id",
																																			   213863,
																																			   "shopId",
																																			   304292)
																														   )))),
									  true, "id should be integer!"),
				setSchemaAndParameter(CommonValidatorUtil.getResponseSchema(), ImmutableMap.of("userInfo",
																							   ImmutableMap.of("data",
																											   ImmutableMap
																													   .of("user",
																														   ImmutableMap
																																   .of("id",
																																	   213863,
																																	   "userId",
																																	   "sadf")
																													   ))),
									  true, "userId should be integer!"),
				setSchemaAndParameter(CommonValidatorUtil.getResponseSchema(), ImmutableMap.of("userInfo",
																							   ImmutableMap.of("data",
																											   ImmutableMap
																													   .of("user",
																														   ImmutableMap
																																   .of("id",
																																	   213863,
																																	   "userId",
																																	   123123,
																																	   "username",
																																	   "johndoe")
																													   ))),
									  false, null),
				setSchemaAndParameter(CommonValidatorUtil.getResponseSchema(), ImmutableMap.of("userInfo",
																							   ImmutableMap.of("data",
																											   ImmutableMap
																													   .of("user",
																														   ImmutableMap
																																   .of("id",
																																	   213863,
																																	   "userId",
																																	   123123,
																																	   "username",
																																	   "johndoe",
																																	   "usernameList",
																																	   "value")
																													   ))),
									  true, "usernameList should be type of list"),
				setSchemaAndParameter(CommonValidatorUtil.getResponseSchema(), ImmutableMap.of("userInfo",
																							   ImmutableMap.of("data",
																											   ImmutableMap
																													   .of("user",
																														   ImmutableMap
																																   .of("id",
																																	   213863,
																																	   "userId",
																																	   123123,
																																	   "username",
																																	   "johndoe",
																																	   "usernameList",
																																	   Arrays.asList(
																																			   "johndoe",
																																			   "abc",
																																			   "xyz"))
																													   ))),
									  false, null)
		).map(Arguments::of);
	}
}
