package jp.co.rakuten.bff.core.service.impl;

import brave.Tracer;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.filter.ResponseFilter;
import jp.co.rakuten.bff.core.instrumentation.prometheus.BffFeatureMetricsManager;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.resolver.GenericParameterResolver;
import jp.co.rakuten.bff.core.service.ApiExecutionService;
import jp.co.rakuten.bff.core.service.ExecutionPlanService;
import jp.co.rakuten.bff.core.service.FeatureExecutionService;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApiExecutionServiceTest {

	private static ResponseFilter responseFilter;
	@Mock
	Tracer tracer;
	private ExecutionPlanService executionPlanService;
	private ResponseUtil responseUtil;
	private ApiRepositoryImpl apiRepository;
	@Mock
	private FeatureExecutionService featureExecutionService;
	@Mock
	private GenericParameterResolver genericParameterResolver;
	@Mock
	private Environment env;

	@BeforeAll
	static void setupOnce() {
		responseFilter = new ResponseFilter();
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		apiRepository = ApiRepositoryTestUtil.getRepository();
		BffFeatureMetricsManager.initialize(apiRepository.getAllApiTemplates());
		executionPlanService = new ExecutionPlanServiceImpl(env);
		responseUtil = new ResponseUtil(tracer);
	}


	@DisplayName("should throw error when invalid service name provided.")
	@Test
	void shouldThrowErrorWhenInvalidServiceNameProvided() {
		//given:
		String service = "invalid_service_name";
		String operation = "any_operation";
		String version = "null";
		RequestModel model = new RequestModel();
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		String operationWithVersioning = operation.concat(".").concat(version);
		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
																			  featureExecutionService,
																			  genericParameterResolver, responseFilter,
																			  responseUtil);
		ApiExecutionService apiExecutionServiceSpy = Mockito.spy(apiExecutionService);

		//when : expect client exception should be thrown.
		ClientException e = assertThrows(ClientException.class,
										 () -> apiExecutionServiceSpy.executeApi(requestModel).block());
		//then:
		assertEquals("Template not found for apiKey: " + service + "." + operationWithVersioning, e.getMessage());
		verify(apiExecutionServiceSpy, atLeastOnce()).executeApi(requestModel);
	}

	@DisplayName("should throw with internal_server_error exception")
	@Test
	void shouldThrowInternalServerError() {
		//given:
		String service = "shopbookmark";
		String operation = "list";
		String version = "v1";

		RequestModel model = TestUtil
				.getObjectFromFilename("mockfiles/user_request/shopbookmark_list_request_all_feature.json",
				                       RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		// mock response map
		Map<String, Object> response = new HashMap<>(
				Map.of("shopbookmark_list", Map.of("data", Map.of("key1", "value1")),
				       "coupon", Map.of("data", Map.of("key1", "value1"))));
		doReturn(response).when(genericParameterResolver).resolveResponseParameter(any(), any());
		Mono<Map<String, Object>> responseModel = Mono
				.error(BackendException.create(BackendErrorEnum.INTERNAL_SERVER_ERROR, "test"));
		when(featureExecutionService.executeFeatures(any(), any(), any(), any())).thenReturn(responseModel);

		String operationWithVersioning = operation.concat(".").concat(version);
		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
		                                                                      featureExecutionService,
		                                                                      genericParameterResolver, responseFilter,
		                                                                      responseUtil);
		ApiExecutionService apiExecutionServiceSpy = Mockito.spy(apiExecutionService);

		//when : expect client exception should be thrown.
		ResponseEntity<Map> responseEntity = apiExecutionServiceSpy.executeApi(requestModel).block();
		//then:
		assertEquals(BackendErrorEnum.INTERNAL_SERVER_ERROR.getErrorCode(), responseEntity.getStatusCode());
		assertEquals("test", TestUtil.extractValue(responseEntity.getBody(), "error.message"));
	}

	@DisplayName("success response from featureExecutionService")
	@Test
	void successResponseFromFeatureExecutionService() {
		//given:
		String service = "shopbookmark";
		String operation = "list";
		String version = "v1";

		RequestModel model = TestUtil
				.getObjectFromFilename("mockfiles/user_request/shopbookmark_list_request_all_feature.json",
									   RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		// mock response map
		Map<String, Object> response = new HashMap<>(
				Map.of("shopbookmark_list", Map.of("data", Map.of("key1", "value1")),
					   "coupon", Map.of("data", Map.of("key1", "value1"))));
		doReturn(Mono.just(response)).when(featureExecutionService).executeFeatures(any(), any(), any(), any());
		doReturn(response).when(genericParameterResolver).resolveResponseParameter(any(), any());

		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
																			  featureExecutionService,
																			  genericParameterResolver, responseFilter,
																			  responseUtil);
		Mono<ResponseEntity<Map>> responseModelMono = apiExecutionService.executeApi(requestModel);
		final ResponseEntity<Map> apiResponseModel = responseModelMono.block();
		// Then:
		assertEquals(BffConstants.SUCCESS, apiResponseModel.getBody().get(BffConstants.STATUS));
		//assertEquals(response, apiResponseModel.getBody());
		assertEquals(HttpStatus.MULTI_STATUS, apiResponseModel.getStatusCode());
	}

	@DisplayName("should throw error when invalid service name provided.")
	@Test
	void shouldThrowErrorWhenInvalidServiceNameProvided1() {
		//given:
		String service = "invalid_service_name";
		String operation = "any_operation";
		String version = "null";
		RequestModel model = new RequestModel();
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		String operationWithVersioning = operation.concat(".").concat(version);
		ApiExecutionService apiExecutionService =
				new ApiExecutionServiceImpl(apiRepository, executionPlanService, featureExecutionService,
											genericParameterResolver, responseFilter, responseUtil);
		ApiExecutionService apiExecutionServiceSpy = Mockito.spy(apiExecutionService);

		//when : expect client exception should be thrown.
		ClientException e =
				assertThrows(ClientException.class, () -> apiExecutionServiceSpy.executeApi(requestModel).block());
		//then:
		assertEquals("Template not found for apiKey: " + service + "." + operationWithVersioning, e.getMessage());
		verify(apiExecutionServiceSpy, atLeastOnce()).executeApi(requestModel);
	}

	@DisplayName("check headers properly added in multiple feature")
	@Test
	void checkHeadersProperlyAddedInMultipleFeature() {
		//given:
		String service = "shopbookmark";
		String operation = "list";
		String version = "v1";

		RequestModel model = TestUtil
				.getObjectFromFilename("mockfiles/user_request/shopbookmark_list_request_all_feature.json",
									   RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		// mock response map
		Map headers1 = Map.of("header-key1", "header-value1", "header-key2", "header-value2");
		Map headers2 = Map.of("header-key11", "header-value11", "header-key22", "header-value22");
		Map<String, Object> response = new HashMap<>(
				Map.of("shopbookmark_list",
					   Map.of(BffConstants.DATA, Map.of("key1", "value1"), BffConstants.HEADER, headers1),
					   "coupon",
					   Map.of(BffConstants.DATA, Map.of("key1", "value1"), BffConstants.HEADER, headers2)));
		doReturn(Mono.just(response)).when(featureExecutionService).executeFeatures(any(), any(), any(), any());
		doReturn(response).when(genericParameterResolver).resolveResponseParameter(any(), any());

		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
																			  featureExecutionService,
																			  genericParameterResolver, responseFilter,
																			  responseUtil);
		Mono<ResponseEntity<Map>> responseModelMono = apiExecutionService.executeApi(requestModel);
		final ResponseEntity<Map> apiResponseModel = responseModelMono.block();
		// Then:
		assertEquals(BffConstants.SUCCESS, apiResponseModel.getBody().get(BffConstants.STATUS));
		//assertEquals(response, apiResponseModel.getBody());
		assertEquals(HttpStatus.MULTI_STATUS, apiResponseModel.getStatusCode());
		assertEquals(headers1.size() + headers2.size(), apiResponseModel.getHeaders().size());
	}


	@DisplayName("check headers properly added in multiple feature")
	@Test
	void checkHeadersProperlyAddedInMultipleFeatureMergeHeadersInMultivalue() {
		//given:
		String service = "shopbookmark";
		String operation = "list";
		String version = "v1";

		RequestModel model = TestUtil
				.getObjectFromFilename("mockfiles/user_request/shopbookmark_list_request_all_feature.json",
									   RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		// mock response map
		Map headers1 = Map.of("header-key1", "header-value1", "header-key2", "header-value2");
		Map headers2 = Map.of("header-key1", "header-value1", "header-key22", "header-value22");
		Map<String, Object> response = new HashMap<>(
				Map.of("shopbookmark_list",
					   Map.of(BffConstants.DATA, Map.of("key1", "value1"), BffConstants.HEADER, headers1),
					   "coupon",
					   Map.of(BffConstants.DATA, Map.of("key1", "value1"), BffConstants.HEADER, headers2)));
		doReturn(Mono.just(response)).when(featureExecutionService).executeFeatures(any(), any(), any(), any());
		doReturn(response).when(genericParameterResolver).resolveResponseParameter(any(), any());

		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
																			  featureExecutionService,
																			  genericParameterResolver, responseFilter,
																			  responseUtil);
		Mono<ResponseEntity<Map>> responseModelMono = apiExecutionService.executeApi(requestModel);
		final ResponseEntity<Map> apiResponseModel = responseModelMono.block();
		// Then:
		assertEquals(BffConstants.SUCCESS, apiResponseModel.getBody().get(BffConstants.STATUS));
		//assertEquals(response, apiResponseModel.getBody());
		assertEquals(HttpStatus.MULTI_STATUS, apiResponseModel.getStatusCode());
		assertTrue(headers1.size() + headers2.size() >= apiResponseModel.getHeaders().size());
	}

	@DisplayName("check headers properly added in single feature")
	@Test
	void checkHeadersProperlyAddedInSingleFeature() {
		//given:
		String service = "room";
		String operation = "feed";
		String version = "v1";

		RequestModel model = TestUtil
				.getObjectFromFilename("mockfiles/user_request/roomFeedInfo_v1_full.json", RequestModel.class);
		ClientRequestModel requestModel = new ClientRequestModel();
		requestModel.setService(service);
		requestModel.setOperation(operation);
		requestModel.setVersion(version);
		requestModel.setRequestModel(model);

		// mock response map
		Map headers1 = Map
				.of("header-key1", "header-value1", "header-key2", "header-value2", "header-key11", "header-value11",
					"header-key22", "header-value22");
		Map<String, Object> response = new HashMap<>(
				Map.of("roomFeedInfo",
					   Map.of(BffConstants.DATA, Map.of("key1", "value1"), BffConstants.HEADER, headers1)));
		doReturn(Mono.just(response)).when(featureExecutionService).executeFeatures(any(), any(), any(), any());
		doReturn(response).when(genericParameterResolver).resolveResponseParameter(any(), any());

		ApiExecutionService apiExecutionService = new ApiExecutionServiceImpl(apiRepository, executionPlanService,
																			  featureExecutionService,
																			  genericParameterResolver, responseFilter,
																			  responseUtil);
		Mono<ResponseEntity<Map>> responseModelMono = apiExecutionService.executeApi(requestModel);
		final ResponseEntity<Map> apiResponseModel = responseModelMono.block();
		// Then:
		assertEquals(BffConstants.SUCCESS, apiResponseModel.getBody().get(BffConstants.STATUS));
		//assertEquals(response, apiResponseModel.getBody());
		assertEquals(HttpStatus.OK, apiResponseModel.getStatusCode());
		assertEquals(headers1.size(), apiResponseModel.getHeaders().size());
		//
		headers1.forEach((o, o2) ->
								 assertTrue(apiResponseModel.getHeaders().containsKey(o)
													&& o2.equals(apiResponseModel.getHeaders().get(o).get(0)))
		);
	}

}