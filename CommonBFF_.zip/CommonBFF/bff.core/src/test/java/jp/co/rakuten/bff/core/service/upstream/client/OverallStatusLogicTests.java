package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


class OverallStatusLogicTests {
	@InjectMocks
	OverallStatusLogic overallStatusLogic;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() {
		overallStatusLogic = null;
	}

	@Test
	void allSuccess() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();
		responses.add(getResponse(null));
		responses.add(getResponse(null));

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("SUCCESS", overallStatus);

		// Verify mocks: NA
	}

	@Test
	void allFailure() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();
		responses.add(getResponse(HttpStatus.SERVICE_UNAVAILABLE));
		responses.add(getResponse(HttpStatus.INTERNAL_SERVER_ERROR));

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("FAILURE", overallStatus);

		// Verify mocks: NA
	}

	@Test
	void successAndFailure() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();
		responses.add(getResponse(null));
		responses.add(getResponse(HttpStatus.INTERNAL_SERVER_ERROR));

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("PARTIAL_FAILURE", overallStatus);

		// Verify mocks: NA
	}

	@Test
	void successAnd207() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();
		responses.add(getResponse(null));
		responses.add(getResponse(HttpStatus.MULTI_STATUS));

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("PARTIAL_FAILURE", overallStatus);

		// Verify mocks: NA
	}

	@Test
	void failureAnd207() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();
		responses.add(getResponse(HttpStatus.INTERNAL_SERVER_ERROR));
		responses.add(getResponse(HttpStatus.MULTI_STATUS));

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("FAILURE", overallStatus);

		// Verify mocks: NA
	}

	@Test
	void noResponse() {
		// Setup: NA

		// Given:
		List<CustomHttpResponse> responses = new ArrayList<>();

		// When:
		String overallStatus = overallStatusLogic.computeOverallStatus(responses);

		// Verify response:
		assertEquals("PARTIAL_FAILURE", overallStatus);

		// Verify mocks: NA
	}

	private CustomHttpResponse getResponse(HttpStatus errorCode) {
		CustomHttpResponse response = new CustomHttpResponse();
		if (errorCode != null) {
			response.setError(
					new CustomError.CustomErrorBuilder().code(String.valueOf(errorCode.value())).message("config/error")
							.build());
		}
		return response;
	}
}
