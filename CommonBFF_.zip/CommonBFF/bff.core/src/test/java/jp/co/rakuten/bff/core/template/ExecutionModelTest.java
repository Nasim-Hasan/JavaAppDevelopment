package jp.co.rakuten.bff.core.template;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class ExecutionModelTest {

	@Test
	void testToString() {
		ExecutionModel model = new ExecutionModel();
		model.setDefaultResponse(Map.of("foo", "bar"));
		assertFalse(model.toString().contains("foo"));
	}
}
