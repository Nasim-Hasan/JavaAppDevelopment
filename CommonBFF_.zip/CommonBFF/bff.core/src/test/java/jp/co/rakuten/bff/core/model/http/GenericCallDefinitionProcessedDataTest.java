package jp.co.rakuten.bff.core.model.http;

import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GenericCallDefinitionProcessedDataTest {
	private GenericCallDefinitionProcessedData model;

	@Autowired
	Environment environment;

	@Mock
	CommonRequestModel validatedRequest;

	@BeforeEach
	void setUp() {
		model = new GenericCallDefinitionProcessedData();
		MockitoAnnotations.initMocks(this);
		validatedRequest = new CommonRequestModel();
	}

	@Test
	@DisplayName("Getter-Setter test")
	void checkGetterSetter() {

		validatedRequest.setParams(
				Map.of(
						"a", 1,
						"b", 2
				));
		Map<String, Object> requestMap = new HashMap<>();
		requestMap.put("shopList", validatedRequest);
		Map<String, Map<String, Object>> prepRequest = new HashMap<>();
		prepRequest.put("brandList", requestMap);
		assertDoesNotThrow(() -> {
			model.setPreparedRequest(prepRequest);
			model.setInterfaceToRequestIdMap(Map.of("shopList", List.of("brandList")));
		});
		assertTrue(model.getPreparedRequest().containsKey("brandList"));
		assertTrue(model.getInterfaceToRequestIdMap().containsKey("shopList"));
		model.getRequestByInterface("shopList");
	}

	@Test
	@DisplayName("getRequestByInterface test")
	void getRequestByInterfaceTest() {
		assertNull(model.getRequestByInterface("shopList"));
		model.setInterfaceToRequestIdMap(Map.of("shopList", List.of("brandList")));
		assertNull(model.getRequestByInterface("shopList"));
	}

	@Test
	@DisplayName("removeRequestByInterface test")
	void removeRequestByInterfaceTest() {
		assertNull(model.removeRequestByInterface("shopList"));
		List<String> interfaceList=new ArrayList<>();
		interfaceList.add("brandList");
		Map<String,List<String>> requestIdMap=new HashMap<>();
		requestIdMap.put("shopList",interfaceList);
		model.setInterfaceToRequestIdMap(requestIdMap);
		model.setPreparedRequest(null);
		assertNull(model.removeRequestByInterface("shopList"));
	}

	@ParameterizedTest
	@CsvSource(value = {
			"10|true",
			"1|true",
			"0|false",
	}, delimiter = '|')
	@DisplayName("test should Call Definition Run")
	void testShouldCDRun(int remaining, boolean shouldItRun) {
		GenericCallDefinitionProcessedData modelSpy = spy(model);
		when(modelSpy.getPreparedRequest()).thenReturn(getMockRequestMap(remaining));
		assertEquals(shouldItRun, modelSpy.shouldCDRun());
	}

	private Map<String, Map<String, Object>> getMockRequestMap(int size){
		Map<String, Map<String, Object>> requestMap = new HashMap();
		while(size-- != 0) requestMap.put(UUID.randomUUID().toString(), new HashMap<>());
		return requestMap;
	}
}
