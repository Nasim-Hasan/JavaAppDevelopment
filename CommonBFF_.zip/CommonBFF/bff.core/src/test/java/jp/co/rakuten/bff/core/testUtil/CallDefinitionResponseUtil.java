package jp.co.rakuten.bff.core.testUtil;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CallDefinitionResponseUtil {

	public Map<String, CallDefinitionResponse> getUpstreamResponseSuccess(String callDefinitionName,
																		  String interfaceName,
																		  String fileName) {
		return getUpstreamResponseSuccess(callDefinitionName, interfaceName, fileName, ResponseFormatEnum.JSON);
	}

	public Map<String, CallDefinitionResponse> getUpstreamResponseSuccess(String callDefinitionName,
																		  String[] interfaceNames,
																		  String[] fileNames) {
		return getUpstreamResponseSuccess(callDefinitionName, interfaceNames, fileNames, ResponseFormatEnum.JSON);
	}

	public Map<String, CallDefinitionResponse> getUpstreamResponseSuccess(String callDefinitionName,
																		  String[] interfaceNames,
																		  String[] fileNames,
																		  ResponseFormatEnum format) {
		CallDefinitionResponse callDefinitionResponse = getCallDefinitionResponseSuccess(interfaceNames, fileNames,
				format);
		return Map
				.of(callDefinitionName, callDefinitionResponse);
	}

	public CallDefinitionResponse getCallDefinitionResponseSuccess(String[] interfaceNames, String[] fileNames,
																   ResponseFormatEnum format) {
		MultipleResponses multipleResponses = new MultipleResponses();
		multipleResponses.setOverallStatus(BffConstants.UPSTREAM_RESPONSE_SUCCESS);

		Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
		Map<String, CustomHttpResponse> responses = new HashMap<>();
		CallDefinitionResponse callDefinitionResponse = null;
		int index = interfaceNames.length;
		while (index > 0) {
			String requestId = UUID.randomUUID().toString();
			CustomHttpResponse customHttpResponse = new CustomHttpResponse();
			customHttpResponse.setBodyAsString(TestUtil.getFileContents(fileNames[index - 1]));
			switch (format) {
				case XML:
					customHttpResponse.setBodyMap(TestUtil.getXmlToMap(fileNames[index - 1]));
				case JSON:
					customHttpResponse.setBodyMap(TestUtil.getObjectFromFilename(fileNames[index - 1], Map.class));
				case TEXT:
				default:
					//none
			}
			customHttpResponse.setInterfaceKey(interfaceNames[index - 1]);
			responses.put(requestId, customHttpResponse);
			interfaceToRequestIdMap.put(customHttpResponse.getInterfaceKey(), Collections.singletonList(requestId));

			index--;
		}

		multipleResponses.setResponses(responses);
		callDefinitionResponse = new CallDefinitionResponse(
				CallDefinitionResponseStatus.SUCCESS);
		callDefinitionResponse.setMultipleResponses(multipleResponses);
		callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);

		return callDefinitionResponse;
	}

	public Map<String, CallDefinitionResponse> getUpstreamResponseSuccess(String callDefinitionName, String interfaceName,
																		  String fileName, ResponseFormatEnum format) {
		CallDefinitionResponse callDefinitionResponse = getCallDefinitionResponseSuccess(interfaceName, fileName, format);
		return Map
				.of(callDefinitionName, callDefinitionResponse);
	}

	public CallDefinitionResponse getCallDefinitionResponseSuccess(String interfaceName, String fileName) {
		return getCallDefinitionResponseSuccess(interfaceName, fileName, ResponseFormatEnum.JSON);
	}

	public CallDefinitionResponse getCallDefinitionResponseSuccess(String interfaceName, String fileName,
																   ResponseFormatEnum format) {
		MultipleResponses multipleResponses = new MultipleResponses();
		multipleResponses.setOverallStatus(BffConstants.UPSTREAM_RESPONSE_SUCCESS);

		String requestId = UUID.randomUUID().toString();

		CustomHttpResponse customHttpResponse = new CustomHttpResponse();
		customHttpResponse.setBodyAsString(TestUtil.getFileContents(fileName));
		switch (format) {
			case XML:
				customHttpResponse.setBodyMap(TestUtil.getXmlToMap(fileName));
			case JSON:
				customHttpResponse.setBodyMap(TestUtil.getObjectFromFilename(fileName, Map.class));
			case TEXT:
			default:
				//none
		}
		customHttpResponse.setInterfaceKey(interfaceName);
		multipleResponses.setResponses(Map.of(requestId, customHttpResponse));

		CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
		callDefinitionResponse.setMultipleResponses(multipleResponses);

		Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
		interfaceToRequestIdMap.put(customHttpResponse.getInterfaceKey(), Collections.singletonList(requestId));
		callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);

		return callDefinitionResponse;
	}

	public Map<String, CallDefinitionResponse> getUpstreamResponseFailed(String callDefinitionName) {
		return Map.of(callDefinitionName, getCallDefinitionResponseFailed());
	}

	public CallDefinitionResponse getCallDefinitionResponseFailed() {
		CallDefinitionError callDefinitionError = new CallDefinitionError();
		callDefinitionError.setCode(503);
		callDefinitionError.setMessage("Service unavailable");

		CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.FAILURE);
		callDefinitionResponse.setCallDefinitionError(callDefinitionError);

		return callDefinitionResponse;
	}

	/**
	 * Creates and adds CallDefinitionResponse object to CallDefinitionResponse map
	 * and returns the created object
	 *
	 * @param callDefResponseMap CallDefinitionResponse map to add the created object to
	 * @param callDefName        name of the callDefinition
	 * @param status             CallDefinitionResponseStatus
	 * @return created object
	 */
	public static CallDefinitionResponse addNewCallDefToMap(
			Map<String, CallDefinitionResponse> callDefResponseMap, String callDefName, CallDefinitionResponseStatus status) {
		CallDefinitionResponse callDef = new CallDefinitionResponse(status);
		callDefResponseMap.put(callDefName, callDef);
		return callDef;
	}

	/**
	 * See - {@link #addInterfaceResponseToCallDef(CallDefinitionResponse, String, Map, String)}
	 */
	public static CallDefinitionResponse addInterfaceResponseToCallDef(CallDefinitionResponse callDef,
																	   String interfaceName, Map<String, Object> interfaceBodyMap) {
		return addInterfaceResponseToCallDef(callDef, interfaceName, interfaceBodyMap, interfaceBodyMap.toString());
	}

	/**
	 * Creates and adds Interface Response to CallDefinitionResponse object.<br>
	 * A random requestId will be generated and added for the interface.<br>
	 * It will also return the CallDefinitionResponse object after performing these operations in case needed.
	 *
	 * @param callDef          CallDefinitionResponse object
	 * @param interfaceName    interface name
	 * @param interfaceBodyMap response body map for interface response
	 * @param bodyAsString     response body as String
	 * @return
	 */
	public static CallDefinitionResponse addInterfaceResponseToCallDef(CallDefinitionResponse callDef,
																	   String interfaceName, Map<String, Object> interfaceBodyMap, String bodyAsString) {
		String requestId = UUID.randomUUID().toString();
		callDef.setInterfaceToRequestIdMap(new HashMap(Map.of(interfaceName, new ArrayList(List.of(requestId)))));
		MultipleResponses multipleResponses = callDef.getMultipleResponses() == null ?
				new MultipleResponses() : callDef.getMultipleResponses();
		if (!multipleResponses.getResponses().isEmpty()) {
			multipleResponses.getResponses().put(requestId,
					getCustomHttpResponse(requestId, interfaceName, interfaceBodyMap, bodyAsString));
		} else {
			multipleResponses.setResponses(new HashMap<>(Map.of(requestId,
					getCustomHttpResponse(requestId, interfaceName, interfaceBodyMap, bodyAsString))));
		}
		callDef.setMultipleResponses(multipleResponses);
		return callDef;
	}

	/**
	 * Creates a CustomHttpResponse object based on provided response
	 *
	 * @param requestId        requestId
	 * @param interfaceKey     interfaceKey
	 * @param interfaceBodyMap response body map for interface response
	 * @return
	 */
	public static CustomHttpResponse getCustomHttpResponse(String requestId, String interfaceKey,
														   Map<String, Object> interfaceBodyMap, String bodyAsString) {
		return CustomHttpResponse.builder()
				.bodyMap(interfaceBodyMap)
				.bodyAsString(bodyAsString)
				.interfaceKey(interfaceKey)
				.build();
	}
}
