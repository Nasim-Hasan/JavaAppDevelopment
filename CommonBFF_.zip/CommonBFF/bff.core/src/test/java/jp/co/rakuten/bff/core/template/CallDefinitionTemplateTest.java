package jp.co.rakuten.bff.core.template;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CallDefinitionTemplateTest {

    private CallDefinitionTemplate callDefinitionTemplate = new CallDefinitionTemplate();
    private CallDefinitionTemplate callDefinitionTemplate1 = new CallDefinitionTemplate();
    private Map<String, CallDefinitionTemplate> dependsMap = new HashMap<>();

    @Test
    void toStringTest(){
        dependsMap.put("test", callDefinitionTemplate1);
        callDefinitionTemplate.setType("single");
        callDefinitionTemplate.setName("testInfo");
        List<String> interfaceTestList = new ArrayList<>();
        List<String> dependTestList = new ArrayList<>();
        interfaceTestList.add("testInterface1");
        interfaceTestList.add("testInterface2");
        callDefinitionTemplate.setInterfacesList(interfaceTestList);
        dependTestList.add("testDepend1");
        dependTestList.add("testDepend2");
        callDefinitionTemplate.setDependsList(dependTestList);

        callDefinitionTemplate.setDependsMap(dependsMap);
        String str = callDefinitionTemplate.toString();
        assertEquals("CallDefinitionTemplate(type=single, dependsList=[testDepend1, testDepend2], interfacesList=[testInterface1, testInterface2], name=testInfo, dependsMap={test=" +
                "CallDefinitionTemplate(type=null, dependsList=[], interfacesList=[]," +
                " name=null, dependsMap={})})", str);
    }
}
