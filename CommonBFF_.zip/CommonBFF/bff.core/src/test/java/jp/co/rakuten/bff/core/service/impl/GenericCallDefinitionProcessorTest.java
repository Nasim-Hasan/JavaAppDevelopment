package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.mockito.Mock;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

class GenericCallDefinitionProcessorTest {

	@Mock
	Environment environment;

	private ExecutionModel executionModel;
	private ApiTemplate apiTemplate;
	private Map<String, CommonRequestModel> validatedRequest;
	private GenericCallDefinitionProcessor genericCallDefinitionProcessor;

	@BeforeEach
	void setup(TestInfo testInfo) {
		initMocks(this);
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
		genericCallDefinitionProcessor = new GenericCallDefinitionProcessor(environment);
		if (testInfo.getTags().contains("SkipBeforeEach")) {
			return;
		}
		if (testInfo.getTags().contains("SkipBeforeEach")) {
			return;
		}

		validatedRequest = TestUtil
				.getValidatedRequest("mockfiles/validated_schema/GUP_shopbookmark_list_all_feature.json");
		ClientRequestModel clientRequestModel = TestUtil
				.getClientRequestModel("mockfiles/user_request/GUP_shopbookmark_list_all_feature.json");
		executionModel = new ExecutionPlanServiceImpl(environment)
				.prepareExecutionPlan(clientRequestModel, apiTemplate);
	}

	@Test
	@DisplayName("For specific features, interface's template parameter length and prepared parameter length should be same")
	void testTemplateParamLength() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());
		int expectedParamNumber = 0;
		for (InterfaceTemplate endpointTemplate : interfaceMap.values()) {
			expectedParamNumber += endpointTemplate.getHeaders().size();
			expectedParamNumber += endpointTemplate.getUrlParams().size();
			expectedParamNumber += endpointTemplate.getBodyParams().size();
			expectedParamNumber += endpointTemplate.getMetaParameters().size();
		}

		int returnedParamNumber = 0;
		for (Map<String, Object> map : genericCDProcessedData.getPreparedRequest().values()) {
			returnedParamNumber += (map.get(HEADER_PARAMETERS) != null ?
					((Map<String, String>) map.get(HEADER_PARAMETERS)).size() : 0);
			returnedParamNumber += (map.get(URL_PARAMETERS) != null ?
					((Map<String, String>) map.get(URL_PARAMETERS)).size() : 0);
			returnedParamNumber += (map.get(BODY_PARAMETERS) != null ?
					((Map<String, String>) map.get(BODY_PARAMETERS)).size() : 0);
		}

		assertEquals(expectedParamNumber, returnedParamNumber);
	}

	@Test
	@DisplayName("For specific feature, interfaces GG parameter length and prepared parameter length should be same")
	void testGGParamLength() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());
		int expectedParamNumber = 0;
		for (InterfaceTemplate endpointTemplate : interfaceMap.values()) {
			expectedParamNumber += endpointTemplate.getParameterLinks().size();
			expectedParamNumber += endpointTemplate.getDependencyCondition().size();
			expectedParamNumber += endpointTemplate.getResponseFilters().size();
		}

		int returnedParamNumber = 0;
		for (Map<String, Object> map : genericCDProcessedData.getPreparedRequest().values()) {
			returnedParamNumber += (map.get(PARAMETER_LINKS) != null ?
					((List<Map<String, Object>>) map.get(PARAMETER_LINKS)).size() : 0);
			returnedParamNumber += (map.get(DEPENDENCY_CONDITIONS) != null ?
					((List<Map<String, Object>>) map.get(DEPENDENCY_CONDITIONS)).size() : 0);
			returnedParamNumber += (map.get(RESPONSE_FILTERS) != null ?
					((List<Map<String, Object>>) map.get(RESPONSE_FILTERS)).size() : 0);
		}

		assertEquals(expectedParamNumber, returnedParamNumber);
	}

	@Test
	@DisplayName("If no parameter passed then interface template parameter length should be zero")
	void testEmptyParamLength() {
		//given
		validatedRequest = new HashMap<>();
		validatedRequest.put("shopbookmark_list", null);
		validatedRequest.put("coupon", new CommonRequestModel());
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("coupon");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());

		int returnedParamNumber = 0;
		for (Map<String, Object> map : genericCDProcessedData.getPreparedRequest().values()) {
			returnedParamNumber += (map.get(HEADER_PARAMETERS) != null ?
					((Map<String, String>) map.get(HEADER_PARAMETERS)).size() : 0);
			returnedParamNumber += (map.get(URL_PARAMETERS) != null ?
					((Map<String, String>) map.get(URL_PARAMETERS)).size() : 0);
			returnedParamNumber += (map.get(BODY_PARAMETERS) != null ?
					((Map<String, String>) map.get(BODY_PARAMETERS)).size() : 0);
		}

		assertEquals(0, returnedParamNumber);
	}

	@Test
	@DisplayName("If property value not exist in environment set default value")
	void testPropertyDefaultValue() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});

		//when
		String sidEnvValue = "sid_value";
		when(environment.getProperty(eq("abc.sid"))).thenAnswer(invocation -> sidEnvValue);
		when(environment.getProperty(eq("abc.authKey"))).thenAnswer(invocation -> null);

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());

		String requestId = genericCDProcessedData.getInterfaceToRequestIdMap()
				.get("shopbiz_point_info").iterator().next();

		String sid = ((Map<String, String>) genericCDProcessedData.getPreparedRequest()
				.get(requestId).get("headerParameters")).get("sid");
		String authKey = ((Map<String, String>) genericCDProcessedData.getPreparedRequest()
				.get(requestId).get("headerParameters")).get("authKey");
		assertEquals(sidEnvValue, sid);
		assertEquals("defaultValue", authKey);

		// environment should call 2 times because of total 2 property type
		verify(environment, times(2)).getProperty(anyString());
	}

	@Test
	@DisplayName("single interface multiple existence test")
	void testSingleInterfaceMultipleTime() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());

		int interfaceCount = 0;
		for (Map.Entry<String, Map<String, Object>> entry :
				genericCDProcessedData.getPreparedRequest().entrySet()) {
			String requestId = entry.getKey();
			Map<String, Object> requestMap = entry.getValue();
			if (String.valueOf(requestMap.get(INTERFACE_KEY)).equals("gsp_shop_review")) {
				interfaceCount++;
			}
		}
		assertEquals(2, interfaceCount);
	}

	@Test
	@Tag("SkipBeforeEach")
	@DisplayName("body test")
	void testBody() {
		//given
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate bodyApiTemplate = apiRepository.getApiRepositoryTemplate("body.test.v1");
		FeatureTemplate featureTemplate = bodyApiTemplate.getFeaturesMap().get("bodyTest");
		validatedRequest = TestUtil.getValidatedRequest("mockfiles/validated_schema/ValidatedBodyRequest.json");
		ClientRequestModel clientRequestModel = TestUtil
				.getClientRequestModel("mockfiles/user_request/BodyRequest.json");

		executionModel = new ExecutionPlanServiceImpl(environment)
				.prepareExecutionPlan(clientRequestModel, bodyApiTemplate);
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, bodyApiTemplate.getInterfacesMap().get(interfaceName));
		});

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then
		GenericCallDefinitionProcessedData genericCDProcessedData =
				genericCallDefinitionProcessor.preProcess(interfaceMap, validatedRequest,
														  executionModel.getFeatureModelList());

		//verify
		assertNotNull(genericCDProcessedData);
		assertNotNull(genericCDProcessedData.getPreparedRequest());
		assertNotNull(genericCDProcessedData.getInterfaceToRequestIdMap());

		Object gspShopReview = null;
		for (Map.Entry<String, Map<String, Object>> entry :
				genericCDProcessedData.getPreparedRequest().entrySet()) {
			String requestId = entry.getKey();
			Map<String, Object> requestMap = entry.getValue();
			if (String.valueOf(requestMap.get(INTERFACE_KEY)).equals("bodyTest")) {
				gspShopReview = requestMap.get(BODY);
				break;
			}
		}
		String expected = "{\"easyId\":1234, \"testKey\":[{\"sourceTest\":\"2\"},{\"propTest\":\"Test\"}]}";
		Object expectedObj = TestUtil.getObjectFromString(expected, Object.class);
		assertEquals(expectedObj.toString(), gspShopReview.toString());
	}

	@Test
	@DisplayName("setParamsFromModelToRequestMap deepCopy Success test")
	void setParamsFromModelToRequestMapTest() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, apiTemplate.getInterfacesMap().get(interfaceName));
		});
		InterfaceTemplate interfaceTemplate= interfaceMap.get("shopbookmark_list");
		Map<String, Object> requestMap = new HashMap<>();
		String interfaceKey = interfaceTemplate.getInterfaceKey();
		requestMap.put(INTERFACE_KEY,interfaceKey);
		String requestId = UUID.randomUUID().toString();
		requestMap.put(REQUEST_ID, requestId);

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then

		genericCallDefinitionProcessor.setParamsFromModelToRequestMap(
				apiTemplate.getInterfacesMap().get("shopbookmark_list"),
				validatedRequest,
				List.of(featureTemplate),requestMap);

		//verify
		assertNotSame(interfaceTemplate.getParameterLinks(), requestMap.get(PARAMETER_LINKS));
		assertNotSame(interfaceTemplate.getDependencyCondition(), requestMap.get(DEPENDENCY_CONDITIONS));
		assertNotSame(interfaceTemplate.getResponseFilters(), requestMap.get(RESPONSE_FILTERS));
	}

	@Test
	@Tag("SkipBeforeEach")
	@DisplayName("setParamsFromModelToRequestMap body test With DeepCopy")
	void setParamsFromModelToRequestMapTestBody() {
		//given
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate bodyApiTemplate = apiRepository.getApiRepositoryTemplate("body.test.v1");
		FeatureTemplate featureTemplate = bodyApiTemplate.getFeaturesMap().get("bodyTest");
		validatedRequest = TestUtil.getValidatedRequest("mockfiles/validated_schema/ValidatedBodyRequest.json");
		ClientRequestModel clientRequestModel = TestUtil
				.getClientRequestModel("mockfiles/user_request/BodyRequest.json");

		executionModel = new ExecutionPlanServiceImpl(environment)
				.prepareExecutionPlan(clientRequestModel, bodyApiTemplate);
		Map<String, InterfaceTemplate> interfaceMap = new HashMap<>();
		featureTemplate.getInterfaceNameList().forEach(interfaceName -> {
			interfaceMap.put(interfaceName, bodyApiTemplate.getInterfacesMap().get(interfaceName));
		});
		InterfaceTemplate interfaceTemplate= interfaceMap.get("bodyTest");
		Map<String, Object> requestMap = new HashMap<>();
		String interfaceKey = interfaceTemplate.getInterfaceKey();
		requestMap.put(INTERFACE_KEY,interfaceKey);
		String requestId = UUID.randomUUID().toString();
		requestMap.put(REQUEST_ID, requestId);

		//when
		when(environment.getProperty(anyString())).thenAnswer(invocation -> "Test");

		//then
		genericCallDefinitionProcessor.setParamsFromModelToRequestMap(
				interfaceTemplate,
				validatedRequest,
				List.of(featureTemplate),requestMap);
		assertNotSame(interfaceTemplate.getBody().getTemplate(), requestMap.get(BODY));
	}
}