package jp.co.rakuten.bff.core.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.exception.SystemException;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class MapUtilTest {
	private static ObjectMapper objectMapper = MapUtil.getObjectMapper();

	private static Stream<Arguments> putValueSuccessArguments() throws JsonProcessingException {
		return Stream.of(
				Arguments.of(objectMapper.readValue("{\"k1\":{\"k2\":\"\"}}", Map.class), "k1.k2", "v2",
						Map.of("k1", Map.of("k2", "v2"))),
				Arguments.of(objectMapper.readValue("{\"k1\":{\"k2\":\"\"}}", Map.class), "k1.k3", "v2",
						Map.of("k1", Map.of("k2", ""))),
				Arguments.of(objectMapper.readValue("{\"k1\":[{\"k2\":\"\"}]}", Map.class), "k1.k2", "v2",
						Map.of("k1", List.of(Map.of("k2", "v2"))))
		);
	}

	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	@ParameterizedTest
	@MethodSource("putValueSuccessArguments")
	void testPutValueSuccess(Map<String, Object> body, String path, Object value, Map<String, Object> expect) {
		//when
		MapUtil.putValue(body, path, value);
		//then
		assertEquals(body.toString(), expect.toString());
	}

	@Test
	void testPutValueException() throws JsonProcessingException {
		Map<String, Object> body = objectMapper.readValue("{\"k1\":{\"k2\":\"\"}}", Map.class);
		assertThrows(SystemException.class, () -> {
			MapUtil.putValue(body, "k1.k2.k3", 123);
		}, "Invalid object");
	}

	@DisplayName("Test getFieldFromMap")
	@org.junit.jupiter.api.Test
	void testGetFieldFromMap() {
		// given:
		String key = null;
		Map data = null;

		//when:
		// case 1: when both are null
		Object result = MapUtil.getFieldFromMap(key, data);
		// then:
		assertNull(result);

		//case 2: when data is not null but key is null
		result = MapUtil.getFieldFromMap(null, Map.of("key", "value"));
		// then:
		assertNull(result);


		//case 3: when data is not null but map does not contain that key.
		result = MapUtil.getFieldFromMap("invalidKey", Map.of("key", "value"));
		// then:
		assertNull(result);

		//case 4: when data is not null but map does not contain that key.
		result = MapUtil.getFieldFromMap("in.va.ey", Map.of("in", Map.of("va", Map.of("li", "value"))));
		// then:
		assertNull(result);

		//case 5: when data is not null but map does not contain that key.
		ClassCastException classCastException = assertThrows(ClassCastException.class, () ->
				MapUtil.getFieldFromMap("in.va.li.dK.ey", Map.of("in", Map.of("va", Map.of("li", "value")))));
		// then:
		assertNotNull(classCastException);


		//case 5: return data from the map.
		String expected = "expected";
		key = "a.b.c.d.e";
		result = MapUtil
				.getFieldFromMap(key, Map.of("a", Map.of("b", Map.of("c", Map.of("d", Map.of("e", expected))))));
		// then:
		assertNotNull(result);
		assertEquals(expected, result);
	}

	@Test
	public void testGetDirectParent() throws Exception {
		Map map = MapUtil.getObjectMapper().readValue("{\"data\":{\"shopId\":1, \"other\": 0}}", Map.class);
		Map<String, Object> parent = MapUtil.getDirectParent(map, "data.shopId");
		Assert.assertNotNull(parent);
		Assert.assertEquals(1, parent.get("shopId"));
		Assert.assertEquals(0, parent.get("other"));
	}

	@DisplayName("when return type is Map")
	@Test
	public void testDeepCopyMethodForMap(){
		Map<String, Object> testMap = new HashMap<>();
		testMap.put("testB",1);
		testMap.put("testA","test");
		Map returnedElement = MapUtil.deepCopy(testMap);
		assertEquals("test", returnedElement.get("testA"));
	}
}