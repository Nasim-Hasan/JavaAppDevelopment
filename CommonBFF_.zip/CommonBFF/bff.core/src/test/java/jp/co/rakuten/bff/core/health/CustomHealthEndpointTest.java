package jp.co.rakuten.bff.core.health;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.actuate.health.*;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class CustomHealthEndpointTest {
    @Mock
    HealthContributorRegistry healthContributorRegistry;
    @Mock
    HealthEndpointGroups healthEndpointGroups;

    /**
     * Equivalent of @RunWith(MockitoJUnitRunner.class)
     * Doing this instead as we already call SpringRunner to RunWith
     */
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @ParameterizedTest
    @CsvSource(value = {
            "DOWN",
            "OUT_OF_SERVICE",
            "UNKNOWN",
    }, delimiter = '|')
    public void tesNegativetHealth(String statusCode) throws Exception {
        // Setup: pre-requisite resources and mocks
        // Given: instantiated by cnstructor and set a spy
        CustomHealthEndpoint customHealthEndpoint = Mockito.spy(new CustomHealthEndpoint(healthContributorRegistry,
                healthEndpointGroups));
        Status status = new Status(statusCode);
        Health.Builder builder = new Health.Builder(status, Map.of());
        Health health = builder.build();
        Mockito.doReturn(health).when(customHealthEndpoint).callParentHealth();

        // When: health triggered
        HealthComponent healthResult = customHealthEndpoint.health();

        // Verify Response: N/A because this is method is void
        // Verify Mock: verifying mock calls through spy
        Assert.assertEquals(statusCode, healthResult.getStatus().getCode());
    }

    @Test
    public void testPositiveHealth() throws Exception {
        // Setup: pre-requisite resources and mocks
        // Given: instantiated by cnstructor and set a spy
        CustomHealthEndpoint customHealthEndpoint = Mockito.spy(new CustomHealthEndpoint(healthContributorRegistry,
                healthEndpointGroups));
        Health.Builder builder = new Health.Builder(Status.UP, Map.of());
        Health health = builder.build();
        Mockito.doReturn(health).when(customHealthEndpoint).callParentHealth();

        // When: health triggered
        HealthComponent healthResult = customHealthEndpoint.health();

        // Verify Response: N/A because this is method is void
        // Verify Mock: verifying mock calls through spy
        Assert.assertEquals("UP", healthResult.getStatus().getCode());
    }

    @Test
    public void testLoggerException() {
        // Setup: pre-requisite resources and mocks
        // Given: instantiated by constructor and set a spy
        ObjectMapper objectMapper = spy(new ObjectMapper()
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, true));
        CustomHealthEndpoint customHealthEndpoint = Mockito.spy(new CustomHealthEndpoint(healthContributorRegistry,
                healthEndpointGroups));
        customHealthEndpoint.setObjectMapper(objectMapper);
        HealthComponent healthMock = mock(HealthComponent.class);
        when(healthMock.toString()).thenReturn(healthMock.getClass().getName());

        // When: health triggered
        customHealthEndpoint.logUnhealthyStatus(healthMock);

        // Verify Response: N/A because this is method is void
        // Verify Mock: verifying mock calls through spy
        try {
            verify(objectMapper, atLeastOnce()).writeValueAsString(any());
        } catch (JsonProcessingException e) {
            // do nothing
        }
    }

    @Test
    public void testNullPointerNoContextHealthEndpoint(){
        CustomHealthEndpoint customHealthEndpoint = Mockito.spy(new CustomHealthEndpoint(healthContributorRegistry,
                healthEndpointGroups));
        NullPointerException exception = Assertions.assertThrows(NullPointerException.class, () -> customHealthEndpoint.callParentHealth());
    }
}