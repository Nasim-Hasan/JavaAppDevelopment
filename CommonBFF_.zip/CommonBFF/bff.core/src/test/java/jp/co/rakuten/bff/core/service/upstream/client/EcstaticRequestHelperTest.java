package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.config.InterfaceConfig;
import jp.co.rakuten.bff.core.config.InterfaceConfigLoader;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;

import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class EcstaticRequestHelperTest {
	private static String INTERFACE_NAME = "cardCampaignECStatic";

	@Mock
	private InterfaceConfigLoader interfaceConfigLoader;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@AfterEach
	void tearDown() {
	}

	@DisplayName("Test that client wise backend url is picked when client data is in urlParameter map")
	@ParameterizedTest
	@CsvSource({
			"ichiba_iphone_long,iphone_url",
			"ichiba_android_long,android_url"
	})
	void testGetCustomRequest_UrlParamMap(String clientId, String backendUrl) {
		//Given:
		mockInterfaceConfigLoader();
		Map<String, Object> params = Map.of(
				REQUEST_ID, "test_id",
				URL_PARAMETERS, Map.of(X_CLIENT_ID, clientId)
		);

		//When:
		CustomHttpRequest customRequest = EcstaticRequestHelper.getCustomRequest(params, interfaceConfigLoader,
				new HttpHeaders(), "", false);

		//Then:
		assertNotNull(customRequest);
		assertEquals(backendUrl, customRequest.getConnectionMap().get("url"));
	}

	@DisplayName("Test that client wise backend url is picked when client data is in headerParameter map")
	@ParameterizedTest
	@CsvSource({
			"ichiba_iphone_long,iphone_url",
			"ichiba_android_long,android_url"
	})
	void testGetCustomRequest_HeaderParamMap(String clientId, String backendUrl) {
		//Given:
		mockInterfaceConfigLoader();
		Map<String, Object> params = Map.of(
				REQUEST_ID, "test_id",
				HEADERS, Map.of(X_CLIENT_ID, clientId)
		);

		//When:
		CustomHttpRequest customRequest = EcstaticRequestHelper.getCustomRequest(params, interfaceConfigLoader,
				new HttpHeaders(), "", false);

		//Then:
		assertNotNull(customRequest);
		assertEquals(backendUrl, customRequest.getConnectionMap().get("url"));
	}

	@DisplayName("Test that client wise backend url is picked when client data is in metaParameter map")
	@ParameterizedTest
	@CsvSource({
			"ichiba_iphone_long,iphone_url",
			"ichiba_android_long,android_url"
	})
	void testGetCustomRequest_MetaParamMap(String clientId, String backendUrl) {
		//Given:
		mockInterfaceConfigLoader();
		Map<String, Object> params = Map.of(
				REQUEST_ID, "test_id",
				META_PARAMETERS, Map.of(X_CLIENT_ID, clientId)
		);

		//When:
		CustomHttpRequest customRequest = EcstaticRequestHelper.getCustomRequest(params, interfaceConfigLoader,
				new HttpHeaders(), "", false);

		//Then:
		assertNotNull(customRequest);
		assertEquals(backendUrl, customRequest.getConnectionMap().get("url"));
	}

	private void mockInterfaceConfigLoader() {
		InterfaceConfig interfaceConfig = new InterfaceConfig(INTERFACE_NAME);
		interfaceConfig.putToConnectionMap("url.suffix.key", X_CLIENT_ID);
		interfaceConfig.putToConnectionMap(BffConstants.URL + "_ichiba_iphone_long", "iphone_url");
		interfaceConfig.putToConnectionMap(BffConstants.URL + "_ichiba_android_long", "android_url");

		when(interfaceConfigLoader.getInterface(anyString())).thenReturn(interfaceConfig);
	}
}
