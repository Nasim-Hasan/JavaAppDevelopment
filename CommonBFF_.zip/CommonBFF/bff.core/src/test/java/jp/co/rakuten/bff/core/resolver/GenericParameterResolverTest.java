package jp.co.rakuten.bff.core.resolver;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.ValidatorTypeEnum;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.resolver.provider.SchemaAndParameterRequestArgumentsProvider;
import jp.co.rakuten.bff.core.resolver.provider.SchemaAndParameterResponseArgumentsProvider;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.util.PropertyReader;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static jp.co.rakuten.bff.core.constant.BffConstants.EMPTY_ALLOWED;
import static jp.co.rakuten.bff.core.testUtil.CommonValidatorUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class GenericParameterResolverTest {

	@Mock
	PropertyReader propertyReader;
	@InjectMocks
	private GenericParameterResolver genericParameterResolver;

	private static Stream<Object> stringTypeFailureValidator() {
		return Stream.of(1, 2.2, 2342342342342L, true);
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		when(propertyReader.getPropertyValue("benefits.calculation.aid.abc", ValidatorTypeEnum.INTEGER.getType()))
				.thenReturn("2");
	}

	@AfterEach
	void tearDown() {
		propertyReader = null;
	}

	@DisplayName("Generic request type validation for success")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        | true                  ",
			"boolean        | false                 ",
			"boolean        | true                  ",
			"boolean        | false                 ",
			"integer        | 5                     ",
			"integer        | 5                     ",
			"long           | 50000                 ",
			"double         | 456345.33456346       ",
			"double         | 456345.33456346       ",
	}, delimiter = '|')
	void requestTypeSuccessValidator(String dataType, Object value) {
		Map<String, Object> data = testData(dataType, value);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Validation passes for string When param to validate is not required but empty and Empty value is allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"string        |        "
	}, delimiter = '|')
	void paramNotRequiredButEmptyAndEmptyAllowed_StringType(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setValueComparator(EMPTY_ALLOWED);
		if(value == null){
			value = "";
		}

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Validation passes for string When param to validate is required but empty and Empty value is allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"string        |        "
	}, delimiter = '|')
	void paramRequiredButEmptyAndEmptyAllowed_StringType(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setRequired(true);
		commonSchema.setValueComparator(EMPTY_ALLOWED);
		if(value == null){
			value = "";
		}

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Validation fails for string When param to validate is required but empty and Empty value not allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"string        |        "
	}, delimiter = '|')
	void paramRequiredButEmptyAndEmptyNotAllowed_StringType(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setRequired(true);
		if(value == null){
			value = "";
		}

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
		                                          () -> genericParameterResolver
				                                          .resolveRequestParameter(featureTemplates,
				                                                                   clientRequestModel));
		assertEquals(exception.getMessage(), "param1 request parameter is required!");
	}

	@DisplayName("Validation fails for non string type When param to validate is required but empty and Empty value is not allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"integer        |        ",
			"integer        |        ",
			"long           |        ",
			"double         |        ",
			"double         |        "
	}, delimiter = '|')
	void paramRequiredButEmptyAndEmptyNotAllowed(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setRequired(true);
		if(value == null){
			value = "";
		}

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
		                                          () -> genericParameterResolver
				                                          .resolveRequestParameter(featureTemplates,
				                                                                   clientRequestModel));
		assertEquals(exception.getMessage(), "param1 request parameter is required!");
	}

	@DisplayName("Validation passes for non string type When param to validate is required but empty and Empty value is allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        |        |should be boolean!",
			"boolean        |        |should be boolean!",
			"boolean        |        |should be boolean!",
			"boolean        |        |should be boolean!",
			"integer        |        |should be integer!",
			"integer        |        |should be integer!",
			"integer        |        |should be integer!",
			"long           |        |should be long!",
			"double         |        |should be double!",
			"double         |        |should be double!",
	}, delimiter = '|')
	void requestTypeFailureValidator_EMPTY_ALLOWED_Check(String dataType, Object value, String errorMessage) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setRequired(true);
		commonSchema.setValueComparator(EMPTY_ALLOWED);
		if(value == null){
			value = "";
		}

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		String name = (String) data.get("name");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Validation fails for non string type When param to validate is required but null and Empty value is not allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"integer        |        ",
			"integer        |        ",
			"long           |        ",
			"double         |        ",
			"double         |        "
	}, delimiter = '|')
	void paramRequiredButNullAndEmptyNotAllowed(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setRequired(true);

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
		                                          () -> genericParameterResolver
				                                          .resolveRequestParameter(featureTemplates,
				                                                                   clientRequestModel));
		assertEquals(exception.getMessage(), "param1 request parameter is required!");
	}

	@DisplayName("Validation passes When param to validate is not required and null and Empty value is allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"integer        |        ",
			"integer        |        ",
			"long           |        ",
			"double         |        ",
			"double         |        "
	}, delimiter = '|')
	void paramRequiredButNullAndEmptyAllowed(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");
		commonSchema.setValueComparator(EMPTY_ALLOWED);

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Validation passes When param to validate is not required and null and Empty value is not allowed")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"boolean        |        ",
			"integer        |        ",
			"integer        |        ",
			"long           |        ",
			"double         |        ",
			"double         |        "
	}, delimiter = '|')
	void paramNotRequiredAndNullAndEmptyNotAllowed(String dataType, Object value) {
		Map<String, Object> template = templateLoader(dataType, null);
		CommonSchema commonSchema = (CommonSchema) template.get("commonSchema");

		Map<String, Object> data = testData(dataType, value, template);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Generic request type validation for failure")
	@ParameterizedTest
	@CsvSource(value = {
			"boolean        | abc                   |should be boolean!",
			"boolean        | xyz                   |should be boolean!",
			"boolean        | 1                     |should be boolean!",
			"boolean        | 2                     |should be boolean!",
			"integer        | 5,3                   |should be integer!",
			"integer        | 5.5                   |should be integer!",
			"integer        | abc                   |should be integer!",
			"long           | 50000P                |should be long!",
			"double         | 456345,33456346       |should be double!",
			"double         | 456345_33456346       |should be double!",
	}, delimiter = '|')
	void requestTypeFailureValidator(String dataType, Object value, String errorMessage) {
		Map<String, Object> data = testData(dataType, value);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		String name = (String) data.get("name");

		FeatureException exception = assertThrows(FeatureException.class,
												  () -> genericParameterResolver
														  .resolveRequestParameter(featureTemplates,
																				   clientRequestModel));
		assertEquals(exception.getMessage(), name + " " + errorMessage);

	}

	@DisplayName("Date type test for success")
	@ParameterizedTest
	@CsvSource(value = {
			"02/28/2017 00:00:00                        | MM/dd/yyyy HH:mm:ss         ",
			"01/01/2001                                 | dd/MM/yyyy                  ",
			"02001.July.04 AD 12:08 PM                  | yyyyy.MMMMM.dd GGG hh:mm aaa",
			"Wed, 4 Jul 2001 12:08:56 -0700             | EEE, d MMM yyyy HH:mm:ss Z  ",
			"010704120856-0700                          | yyMMddHHmmssZ               ",
			"2001-07-04T12:08:56.235-0700               | yyyy-MM-dd'T'HH:mm:ss.SSSZ  ",
			"sysdate									| yyyy/MM/dd				  "
	}, delimiter = '|')
	void requestDateTypeSuccessValidator(String value, String format) {
		Map<String, Object> data = testDateData(value, format);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@DisplayName("Date type test for failure")
	@ParameterizedTest
	@CsvSource(value = {
			"02/28/2017 00:00:fh                        | MM/dd/yyyy HH:mm:ss                   | format must be like 'MM/dd/yyyy HH:mm:ss'",
			"2001.ggsdgdg.04 AD 12:08 PM                | dd/MM/yyyy                            | format must be like 'dd/MM/yyyy'",
			"20rgsdg01.July.04 AD 12:08 PM              | yyyyy.MMMMM.dd GGG hh:mm aaa          | format must be like 'yyyyy.MMMMM.dd GGG hh:mm aaa'",
			"Weddgsdgdg, 4 Jul 2001 12:08:56 -0700      | EEE, d MMM yyyy HH:mm:ss Z            | format must be like 'EEE, d MMM yyyy HH:mm:ss Z'",
			"010704dgdfg120856-0700                     | yyMMddHHmmssZ                         | format must be like 'yyMMddHHmmssZ'",
			"2001-07-04T12:08gsdfg:56.235-0700          | yyyy-MM-dd'T'HH:mm:ss.SSSZ            | format must be like 'yyyy-MM-dd'T'HH:mm:ss.SSSZ'",
	}, delimiter = '|')
	void requestDateTypeFailureValidator(String value, String format, String errorMessage) {
		Map<String, Object> data = testDateData(value, format);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		String name = (String) data.get("name");

		FeatureException exception = assertThrows(FeatureException.class,
												  () -> genericParameterResolver
														  .resolveRequestParameter(featureTemplates,
																				   clientRequestModel));
		assertEquals(exception.getMessage(), name + " " + errorMessage);
	}

	@DisplayName("string type validation for failure")
	@ParameterizedTest
	@MethodSource("stringTypeFailureValidator")
	void stringTypeFailureValidator(Object value) {
		Map<String, Object> data = testData("string", value);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		String name = (String) data.get("name");

		FeatureException exception = assertThrows(FeatureException.class,
												  () -> genericParameterResolver
														  .resolveRequestParameter(featureTemplates,
																				   clientRequestModel));
		assertEquals(exception.getMessage(), name + " should be type of string");
	}

	@DisplayName("Different schema and request parameter success test")
	@ParameterizedTest
	@ArgumentsSource(SchemaAndParameterRequestArgumentsProvider.class)
	void differentSchemaAndRequestParameterSuccessTest(Map<String, Object> validatorTestData) {
		List<FeatureTemplate> featureTemplateList = (List<FeatureTemplate>) validatorTestData.get("requestTemplateMap");
		ClientRequestModel requestModel = (ClientRequestModel) validatorTestData.get("actualRequest");

		String errorMessage = (String) validatorTestData.get("errorMessage");

		if (StringUtils.isEmpty(errorMessage)) {
			assertDoesNotThrow(
					() -> genericParameterResolver.resolveRequestParameter(featureTemplateList, requestModel));
		}
	}

	@DisplayName("Different schema and response parameter success test")
	@ParameterizedTest
	@ArgumentsSource(SchemaAndParameterResponseArgumentsProvider.class)
	void differentSchemaAndResponseParameterSuccessTest(Map<String, Object> validatorTestData) {
		List<FeatureTemplate> featureTemplateList = (List<FeatureTemplate>) validatorTestData
				.get("responseTemplateMap");
		Map<String, Object> actualResponse = (Map<String, Object>) validatorTestData.get("actualResponse");

		String errorMessage = (String) validatorTestData.get("errorMessage");

		if (StringUtils.isEmpty(errorMessage)) {
			assertDoesNotThrow(
					() -> genericParameterResolver.resolveResponseParameter(featureTemplateList, actualResponse));
		}
	}

	@DisplayName("Different schema and request parameter failure test")
	@ParameterizedTest
	@ArgumentsSource(SchemaAndParameterRequestArgumentsProvider.class)
	@Disabled
	void differentSchemaAndRequestParameterFailureTest(Map<String, Object> validatorTestData) {
		List<FeatureTemplate> schemaLoader = (List<FeatureTemplate>) validatorTestData.get("requestTemplateMap");
		ClientRequestModel requestTemplateMap = (ClientRequestModel) validatorTestData.get("actualRequest");

		String errorMessage = (String) validatorTestData.get("errorMessage");

		if (StringUtils.isNotEmpty(errorMessage)) {
			FeatureException exception = assertThrows(FeatureException.class,
													  () -> genericParameterResolver
															  .resolveRequestParameter(schemaLoader,
																					   requestTemplateMap));
			assertEquals(exception.getMessage(), errorMessage);
		}
	}

	@DisplayName("Different schema and response parameter failure test")
	@ParameterizedTest
	@ArgumentsSource(SchemaAndParameterResponseArgumentsProvider.class)
	void differentSchemaAndResponseParameterFailureTest(Map<String, Object> validatorTestData) {
		List<FeatureTemplate> schemaLoader = (List<FeatureTemplate>) validatorTestData.get("responseTemplateMap");
		Map<String, Object> actualResponse = (Map<String, Object>) validatorTestData.get("actualResponse");

		String errorMessage = (String) validatorTestData.get("errorMessage");

		Map<String, Object> validatedResponse = genericParameterResolver
				.resolveResponseParameter(schemaLoader, actualResponse);
		if (StringUtils.isNotBlank(errorMessage)) {
			validatedResponse.forEach((k, v) -> {
				int status = (Integer) ((Map) ((Map) v).get("error")).get("code");
				String message = (String) ((Map) ((Map) v).get("error")).get("message");
				assertEquals(503, status);
				assertEquals(errorMessage, message);
			});
		}
	}

	@DisplayName("should not throw exception or remove feature map even if the feature contains empty data")
	@Test
	void validateEmptyFeatureResponses() {
		//given:
		ApiRepository repository = ApiRepositoryTestUtil.getRepository();
		ApiTemplate roomFeedTemplate = repository.getApiRepositoryTemplate("room.feed.v1");
		Map roomFeedFeatureResponse = Map
				.of("roomFeedInfo", Map.of("data", new HashMap<>(), "header", new HashMap<>()));

		//when:
		Map resolveResponseParameter = genericParameterResolver
				.resolveResponseParameter(new ArrayList<>(roomFeedTemplate.getFeaturesMap().values()),
										  roomFeedFeatureResponse);

		//then;
		assertTrue(ObjectUtils.isNotEmpty(resolveResponseParameter));
		assertNotNull(resolveResponseParameter.get("roomFeedInfo"));
		assertEquals(roomFeedFeatureResponse, resolveResponseParameter);
	}

	@DisplayName("Min and Max Value Numeric Exception test")
	@ParameterizedTest
	@CsvSource(value = {
			"integer	| 5          | 10         | 20        |must be over",
			"integer	| 10         | 1          | 5         |must be under",
			"long		| 5000000    | 10000000   | 20000000  |must be over",
			"long		| 1000000    | 100000     | 500000    |must be under",
			"double	    | 5.6    	 | 10      	  | 20        |must be over",
			"double		| 10.8       | 1       	  | 5         |must be under"
	}, delimiter = '|')
	void minMaxNumericFailureTest(String datatype ,Object value ,int min ,int max ,String message) {
			Map<String, Object> data = testNumericData(datatype, value,min,max);
			List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
			ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
				() -> genericParameterResolver
						.resolveRequestParameter(featureTemplates,
								clientRequestModel));

		assertTrue(exception.getMessage().contains(message));
	}

	@DisplayName("Options Exception test")
	@ParameterizedTest
	@CsvSource(value = {
			"string	 | abc          | def,ghi,mno         ",
			"integer | 10           | 1,5,7,8             ",
	}, delimiter = '|')
	void optionFailureTest(String datatype ,Object value ,Object listValue) {
		List optionList = new ArrayList() ;
		if(datatype.equals("string")){
			optionList = Arrays.asList(listValue.toString().split(","));
		}
		if(datatype.equals("integer")){
			optionList = Arrays.stream(listValue.toString().split(",")).map(Integer::parseInt).collect(Collectors.toList());
		}
		Map<String, Object> data = testOption(datatype, value,optionList);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
				() -> genericParameterResolver
						.resolveRequestParameter(featureTemplates,
								clientRequestModel));

		assertTrue(exception.getMessage().contains("for parameter:"));
		assertTrue(exception.getMessage().contains("Please select the value from"));
	}

	@DisplayName("MultiOptions Exception test")
	@ParameterizedTest
	@CsvSource(value = {
			"string	 | abc          		| def,ghi,mno  		       |  1    | 2  | values must be selected",
			"string	 | kbg,rst      		| def,ghi,mno,kbg,rst,wer  |  3    | 4  | , minimum              ",
			"string	 | def,ghi,mno          | def,ghi,mno              |  1    | 2  | and maximum            ",
			"string	 | abc,def         		| def,ghi,mno  			   |  1    | 2  | values must be selected",
			"integer | 10,29        		| 1,5,7,8      			   |  2    | 3  | values must be selected",
			"integer | 7           			| 1,5,7,8       		   |  2    | 3  | , minimum              ",
			"integer | 1,5,7,8         		| 1,5,7,8      			   |  2    | 3  | and maximum            ",
			"integer | 5,8,23          		| 1,5,7,8      			   |  2    | 3  | values must be selected",
	}, delimiter = '|')
	void multiOptionFailureTest(String datatype ,Object value ,Object listValue,Integer minSelect ,Integer maxSelect ,String message) {
		List optionList = new ArrayList() ;
		List valueList  = new ArrayList() ;
		if(datatype.equals("string")){
			valueList = Arrays.asList(value.toString().split(","));
			optionList = Arrays.asList(listValue.toString().split(","));
		}
		if(datatype.equals("integer")){
			valueList = Arrays.stream(value.toString().split(",")).map(Integer::parseInt).collect(Collectors.toList());
			optionList = Arrays.stream(listValue.toString().split(",")).map(Integer::parseInt).collect(Collectors.toList());
		}
		Map<String, Object> data = testMutliOption(datatype, valueList,optionList,minSelect,maxSelect);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");

		FeatureException exception = assertThrows(FeatureException.class,
				() -> genericParameterResolver
						.resolveRequestParameter(featureTemplates,
								clientRequestModel));
		assertTrue(exception.getMessage().contains(message));
	}

	@DisplayName("request failed for Exception for empty featureTemplate")
	@Test
	void requestTypeWithException(){
		List<FeatureTemplate> featureTemplates = new ArrayList<>();
		ClientRequestModel clientRequestModel = new ClientRequestModel();

		ClientException exception = assertThrows(ClientException.class,
				() -> genericParameterResolver
						.resolveRequestParameter(featureTemplates,
								clientRequestModel));
		assertTrue(exception.getMessage().contains("No available feature is being requested"));

	}

	@Test
	void requestTypeSuccessValidatorWithEasyId() {
		Map<String, Object> data = testData("boolean", "true");
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		HttpHeaders header = new HttpHeaders();
		String easyId = "12345";
		List<String> headerList = new ArrayList<>();
		headerList.add(easyId);
		header.put(BffConstants.EASY_ID,headerList );
		clientRequestModel.setHeader(header);

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@Test
	void requestTypeSuccessValidatorWithEmptyCommonRequestModel() {
		Map<String, Object> data = testData("boolean", "true");
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		RequestModel request = clientRequestModel.getRequestModel();
		request.setFeatures(new HashMap<>());
		clientRequestModel.setRequestModel(request);
		HttpHeaders header = new HttpHeaders();
		String regex = "welcome";
		List<String> headerList = new ArrayList<>();
		headerList.add(regex);
		header.put(BffConstants.EASY_ID,headerList );
		clientRequestModel.setHeader(header);

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));
	}

	@Test
	void featureWiseRequestParameterResolveTest(){
		Map<String, Object> data = testData("boolean", "true");
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		RequestModel request = clientRequestModel.getRequestModel();
		Map<String, CommonRequestModel> featureWiseParams = request.getFeatures();
		CommonRequestModel featureWiseRequestModelTest = featureWiseParams.get("feature");
		Set<String> includes = new HashSet<>();
		includes.add("testInclude");
		featureWiseRequestModelTest.setInclude(includes);
		Set<String> excludes = new HashSet<>();
		excludes.add("testExclude");
		excludes.add(null);
		featureWiseRequestModelTest.setExclude(excludes);
		featureWiseParams.put("feature", featureWiseRequestModelTest);
		request.setFeatures(featureWiseParams);
		clientRequestModel.setRequestModel(request);

		FeatureException exception = assertThrows(FeatureException.class,
				() -> genericParameterResolver
						.resolveRequestParameter(featureTemplates,
								clientRequestModel));
		assertNotNull(exception);
		assertTrue(exception.getMessage().contains("Please input includeParams or excludeParams, not both") );

		excludes.remove("testExclude");
		featureWiseRequestModelTest.setExclude(excludes);
		featureWiseParams.put("feature", featureWiseRequestModelTest);
		request.setFeatures(featureWiseParams);
		clientRequestModel.setRequestModel(request);

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));

	}

	@Test
	void validateExcludeFeatureListTest(){
		Map<String, Object> data = testData("boolean", "true");
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>) data.get("featureTemplates");
		ClientRequestModel clientRequestModel = (ClientRequestModel) data.get("ClientRequestModel");
		RequestModel request = clientRequestModel.getRequestModel();
		CommonRequestModel commonParams = new CommonRequestModel();
		Set<String> excludes = new HashSet<>();
		excludes.add("testExclude");
		excludes.add("testExclude2");
		commonParams.setExclude(excludes);
		request.setCommon(commonParams);
		clientRequestModel.setRequestModel(request);

		assertDoesNotThrow(
				() -> genericParameterResolver.resolveRequestParameter(featureTemplates, clientRequestModel));

	}


}
