package jp.co.rakuten.bff.core.filter;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author BJIT Limited
 * Created by tareq rahman on 11/26/19.
 */
public class ResponseFilterTest {
	private static ResponseFilter responseFilter;

	@BeforeAll
	static void setupOnce() {
		responseFilter = new ResponseFilter();
	}

	@DisplayName("test filter method for include: valid case")
	@Test
	void testFilterInclude() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setInclude(
				Set.of("coupon_byshop.response", "shopbookmark_list.data.reviewCount",
					   "shopbookmark_list.data.shopId"));
		CommonRequestModel bookmarkModel = new CommonRequestModel();
		bookmarkModel
				.setInclude(Set.of("shopbookmark_list",
								   "shopbiz_pointinfo.result.shopPointInfoList.shopPointInfo.campaignId"));
		requestModel.setFeatures(Map.of("shopbookmark_list", bookmarkModel, "coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);

		Map responseMap = TestUtil.getObjectFromFilename("http.response/response-filter-test.json", Map.class);

		//assertion before filter
		//Assertion for feature coupon
		Map couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		Map couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		assertNotNull(couponByShop.get("status"));

		Map couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		assertNotNull(couponBookMark.get("shopUrl"));
		assertNotNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		Map shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		Map shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		Map shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("timeStamp"));
		assertNotNull(shopPoint.get("campaignId"));

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		//Assertion for feature coupon
		couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		//Null after include filter
		assertNull(couponByShop.get("status"));

		couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		//Null after include filter
		assertNull(couponBookMark.get("shopUrl"));
		assertNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("campaignId"));
		//Null after include filter
		assertNull(shopPoint.get("timeStamp"));
	}

	@DisplayName("test filter method for exclude: valid case")
	@Test
	void testFilterExclude() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setExclude(
				Set.of("coupon_byshop.response", "shopbookmark_list.data.reviewCount", "shopbookmark_list.data.shopId",
					   "shopbookmark_list.data"));
		CommonRequestModel bookmarkModel = new CommonRequestModel();
		bookmarkModel
				.setExclude(Set.of("shopbookmark_list",
								   "shopbiz_pointinfo.result.shopPointInfoList.shopPointInfo.campaignId"));
		requestModel.setFeatures(Map.of("shopbookmark_list", bookmarkModel, "coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);

		Map responseMap = TestUtil.getObjectFromFilename("http.response/response-filter-test.json", Map.class);

		//assertion before filter
		//Assertion for feature coupon
		Map couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		Map couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop.get("response"));
		assertNotNull(couponByShop.get("status"));

		Map couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		assertNotNull(couponBookMark.get("shopUrl"));
		assertNotNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		Map shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		Map shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		Map shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("timeStamp"));
		assertNotNull(shopPoint.get("campaignId"));

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		//Assertion for feature coupon
		couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		couponByShop = (Map) couponData.get("coupon_byshop");
		assertNull(couponByShop.get("response"));
		//Has value after exclude filter
		assertNotNull(couponByShop.get("status"));

		couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) (couponBookMark.get("data"));
		assertNull(couponBookMark);

		//Assertion for feature shop bookmark
		shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNull(shopBookMarkList);
		shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNull(shopPoint.get("campaignId"));
		//Has value after exclude filter
		assertNotNull(shopPoint.get("timeStamp"));
	}

	@DisplayName("test filter method for include and exclude both: valid case")
	@Test
	void testFilterIncludeAndExclude() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setInclude(
				Set.of("coupon_byshop.response", "shopbookmark_list.data.reviewCount",
					   "shopbookmark_list.data.shopId"));
		CommonRequestModel bookmarkModel = new CommonRequestModel();
		bookmarkModel
				.setExclude(Set.of("shopbookmark_list",
								   "shopbiz_pointinfo.result.shopPointInfoList.shopPointInfo.campaignId"));
		requestModel.setFeatures(Map.of("shopbookmark_list", bookmarkModel, "coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);

		Map responseMap = TestUtil.getObjectFromFilename("http.response/response-filter-test.json", Map.class);

		//assertion before filter
		//Assertion for feature coupon
		Map couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		Map couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		assertNotNull(couponByShop.get("status"));

		Map couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		assertNotNull(couponBookMark.get("shopUrl"));
		assertNotNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		Map shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		Map shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		Map shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("timeStamp"));
		assertNotNull(shopPoint.get("campaignId"));

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		//Assertion for feature coupon
		couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		//Null after include filter
		assertNull(couponByShop.get("status"));
		couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		//Null after include filter
		assertNull(couponBookMark.get("shopUrl"));
		assertNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNull(shopBookMarkList);
		shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNull(shopPoint.get("campaignId"));
		//Has value after exclude filter
		assertNotNull(shopPoint.get("timeStamp"));
	}

	@DisplayName("test filter method for include: invalid case")
	@Test
	void testFilterIncludeFailure() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setInclude(
				Set.of("coupon_byshop.response", "shopbookmark_list.data.reviewCount",
					   "shopbookmark_list.data.reviewCount.number", "shopbookmark_list.data.shopId.itemId"));
		CommonRequestModel bookmarkModel = new CommonRequestModel();
		requestModel.setFeatures(Map.of("shopbookmark_list", bookmarkModel, "coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);

		Map responseMap = TestUtil.getObjectFromFilename("http.response/response-filter-test.json", Map.class);

		//assertion before filter
		//Assertion for feature coupon
		Map couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		Map couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		assertNotNull(couponByShop.get("status"));

		Map couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		assertNotNull(couponBookMark.get("shopUrl"));
		assertNotNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		Map shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		Map shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		Map shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("timeStamp"));
		assertNotNull(shopPoint.get("campaignId"));

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		//Assertion for feature coupon
		couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		//Null after include filter
		assertNull(couponByShop.get("status"));
		couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertFalse(couponBookMark.get("reviewCount") instanceof Map);
	}

	@DisplayName("test filter method for exclude: invalid case")
	@Test
	void testFilterExcludeFailure() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setExclude(
				Set.of("coupon_byshop.response", "shopbookmark_list.data.reviewCount",
					   "shopbookmark_list.data.reviewCount.number", "shopbookmark_list.data.shopId.itemId"));
		CommonRequestModel bookmarkModel = new CommonRequestModel();
		requestModel.setFeatures(Map.of("shopbookmark_list", bookmarkModel, "coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);

		Map responseMap = TestUtil.getObjectFromFilename("http.response/response-filter-test.json", Map.class);

		//assertion before filter
		//Assertion for feature coupon
		Map couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		Map couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNotNull(couponByShop.get("response"));
		assertNotNull(couponByShop.get("status"));

		Map couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertNotNull(couponBookMark.get("reviewCount"));
		assertNotNull(couponBookMark.get("shopId"));
		assertNotNull(couponBookMark.get("shopUrl"));
		assertNotNull(couponBookMark.get("reviewRating"));

		//Assertion for feature shop bookmark
		Map shopBookMark = (Map) ((Map) responseMap.get("shopbookmark_list")).get("data");
		assertNotNull(shopBookMark);
		Map shopBookMarkList = (Map) shopBookMark.get("shopbookmark_list");
		assertNotNull(shopBookMarkList);
		Map shopPoint = (Map) shopBookMark.get("shopbiz_pointinfo");
		shopPoint = (Map) ((List) shopPoint.get("result")).get(0);
		shopPoint = (Map) shopPoint.get("shopPointInfoList");
		shopPoint = (Map) ((List) shopPoint.get("shopPointInfo")).get(0);
		assertNotNull(shopPoint.get("timeStamp"));
		assertNotNull(shopPoint.get("campaignId"));

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		//Assertion for feature coupon
		couponData = (Map) ((Map) responseMap.get("coupon")).get("data");
		assertNotNull(couponData);
		couponByShop = (Map) couponData.get("coupon_byshop");
		assertNotNull(couponByShop);
		assertNull(couponByShop.get("response"));
		//Null after include filter
		couponBookMark = (Map) couponData.get("shopbookmark_list");
		couponBookMark = (Map) ((List) couponBookMark.get("data")).get(0);
		assertFalse(couponBookMark.get("reviewCount") instanceof Map);
	}

	@DisplayName("test filter include: while user mistakenly expect data from list of string but with a key")
	@Test
	void testFilterInvalidCase() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setInclude(Set.of("dummy.inner.value1"));
		requestModel.setFeatures(Map.of("coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);
		Map responseMap = new HashMap(
				Map.of("coupon", Map.of("data", Map.of("dummy", Map.of("inner", List.of("value1", "value2"))))));

		//before filter
		assertEquals(2, ((List) ((Map) ((Map) ((Map) responseMap.get("coupon")).get("data")).get("dummy")).get("inner"))
				.size());

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		assertEquals(0, ((List) ((Map) ((Map) ((Map) responseMap.get("coupon")).get("data")).get("dummy")).get("inner"))
				.size());
	}

	@DisplayName("test filter exclude: while user mistakenly expect data from list of string but with a key")
	@Test
	void testFilterExvalidCase() {
		//given
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel couponModel = new CommonRequestModel();
		couponModel.setExclude(Set.of("dummy.inner.value1"));
		requestModel.setFeatures(Map.of("coupon", couponModel));
		clientRequestModel.setRequestModel(requestModel);
		Map responseMap = new HashMap(
				Map.of("coupon", Map.of("data", Map.of("dummy", Map.of("inner", List.of("value1", "value2"))))));

		//before filter
		assertEquals(2, ((List) ((Map) ((Map) ((Map) responseMap.get("coupon")).get("data")).get("dummy")).get("inner"))
				.size());

		//when
		responseFilter.filter(clientRequestModel, responseMap);

		//assertion after filter
		assertNotNull(responseMap);
		assertEquals(2, ((List) ((Map) ((Map) ((Map) responseMap.get("coupon")).get("data")).get("dummy")).get("inner"))
				.size());
	}

}
