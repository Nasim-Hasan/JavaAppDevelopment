package jp.co.rakuten.bff.core.model.http;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CustomErrorTest {
	@Test
	void testBoilerplates() {
		String errMsg = "To err is human";
		CustomError err = CustomError.builder().message(errMsg).build();
		assertEquals(errMsg, err.getMessage());
		assertTrue(err.toString().contains(errMsg));
	}
}
