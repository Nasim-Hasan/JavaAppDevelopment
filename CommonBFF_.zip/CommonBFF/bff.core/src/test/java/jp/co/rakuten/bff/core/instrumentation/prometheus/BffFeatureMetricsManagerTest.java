package jp.co.rakuten.bff.core.instrumentation.prometheus;

import jp.co.rakuten.bff.core.template.ApiTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import javax.management.MBeanServer;
import java.lang.management.ManagementFactory;
import java.util.HashMap;


/**
 * @author prithviraj.pawar
 */
public class BffFeatureMetricsManagerTest {
	static final String API_KEY = "my.cool.bff";
	ApiTemplate apiTemplate = new ApiTemplate();
	HashMap<String, ApiTemplate> map = new HashMap();
	private MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void featureEntry() {
		//given:
		BffFeatureMetricsManager.initialize(map);
		//when:
		//There shouldnt be any error
		BffFeatureMetricsManager.markFeatureEntry(API_KEY, null);

	}

	@Test
	public void FeatureExit() {
		//given:
		BffFeatureMetricsManager.initialize(map);
		//when:
		//There shouldnt be any error
		BffFeatureMetricsManager.markFeatureExit(API_KEY, null);
	}

	@Test
	public void callDefinitionExit() {
		//given:
		BffFeatureMetricsManager.initialize(map);
		//when:
		//There shouldnt be any error
		BffFeatureMetricsManager.markCallDefinitionExit(API_KEY, null, null);
	}


}
