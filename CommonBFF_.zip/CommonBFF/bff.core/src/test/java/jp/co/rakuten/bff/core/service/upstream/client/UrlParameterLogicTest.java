package jp.co.rakuten.bff.core.service.upstream.client;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.model.http.CustomHttpRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;

class UrlParameterLogicTest {

	@InjectMocks
	UrlParameterLogic urlParameterLogic;

	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() {
		urlParameterLogic = null;
	}

	@Test
	void testRegularScenario() {
		// Setup: NA

		// Given:
		CustomHttpRequest customHttpRequest = getDefaultMockedCustomHttpRequest();

		// When:
		URI uri = UrlParameterLogic.buildUri(customHttpRequest);

		// Verify response:
		assertEquals("http://stg-ashopbizapi101z.stg.jp.local:7030" +
							 // {shopId} has been replaced by "1"
							 "/shopbiz/shopPointInfo/1" +
							 "?" +
							 // The easyId has been added after the question mark
							 "easyId=504150" +
							 "&" +
							 // The null value has been converted to "null"
							 "keyWithNullValue=null",
					 uri.toString());

		// Verify mocks: NA
	}

	@Test
	void testQuestionMarkAlreadyPresentInTheUrl() {
		// Setup: NA

		// Given:
		CustomHttpRequest customHttpRequest = CustomHttpRequest.builder()
				.interfaceKey("shopbiz_pointinfo")
				.connectionMap(Map.of(URL,
									  "http://stg-ashopbizapi101z.stg.jp.local:7030/shopbiz/shopPointInfo?hits=20"))
				.urlParameterMap(Map.of("shopId", "1"))
				.build();

		// When:
		URI uri = UrlParameterLogic.buildUri(customHttpRequest);

		// Verify response:
		assertEquals("http://stg-ashopbizapi101z.stg.jp.local:7030/shopbiz/shopPointInfo?hits=20&shopId=1",
					 uri.toString());

		// Verify mocks: NA
	}

	@Test
	void testUnsupportedEncodingException() {
		// Setup
		CustomHttpRequest customHttpRequest = CustomHttpRequest.builder()
				.interfaceKey("shopbiz_pointinfo")
				.connectionMap(Map.of(URL, "a.com", REQUEST_CHARSET, "not-supported"))
				.urlParameterMap(Map.of("shopId", "1"))
				.build();
		// When + Verify response:
		assertThrows(SystemException.class, () -> UrlParameterLogic.buildUri(customHttpRequest));

		// Verify mocks: NA
	}

	private CustomHttpRequest getDefaultMockedCustomHttpRequest() {
		Map<String, String> urlParamMap = new HashMap<>();
		urlParamMap.put("shopId", "1");
		urlParamMap.put("easyId", "504150");
		urlParamMap.put("keyWithNullValue", null);
		return CustomHttpRequest.builder()
				.interfaceKey("shopbiz_pointinfo")
				.connectionMap(Map.of(URL,
									  "http://stg-ashopbizapi101z.stg.jp.local:7030/shopbiz/shopPointInfo/{shopId}"))
				.urlParameterMap(urlParamMap)
				.build();
	}
}