package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.exception.SystemException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ApiDetailTest {

	@Test
	void testWithWrongKey() {
		assertThrows(SystemException.class, () -> {
			new ApiDetail("");
		});
	}

	@Test
	void testWithValidKey() {
		String service = "mySerive";
		String operation = "myOperation";
		String version = "v1";
		String apiKey = service + "." + operation + "." + version;
		ApiDetail model = new ApiDetail(apiKey);
		assertEquals(service, model.getService());
		assertEquals(operation, model.getOperation());
		assertEquals(version, model.getVersion());
	}
}
