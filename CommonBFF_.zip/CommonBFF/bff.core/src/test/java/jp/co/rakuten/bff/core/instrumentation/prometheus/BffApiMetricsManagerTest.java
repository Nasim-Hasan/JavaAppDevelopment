package jp.co.rakuten.bff.core.instrumentation.prometheus;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.ApiDetail;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;


/**
 * @author prithviraj.pawar
 */
public class BffApiMetricsManagerTest {
	static final String API_KEY = "my.cool.bff";
	static final String CLIENT_ID = "boring.client";
	ApiTemplate apiTemplate = new ApiTemplate();
	HashMap<String, ApiTemplate> map = new HashMap();
	private MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
    private String repoDir = ApiRepositoryTestUtil.DEFAULT_REPO_DIR;

    private Environment environment;

    @Mock
    private ApiRepository apiRepository;

	@BeforeEach
	void setUp() {
        environment = ApiRepositoryTestUtil.getMockEnv(repoDir);
        MockitoAnnotations.initMocks(this);
	}

	@Test
	public void initSuccess() throws MalformedObjectNameException {
		//When:
        apiTemplate.setApiDetail(new ApiDetail(API_KEY));
        map.put(API_KEY, apiTemplate);
        when(apiRepository.getAllApiTemplates()).thenReturn(map);
        when(environment.getProperty("api.slow.requests.threshold.time",Long.class,2000L)).thenReturn(2000L);
        BffApiMetricsManager.initialize(apiRepository,environment);
		Set apiNames = mbs.queryNames(null, null);

		//verify the requestType mbeans created
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.api.time.histogram:name=my.cool.bff,type=histograms")),
					 true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.api.requests:name=my.cool.bff,type=counters")), true);
		assertEquals(mbs.isRegistered(new ObjectName("ichiba.bff.api.time:name=my.cool.bff,type=counters")), true);

	}

	@Test
	public void apiEntry() {
		//given:
        when(apiRepository.getAllApiTemplates()).thenReturn(map);
        when(environment.getProperty("api.slow.requests.threshold.time",Long.class,2000L)).thenReturn(2000L);
        BffApiMetricsManager.initialize(apiRepository,environment);

		//when:
		//There shouldnt be any error
		BffApiMetricsManager.markEntry(API_KEY, null, CLIENT_ID);

		//when: No Headers present
		//there shouldnt be any error
		BffApiMetricsManager.markEntry(API_KEY, null, null);
	}

	@Test
	public void apiExit() {
		//Given:
		String requestType = "single";
		String overallStatus = "FAILURE";
		HttpStatus httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
		String errorType = "service_unavailable";

		//given:
        when(apiRepository.getAllApiTemplates()).thenReturn(map);
        when(environment.getProperty("api.slow.requests.threshold.time",Long.class,2000L)).thenReturn(2000L);
        BffApiMetricsManager.initialize(apiRepository,environment);

		//when:
		//There shouldnt be any error
		BffApiMetricsManager.markExit(API_KEY, HttpStatus.MULTI_STATUS, null);

		//there shouldnt be any error
		BffApiMetricsManager.markExit(API_KEY, HttpStatus.INTERNAL_SERVER_ERROR,
									  SystemException
											  .create(SystemErrorEnum.INTERNAL, new NullPointerException("Null value"),
													  "Bff not so cool").getErrorType());


	}

}
