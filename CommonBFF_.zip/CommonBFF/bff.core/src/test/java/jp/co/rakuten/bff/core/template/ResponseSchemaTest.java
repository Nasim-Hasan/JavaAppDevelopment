package jp.co.rakuten.bff.core.template;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ResponseSchemaTest {

	@Test
	void testBoilerplates() {
		ResponseSchema schema = new ResponseSchema();
		List headers = List.of(new ResponseSchema());
		schema.setHeaders(headers);
		assertEquals(headers, schema.getHeaders());
		schema.setFastForward(true);
		assertEquals(true,schema.getFastForward());
	}
}
