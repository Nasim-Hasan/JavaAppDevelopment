package jp.co.rakuten.bff.core.model;

import jp.co.rakuten.bff.core.model.http.CustomError;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class FeaturePostProcessorResponseTest {

	@Test
	void testToString() {
		FeaturePostProcessorResponse featurePostProcessorResponse = new FeaturePostProcessorResponse();
		assertDoesNotThrow(()->{
			featurePostProcessorResponse.setHeaders(Map.of("a","val"));
		});
		String response= featurePostProcessorResponse.toString();
		assertNotNull(response);
		FeaturePostProcessorResponse responseMono= featurePostProcessorResponse.getEmptyResponseMono().block();
		assertTrue(responseMono instanceof FeaturePostProcessorResponse);
	}
}
