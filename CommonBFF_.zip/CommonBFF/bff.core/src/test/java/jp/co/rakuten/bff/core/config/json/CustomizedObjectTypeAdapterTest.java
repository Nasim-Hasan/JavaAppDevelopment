package jp.co.rakuten.bff.core.config.json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;


class CustomizedObjectTypeAdapterTest {
	private Gson gson;

	@BeforeEach
	void setUp() {
		CustomizedObjectTypeAdapter adapter = new CustomizedObjectTypeAdapter();
		gson = new GsonBuilder()
				.registerTypeAdapter(Map.class, adapter)
				.registerTypeAdapter(List.class, adapter)
				.create();
	}

	@AfterEach
	void tearDown() {
	}

	@Test
	void read() {
		//Given:
		String fileName = "sampleJson/benefit_status_ecstatic.json";
		String contents = TestUtil.getFileContents(fileName);

		//When:
		Map result = gson.fromJson(contents, Map.class);

		//Then:
		assertNotNull(result);
		Map data = (Map) ((List) result.get("data")).get(0);
		Map innerData = (Map) ((List) ((Map) ((List) result.get("data")).get(0)).get("items")).get(0);
		assertEquals(1, data.get("section_type"));
		assertEquals("totalRate", innerData.get("id"));
		assertEquals(1, innerData.get("type"));
		assertEquals(2147483649L, innerData.get("title_item"));
		assertEquals("あなたはポイント", innerData.get("title_non_item"));
		assertEquals(20.5, innerData.get("point_rate_prefix"));
		assertEquals(2147483649.544, innerData.get("point_rate_suffix"));
		assertTrue(data.get("section_type") instanceof Integer);
		assertTrue(innerData.get("id") instanceof String);
		assertTrue(innerData.get("type") instanceof Integer);
		assertTrue(innerData.get("title_item") instanceof Long);
		assertTrue(innerData.get("title_non_item") instanceof String);
		assertTrue(innerData.get("point_rate_prefix") instanceof Double);
		assertTrue(innerData.get("point_rate_suffix") instanceof Double);
	}
}
