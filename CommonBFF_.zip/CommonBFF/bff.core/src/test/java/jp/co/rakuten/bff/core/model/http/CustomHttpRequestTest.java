package jp.co.rakuten.bff.core.model.http;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class CustomHttpRequestTest {

	String requestId;
	String interfaceKey;
	String circuit;
	Map connMap;
	Map headMap;
	Map paraMap;
	CustomHttpRequest model;

	@BeforeEach
	void setup() {
		requestId = "rId";
		interfaceKey = "iKey";
		circuit = "cIrc";
		connMap = Map.of("fooConn", "barConn");
		headMap = Map.of("fooHead", "barHead");
		paraMap = Map.of("fooPara", "barPara");
		model = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
	}

	@Test
	void testEquals() {
		CustomHttpRequest reqEqual = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
		assertTrue(model.equals(reqEqual));
		assertTrue(model.equals(model));
		assertFalse(model.equals(null));
		assertFalse(model.equals(requestId));
		assertFalse(model.equals(requestId));

		CustomHttpRequest reqNoCircuit = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.build();
		assertFalse(model.equals(reqNoCircuit));

		CustomHttpRequest reqNoUrl = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.headerMap(headMap)
				.circuit(circuit)
				.build();
		assertFalse(model.equals(reqNoUrl));

		CustomHttpRequest reqNoHeader = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
		assertFalse(model.equals(reqNoHeader));

		CustomHttpRequest reqNoConn = CustomHttpRequest.builder()
				.requestId(requestId)
				.interfaceKey(interfaceKey)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
		assertFalse(model.equals(reqNoConn));

		CustomHttpRequest reqNoIfaceKey = CustomHttpRequest.builder()
				.requestId(requestId)
				.connectionMap(connMap)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
		assertFalse(model.equals(reqNoIfaceKey));

		CustomHttpRequest reqReqId = CustomHttpRequest.builder()
				.interfaceKey(interfaceKey)
				.connectionMap(connMap)
				.headerMap(headMap)
				.urlParameterMap(paraMap)
				.circuit(circuit)
				.build();
		assertFalse(model.equals(reqReqId));
	}

	@Test
	void testHash() {
		assertEquals(-1389351238, model.hashCode());
	}

	@Test
	void testBoilerplates() {
		assertEquals(circuit, model.getCircuit());
		assertTrue(model.toString().contains(requestId));
	}
}
