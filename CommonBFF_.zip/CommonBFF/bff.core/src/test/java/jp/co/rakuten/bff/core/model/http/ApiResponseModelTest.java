package jp.co.rakuten.bff.core.model.http;

import jp.co.rakuten.bff.core.model.ApiResponseModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class ApiResponseModelTest {
	private ApiResponseModel model;

	@BeforeEach
	void cleanup() {
		model = new ApiResponseModel();
	}

	@Test
	@DisplayName("Getter-Setter test")
	void checkGetterSetter() {
		HttpStatus httpStatus = mock(HttpStatus.class);
		String status = "testStatus";
		assertDoesNotThrow(() -> {
			model.setHttpStatus(httpStatus);
			model.setStatus(status);
			model.setBody(model.getBody());
			model.setHeaders(model.getHeaders());
		});
		assertEquals(httpStatus, model.getHttpStatus());
		assertEquals(status, model.getStatus());
		assertNotNull(model.getBody());
		assertNotNull(model.getHeaders());
		assertTrue(model.toString().contains("ApiResponseModel"));
	}
}
