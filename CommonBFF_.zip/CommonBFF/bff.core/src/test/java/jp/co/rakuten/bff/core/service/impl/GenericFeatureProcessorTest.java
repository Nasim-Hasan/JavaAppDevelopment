package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.model.CallDefinitionError;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;

class GenericFeatureProcessorTest {

	private static ApiTemplate apiTemplate;
	private static GenericFeatureProcessor genericFeatureProcessor;

	@BeforeAll
	static void setUpAll() {
		genericFeatureProcessor = new GenericFeatureProcessor();
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();
		apiTemplate = apiRepository.getApiRepositoryTemplate("shopbookmark.list.v");
	}

	@Test
	@DisplayName("If all call definition run with CallDefinitionResponseStatus.SUCCESS")
	void allCallDefinitionSuccess() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		featureTemplate.getCallDefinitionsSet().forEach(callDefinitionTemplate -> {

			MultipleResponses multipleResponses = new MultipleResponses();
			multipleResponses.setOverallStatus(UPSTREAM_RESPONSE_SUCCESS);

			Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
			HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
			callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
				String requestId = UUID.randomUUID().toString();
				CustomHttpResponse customHttpResponse = CustomHttpResponse.builder()
						.interfaceKey(interfaceName)
						.bodyMap(Map.of(interfaceName, interfaceName))
						.build();
				responseMap.put(requestId, customHttpResponse);
				if (interfaceToRequestIdMap.containsKey(interfaceName)) {
					interfaceToRequestIdMap.get(interfaceName).add(requestId);
				} else {
					List<String> requestIdList = new ArrayList<>();
					requestIdList.add(requestId);
					interfaceToRequestIdMap.put(interfaceName, requestIdList);
				}
			});
			multipleResponses.setResponses(responseMap);

			CallDefinitionResponse callDefinitionResponse =
					new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
			callDefinitionResponse.setMultipleResponses(multipleResponses);
			callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);
			callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
		});

		//then
		FeaturePostProcessorResponse response = genericFeatureProcessor.postProcess(null, featureTemplate,
				callDefinitionResponseMap).block();

		//verify
		assertNotNull(response);
		assertTrue(response.isCacheable());
		assertEquals(4, response.getResponseMap().size());
		featureTemplate.getInterfaceNameList().forEach((String interfaceName) ->
				assertNotNull(response.getResponseMap().get(interfaceName)));
	}

	@Test
	@DisplayName("If one call definition run with CallDefinitionResponseStatus.FAILURE")
	void oneCallDefinitionRunWithFailure() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		for (CallDefinitionTemplate callDefinitionTemplate : featureTemplate.getCallDefinitionsSet()) {
			if (callDefinitionTemplate.getName().equalsIgnoreCase("pointinfo_gspinfo_coupon")) {
				CallDefinitionError callDefinitionError = new CallDefinitionError();
				callDefinitionError.setCode(GG_NOT_CALL_RESPONSE_STATUS);
				callDefinitionError.setMessage(GG_NOT_CALL_RESPONSE_MSG);

				CallDefinitionResponse callDefinitionResponse =
						new CallDefinitionResponse(CallDefinitionResponseStatus.FAILURE);
				callDefinitionResponse.setCallDefinitionError(callDefinitionError);
				callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
			} else {
				MultipleResponses multipleResponses = new MultipleResponses();
				multipleResponses.setOverallStatus(UPSTREAM_RESPONSE_SUCCESS);

				HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
				Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
				callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
					String requestId = UUID.randomUUID().toString();
					CustomHttpResponse customHttpResponse = CustomHttpResponse.builder()
							.interfaceKey(interfaceName)
							.bodyMap(Map.of(interfaceName, interfaceName))
							.build();
					responseMap.put(requestId, customHttpResponse);
					if (interfaceToRequestIdMap.containsKey(interfaceName)) {
						interfaceToRequestIdMap.get(interfaceName).add(requestId);
					} else {
						List<String> requestIdList = new ArrayList<>();
						requestIdList.add(requestId);
						interfaceToRequestIdMap.put(interfaceName, requestIdList);
					}
				});
				multipleResponses.setResponses(responseMap);

				CallDefinitionResponse callDefinitionResponse =
						new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
				callDefinitionResponse.setMultipleResponses(multipleResponses);
				callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);
				callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
			}
		}

		//then
		FeaturePostProcessorResponse response = genericFeatureProcessor.postProcess(null, featureTemplate,
				callDefinitionResponseMap).block();

		//verify
		assertNotNull(response);
		assertFalse(response.isCacheable());
		assertEquals(4, response.getResponseMap().size());
		featureTemplate.getInterfaceNameList().forEach((String interfaceName) -> {
			if (interfaceName.equalsIgnoreCase("shopbookmark_list") ||
					interfaceName.equalsIgnoreCase("gsp_multiple_test")) {
				assertNotNull(response.getResponseMap().get(interfaceName));
			} else {
				Map<String, Object> interfaceResponse =
						(Map<String, Object>) response.getResponseMap().get(interfaceName);
				assertNotNull(interfaceResponse);
				assertEquals(GG_NOT_CALL_RESPONSE_STATUS,
						((CallDefinitionError) interfaceResponse.get(ERROR)).getCode());
				assertEquals(GG_NOT_CALL_RESPONSE_MSG,
						((CallDefinitionError) interfaceResponse.get(ERROR)).getMessage());
			}
		});
	}

	@Test
	@DisplayName("If one call definition run with CallDefinitionResponseStatus.NOT_CALLED")
	void oneCallDefinitionRunWithNotCall() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		for (CallDefinitionTemplate callDefinitionTemplate : featureTemplate.getCallDefinitionsSet()) {
			if (callDefinitionTemplate.getName().equalsIgnoreCase("shopbookmark_list")) {
				CallDefinitionError callDefinitionError = new CallDefinitionError();
				callDefinitionError.setCode(GG_NOT_CALL_RESPONSE_STATUS);
				callDefinitionError.setMessage(GG_NOT_CALL_RESPONSE_MSG);

				CallDefinitionResponse callDefinitionResponse =
						new CallDefinitionResponse(CallDefinitionResponseStatus.NOT_CALLED);
				callDefinitionResponse.setCallDefinitionError(callDefinitionError);

				callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
			} else {
				MultipleResponses multipleResponses = new MultipleResponses();
				multipleResponses.setOverallStatus(UPSTREAM_RESPONSE_SUCCESS);

				HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
				Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
				callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
					String requestId = UUID.randomUUID().toString();
					CustomHttpResponse customHttpResponse = CustomHttpResponse.builder()
							.interfaceKey(interfaceName)
							.bodyMap(Map.of(interfaceName, interfaceName))
							.build();
					responseMap.put(requestId, customHttpResponse);
					if (interfaceToRequestIdMap.containsKey(interfaceName)) {
						interfaceToRequestIdMap.get(interfaceName).add(requestId);
					} else {
						List<String> requestIdList = new ArrayList<>();
						requestIdList.add(requestId);
						interfaceToRequestIdMap.put(interfaceName, requestIdList);
					}
				});
				multipleResponses.setResponses(responseMap);

				CallDefinitionResponse callDefinitionResponse =
						new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
				callDefinitionResponse.setMultipleResponses(multipleResponses);
				callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);
				callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
			}
		}

		//then
		FeaturePostProcessorResponse response = genericFeatureProcessor.postProcess(null, featureTemplate,
				callDefinitionResponseMap).block();

		//verify
		assertNotNull(response);
		assertFalse(response.isCacheable());
		assertEquals(4, response.getResponseMap().size());
		featureTemplate.getInterfaceNameList().forEach((String interfaceName) -> {
			if (interfaceName.equalsIgnoreCase("shopbookmark_list")) {
				Map<String, Object> interfaceResponse =
						(Map<String, Object>) response.getResponseMap().get(interfaceName);
				assertNotNull(interfaceResponse);
				assertEquals(GG_NOT_CALL_RESPONSE_STATUS,
						((CallDefinitionError) interfaceResponse.get(ERROR)).getCode());
				assertEquals(GG_NOT_CALL_RESPONSE_MSG,
						((CallDefinitionError) interfaceResponse.get(ERROR)).getMessage());
			} else {
				assertNotNull(response.getResponseMap().get(interfaceName));
			}
		});
	}

	@Test
	@DisplayName("If all call definition run CallDefinitionResponseStatus.SUCCESS but one interface failed in GG")
	void allCallDefinitionSuccessButOneInterfaceFailedInGG() {
		//given
		FeatureTemplate featureTemplate = apiTemplate.getFeaturesMap().get("shopbookmark_list");
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		featureTemplate.getCallDefinitionsSet().forEach(callDefinitionTemplate -> {

			MultipleResponses multipleResponses = new MultipleResponses();
			multipleResponses.setOverallStatus(UPSTREAM_RESPONSE_SUCCESS);

			HashMap<String, CustomHttpResponse> responseMap = new HashMap<>();
			Map<String, List<String>> interfaceToRequestIdMap = new HashMap<>();
			callDefinitionTemplate.getInterfacesList().forEach((String interfaceName) -> {
				String requestId = UUID.randomUUID().toString();
				CustomHttpResponse customHttpResponse = CustomHttpResponse.builder()
						.interfaceKey(interfaceName)
						.bodyMap(Map.of(interfaceName, interfaceName))
						.build();
				if (interfaceName.equalsIgnoreCase("gsp_shop_review")) {
					customHttpResponse.setBodyMap(null);
					customHttpResponse.setError(CustomError.builder().code("503").build());
				}
				responseMap.put(requestId, customHttpResponse);
				if (interfaceToRequestIdMap.containsKey(interfaceName)) {
					interfaceToRequestIdMap.get(interfaceName).add(requestId);
				} else {
					List<String> requestIdList = new ArrayList<>();
					requestIdList.add(requestId);
					interfaceToRequestIdMap.put(interfaceName, requestIdList);
				}
			});
			multipleResponses.setResponses(responseMap);

			CallDefinitionResponse callDefinitionResponse =
					new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
			callDefinitionResponse.setMultipleResponses(multipleResponses);
			callDefinitionResponse.setInterfaceToRequestIdMap(interfaceToRequestIdMap);
			callDefinitionResponseMap.put(callDefinitionTemplate.getName(), callDefinitionResponse);
		});

		//then
		FeaturePostProcessorResponse response = genericFeatureProcessor.postProcess(null, featureTemplate,
				callDefinitionResponseMap).block();

		//verify
		assertNotNull(response);
		assertFalse(response.isCacheable());
		assertEquals(4, response.getResponseMap().size());
		featureTemplate.getInterfaceNameList().forEach((String interfaceName) -> {
			if (interfaceName.equalsIgnoreCase("gsp_shop_review")) {
				assertEquals("503",
						((CustomError) response.getResponseMap().get(interfaceName)).getCode());
			} else {
				assertNotNull(response.getResponseMap().get(interfaceName));
			}
		});
	}

}