package jp.co.rakuten.bff.core.exception;

import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author BJIT Limited Created by tareq rahman on 12/3/19.
 */
public class BffExceptionTest {

	@DisplayName("test get detail message")
	@Test
	void testGetDetailedMessage() {
		BffException bffException = ClientException.create(ClientErrorEnum.BAD_REQUEST, "test")
				.addDetailForLog("dummy message");

		String message = bffException.getDetailedMessage();

		assertNotNull(message);
		assertEquals("test. dummy message", message);

		bffException = ClientException.create(ClientErrorEnum.BAD_REQUEST, "test");

		message = bffException.getDetailedMessage();

		assertNotNull(message);
		assertEquals("test", message);

		bffException = FeatureException.create("itemInfo",ClientErrorEnum.BAD_REQUEST, "test");

		message = bffException.getDetailedMessage();

		assertNotNull(message);
		assertEquals("test", message);

		bffException = FeatureException.create("itemInfo","test");

		message = bffException.getDetailedMessage();

		assertNotNull(message);
		assertEquals("test", message);
	}

	@DisplayName("test get Upstream status code")
	@Test
	void testGetUpstreamStatusCode() {
		BffException bffException = BackendException
				.create(BackendErrorEnum.NOT_FOUND, HttpStatus.METHOD_NOT_ALLOWED, "Wrong Http Method")
				.addDetailForLog("Upstream returned: 405 Method Not Allowed");

		HttpStatus upstreamStatusCode = bffException.getUpstreamStatusCode();

		assertNotNull(upstreamStatusCode);
		assertEquals(HttpStatus.METHOD_NOT_ALLOWED, upstreamStatusCode);
	}
}
