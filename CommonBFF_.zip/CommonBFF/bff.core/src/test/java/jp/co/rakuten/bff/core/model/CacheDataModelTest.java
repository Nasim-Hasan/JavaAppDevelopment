package jp.co.rakuten.bff.core.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class CacheDataModelTest {

	@Test
	void checkGetSet() {
		CacheDataModel model = new CacheDataModel();
		assertDoesNotThrow(() -> {
			model.setStaleCache(true);
			model.setCacheMap(null);
		});
	}
}
