package jp.co.rakuten.bff.core.controller;

import brave.Tracer;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import jp.co.rakuten.bff.core.model.ApiResponseModel;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.service.ApiExecutionService;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ApiControllerTest {
	ResponseUtil responseUtil;
	@Mock
	Tracer tracer;
	@Mock
	private Environment environment;
	@Mock
	private ApiExecutionService executionService;
	@Mock
	private HttpLogger apiLogger;

	@BeforeEach
	private void setup() {
		MockitoAnnotations.initMocks(this);
		responseUtil = new ResponseUtil(tracer);
	}

	@DisplayName("Spy(object) executionService for Mono with exception and count calls")
	@Test
	void spyObjectExecutionServiceForMonoWithExceptionAndCountCalls() {

		Mono<ApiResponseModel> responseModel = Mono
				.error(BackendException.create(BackendErrorEnum.SERVICE_CONDITION, "test"));
		ApiExecutionService executionServiceSpy = Mockito.spy(executionService);
		doReturn(responseModel).when(executionServiceSpy).executeApi(any());

		ApiController controller = new ApiController(environment, executionServiceSpy, apiLogger, responseUtil);

		String requestModel =
				TestUtil.getFileContents("mockfiles/user_request/screen_item_v1.json");

		final ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setHeader(new HttpHeaders());
		clientRequestModel.setService("shopbookmark");
		clientRequestModel.setOperation("list");
		clientRequestModel.setVersion("v1");

		final StringBuilder result = new StringBuilder();

		//assertions:

		ResponseEntity<Map> responseEntity =
				controller.api(clientRequestModel.getHeader(), clientRequestModel.getService(),
							   clientRequestModel.getOperation(), clientRequestModel.getVersion(),
							   requestModel).block();

		assertEquals(BackendErrorEnum.SERVICE_CONDITION.getErrorCode(), responseEntity.getStatusCode());
		assertEquals("test", TestUtil.extractValue(responseEntity.getBody(), "error.message"));
	}

	@DisplayName("Spy(object) executionService for Mono with internal_server_error exception")
	@Test
	void spyObjectExecutionServiceForMonoWithInternalServerException() {

		Mono<ApiResponseModel> responseModel = Mono
				.error(BackendException.create(BackendErrorEnum.INTERNAL_SERVER_ERROR, "test"));
		ApiExecutionService executionServiceSpy = Mockito.spy(executionService);
		doReturn(responseModel).when(executionServiceSpy).executeApi(any());

		ApiController controller = new ApiController(environment, executionServiceSpy, apiLogger, responseUtil);

		String requestModel =
				TestUtil.getFileContents("mockfiles/user_request/screen_item_v1.json");

		final ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setHeader(new HttpHeaders());
		clientRequestModel.setService("shopbookmark");
		clientRequestModel.setOperation("list");
		clientRequestModel.setVersion("v1");

		final StringBuilder result = new StringBuilder();

		//assertions:

		ResponseEntity<Map> responseEntity =
				controller.api(clientRequestModel.getHeader(), clientRequestModel.getService(),
				               clientRequestModel.getOperation(), clientRequestModel.getVersion(),
				               requestModel).block();

		assertEquals(BackendErrorEnum.INTERNAL_SERVER_ERROR.getErrorCode(), responseEntity.getStatusCode());
		assertEquals("test", TestUtil.extractValue(responseEntity.getBody(), "error.message"));
	}

	@DisplayName("Dynamic conditional response check with parameterized test")
	@ParameterizedTest
	@CsvSource(value = {"screen:200", "shopbookmark:400"}, delimiter = ':')
	void DYNAMIC_CONDITIONAL_RESPONSE_CHECK_WITH_PARAMETERIZED_TEST(String service, int apiStatus) {
		final ResponseEntity<Map> responseEntity = ResponseEntity.status(HttpStatus.resolve(apiStatus))
				.body(new HashMap<>());

		ApiExecutionService executionServiceSpy = Mockito.spy(executionService);
		doReturn(Mono.just(responseEntity)).when(executionServiceSpy).executeApi(any());

		ApiController controller = new ApiController(environment, executionServiceSpy, apiLogger, responseUtil);
		String requestModel =
				TestUtil.getFileContents("mockfiles/user_request/screen_item_v1.json");
		final ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setHeader(new HttpHeaders());
		clientRequestModel.setService("shopbookmark");
		clientRequestModel.setOperation("list");
		clientRequestModel.setVersion("v1");

		//assertions:
		ResponseEntity response = controller
				.api(clientRequestModel.getHeader(), clientRequestModel.getService(), clientRequestModel.getOperation(),
					 clientRequestModel.getVersion(), requestModel).block();
		assertEquals(apiStatus, response.getStatusCode().value());
	}

	@DisplayName("different Maintenance Mode checker")
	@ParameterizedTest
	@CsvSource({"service", "service.operation", "service.operation.version"})
	void differentMaintenanceModeChecker(String inMaintenance) {
		//given:
		ClientRequestModel model = new ClientRequestModel();
		model.setService("service");
		model.setOperation("operation");
		model.setVersion("version");

		Environment environment = mock(Environment.class);
		doReturn("true").when(environment).getProperty(inMaintenance + ".maintenance", "false");

		ApiController controller = new ApiController(environment, mock(ApiExecutionService.class), apiLogger,
													 responseUtil);
		//when:
		ResponseEntity<Map> responseEntity =
				controller.api(new HttpHeaders(), model.getService(), model.getOperation(), model.getVersion(),
							   "").block();

		assertEquals(inMaintenance + " is in maintenance mode.",
					 TestUtil.extractValue(responseEntity.getBody(), "error.message"));

	}


	@DisplayName("will throw error if maintenance mode is enabled")
	@ParameterizedTest
	@CsvSource(value = {
			"service     |operation     |v1         |service                 | all operation of a service",
			"service2    |operation2    |v2         |service2.operation2     | all version of API",
			"service3    |operation3    |v3         |service3.operation3.v3  | specific version of an API"

	}, delimiter = '|')
	void willThrowErrorIfMaintenanceModeIsEnabled(String service, String operation, String version,
												  String inMaintenanceKey) {
		//given:
		ClientRequestModel model = new ClientRequestModel();
		model.setService(service);
		model.setOperation(operation);
		model.setVersion(version);

		Environment environment = mock(Environment.class);
		doReturn("true").when(environment).getProperty(inMaintenanceKey + ".maintenance", "false");

		final ResponseEntity<Map<String, String>> ok = ResponseEntity.ok(Map.of("status", "success"));

		ApiExecutionService apiExecutionService = mock(ApiExecutionService.class);
		doReturn(Mono.just(ok)).when(apiExecutionService).executeApi(any());

		ApiController controller = new ApiController(environment, apiExecutionService, apiLogger, responseUtil);
		//when:
		ResponseEntity api =
				controller.api(new HttpHeaders(), model.getService(), model.getOperation(), model.getVersion(),
							   "{}").block();

		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, api.getStatusCode());
		assertEquals(Map.of(BffConstants.STATUS, BffConstants.UPSTREAM_RESPONSE_FAILURE,
							BffConstants.ERROR, Map.of(BffConstants.CODE, HttpStatus.SERVICE_UNAVAILABLE.value(),
													   BffConstants.MESSAGE,
													   inMaintenanceKey + " is in maintenance mode.")), api.getBody());
	}

	@DisplayName("Exception when request body contains error")
	@ParameterizedTest
	@CsvSource(value = {
			"null|invalid request body",
			"invalidJson}}}|invalid request body"
	}, delimiter = '|')
	void willThrowErrorIfMaintenanceModeIsEnabled(String body, String expectedMsg) {
		//given:
		Mono<ApiResponseModel> responseModel = Mono
				.error(BackendException.create(BackendErrorEnum.SERVICE_CONDITION, "test"));
		ApiExecutionService executionServiceSpy = Mockito.spy(executionService);
		doReturn(responseModel).when(executionServiceSpy).executeApi(any());

		ApiController controller = new ApiController(environment, executionServiceSpy, apiLogger, responseUtil);

		final ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setHeader(new HttpHeaders());
		clientRequestModel.setService("shopbookmark");
		clientRequestModel.setOperation("list");
		clientRequestModel.setVersion("v1");

		//assertions:
		ResponseEntity<Map> responseEntity = controller.api(
				clientRequestModel.getHeader(), clientRequestModel.getService(),
				clientRequestModel.getOperation(), clientRequestModel.getVersion(),
				body).block();

		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(Map.of(
				BffConstants.STATUS, BffConstants.FAILURE,
				BffConstants.ERROR, Map.of(
						BffConstants.CODE, HttpStatus.BAD_REQUEST.value(),
						BffConstants.MESSAGE, expectedMsg
				)), responseEntity.getBody());
	}
}
