package jp.co.rakuten.bff.core.service.impl;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.service.ApiRepository;
import jp.co.rakuten.bff.core.service.ExecutionPlanService;
import jp.co.rakuten.bff.core.service.upstream.client.impl.EcstaticUpstreamClient;
import jp.co.rakuten.bff.core.service.upstream.client.impl.GenericGatewayUpstreamClient;
import jp.co.rakuten.bff.core.template.ApiTemplate;
import jp.co.rakuten.bff.core.template.CallDefinitionTemplate;
import jp.co.rakuten.bff.core.template.ExecutionModel;
import jp.co.rakuten.bff.core.template.InterfaceTemplate;
import jp.co.rakuten.bff.core.testUtil.ApiRepositoryTestUtil;
import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CallDefinitionExecutionServiceImplTest {

	@Mock
	private static Environment env;
	@Mock
	private GenericGatewayUpstreamClient genericGatewayUpstreamClient;
	@Mock
	private EcstaticUpstreamClient ecstaticUpstreamClient;
	@Mock
	private GenericCallDefinitionProcessor genericCallDefinitionProcessor;
	@InjectMocks
	private CallDefinitionExecutionServiceImpl callDefinitionExecutionService;
	private ApiTemplate apiTemplate;
	private CallDefinitionTemplate callDefinitionTemplate;
	private ExecutionModel executionModel;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);

		ExecutionPlanService executionPlanService = new ExecutionPlanServiceImpl(env);
		String requestRepoDir = "mockfiles/user_request";
		ApiRepository apiRepository = ApiRepositoryTestUtil.getRepository();

		apiTemplate = apiRepository.getApiRepositoryTemplate("callDefinition.list.v1");
		RequestModel requestModel = TestUtil.getObjectFromFilename(
				requestRepoDir + "/FES_shopbookmark_list_some_feature.json", RequestModel.class);
		ClientRequestModel model = new ClientRequestModel();
		model.setVersion(UUID.randomUUID().toString());
		model.setRequestModel(requestModel);
		executionModel = executionPlanService.prepareExecutionPlan(model, apiTemplate);
		callDefinitionTemplate = executionModel.getExecutionMap().get("pointinfo_coupon");
	}

	@AfterEach
	void tearDown() {
		genericGatewayUpstreamClient = null;
		ecstaticUpstreamClient = null;
		genericCallDefinitionProcessor = null;
	}

	@Test
	@DisplayName("If call definition called successfully then its callDefinitionResponseStatus should SUCCESS")
	void preProcessorFalseStatusShouldReturnSuccess() {

		//given
		InterfaceTemplate endpointTemplate = apiTemplate.getInterfacesMap()
				.get(callDefinitionTemplate.getInterfacesList().get(0));
		endpointTemplate.setProcessorBean(new InterfaceProcessor() {
			@Override
			public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
									  GenericCallDefinitionProcessedData genericCDProcessedData,
									  Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
				return true;
			}
		});

		Map<String, Object> gatewayRespose = Map.of("mock_key", "mock_value");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		preparedRequest.put("shopbookmark_list", gatewayRespose);
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		genericCDProcessedData.setPreparedRequest(preparedRequest);

		//when
		when(genericCallDefinitionProcessor.preProcess(anyMap(), anyMap(), anyList(), any()))
				.thenReturn(genericCDProcessedData);
		when(genericGatewayUpstreamClient.execute(anyString(), anyCollection(), anyString()))
				.thenReturn(Mono.just(new MultipleResponses()));

		//then
		Mono<CallDefinitionResponse> callDefinitionResponseMono = callDefinitionExecutionService
				.getCallDefinitionResponse(
						callDefinitionTemplate, Collections.EMPTY_MAP, apiTemplate, executionModel,
						Collections.EMPTY_MAP, null, null);

		//verify
		assertNotNull(callDefinitionResponseMono);
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMono.block();
		assertNotNull(callDefinitionResponse);
		assertNotNull(callDefinitionResponse.getStatus());
		assertEquals(CallDefinitionResponseStatus.SUCCESS, callDefinitionResponse.getStatus());

		verify(genericCallDefinitionProcessor, times(1))
				.preProcess(anyMap(), anyMap(), anyList(), any());
		verify(genericGatewayUpstreamClient, times(1)).execute(anyString(), anyCollection(), anyString());
	}

	@Test
	@DisplayName("If ecstatic type call definition called successfully " +
			"then its callDefinitionResponseStatus should SUCCESS")
	void ecstaticTypeCallTest() {

		//given
		CallDefinitionTemplate ecstaticTypeTemplate = executionModel.getExecutionMap().get("gspinfo");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		preparedRequest.put("shopbookmark_list", Map.of("mock_key", "mock_value"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		genericCDProcessedData.setPreparedRequest(preparedRequest);

		//when
		when(genericCallDefinitionProcessor.preProcess(anyMap(), anyMap(), anyList(), any()))
				.thenReturn(genericCDProcessedData);
		when(ecstaticUpstreamClient.execute(anyString(), anyCollection(), anyString()))
				.thenReturn(Mono.just(new MultipleResponses()));

		//then
		Mono<CallDefinitionResponse> callDefinitionResponseMono = callDefinitionExecutionService
				.getCallDefinitionResponse(
						ecstaticTypeTemplate, Collections.EMPTY_MAP, apiTemplate, executionModel, Collections.EMPTY_MAP,
						null,null);

		//verify
		assertNotNull(callDefinitionResponseMono);
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMono.block();
		assertNotNull(callDefinitionResponse);
		assertNotNull(callDefinitionResponse.getStatus());
		assertEquals(CallDefinitionResponseStatus.SUCCESS, callDefinitionResponse.getStatus());

		verify(genericCallDefinitionProcessor, times(1))
				.preProcess(anyMap(), anyMap(), anyList(), any());
		verify(ecstaticUpstreamClient, times(1)).execute(anyString(), anyCollection(), anyString());
	}

	@Test
	@DisplayName("If call definition not called due to interface's pre-processor false status " +
			"then its callDefinitionResponseStatus should NOT_CALLED")
	void preProcessorFalseStatusShouldReturnNotCall() {
		//given
		InterfaceTemplate endpointTemplate = apiTemplate.getInterfacesMap()
				.get(callDefinitionTemplate.getInterfacesList().get(0));
		endpointTemplate.setProcessorBean(new InterfaceProcessor() {
			@Override
			public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
									  GenericCallDefinitionProcessedData genericCDProcessedData,
									  Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
				return false;
			}
		});
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		preparedRequest.put("shopbiz_point_info", Map.of("mock_key", "mock_value"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		genericCDProcessedData.setInterfaceToRequestIdMap(
				new HashMap<>(Map.of("shopbiz_point_info", Collections.singletonList("shopbiz_point_info"))));

		//when
		when(genericCallDefinitionProcessor.preProcess(anyMap(), anyMap(), anyList(), any()))
				.thenReturn(genericCDProcessedData);

		//then
		Mono<CallDefinitionResponse> callDefinitionResponseMono = callDefinitionExecutionService
				.getCallDefinitionResponse(
						callDefinitionTemplate, Collections.EMPTY_MAP, apiTemplate, executionModel,
						Collections.EMPTY_MAP,
						null, null);

		//verify
		assertNotNull(callDefinitionResponseMono);
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMono.block();
		assertNotNull(callDefinitionResponse);
		assertNotNull(callDefinitionResponse.getStatus());
		assertEquals(CallDefinitionResponseStatus.FAILURE, callDefinitionResponse.getStatus());

		verify(genericCallDefinitionProcessor, times(1))
				.preProcess(anyMap(), anyMap(), anyList(), any());
	}

	@Test
	@DisplayName("If call definition not called due to custom interface pre processor's exception " +
			"then its callDefinitionResponseStatus should NOT_CALLED")
	void customInterfacePreProcessorException() {
		//given
		InterfaceTemplate interfaceTemplate = apiTemplate.getInterfacesMap()
				.get(callDefinitionTemplate.getInterfacesList().get(0));
		interfaceTemplate.setProcessorBean(new InterfaceProcessor() {
			@Override
			public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
									  GenericCallDefinitionProcessedData genericCDProcessedData,
									  Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
				throw new RuntimeException();
			}
		});

		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		preparedRequest.put("shopbiz_point_info", Map.of("mock_key", "mock_value"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		genericCDProcessedData.setInterfaceToRequestIdMap(
				new HashMap<>(Map.of("shopbiz_point_info", Collections.singletonList("shopbiz_point_info"))));

		//when
		when(genericCallDefinitionProcessor.preProcess(anyMap(), anyMap(), anyList(), any()))
				.thenReturn(genericCDProcessedData);

		//then
		Mono<CallDefinitionResponse> callDefinitionResponseMono = callDefinitionExecutionService
				.getCallDefinitionResponse(
						callDefinitionTemplate, Collections.EMPTY_MAP, apiTemplate, executionModel,
						Collections.EMPTY_MAP,
						null,null);

		//verify
		assertNotNull(callDefinitionResponseMono);
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMono.block();
		assertNotNull(callDefinitionResponse);
		assertNotNull(callDefinitionResponse.getStatus());
		assertEquals(CallDefinitionResponseStatus.NOT_CALLED, callDefinitionResponse.getStatus());

		verify(genericCallDefinitionProcessor, times(1))
				.preProcess(anyMap(), anyMap(), anyList(),any());
	}

	@Test
	@DisplayName("If call definition not called due to call definition client exception " +
			"then its callDefinitionResponseStatus should FAILURE")
	void noUpstreamCallshouldReturnFalse() {
		//given
		Map<String, Object> gatewayRespose = Map.of("mock_key", "mock_value");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		preparedRequest.put("shopbookmark_list", gatewayRespose);
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		genericCDProcessedData.setPreparedRequest(preparedRequest);

		//when
		when(genericCallDefinitionProcessor.preProcess(anyMap(), anyMap(), anyList(), any()))
				.thenReturn(genericCDProcessedData);
		when(genericGatewayUpstreamClient.execute(anyString(), anyCollection(), anyString()))
				.thenReturn(Mono.fromCallable(() -> {
					throw SystemException.create(SystemErrorEnum.INTERNAL, "UT error");
				}));

		//verify
		assertThrows(SystemException.class, () -> callDefinitionExecutionService.getCallDefinitionResponse(
				callDefinitionTemplate, Collections.EMPTY_MAP, apiTemplate, executionModel, Collections.EMPTY_MAP,
				null, null).block());
		verify(genericCallDefinitionProcessor, times(1))
				.preProcess(anyMap(), anyMap(), anyList(), any());
		verify(genericGatewayUpstreamClient, times(1)).execute(anyString(), anyCollection(), anyString());
	}

	@DisplayName("Interface will be called if user requested feature and response match json configuration")
	@ParameterizedTest(name = "{index} when: include=''{0}'' and exclude=''{1}'' should return {5}")
	@CsvSource(value = {
			"point      |            | itemInfo | itemInfo | point.pointsCalculation | true",
			"point      |            | itemInfo | itemInfo | point,newPoint          | true",
			"newPoint   |            | itemInfo | itemInfo | point,newPoint          | true",
			"other      |            | itemInfo | itemInfo | point.pointsCalculation | false",
			"           |            | itemInfo | itemInfo | point.pointsCalculation | true",
			"point      |            | itemInfo | itemInfo | other                   | false",
			"           | point      | itemInfo | itemInfo | point.pointsCalculation | false",
			"           | other      | itemInfo | itemInfo | point.pointsCalculation | true",
			"point      |            | shopInfo | itemInfo | point.pointsCalculation | false", /*feature not requested*/
			"point      |            | itemInfo | shopInfo | point.pointsCalculation | false", /*feature not requested*/
	}, delimiter = '|')
	void testNeedToCallInterface(String include, String exclude, String userRequestedFeature, String jsonFeature,
	                             String jsonResponseField, Boolean expected) {
		//given:
		CommonRequestModel requestModel = new CommonRequestModel();
		requestModel.setHeaders(Map.of(BffConstants.EASY_ID, "1234567"));
		requestModel.setInclude(new HashSet<>(TestUtil.splitAndTrim(include)));
		requestModel.setExclude(new HashSet<>(TestUtil.splitAndTrim(exclude)));
		InterfaceTemplate interfaceTemplate =
				apiTemplate.getInterfacesMap().entrySet().stream().findFirst().get().getValue();
		interfaceTemplate.setTargetResponseMappings(Map.of(jsonFeature, Arrays.asList(jsonResponseField.split(","))));

		Map<String, CommonRequestModel> validatedRequest = Map.of(userRequestedFeature, requestModel);

		// when:
		final boolean result = callDefinitionExecutionService.needToCallInterface(interfaceTemplate, validatedRequest);

		// then:
		assertEquals(expected, result);
	}

	@Test
	@DisplayName("Check postProcessor method error")
	void testPostProcessorError() {
		InterfaceProcessor processorMock = mock(InterfaceProcessor.class);
		when(processorMock.postProcess(any(), any(), any(), any(), any())).thenThrow(new NullPointerException("test"));
		InterfaceTemplate interfaceTemplate = new InterfaceTemplate();
		interfaceTemplate.setProcessorBean(processorMock);
		interfaceTemplate.setInterfaceKey("test interface");
		assertDoesNotThrow(() -> {
			Mono<Boolean> result = callDefinitionExecutionService.postProcessor(
					null, null, null, null, interfaceTemplate, null
			);
			assertFalse(result.block());
		});
	}
}
