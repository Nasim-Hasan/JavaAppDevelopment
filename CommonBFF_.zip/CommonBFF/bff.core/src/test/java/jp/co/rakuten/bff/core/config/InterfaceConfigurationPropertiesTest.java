package jp.co.rakuten.bff.core.config;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class InterfaceConfigurationPropertiesTest {

	private final String SAMPLE_INTERFACE_KEY_1 = "shopbookmark_list";
	private final String SAMPLE_GROUP_KEY_1 = "shopbookmark";
	private final String SAMPLE_INTERFACE_KEY_2 = "shopbiz_shopmaster";
	private final String SAMPLE_GROUP_KEY_2 = "shopbiz";

	@Test
	public void testSetters() throws Exception {
		// Setup:

		// Given: Map of dummy values
		Map interfaces = Map.of(SAMPLE_INTERFACE_KEY_1, SAMPLE_GROUP_KEY_1, SAMPLE_INTERFACE_KEY_2, SAMPLE_GROUP_KEY_2);

		// When: Instantiated by constructor and set through setter
		InterfaceConfigurationProperties interfaceConfigurationProperties = new InterfaceConfigurationProperties();
		interfaceConfigurationProperties.setMapping(interfaces);

		// Verify Response: N/A for void methods

		// Verify Mock: verify dummy values through getters
		assertEquals(SAMPLE_GROUP_KEY_1, interfaceConfigurationProperties.getMapping().get(SAMPLE_INTERFACE_KEY_1));
		assertEquals(SAMPLE_GROUP_KEY_2, interfaceConfigurationProperties.getMapping().get(SAMPLE_INTERFACE_KEY_2));
	}

}