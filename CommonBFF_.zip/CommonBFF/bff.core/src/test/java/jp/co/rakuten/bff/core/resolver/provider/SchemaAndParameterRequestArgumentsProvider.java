package jp.co.rakuten.bff.core.resolver.provider;

import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.testUtil.CommonValidatorUtil;
import jp.co.rakuten.bff.core.testUtil.ImmutableMap;
import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import org.springframework.http.HttpHeaders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public class SchemaAndParameterRequestArgumentsProvider implements ArgumentsProvider {

	private Map<String, Object> setSchemaAndParameter(List<FeatureTemplate> schemaLoader,
													  ClientRequestModel actualRequest,
													  boolean isError, String errorMessage) {
		if (isError) {
			return ImmutableMap.of(
					"actualRequest", actualRequest,
					"requestTemplateMap", schemaLoader,
					"errorMessage", errorMessage);
		} else {
			return ImmutableMap.of(
					"actualRequest", actualRequest,
					"requestTemplateMap", schemaLoader);
		}
	}

	private ClientRequestModel buildRequestModel(Map<Object, Object> requestMap) {
		ClientRequestModel requestModel = new ClientRequestModel();
		RequestModel request = new RequestModel();
		Map<String, String> headerMap = (Map<String, String>) requestMap.get("header");
		if (MapUtils.isNotEmpty(headerMap)) {
			MultiValueMap<String, String> headerValue = new LinkedMultiValueMap<>();
			headerValue.setAll(headerMap);
			HttpHeaders header = new HttpHeaders(headerValue);
			requestModel.setHeader(header);
		}

		Map<Object, Object> requestFeature = (Map<Object, Object>) requestMap.get("request");

		requestFeature.forEach((k, v) -> {
			Map<String, Object> common = (Map<String, Object>) k;
			Map<String, Object> features = (Map<String, Object>) v;
			if (MapUtils.isNotEmpty(common)) {
				Map<String, Object> commonParams = (Map<String, Object>) common.get("common");
				CommonRequestModel commonRequestModel = new CommonRequestModel(
						(Map<String, Object>) commonParams.get("params"),
						(Map<String, Object>) commonParams.get("headers"),
						(Set<String>) commonParams.get("includes"), (Set<String>) commonParams.get("excludes"));
				request.setCommon(commonRequestModel);
			}

			if (MapUtils.isNotEmpty(features)) {
				Map<String, Object> featureParams = (Map<String, Object>) features.get("features");
				Map<String, CommonRequestModel> finalMap = new HashMap<>();
				featureParams.forEach((s, r) -> {
					CommonRequestModel featureModel = new CommonRequestModel();
					Map<String, Object> commonModel = (Map<String, Object>) r;
					commonModel.forEach((p, q) -> {
						if (p.equals("params")) {
							featureModel.setParams((Map<String, Object>) q);
						}

						if (p.equals("includes")) {
							featureModel.setInclude((Set<String>) q);
						}

						if (p.equals("excludes")) {
							featureModel.setExclude((Set<String>) q);
						}
					});
					finalMap.putAll(ImmutableMap.of(s, featureModel));

					request.setFeatures(finalMap);
				});
			}
		});

		requestModel.setRequestModel(request);
		return requestModel;
	}

	@Override
	public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws Exception {
		return Stream.of(
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of("header", ImmutableMap.of("x-request-id", "1"),
										"request", ImmutableMap.of(ImmutableMap.wrap("common",
																					 ImmutableMap
																							 .of("params", ImmutableMap
																										 .of("easyId",
																											 "234239",
																											 "version",
																											 "v1.1"),
																								 "includes",
																								 Collections.emptySet(),
																								 "excludes", Collections
																										 .emptySet())),
																   ImmutableMap.wrap("features",
																					 ImmutableMap.of("shopbookmarkList",
																									 ImmutableMap
																											 .of("params",
																												 ImmutableMap
																														 .of("easyId",
																															 "234234"),
																												 "includes",
																												 Collections
																														 .emptySet(),
																												 "excludes",
																												 Collections
																														 .emptySet())),
																					 ImmutableMap.of("coupon",
																									 ImmutableMap
																											 .of("params",
																												 ImmutableMap
																														 .of("easyId",
																															 "234556"),
																												 "includes",
																												 Collections
																														 .emptySet(),
																												 "excludes",
																												 Collections
																														 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of("header", ImmutableMap.of("x-request-id", "1"),
										"request", ImmutableMap.of(ImmutableMap.wrap("common",
																					 ImmutableMap
																							 .of("params", ImmutableMap
																										 .of("easyId",
																											 "234239",
																											 "version",
																											 "v1.1"),
																								 "includes",
																								 Collections.emptySet(),
																								 "excludes", Collections
																										 .emptySet())),
																   ImmutableMap.wrap("features",
																					 ImmutableMap.of("shopbookmarkList",
																									 ImmutableMap
																											 .of("params",
																												 ImmutableMap
																														 .of("easyId",
																															 "234234"),
																												 "includes",
																												 Set.of("easyId"),
																												 "excludes",
																												 Set.of("itemId"))),
																					 ImmutableMap.of("coupon",
																									 ImmutableMap
																											 .of("params",
																												 ImmutableMap
																														 .of("easyId",
																															 "234556"),
																												 "includes",
																												 Collections
																														 .emptySet(),
																												 "excludes",
																												 Collections
																														 .emptySet())))))


									  )
						, true, "shopbookmarkList Please input includeParams or excludeParams, not both"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234"),
																										 "includes",
																										 null,
																										 "excludes",
																										 null)),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "user",
																													 "something"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "user parameters should be map"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "user",
																													 ImmutableMap
																															 .of("userid",
																																 1,
																																 "username",
																																 "abcdgsdgsdfgsdfgsdfgsfgsdgsdfgsdgsdgsdfgsdfgsdfgsdfgsdfgsdgsdfgsdfgsdgsdgsdfgsdgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsdfgsgd",
																																 "password",
																																 "xyzd")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "username length must be under 100"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "user",
																													 ImmutableMap
																															 .of("userid",
																																 1,
																																 "username",
																																 "sdfsfdfs%34242$$#",
																																 "password",
																																 "xyzd")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "username must follow ^[a-zA-Z0-9]+$"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "user",
																													 ImmutableMap
																															 .of("userid",
																																 1,
																																 "username",
																																 "abc",
																																 "password",
																																 "xyz")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "password length must be over 4"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "genreId",
																													 1000000,
																													 "user",
																													 ImmutableMap
																															 .of("userid",
																																 1,
																																 "username",
																																 "abc",
																																 "password",
																																 "pxyz")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "genreId must be under 999999"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "genreId",
																													 0,
																													 "user",
																													 ImmutableMap
																															 .of("userid",
																																 1,
																																 "username",
																																 "abc",
																																 "password",
																																 "pxyz")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "genreId must be over 5"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "userList",
																													 Arrays.asList(
																															 "abc",
																															 "pqr",
																															 "lmn",
																															 "opn",
																															 "asdf",
																															 "wer")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "userList size must be under 5"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "userList",
																													 Arrays.asList(
																															 "abc",
																															 "pqr",
																															 "lmn",
																															 "opn",
																															 "asdf")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "userList should be type of string"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 ImmutableMap
																															 .of("1",
																																 "2")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "deliveryInfo cannot be type of map or list"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 Arrays.asList(
																															 1,
																															 2,
																															 3)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "deliveryInfo cannot be type of map or list"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 90),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "Please select the value from [1, 2, 3, 4]"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "X-Analytics-Aid",
																													 "abc",
																													 "deliveryInfo",
																													 ImmutableMap
																															 .of("id",
																																 1)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "deliveryInfo cannot be type of map or list"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "X-Analytics-Aid",
																													 "abc",
																													 "deliveryInfo",
																													 Arrays.asList(
																															 1,
																															 2)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "deliveryInfo cannot be type of map or list"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 ImmutableMap
																															 .of("type",
																																 "1")),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "membershipTypes cannot be type of map"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 "1"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 Arrays.asList(
																															 1,
																															 2,
																															 3)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true,
									  "membershipTypes values must be selected from [1, 2, 3], minimum 1 and maximum 2 values can be selected"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 Arrays.asList(
																															 4,
																															 5)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "Please select the value from [1, 2, 3]"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Set.of("shopbookmarkList"),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Set.of("shopbookmarkList"),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .emptyMap(),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"header", ImmutableMap.of("x-request-id", "1"),
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes", Set.of("coupon"),
																						 "excludes",
																						 Collections.emptySet())),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("coupon",
																							 new HashMap<>()))))


									  )
						, false, null),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Set.of("coupon"))),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 Arrays.asList(
																															 4,
																															 5)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234556"),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "coupon feature cannot be included"),
				setSchemaAndParameter(CommonValidatorUtil.schemaLoader(), buildRequestModel(
						ImmutableMap.of(
								"request", ImmutableMap.of(ImmutableMap.wrap("common",
																			 ImmutableMap
																					 .of("params", ImmutableMap
																								 .of("easyId", "234239",
																									 "version", "v1.1"),
																						 "includes",
																						 Collections.emptySet(),
																						 "excludes",
																						 Set.of("coupon"))),
														   ImmutableMap.wrap("features",
																			 ImmutableMap.of("shopbookmarkList",
																							 ImmutableMap
																									 .of("params",
																										 ImmutableMap
																												 .of("easyId",
																													 "234234",
																													 "deliveryInfo",
																													 4,
																													 "X-Analytics-Aid",
																													 "abc",
																													 "membershipTypes",
																													 Arrays.asList(
																															 4,
																															 5)),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())),
																			 ImmutableMap.of("coupon",
																							 ImmutableMap
																									 .of("params",
																										 Collections
																												 .emptyMap(),
																										 "includes",
																										 Collections
																												 .emptySet(),
																										 "excludes",
																										 Collections
																												 .emptySet())))))


									  )
						, true, "coupon feature cannot be included")
		).map(Arguments::of);
	}
}
