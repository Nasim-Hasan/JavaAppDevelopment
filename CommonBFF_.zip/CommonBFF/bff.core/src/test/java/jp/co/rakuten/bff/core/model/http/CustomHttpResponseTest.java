package jp.co.rakuten.bff.core.model.http;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CustomHttpResponseTest {
	@Test
	void testBuildWithCustomError() {
		String errMsg = "To err is human";
		CustomError err = CustomError.builder().message(errMsg).build();
		CustomHttpResponse errResponse = CustomHttpResponse.builder().error(err).build();
		assertTrue(errResponse.toString().contains(errMsg));
	}
}
