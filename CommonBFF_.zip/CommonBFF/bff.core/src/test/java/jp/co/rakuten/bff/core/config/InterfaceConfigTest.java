package jp.co.rakuten.bff.core.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class InterfaceConfigTest {
	private final String SAMPLE_INTERFACE_KEY = "shopbookmark_list";
	private final String SAMPLE_CIRCUIT = "shopbookmark_list";
	private final String SAMPLE_CONNECTION_PARAM_KEY = "timeout";
	private final String SAMPLE_CONNECTION_PARAM_VALUE = "991031";
	private final String SAMPLE_URL_PARAM_KEY = "hits";
	private final String SAMPLE_URL_PARAM_VALUE = "2";
	private final String SAMPLE_HEADER_PARAM_KEY = "x-api-key";
	private final String SAMPLE_HEADER_PARAM_VALUE = "default";
	private final String SAMPLE_METADATA_PARAM_KEY = "x-api-key";
	private final String SAMPLE_METADATA_PARAM_VALUE = "default";

	private void loadInterfaceConfigWithDummy(InterfaceConfig interfaceConfig) {
		interfaceConfig.setInterfaceKey(SAMPLE_INTERFACE_KEY);
		interfaceConfig.setCircuit(SAMPLE_CIRCUIT);
		interfaceConfig.putToConnectionMap(SAMPLE_CONNECTION_PARAM_KEY, SAMPLE_CONNECTION_PARAM_VALUE);
		interfaceConfig.putToHeaderMap(SAMPLE_HEADER_PARAM_KEY, SAMPLE_HEADER_PARAM_VALUE);
		interfaceConfig.putToMetadataMap(SAMPLE_METADATA_PARAM_KEY, SAMPLE_METADATA_PARAM_VALUE);
		interfaceConfig.putToUrlParameterMap(SAMPLE_URL_PARAM_KEY, SAMPLE_URL_PARAM_VALUE);
	}

	@Test
	public void testNullInputForPutMethods() {
		// Setup: no special setup/init

		// Given: instantiate with empty
		InterfaceConfig interfaceConfig = new InterfaceConfig("");
		loadInterfaceConfigWithDummy(interfaceConfig);

		// When: try to override existing values with null
		interfaceConfig.putToConnectionMap(SAMPLE_CONNECTION_PARAM_KEY, null);
		interfaceConfig.putToHeaderMap(SAMPLE_HEADER_PARAM_KEY, null);
		interfaceConfig.putToMetadataMap(SAMPLE_METADATA_PARAM_KEY, null);
		interfaceConfig.putToUrlParameterMap(SAMPLE_URL_PARAM_KEY, null);
		interfaceConfig.setCircuit(null);

		// Verify Response: dummy from getters
		assertNotNull(interfaceConfig.getPropertiesConnectionMap().get(SAMPLE_CONNECTION_PARAM_KEY));
		assertNotNull(interfaceConfig.getPropertiesHeaderMap().get(SAMPLE_HEADER_PARAM_KEY));
		assertNotNull(interfaceConfig.getMetadataMap().get(SAMPLE_METADATA_PARAM_KEY));
		assertNotNull(interfaceConfig.getPropertiesUrlParameterMap().get(SAMPLE_URL_PARAM_KEY));
		assertNotNull(interfaceConfig.getCircuit());

		// Verify Mock: N/A

	}
}