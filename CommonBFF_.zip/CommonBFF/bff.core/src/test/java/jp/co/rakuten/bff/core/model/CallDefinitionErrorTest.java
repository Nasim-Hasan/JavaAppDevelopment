package jp.co.rakuten.bff.core.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class CallDefinitionErrorTest {
	private CallDefinitionError callDefinitionError;

	@Autowired
	Environment environment;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionError=new CallDefinitionError(400,"bad request");
	}

	@DisplayName("Overridden toString() Method test")
	@Test
	void toStringTest(){
		callDefinitionError.toString();
	}
}
