package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ResponseFilterHelperTest {

	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	@DisplayName("test digUpValueAndSet: Valid Local Map found on topMost node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"title,ja-JP,人間用の新野菜",
			"salesDescription,ja-JP,販売説明分",
			"images,ja-JP,ArrayList",
			"video,ja-JP,LinkedHashMap"
	})
	void digUpValueAndSet_withoutPath_ValidLocalMapOnTopNode(String field, String requestedKey, String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/ValidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, field, requestedKey);

		// Then:
		if (Arrays.asList("ArrayList", "LinkedHashMap").contains(response)) {
			assertEquals(response, responseModel.get(field).getClass().getSimpleName());
		} else {
			assertEquals(response, responseModel.get(field));
		}
	}

	@DisplayName("test digUpValueAndSet: Valid Local Map found on topMost node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"title,ja-JP,人間用の新野菜",
			"salesDescription,ja-JP,販売説明分",
			"images,ja-JP,ArrayList",
			"video,ja-JP,LinkedHashMap"
	})
	void digUpValueAndSet_withoutPath_FieldDoesntExist(String field, String requestedKey, String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/ValidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);
		responseModel.remove(field);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, field, requestedKey);

		// Then:
		assertNull(responseModel.get(field));
	}

	@DisplayName("test digUpValueAndSet: Invalid Local Map found on topMost node and field removed")
	@ParameterizedTest
	@CsvSource(value = {
			"title,ja-JP",
			"salesDescription,ja-JP",
			"images,ja-JP",
			"video,ja-JP"
	})
	void digUpValueAndSet_withoutPath_InvalidLocalMapOnTopNode(String field, String requestedKey) {
		// Given:
		String fileName = "mockfiles/responseFilter/InvalidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, field, requestedKey);

		// Then:
		assertNull(responseModel.get(field));
	}

	@DisplayName("test digUpValueAndSet: Valid DeviceType Map found on topMost node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"tagline,sp,携帯端末ブラウザ向けに最適化されたキャッチコピー的なフィールド",
			"productDescription,sp,<div>携帯端末ブラウザ向けに最適化された商品説明分(HTML)</div>"
	})
	void digUpValueAndSet_withoutPath_ValidDeviceTypeMapOnTopNode(String field, String requestedKey, String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/ValidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, field, requestedKey);
		ResponseFilterHelper.digUpValueAndSet(responseModel, field, "ja-JP");

		// Then:
		if (Arrays.asList("ArrayList", "LinkedHashMap").contains(response)) {
			assertEquals(response, responseModel.get(field).getClass().getSimpleName());
		} else {
			assertEquals(response, responseModel.get(field));
		}
	}

	@DisplayName("test digUpValueAndSet: Valid Local Map found on nested node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"customizationOptions,label,ja-JP,野菜にアレルギーの経験はありますか",
			"customizationOptions.selections,displayValue,ja-JP,はい",
			"subscription,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"buyingClub,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"variantSelectors,i18n,ja-JP,カラー",
			"variantSelectors.values,i18n,ja-JP,赤",
			"variants,images,ja-JP,ArrayList"
	})
	void digUpValueAndSet_withPath_ValidLocalMapOnNestedNodes(String path, String field, String requestedKey,
	                                                          String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/ValidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		if (Arrays.asList("ArrayList", "LinkedHashMap").contains(response)) {
			assertEquals(response, value.getClass().getSimpleName());
		} else {
			assertEquals(response, value.toString());
		}
	}

	@DisplayName("test digUpValueAndSet: Invalid Local Map found on nested node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"customizationOptions.selections,displayValue,ja-JP,はい",
			"customizationOptions,label,ja-JP,野菜にアレルギーの経験はありますか",
			"subscription,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"buyingClub,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"variantSelectors,i18n,ja-JP,カラー",
			"variantSelectors.values,i18n,ja-JP,赤",
			"variants,images,ja-JP,ArrayList"
	})
	void digUpValueAndSet_withPath_InvalidLocalMapOnNestedNodes(String path, String field, String requestedKey,
	                                                            String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/InvalidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertNull(value);
	}

	@DisplayName("test digUpValueAndSet: requested locale doesnt exist")
	@ParameterizedTest
	@CsvSource(value = {
			"customizationOptions,label,ja-JP,野菜にアレルギーの経験はありますか",
			"customizationOptions.selections,displayValue,ja-JP,はい",
			"subscription,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"buyingClub,purchaseDescription,ja-JP,この説明は買い物かごに表示する",
			"variantSelectors,i18n,ja-JP,カラー",
			"variantSelectors.values,i18n,ja-JP,赤",
			"variants,images,ja-JP,ArrayList"
	})
	void digUpValueAndSet_withPath_RequestedLocaleDoesntExist(String path, String field, String requestedKey,
	                                                          String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/TestData_LocaleNotExist.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndSet(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertNull(value);
	}

	@DisplayName("test digUpValueAndAdd: Valid Local List found on nested node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"buyingClub,items,ja-JP,キャベツ"
	})
	void digUpValueAndAdd_withPath_ValidLocalListOnNestedNodes(String path, String field, String requestedKey,
	                                                           String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/ValidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndAdd(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertEquals(response, ((List) value).get(0));
	}

	@DisplayName("test digUpValueAndAdd: Invalid Local List found on nested node and local successfully extracted")
	@ParameterizedTest
	@CsvSource(value = {
			"buyingClub,items,ja-JP, 1",
			"buyingClub,items,ja-JP, 2",
	})
	void digUpValueAndAdd_withPath_InvalidLocalListOnNestedNodes(String path, String field, String requestedKey,
	                                                             int testNo) {
		// Given:
		String fileName = "mockfiles/responseFilter/InvalidTestData.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);
		if (testNo == 2) {
			((Map)responseModel.get("buyingClub")).put("items", List.of(""));
		}

		// When:
		ResponseFilterHelper.digUpValueAndAdd(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertNull(value);
	}

	@DisplayName("test digUpValueAndAdd: requested locale doesnt exist")
	@ParameterizedTest
	@CsvSource(value = {
			"buyingClub,items,ja-JP,キャベツ"
	})
	void digUpValueAndAdd_withPath_RequestedLocaleDoesntExist(String path, String field, String requestedKey,
	                                                          String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/TestData_LocaleNotExist.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);

		// When:
		ResponseFilterHelper.digUpValueAndAdd(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertNull(value);
	}

	@DisplayName("test digUpValueAndAdd: field doesnt exist")
	@ParameterizedTest
	@CsvSource(value = {
			"buyingClub,items,ja-JP,キャベツ"
	})
	void digUpValueAndAdd_withPath_FieldDoesntExist(String path, String field, String requestedKey,
	                                                          String response) {
		// Given:
		String fileName = "mockfiles/responseFilter/TestData_LocaleNotExist.json";
		String responseString = TestUtil.getFileContents(fileName);
		Map<String, Object> responseModel = TestUtil.getObjectFromString(responseString, Map.class);
		((Map)responseModel.get(path)).remove(field);

		// When:
		ResponseFilterHelper.digUpValueAndAdd(responseModel, path, field, requestedKey);

		// Then:
		Object value = extractNestedValue(path + "." + field, responseModel);
		assertNull(value);
	}

	private Object extractNestedValue(String path, Map<String, Object> responseModel) {
		Object finalValue = null;
		String[] fields = path.split("\\.");
		for (int i = 0; i < fields.length; i++) {
			if (i == fields.length - 1) {
				finalValue = responseModel.get(fields[i]);
			} else {
				if (responseModel.get(fields[i]) instanceof List) {
					responseModel = (Map<String, Object>) ((List) responseModel.get(fields[i])).get(0);
				} else {
					responseModel = (Map<String, Object>) responseModel.get(fields[i]);
				}
			}
		}
		return finalValue;
	}
}
