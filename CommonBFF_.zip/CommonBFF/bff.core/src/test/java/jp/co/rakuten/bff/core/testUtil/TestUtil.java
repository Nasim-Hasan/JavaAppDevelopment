package jp.co.rakuten.bff.core.testUtil;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.service.upstream.client.BodyMapConversionLogic;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.env.MockEnvironment;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static java.io.File.separator;
import static org.mockito.Mockito.when;

public class TestUtil {
	private static Logger logger = LoggerFactory.getLogger(TestUtil.class);
	private static MockEnvironment env;
	private static BodyMapConversionLogic bodyMapConversionLogic = new BodyMapConversionLogic();

	private TestUtil() {
		//no instance required
	}

	public static void mockEnv(Environment env, String key, String value) {
		when(env.getProperty(key)).thenReturn(value);
	}

	public static String getResourcePath(String resourcePath) {
		resourcePath.replaceAll("//", separator);
		int slashIdx = resourcePath.indexOf(separator);
		String suffix = "";
		if (slashIdx != -1) {
			suffix = resourcePath.substring(slashIdx);
			resourcePath = resourcePath.substring(0, slashIdx);
		}
		return Objects.requireNonNull(TestUtil.class.getClassLoader().getResource(resourcePath)).getPath() + suffix;
	}

	public static File getFile(String fileName) {
		File inputFile = null;
		try {
			inputFile = new File(TestUtil.class.getResource("/" + fileName).toURI());
		} catch (URISyntaxException e) {
			logger.error("URISyntaxException while getting file: '" + fileName + "', Returning null...", e);
		}
		return inputFile;
	}

	public static String getFileContents(String fileName) {
		return getFileContents(getFile(fileName));
	}

	public static String getFileContents(File file) {
		String content = null;
		try {
			content = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
		} catch (IOException e) {
			logger.error("Error reading file: '" + file.getName() + "', Returning null...", e);
		}
		return content;
	}

	public static Map getXmlToMap(String fileName) {
		try {
			return bodyMapConversionLogic.xmlToMap(getFileContents(fileName), false);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}


	public static <T> T getObjectFromFilename(String fileName, Class<T> valueType) {
		return getObjectFromFile(getFile(fileName), valueType);
	}

	public static <T> T getObjectFromFile(File file, Class<T> valueType) {
		return getObjectFromString(getFileContents(file), valueType);
	}

	public static <T> T getObjectFromString(String value, Class<T> valueType) {
		try {
			return new ObjectMapper().readValue(value, valueType);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	public static <T> T getObjectFromTypeReference(String value, TypeReference<T> typeReference) {
		try {
			return new ObjectMapper().readValue(value, typeReference);
		} catch (Exception e) {
			logger.error("Error while readValue() with value '" + value + "', Returning null...", e);
			return null;
		}
	}

	public static Map mapOf(Object... data) {
		if (data.length % 2 != 0) {
			throw new IllegalArgumentException("data size is not even");
		}
		Map map = new HashMap();
		for (int i = 0; i < data.length; i++) {
			map.put(data[i], data[++i]);
		}
		return map;
	}

	public static Object extractValue(Map map, String keys) {
		return extractValue(map, keys, "\\.");
	}

	public static Object extractValue(Map map, String keys, String regex) {
		String[] strings = keys.split(regex);
		Object data = map;
		for (String key : strings) {
			data = ((Map) data).get(key);
		}
		return data;
	}


	public static MockEnvironment getMockEnvironment() {
		if (env == null) {
			MockEnvironment mockEnvironment = new MockEnvironment();
			mockEnvironment.setProperty("f1.disabled", "false");
			mockEnvironment.setProperty("f2.disabled", "true");
			mockEnvironment.setProperty("featureTogglingTestApi.ft.v1.f3.disabled", "true");
			mockEnvironment.setProperty("f4.android.disabled", "true");
			mockEnvironment.setProperty("featureTogglingTestApi.ft.v1..f5.android.disabled", "true");
			env = mockEnvironment;
		}
		return env;
	}

	/**
	 * Fetches the resource with path and converts to target object.<br>
	 * It uses the provided storeMap (if not null) to memoize parsed files,
	 * so that for same path if processed object already exists,
	 * it will not try to load and parse same file again and again.
	 *
	 * @param resourcePath path to load the resource file from
	 * @param targetClass  target object class type
	 * @param storeMap     map used to store processed value
	 * @return the result object
	 */
	public static <T> T getResourceObject(String resourcePath, Class<T> targetClass, Map<String, T> storeMap)
			throws IOException {
		T resource = null;
		if (storeMap != null) {
			resource = storeMap.get(resourcePath);
		}
		if (resource == null) {
			try (InputStream resourceInStream = new ClassPathResource(resourcePath).getInputStream()) {
				resource = new ObjectMapper().readValue(resourceInStream, targetClass);
				if (storeMap != null) {
					storeMap.put(resourcePath, resource);
				}
			} catch (Exception e) {
				throw e;
			}
		}
		return resource;
	}

	public static List<String> splitAndTrim(String str) {
		return splitAndTrim(str, "\\s*,\\s*");
	}

	public static List<String> splitAndTrim(String str, String regex) {
		return str == null ? Collections.emptyList()
				: Arrays.stream(str.split("\\s*,\\s*")).collect(Collectors.toList());
	}

	public static Map<String, Map<String, CommonRequestModel>> prepareValidatedRequests(String filename) {
		TypeReference<Map<String, Map<String, CommonRequestModel>>> typeRef = new TypeReference<>() {
		};
		return getObjectFromTypeReference(getFileContents(filename), typeRef);
	}

	public static Map<String, GenericCallDefinitionProcessedData> getGenericCallDefinitionProcessedData(
			String filename) {
		TypeReference<Map<String, GenericCallDefinitionProcessedData>> typeRef = new TypeReference<>() {
		};
		return getObjectFromTypeReference(getFileContents(filename), typeRef);
	}

	public static Map<String, CommonRequestModel> getValidatedRequest(String filename) {
		TypeReference<HashMap<String, CommonRequestModel>> typeRef
				= new TypeReference<>() {
		};
		String fileContents = getFileContents(filename);
		return getObjectFromTypeReference(fileContents, typeRef);
	}

	public static ClientRequestModel getClientRequestModel(String filename) {
		RequestModel requestModel = getObjectFromFilename(filename, RequestModel.class);
		ClientRequestModel clientRequestModel = new ClientRequestModel();
		clientRequestModel.setRequestModel(requestModel);

		return clientRequestModel;
	}

}
