package jp.co.rakuten.bff.core.cache;

import jp.co.rakuten.bff.core.config.InterfaceConfig;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;

class IchibaCacheManagerHelperTest {
	private IchibaCacheManagerHelper ichibaCacheManagerHelper;

	@BeforeEach
	void setUp() {
		ichibaCacheManagerHelper = new IchibaCacheManagerHelper();
	}

	@AfterEach
	void tearDown() {

	}

	@DisplayName("hasDifference Test: new and old maps are identical")
	@Test
	void testHasDifference_False() {
		// When
		boolean hasDifference =
				ichibaCacheManagerHelper.
						hasDifference(getInterfaceConfig("true"), getInterfaceConfig("true"));

		// Then
		assertFalse(hasDifference);
	}

	@DisplayName("hasDifference Test: new map has extra entry")
	@Test
	void testHasDifference_extraEntry_newMap() {
		// Given:
		Map<String, String> existingMap = getInterfaceConfig("true");
		Map<String, String> newMap = getInterfaceConfig("true");
		newMap.put("extraKey","extraValue");

		// When
		boolean hasDifference = ichibaCacheManagerHelper.hasDifference(newMap, existingMap);

		// Then
		assertTrue(hasDifference);
	}

	@DisplayName("hasDifference Test: old map has extra entry")
	@Test
	void testHasDifference_extraEntry_existingMap() {
		// Given:
		Map<String, String> existingMap = getInterfaceConfig("true");
		existingMap.put("extraKey","extraValue");
		Map<String, String> newMap = getInterfaceConfig("true");

		// When
		boolean hasDifference = ichibaCacheManagerHelper.hasDifference(newMap, existingMap);

		// Then
		assertTrue(hasDifference);
	}

	@DisplayName("hasDifference Test: new and old maps are not identical")
	@ParameterizedTest
	@ValueSource(strings = {LOCAL_TIMEOUT_PROP_KEY, ENABLED_PROP_KEY, SHARED_TIMEOUT_PROP_KEY,
			LOCAL_MAX_SIZE_PROP_KEY, TYPE_PROP_KEY, STALE_ENABLED_PROP_KEY, STALE_TIMEOUT_PROP_KEY})
	void testHasDifference_True(String propKey) {
		// Given
		Map<String, String> firstMap = getInterfaceConfig("true");
		firstMap.put(propKey, "test");
		Map<String, String> secondMap = getInterfaceConfig("true");

		// When
		boolean hasDifference = ichibaCacheManagerHelper.hasDifference(firstMap, secondMap);

		// Then
		assertTrue(hasDifference);
	}

	@DisplayName("getIchibaCacheConfiguration Test: get config successfully")
	@Test
	void testgetIchibaCacheConfiguration() {
		// Given
		Map<String, Map<String, String>> cacheConfigMap =
				Map.of("TEST_INTERFACE", getInterfaceConfig("true"));

		// When
		IchibaCacheConfiguration result = ichibaCacheManagerHelper
				.getIchibaCacheConfiguration("TEST_INTERFACE", cacheConfigMap);

		// Then
		assertNotNull(result);
		assertEquals("local_and_shared", result.getCacheType().name().toLowerCase());
		assertEquals(Duration.ofMillis(120000), result.getSharedTimeout());
		assertEquals(true, result.isStaleEnabled());
		assertEquals(Duration.ofMillis(50000), result.getLocalTimeout());
		assertEquals(Duration.ofMillis(160000), result.getStaleTimeout());
		assertEquals(100, result.getLocalCacheMaxSize());
	}

	@DisplayName("getSharedCacheTimeout Test: timeout when stale is enabled")
	@Test
	void testgetSharedCacheTimeout_stale() {
		// Given
		Map<String, Map<String, String>> cacheConfigMap =
				Map.of("TEST_INTERFACE", getInterfaceConfig("true"));
		IchibaCacheConfiguration ichibaCacheConfiguration = ichibaCacheManagerHelper
				.getIchibaCacheConfiguration("TEST_INTERFACE", cacheConfigMap);

		// When
		Duration sharedCacheTimeout = ichibaCacheManagerHelper.getSharedCacheTimeout(ichibaCacheConfiguration);

		// Then
		assertNotNull(sharedCacheTimeout);
		assertEquals(ichibaCacheConfiguration.getSharedTimeout()
							 .plus(ichibaCacheConfiguration.getStaleTimeout()), sharedCacheTimeout);
	}

	@DisplayName("getSharedCacheTimeout Test: timeout when stale is disabled")
	@Test
	void testgetSharedCacheTimeout() {
		// Given
		Map<String, Map<String, String>> cacheConfigMap =
				Map.of("TEST_INTERFACE", getInterfaceConfig("false"));
		IchibaCacheConfiguration ichibaCacheConfiguration = ichibaCacheManagerHelper
				.getIchibaCacheConfiguration("TEST_INTERFACE", cacheConfigMap);

		// When
		Duration sharedCacheTimeout = ichibaCacheManagerHelper.getSharedCacheTimeout(ichibaCacheConfiguration);

		// Then
		assertNotNull(sharedCacheTimeout);
		assertEquals(ichibaCacheConfiguration.getSharedTimeout(), sharedCacheTimeout);
	}

	@DisplayName("isLocalCacheExpired Test: local cache expiry passes current time")
	@ParameterizedTest
	@CsvSource({
			"1000,false",
			"-1000,true"
	})
	void testIsLocalCacheExpired(int expiryMillis, boolean isCacheExpired) {
		// Given
		Map<String, Object> cacheData = Map.of("data", "data", CACHE_EXPIRY_TIME,
		                                       LocalDateTime.now().plus(expiryMillis, ChronoUnit.MILLIS));

		// When
		boolean localCacheExpired = ichibaCacheManagerHelper.isLocalCacheExpired(cacheData);

		// Then
		assertEquals(isCacheExpired, localCacheExpired);
	}

	private Map<String, String> getInterfaceConfig(String isStale) {
		InterfaceConfig testInterface = new InterfaceConfig("TEST_INTERFACE");
		testInterface.putToCacheConfigMap(ENABLED_PROP_KEY, "true");
		testInterface.putToCacheConfigMap(LOCAL_TIMEOUT_PROP_KEY, "50000");
		testInterface.putToCacheConfigMap(SHARED_TIMEOUT_PROP_KEY, "120000");
		testInterface.putToCacheConfigMap(LOCAL_MAX_SIZE_PROP_KEY, "100");
		testInterface.putToCacheConfigMap(TYPE_PROP_KEY, "local_and_shared");
		testInterface.putToCacheConfigMap(STALE_ENABLED_PROP_KEY, isStale);
		testInterface.putToCacheConfigMap(STALE_TIMEOUT_PROP_KEY, "160000");
		return testInterface.getCacheConfigMap();
	}
}
