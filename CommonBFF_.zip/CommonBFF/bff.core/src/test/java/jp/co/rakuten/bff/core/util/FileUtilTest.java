package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.exception.SystemException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author BJIT Limited Created by tareq rahman on 12/3/19.
 */
public class FileUtilTest {

	@DisplayName("test get valid json files for valid json file dir")
	@Test
	void getValidJsonFilesForJsonFileDir() throws URISyntaxException {
		File[] files = FileUtil
				.getValidJsonFiles(new File(getClass().getResource("/repoJsonLoaderTest/variousFiles").toURI()));

		assertNotNull(files);
		assertEquals(2, files.length);
	}

	@DisplayName("test get valid json files")
	@Test
	void getValidJsonFilesForInvalidFileDir() throws URISyntaxException {
		File[] files = FileUtil.getValidJsonFiles(new File(getClass().getResource("/mockfiles").toURI()));

		assertNotNull(files);
		assertEquals(0, files.length);
	}

	@DisplayName("test get dir list")
	@Test
	void getDirList() throws URISyntaxException {
		File[] files = FileUtil.getDirList(new File(getClass().getResource("/mockfiles").toURI()));

		assertNotNull(files);
		assertTrue(files.length > 3);
	}

	@DisplayName("test getObjectFromJson with empty json")
	@Test
	void testGetObjectFromJson() {
		String jsonString = "{}";
		assertDoesNotThrow(() -> {
			Map result = FileUtil.getObjectFromJson(jsonString, Map.class);
			assert result.isEmpty();
		});
	}

	@DisplayName("test getObjectFromJson with empty json")
	@Test
	void testGetObjectFromJsonException() {
		String jsonString = "{[}]";
		assertThrows(SystemException.class,() -> FileUtil.getObjectFromJson(jsonString, Map.class));
	}
}
