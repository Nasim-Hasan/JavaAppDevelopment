package jp.co.rakuten.bff.core.logger;


import jp.co.rakuten.bff.core.exception.BffException;
import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.exception.type.SystemErrorEnum;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ThrowableMessageConverterTest {

	ThrowableMessageConverter throwableMessageConverter = new ThrowableMessageConverter();

	@Test
	public void testApplyWithGatewayException() {
		BffException exception = SystemException.create(SystemErrorEnum.INTERNAL, "default message");
		String message = throwableMessageConverter.apply(exception);
		assertTrue(message.contains("default message errorCode: 500"));
	}

	@Test
	public void testApplyWithNonGatewayException() {
		IllegalArgumentException exception = new IllegalArgumentException("an illegal argument");
		String message = throwableMessageConverter.apply(exception);
		assertTrue(message.contains("an illegal argument"));
	}

}
