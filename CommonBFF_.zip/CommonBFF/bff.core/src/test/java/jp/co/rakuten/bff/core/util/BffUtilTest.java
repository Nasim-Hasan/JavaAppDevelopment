package jp.co.rakuten.bff.core.util;

import jp.co.rakuten.bff.core.exception.SystemException;
import jp.co.rakuten.bff.core.logger.HttpLogger;
import org.junit.Assert;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author BJIT Limited Created by tareq rahman on 12/3/19.
 */
public class BffUtilTest {

	@DisplayName("test get valid json files for valid json file dir")
	@Test
	void testBuildUriException() {
		String testUrl = "http://?=^!";
		assertThrows(SystemException.class, () -> BFFUtil.buildURI(testUrl));
	}

	@Test
	public void testSortListOfMap() throws Exception {
		Map map1 = MapUtil.getObjectMapper().readValue("{\"data\":{\"shopId\":1, \"other\": 0}}", Map.class);
		Map map2 = MapUtil.getObjectMapper().readValue("{\"data\":{\"shopId\":2, \"other\": 1}}", Map.class);
		List<Map<String,Object>> list1=new ArrayList<>();
		list1.add(map1);
		list1.add(map2);
		BFFUtil.sortListOfMap(list1,"data");
		Assert.assertNotNull(list1);

		List<Map<String,Object>> listWithNullMap=new ArrayList<>();
		listWithNullMap.add(map1);
		listWithNullMap.add(Map.of());
		BFFUtil.sortListOfMap(listWithNullMap,"data");

		listWithNullMap.remove(0);
		listWithNullMap.add(0,Map.of());
		BFFUtil.sortListOfMap(listWithNullMap,"data");
	}

	@ParameterizedTest
	@ValueSource(ints = {0, 1, 2})
	@DisplayName("test addCallDefinitionInfoToLoggerRequest method")
	public void testAddCallDefinitionInfoToLoggerRequest(int reqSize) throws Exception {
		String cdName = "testCD";
		String reqType = "single";

		Map<String, Object> extras = new HashMap();
		HttpLogger.LoggerRequest loggerRequest = new HttpLogger.LoggerRequest();
		loggerRequest.setExtras(extras);

		List<Map<String, Object>> requests = new ArrayList<>();
		String expectedCDInterfaces = null;
		for (int i = 1; i <= reqSize; i++) {
			String interfaceKey = "req" + i;
			Map<String, Object> req = Map.of("interfaceKey", interfaceKey);
			requests.add(req);
			expectedCDInterfaces = expectedCDInterfaces == null ? interfaceKey : expectedCDInterfaces + "," + interfaceKey;
		}

		assertNull(extras.get("callDefinitionName"));
		assertNull(extras.get("callDefinitionType"));
		assertNull(extras.get("cdInterfaces"));
		assertEquals(reqSize, requests.size());
		if (reqSize > 0) {
			assertEquals(reqSize, expectedCDInterfaces.split(",").length);
		} else {
			assertNull(expectedCDInterfaces);
		}

		BFFUtil.addCallDefinitionInfoToLoggerRequest(loggerRequest, cdName, reqType, requests);

		assertEquals(cdName, extras.get("callDefinitionName"));
		assertEquals(reqType, extras.get("callDefinitionType"));
		assertEquals(expectedCDInterfaces, extras.get("callDefinitionInterfaces"));
	}
}
