package jp.co.rakuten.bff.core.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;

class DeepCopyUtilTest {

	@DisplayName("when return type is List")
	@Test
	void deepCopy_List() {
		// Given:
		Map<String, Object> testMap = new HashMap<>();
		List<Map<String, Object>> testList = new ArrayList<>();
		testMap.put("testB", 1);
		testMap.put("testA", "test");
		testList.add(testMap);

		// When:
		List<Map<String, Object>> returnedList = DeepCopyUtil.deepCopy(testList, List.class);

		// Then:
		assertNotSame(testList, returnedList);
		assertEquals("test", returnedList.get(0).get("testA"));
	}

	@DisplayName("when return type is Map")
	@Test
	void deepCopy_Map() {
		// Given:
		Map<String, Object> innerMap = new HashMap<>();
		List<Map<String, Object>> testList = new ArrayList<>();
		innerMap.put("testB", 1);
		innerMap.put("testA", "test");
		testList.add(innerMap);
		Map<String, Object> testMap = new HashMap<>();
		testMap.put("testB", 1);
		testMap.put("testA", "test");
		testMap.put("testC", testList);

		// When:
		Map<String, Object> returnedMap = DeepCopyUtil.deepCopy(testMap, Map.class);

		// Then:
		assertNotSame(testMap, returnedMap);
		assertEquals("test", returnedMap.get("testA"));
		assertEquals(1, returnedMap.get("testB"));
		testList = (List<Map<String, Object>>) returnedMap.get("testC");
		assertEquals("test", testList.get(0).get("testA"));
		assertEquals(1, testList.get(0).get("testB"));
	}
}
