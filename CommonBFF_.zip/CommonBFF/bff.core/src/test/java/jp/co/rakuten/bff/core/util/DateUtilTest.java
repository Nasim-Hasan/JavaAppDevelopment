package jp.co.rakuten.bff.core.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Date;
import java.util.stream.Stream;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author BJIT Limited Created by Pranoy Das 04/13/2020.
 */
public class DateUtilTest {
	@BeforeEach
	void setup() {
		MockitoAnnotations.initMocks(this);
	}


	@ParameterizedTest
	@DisplayName("Failure case of conversion of date.")
	@CsvSource(value ={
			"null|yyyy-MM-dd",
			"                             |yyyy-MM-dd",
			"2020/04/13 16:53:42          |null",
			"2020/04/13 16:53:42          |",
			"2020/04/13 16:53:42          |yyyy-MM-dd",
			"2017-10-22T09:00:00+09:00    |yyyy-MM-dd:HH:mm:ss'+09:00'",
			"2017-10-22T09:00:00+09:00    |yyyy-MM-dd:HH'T'mm:ss'+09:00'",
			"2017-10-22T09:00:00+09:00    |yyyy-MM-dd:HH'T'mm:ss+09:00",
			"2017-10-22T00:00:00Z         |yyyy-MM-dd'T'HH:mm:ssZ"
	}, delimiter = '|')
	void convertToDateFailTest(String inputString, String inputDateFormat) {
		assertNull(DateUtil.convertToDate(inputString, inputDateFormat));
	}

	@ParameterizedTest
	@DisplayName("test convertToDate(dateString,format) method")
	@CsvSource(value = {
			//inputString                 |inputDateFormat                  |outputDateFormat                 |expectedDateString
			"2020/04/13 16:53:42          |yyyy/MM/dd                       |yyyy/MM/dd                       |2020/04/13",
			"2017-10-22T00:00:00Z	      |yyyy-MM-dd'T'HH:mm:ss'Z'         |yyyy-MM-dd'T'HH:mm:ss'Z'         |2017-10-22T09:00:00Z",
			"2017-10-22T09:00:00	      |yyyy-MM-dd'T'HH:mm:ss            |yyyy-MM-dd'T'HH:mm:ss'+09:00'    |2017-10-22T09:00:00+09:00",
			"2017-10-22T09:00:00+09:00    |yyyy-MM-dd'T'HH:mm:ss'+09:00'    |yyyy-MM-dd'T'HH:mm:ss            |2017-10-22T09:00:00",
			"2020-01-07T14:00:00.000+09:00|yyyy-MM-dd'T'HH:mm:ss.SSS'+09:00'|yyyy-MM-dd'T'HH:mm:ss.SSS'+09:00'|2020-01-07T14:00:00.000+09:00",
			"2017:10:22:06:00:00+06:00    |yyyy:MM:dd:HH:mm:ss'+06:00'      |yyyy:MM:dd:HH:mm:ss'+09:00'      |2017:10:22:09:00:00+09:00",
			"2017:10:22:06:00:00-06:00    |yyyy:MM:dd:HH:mm:ss'-06:00'      |yyyy:MM:dd:HH:mm:ss'+09:00'      |2017:10:22:21:00:00+09:00"
	}, delimiter = '|')
	void testConvertToDate(String inputString, String inputDateFormat, String outputDateFormat, String expectedDateString) {
		Date startDate = DateUtil.convertToDate(inputString, inputDateFormat);
		String stringDateFormatter = DateUtil.format(startDate, outputDateFormat);
		assertEquals(expectedDateString, stringDateFormatter);
	}

	@ParameterizedTest
	@DisplayName("test convertToUTCDate(inputString,inputDateFormat,outputDateFormat) method")
	@CsvSource(value = {
			"2020/04/13 16:53:42          |yyyy/MM/dd                       |yyyy/MM/dd                    |2020/04/12",
			"2017-10-22T00:00:00Z	      |yyyy-MM-dd'T'HH:mm:ss'Z'         |yyyy-MM-dd'T'HH:mm:ss'Z'      |2017-10-22T00:00:00Z",
			"2017-10-22T09:00:00	      |yyyy-MM-dd'T'HH:mm:ss            |yyyy-MM-dd'T'HH:mm:ss'Z'      |2017-10-22T00:00:00Z",
			"2017-10-22T09:00:00+09:00    |yyyy-MM-dd'T'HH:mm:ss'+09:00'    |yyyy-MM-dd'T'HH:mm:ss         |2017-10-22T00:00:00",
			"2020-01-07T14:00:00.000+09:00|yyyy-MM-dd'T'HH:mm:ss.SSS'+09:00'|yyyy-MM-dd'T'HH:mm:ss.SSS'Z'  |2020-01-07T05:00:00.000Z",
			"2017:10:22:06:00:00+06:00    |yyyy:MM:dd:HH:mm:ss'+06:00'      |yyyy:MM:dd:HH:mm:ss'Z'        |2017:10:22:00:00:00Z",
			"2017:10:22:06:00:00-06:00    |yyyy:MM:dd:HH:mm:ss'-06:00'      |yyyy:MM:dd:HH:mm:ss'Z'        |2017:10:22:12:00:00Z"
	}, delimiter = '|')
	void testConvertToUTCDate(String inputString, String inputDateFormat, String outputDateFormat, String expectedDateString) {
		Date startDate = DateUtil.convertToUTCDate(inputString, inputDateFormat);
		String stringDateFormatter = DateUtil.format(startDate, outputDateFormat);
		assertEquals(expectedDateString, stringDateFormatter);
	}

	@DisplayName("Current date is between two date test.")
	@Test
	void isInBetweenCurrentTimeTest() {
		Date startDate = DateUtil.convertToDate("2020/04/10 16:53:42", "yyyy/MM/dd");

		LocalDate time = LocalDate.now();
		long currentYear = time.getYear();
		Date endDate = DateUtil.convertToDate(currentYear+1 + "/01/01 16:53:42", "yyyy/MM/dd");

		assertTrue(DateUtil.isInBetweenCurrentTime(startDate, endDate));
	}

	@DisplayName("Current date is not between two date test.")
	@Test
	void isNotBetweenCurrentTimeTest() {
		Date startDate = DateUtil.convertToDate("2020/04/10 16:53:42", "yyyy/MM/dd");
		Date endDate = DateUtil.convertToDate("2020/04/12 16:53:42", "yyyy/MM/dd");

		Date startDate1 = DateUtil.convertToDate("2030/05/14 16:53:42", "yyyy/MM/dd");
		Date endDate1 = DateUtil.convertToDate("2030/05/17 16:53:42", "yyyy/MM/dd");

		assertFalse(DateUtil.isInBetweenCurrentTime(startDate, endDate));
		assertFalse(DateUtil.isInBetweenCurrentTime(startDate1, endDate1));
		assertFalse(DateUtil.isInBetweenCurrentTime(null, null));
		assertFalse(DateUtil.isInBetweenCurrentTime(null, endDate));
		assertFalse(DateUtil.isInBetweenCurrentTime(startDate, null));
	}

	@DisplayName("isValid: Success for valid date")
	@Test
	void testIsValidSuccess() {
		Date startDate = DateUtil.convertToDate("2017:10:22:00:00:00", "yyyy:MM:dd:HH:mm:ss");
		Date endDate = DateUtil.convertToDate("2017:10:22:23:59:00", "yyyy:MM:dd:HH:mm:ss");
		assertTrue(DateUtil.isValidRange(startDate, endDate));

	}

	@DisplayName("isValid: failure for dates")
	@Test
	void testIsValidFailure() {
		Date endDate = DateUtil.convertToDate("2017:10:22:00:00:00", "yyyy:MM:dd:HH:mm:ss");
		Date startDate = DateUtil.convertToDate("2017:10:22:23:59:00", "yyyy:MM:dd:HH:mm:ss");
		assertFalse(DateUtil.isValidRange(null, endDate));
		assertFalse(DateUtil.isValidRange(startDate, null));
		assertFalse(DateUtil.isValidRange(startDate, endDate));
	}

	@DisplayName("test for format(date,format) method")
	@Test
	void testFormat() {
		Date startDate = DateUtil.convertToDate("2017:10:22:23:59:00", "yyyy:MM:dd:HH:mm:ss");
		assertEquals("2017-10-22T23:59:00+09:00", DateUtil.format(startDate, "yyyy-MM-dd'T'HH:mm:ss'+09:00'"));
		assertNull(DateUtil.format(null, "2017-10-22T23:59:00+09:00"));
		assertNull(DateUtil.format(startDate, ""));
	}

	@DisplayName("Current date is between two null date test.")
	@Test
	void isInBetweenNullDateCurrentTimeTest() {
		assertFalse(DateUtil.isInBetweenCurrentTime(null, null));
	}

	@DisplayName("test for format(format, milliseconds) method")
	@ParameterizedTest
	@MethodSource("formats")
	void testFormatWithMillisecondsInErrorCase(String format, Long millisec, String expected,String inputZoneId, String oututZoneId) {
		assertEquals(expected, DateUtil.format(millisec,format,inputZoneId, oututZoneId));
	}

	static Stream<Arguments> formats() {
		return Stream.of(
				Arguments.of(null, 10000L, null, DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_TOKYO),
				Arguments.of("dummy format", 10000L, null,DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_TOKYO)
		);
	}

	static Stream<Arguments> dataSetsForMillisecondToDate() {
		//Given
		//Milliseconds is provided from UTC date (2020-01-01T01:00:00.000)
		Date utcDate = DateUtil.convertToUTCDate("2020-01-01T10:00:00+09:00", DateUtil.RESPONSE_DATE_FORMAT);
		//Milliseconds is provided from JST date(2020-01-01T10:00:00.000)
		Date jpFromUtcDate = DateUtil.convertToDate("2020-01-01T01:00:00.000Z", DateUtil.UTC_DATE_FORMAT);
		String sysTimeZone = TimeZone.getDefault().getID();
		if ("UTC".equals(sysTimeZone)) {
			return Stream.of(
					//  milliSeconds,  outputFormat,  inputZoneId, outputTimeZoneId, expectedResponse
					Arguments.of( //1. UTC environment or UTC date, System:UTC, input zoneId:UTC outputTimeZoneID:UTC ->TimeZoneSet:No(No conversion)
							utcDate.getTime(), DateUtil.UTC_DATE_FORMAT, DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_UTC, "2020-01-01T01:00:00.000Z"),
					Arguments.of(//2. UTC environment or UTC date, System:UTC, input zoneId:UTC outputTimeZoneID:TOKYO->TimeZoneSet:TOKYO
							utcDate.getTime(), DateUtil.RESPONSE_DATE_FORMAT, DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_TOKYO, "2020-01-01T10:00:00+09:00"),
					Arguments.of(//3. UTC environment or UTC date, System:UTC, input zoneId:TOKYO outputTimeZoneID:UTC->TimeZoneSet:UTC
							jpFromUtcDate.getTime(), DateUtil.UTC_DATE_FORMAT, DateUtil.ZONE_ID_TOKYO, DateUtil.ZONE_ID_UTC, "2020-01-01T10:00:00.000Z"),
					Arguments.of(//4. UTC environment or UTC date, System:UTC, input zoneId:TOKYO outputTimeZoneID:TOKYO->TimeZoneSet:No(No conversion)
							jpFromUtcDate.getTime(), DateUtil.RESPONSE_DATE_FORMAT, DateUtil.ZONE_ID_TOKYO, DateUtil.ZONE_ID_TOKYO, "2020-01-01T10:00:00+09:00")
			);
		} else {
			return Stream.of(
					//  milliSeconds,  outputFormat,  inputZoneId, outputTimeZoneId, expectedResponse
					Arguments.of( //1. UTC environment or UTC date, System:UTC, input zoneId:UTC outputTimeZoneID:UTC ->TimeZoneSet:No(No conversion)
							utcDate.getTime(), DateUtil.UTC_DATE_FORMAT, DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_UTC, "2020-01-01T01:00:00.000Z"),
					Arguments.of(//2. UTC environment or UTC date, System:UTC, input zoneId:UTC outputTimeZoneID:TOKYO->TimeZoneSet:TOKYO
							utcDate.getTime(), DateUtil.RESPONSE_DATE_FORMAT, DateUtil.ZONE_ID_UTC, DateUtil.ZONE_ID_TOKYO, "2020-01-01T01:00:00+09:00"),
					Arguments.of(//3. UTC environment or UTC date, System:UTC, input zoneId:TOKYO outputTimeZoneID:UTC->TimeZoneSet:UTC
							jpFromUtcDate.getTime(), DateUtil.UTC_DATE_FORMAT, DateUtil.ZONE_ID_TOKYO, DateUtil.ZONE_ID_UTC, "2020-01-01T01:00:00.000Z"),
					Arguments.of(//4. UTC environment or UTC date, System:UTC, input zoneId:TOKYO outputTimeZoneID:TOKYO->TimeZoneSet:No(No conversion)
							jpFromUtcDate.getTime(), DateUtil.RESPONSE_DATE_FORMAT, DateUtil.ZONE_ID_TOKYO, DateUtil.ZONE_ID_TOKYO, "2020-01-01T10:00:00+09:00")
			);
		}
	}

	@DisplayName("test for format(milliSeconds,outputFormat,inputZoneId,outputTimeZoneId) method")
	@ParameterizedTest
	@MethodSource("dataSetsForMillisecondToDate")
	void testFormatWithMilliseconds(long milliSeconds, String outputFormat, String inputZoneId, String outputTimeZoneId, String expectedResult) {
		assertEquals(expectedResult, DateUtil.format(milliSeconds, outputFormat, inputZoneId, outputTimeZoneId));
	}

	@DisplayName("test for parse(milliSeconds, inputZoneId, outputTimeZoneId) method")
	@ParameterizedTest
	@MethodSource("dataSetsForMillisecondToDate")
	void testParseWithMilliseconds(long milliSeconds, String outputFormat, String inputZoneId, String outputTimeZoneId, String expectedResult) {
		assertEquals(expectedResult, DateUtil.format(DateUtil.parse(milliSeconds, inputZoneId, outputTimeZoneId), outputFormat));
	}

	@DisplayName("startdate is after Current date test.")
	@Test
	void isBeforeCurrentTimeTest() {
		//valid StartDate
		Date startDate = DateUtil.convertToDate("2020-01-01T18:35:28+09:00",
				DateUtil.RESPONSE_DATE_FORMAT);
		assertTrue(DateUtil.isBeforeCurrentTime(startDate));


		//Non valid StartDate
		LocalDate time = LocalDate.now();
		long currentYear = time.getYear();
		Date startDateNotValid =
				DateUtil.convertToDate(currentYear+1 + "-06-08T18:35:28+09:00",
						DateUtil.RESPONSE_DATE_FORMAT);
		assertFalse(DateUtil.isBeforeCurrentTime(startDateNotValid));

		//null StartDate
		assertFalse(DateUtil.isBeforeCurrentTime(null));
	}

	@DisplayName("Current date is between two date test.")
	@Test
	void isExpiredTest() {
		//valid EndDate
		LocalDate time = LocalDate.now();
		long currentYear = time.getYear();
		Date endDateValid =
				DateUtil.convertToDate(currentYear+1 + "-06-08T18:35:28+09:00",
						DateUtil.RESPONSE_DATE_FORMAT);
		assertTrue(DateUtil.isAfterCurrentTime(endDateValid));

		//Non valid EndDate
		Date endDateNotValid =
				DateUtil.convertToDate(currentYear-1 + "-06-08T18:35:28+09:00",
						DateUtil.RESPONSE_DATE_FORMAT);
		assertFalse(DateUtil.isAfterCurrentTime(endDateNotValid));

		assertFalse(DateUtil.isAfterCurrentTime(null));
	}
}