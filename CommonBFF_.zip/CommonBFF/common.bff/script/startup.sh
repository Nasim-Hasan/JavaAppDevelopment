#!/bin/sh
export profile=$(eval echo $ENV)
export JMX_CONF="-Dcom.sun.management.jmxremote.rmi.port=5000 -Dcom.sun.management.jmxremote=true -Dcom.sun.management.jmxremote.port=5000 -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.local.only=false -Djava.rmi.server.hostname=localhost"

#check for ENV
if [ -z $profile ]
then
	echo "ENV variable not set. Setting it to prod"
	profile=prod
fi

#check for Gateway URI
if [ ! -z $GATEWAY_URL ]
then
	echo "Gateway URL is set: "$GATEWAY_URL
	GATEWAY_URL_CONF="-Dgateway.uri=$GATEWAY_URL"
else
  echo "Gateway URL is NOT set. Property file value will be used."
fi

#Running the application
echo "Starting BFF !!!!"
java $GATEWAY_URL_CONF -Djava.security.egd=file:/dev/./urandom $JMX_CONF $JAVA_OPTS -jar ./app.jar --spring.profiles.active=$profile
