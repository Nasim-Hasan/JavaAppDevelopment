package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

class ItemXInterfaceProcessorTest {

	Map<String, Map<String, CommonRequestModel>> validatedRequests;
	Map<String, Object> validatedRequestsObject;

	Map<String, GenericCallDefinitionProcessedData> genericCDProcessedDatas;
	Map<String, GenericCallDefinitionProcessedData> genericCDProcessedData;
	Map<String, Object> itemxResponse;
	Map<String, Object> itemxGGResponse;
	Map<String, Object> parametersMap;
	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private static final String BASE_PATH = "mockfiles/feature/itemInfo/";
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
  private  static final String ITEMX_SELECTIONS = "selections";
	@InjectMocks
	private ItemXInterfaceProcessor itemxInterfaceProcessor;

	@BeforeEach
	void setUp() {
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		itemxInterfaceProcessor = new ItemXInterfaceProcessor();
		callDefinitionResponseMap = new HashMap<>();

		validatedRequests = TestUtil.prepareValidatedRequests(BASE_PATH + "validatedRequests.json");
		validatedRequestsObject = TestUtil.getObjectFromFilename(BASE_PATH + "validatedRequests.json", Map.class);
		genericCDProcessedDatas =
				TestUtil.getGenericCallDefinitionProcessedData(BASE_PATH + "genericPreparedRequest.json");
		itemxGGResponse = TestUtil.getObjectFromFilename(BASE_PATH + "itemxUpstreamResponse.json",
				Map.class);
		itemxResponse = TestUtil.getObjectFromFilename(BASE_PATH + "itemxUpstreamResponse.json",
				Map.class);

	}

	@Test
	@DisplayName( "Post Process Test")
	void testPostProcess(){
		//Given
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get("shopIdManageNumber");
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		Map itemxGGResponseBodyMap = TestUtil.getObjectFromFilename(BASE_PATH + "itemxUpstreamResponse.json",
				Map.class);

		CallDefinitionResponse callDefinitionResponse = getCallDefinitionResponse(itemxGGResponseBodyMap);

		//Then
		itemxInterfaceProcessor.postProcess(validatedRequest, callDefinitionResponse, genericCDProcessedData, null);

		//Verify
		Map<String, Object> itemxResponse = callDefinitionResponse.getResponseForSingleCall(
				ItemXInfoConstants.ITEMX_INTERFACE_KEY).getBodyMap();
		assertEquals("人間用の新野菜",itemxResponse.get("title"));

	}

	@Test
	@DisplayName( "Post Process Test Do Nothing")
	void testPostProcessDoNothing(){
		//Given
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get("shopIdManageNumber");
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		CallDefinitionResponse callDefinitionResponse = getCallDefinitionResponse(Collections.EMPTY_MAP);

		//Then
		itemxInterfaceProcessor.postProcess(validatedRequest, callDefinitionResponse, genericCDProcessedData, null);

		//Verify
		Map<String, Object> itemxResponse = callDefinitionResponse.getResponseForSingleCall(
				ItemXInfoConstants.ITEMX_INTERFACE_KEY).getBodyMap();
		assertFalse(false);

	}

	private CallDefinitionResponse getCallDefinitionResponse(Map<String, Object> bodyMap) {
		String fileName = BASE_PATH + "itemxGGResponseBodyMap.json";
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				ItemXInfoConstants.ITEMX_INTERFACE_KEY, fileName);
		CustomHttpResponse itemxInterfaceResponse = callDefinitionResponse.getResponseForSingleCall(ItemXInfoConstants.ITEMX_INTERFACE_KEY);
		itemxInterfaceResponse.setBodyMap(bodyMap);
		return callDefinitionResponse;
	}

	@Test
	@DisplayName("When itemxInterfaceResponse is not null")
	void transformResponseMethodTest() {

		parametersMap = new HashMap<>();

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("人間用の新野菜", itemxResponse.get(ItemXInfoConstants.ITEMX_TITLE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("new vegetable for new species", itemxResponse.get(ItemXInfoConstants.ITEMX_TITLE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("PCブラウザ向けに最適化されたキャッチコピー的なフィールド", itemxResponse.get(ItemXInfoConstants.ITEMX_TAGLINE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("This's a catch copy for PC browsers", itemxResponse.get(ItemXInfoConstants.ITEMX_TAGLINE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "sp");
		assertEquals("携帯端末ブラウザ向けに最適化されたキャッチコピー的なフィールド", itemxResponse.get(ItemXInfoConstants.ITEMX_TAGLINE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "sp");
		assertEquals("A catch copy to appear on mobile phone", itemxResponse.get(ItemXInfoConstants.ITEMX_TAGLINE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("<div>PCブラウザ向けに最適化された商品説明分(HTML)</div>", itemxResponse.get(ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("<div>Production description for desktop PC</div>", itemxResponse.get(ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "sp");
		assertEquals("<div>携帯端末ブラウザ向けに最適化された商品説明分(HTML)</div>", itemxResponse.get(ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "sp");
		assertEquals("<div>Production description for mobile</div>", itemxResponse.get(ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("販売説明分", itemxResponse.get(ItemXInfoConstants.ITEMX_SALES_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("More explanation to boost sales", itemxResponse.get(ItemXInfoConstants.ITEMX_SALES_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("医薬品の説明文", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_PRECAUTIONS)).get(ItemXInfoConstants.ITEMX_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("Please explain about how to use medicine in here", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_PRECAUTIONS)).get(ItemXInfoConstants.ITEMX_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("医薬品注意事項がかごに表示する", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_PRECAUTIONS)).get(ItemXInfoConstants.ITEMX_AGREEMENT));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("How the medicine should be used and approval from shoppers", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_PRECAUTIONS)).get(ItemXInfoConstants.ITEMX_AGREEMENT));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals(((Map<String, Object>) itemxGGResponse.get(ItemXInfoConstants.ITEMX_IMAGES)).get("ja-JP"), itemxResponse.get(ItemXInfoConstants.ITEMX_IMAGES));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals(((Map<String, Object>) itemxGGResponse.get(ItemXInfoConstants.ITEMX_IMAGES)).get("en-US"), itemxResponse.get(ItemXInfoConstants.ITEMX_IMAGES));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		Map videoProcess = (Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO);
		assertTrue(videoProcess.containsKey("type"));
		assertTrue(videoProcess.containsKey("value"));
		assertEquals("HTML",videoProcess.get("type"));
		assertEquals("<script src=" ,videoProcess.get("value"));


		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals(null, itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("野菜にアレルギーの経験はありますか", ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ItemXInfoConstants.ITEMX_LABEL));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("Are you allergic to vegetable before?", ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ItemXInfoConstants.ITEMX_LABEL));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("はい", ((Map<String, Object>) ((List<Object>) ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ITEMX_SELECTIONS)).get(0)).get(ItemXInfoConstants.ITEMX_DISPLAY_VALUE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("Yes", ((Map<String, Object>) ((List<Object>) ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ITEMX_SELECTIONS)).get(0)).get(ItemXInfoConstants.ITEMX_DISPLAY_VALUE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("いいえ", ((Map<String, Object>) ((List<Object>) ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ITEMX_SELECTIONS)).get(1)).get(ItemXInfoConstants.ITEMX_DISPLAY_VALUE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("No", ((Map<String, Object>) ((List<Object>) ((Map<String, Object>) (((List<Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS)).get(0))).get(ITEMX_SELECTIONS)).get(1)).get(ItemXInfoConstants.ITEMX_DISPLAY_VALUE));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("この説明は買い物かごに表示する", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_SUBSCRIPTION)).get(ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("This description shows in checkout", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_SUBSCRIPTION)).get(ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "ja-JP", "pc");
		assertEquals("キャベツ", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(0));
		assertEquals("トマト", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(1));
		assertEquals("きゅうり", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(2));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse, parametersMap, "en-US", "pc");
		assertEquals("cabbage", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(0));
		assertEquals("Tomato", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(1));
		assertEquals("Cucumber", ((List<Object>) ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_ITEMS)).get(2));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse,parametersMap,"ja-JP","pc");
		assertEquals("この説明は買い物かごに表示する", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION));

		itemxResponse = setTestCasesforTransformResponseMethodTest(itemxGGResponse,parametersMap,"en-US","pc");
		assertEquals("This description shows in checkout", ((Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_BUYING_CLUB)).get(ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION));
	}

	private Map<String, Object> setTestCasesforTransformResponseMethodTest(Map<String, Object> itemxResponse, Map<String, Object> parametersMap, String localeValue, String deviceTypeValue) {
		parametersMap.put("deviceType", deviceTypeValue);
		parametersMap.put("locale", localeValue);
		itemxInterfaceProcessor.transformResponse(parametersMap, itemxResponse);
		itemxGGResponse = TestUtil.getObjectFromFilename(BASE_PATH + "itemxUpstreamResponse.json",
				Map.class);
		return itemxResponse;

	}
	private Map<String, Object> setTestCasesforTransformResponseMethodTest1(Map<String, Object> itemxResponse, Map<String, Object> parametersMap, String localeValue, String deviceTypeValue,String filename) {
		parametersMap.put("deviceType", deviceTypeValue);
		parametersMap.put("locale", localeValue);
		itemxResponse = TestUtil.getObjectFromFilename(BASE_PATH + filename+".json",
				Map.class);
		itemxInterfaceProcessor.transformResponse(parametersMap, itemxResponse);
		return itemxResponse;

	}
	@Test
	@DisplayName("When itemxInterfaceResponse is not null")
	void transformResponseMethodVideoTest() {
		parametersMap = new HashMap<>();

		itemxResponse = setTestCasesforTransformResponseMethodTest1(itemxGGResponse, parametersMap, "ja-JP", "pc","itemxUpstreamEmptyVideo");
		assertFalse(itemxResponse.containsKey(ItemXInfoConstants.ITEMX_VIDEO));

		itemxResponse = setTestCasesforTransformResponseMethodTest1(itemxGGResponse, parametersMap, "ja-JP", "pc","itemxUpstreamResponseVideoEmptyParam");
		Map videoProcess = (Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO);
		assertTrue(videoProcess.containsKey("type"));
		assertFalse(videoProcess.containsKey("value"));
		assertEquals("HTML", videoProcess.get("type"));

		itemxResponse = setTestCasesforTransformResponseMethodTest1(itemxGGResponse, parametersMap, "ja-JP", "pc","itemxUpstreamResponseVideoNoParam");
		videoProcess = (Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO);
		assertTrue(videoProcess.containsKey("type"));
		assertFalse(videoProcess.containsKey("value"));
		assertEquals("HTML", videoProcess.get("type"));

		itemxResponse = setTestCasesforTransformResponseMethodTest1(itemxGGResponse, parametersMap, "ja-JP", "pc","itemxUpstreamResponseVideoParamBlankValue");
		videoProcess = (Map<String, Object>) itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO);
		assertTrue(videoProcess.containsKey("type"));
		assertFalse(videoProcess.containsKey("value"));
		assertEquals("HTML", videoProcess.get("type"));
	}

}