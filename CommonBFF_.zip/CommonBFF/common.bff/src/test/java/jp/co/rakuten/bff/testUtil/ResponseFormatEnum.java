package jp.co.rakuten.bff.testUtil;

 enum ResponseFormatEnum {
	JSON,
	XML,
	TEXT
}
