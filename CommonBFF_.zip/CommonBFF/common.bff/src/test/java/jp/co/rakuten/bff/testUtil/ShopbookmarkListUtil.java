package jp.co.rakuten.bff.testUtil;

import com.fasterxml.jackson.core.type.TypeReference;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShopbookmarkListUtil {

	private static final String BASE_PATH = "mockfiles/feature/shopbookmarkList/";

	private ShopbookmarkListUtil() {
	}

	public static Map<String, CommonRequestModel> prepareValidatedRequest() {
		TypeReference<HashMap<String, CommonRequestModel>> typeRef = new TypeReference<>() {};
		String validatedRequestFileContents = TestUtil.getFileContents(BASE_PATH + "validatedRequest.json");
		return TestUtil.getObjectFromTypeReference(validatedRequestFileContents, typeRef);
	}

	public static MultipleResponses prepareMultipleResponses(String fileName) {
		String callDefinitionResponseFileContents = TestUtil.getFileContents(BASE_PATH + fileName);
		return TestUtil.getObjectFromString(callDefinitionResponseFileContents, MultipleResponses.class);
	}

	public static Map<String, Map<String, Object>> prepareGenericPreparedRequest(String filename) {
		TypeReference<Map<String, Map<String, Object>>> typeRef = new TypeReference<>() {};
		String genericPreparedRequestFileContents = TestUtil.getFileContents(BASE_PATH + filename);
		return TestUtil.getObjectFromTypeReference(genericPreparedRequestFileContents, typeRef);
	}

	public static List<Map<String, Object>> prepareValidCouponResponse(String filename) {
		TypeReference<List<Map<String, Object>>> typeRef = new TypeReference<>() {};
		String genericPreparedRequestFileContents = TestUtil.getFileContents(BASE_PATH + filename);
		return TestUtil.getObjectFromTypeReference(genericPreparedRequestFileContents, typeRef);
	}

	public static List<Map<String, Object>> prepareValidPointResponse(String filename) {
		TypeReference<List<Map<String, Object>>> typeRef = new TypeReference<>() {
		};

		String genericPreparedRequestFileContents = TestUtil.getFileContents(BASE_PATH + filename);
		return TestUtil.getObjectFromTypeReference(genericPreparedRequestFileContents, typeRef);
	}
}
