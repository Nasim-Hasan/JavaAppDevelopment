package jp.co.rakuten.bff.business.itembookmark.list.validdators;

import jp.co.rakuten.bff.business.itembookmark.list.validators.ItemBookmarkListValidator;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ItemBookmarkListValidatorTest {
	private ItemBookmarkListValidator itemBookmarkListValidator;
	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		itemBookmarkListValidator = new ItemBookmarkListValidator();
	}

	@AfterEach
	void tearDown() {
		itemBookmarkListValidator = null;
	}


	@Test
	@DisplayName("ItemBookmarkListValidator: validate successfully")
	void testBrowsingHistoryAddValidatorSuccess() {
		//Given
		CommonRequestModel commonRequestModel = prepareCommonRequestModel(1010);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put("itemBookmarkListInfo", commonRequestModel);

		ClientRequestModel clientRequestModel = new ClientRequestModel();

		//Then+Verify
		Map<String, CommonRequestModel> validatedData = itemBookmarkListValidator.validate(validatedRequest,
				null, clientRequestModel);
		assertNotNull(validatedData);
	}

	@Test
	@DisplayName("ItemBookmarkListValidator: validate failure")
	void testBrowsingHistoryAddValidatorFailed() {
		//Given
		CommonRequestModel commonRequestModel = prepareCommonRequestModel(-1);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put("itemBookmarkListInfo", commonRequestModel);

		ClientRequestModel clientRequestModel = new ClientRequestModel();

		//Then+Verify
		assertThrows(ClientException.class,
				() -> itemBookmarkListValidator.validate(validatedRequest, null, clientRequestModel));
	}

	private CommonRequestModel prepareCommonRequestModel(Integer easyId) {
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		Map<String, Object> headers = new HashMap<>();
		headers.put("easyId", easyId);
		commonRequestModel.setHeaders(headers);
		return commonRequestModel;
	}

}