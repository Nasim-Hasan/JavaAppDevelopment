package jp.co.rakuten.bff.business.itembookmark.add.processors.features;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ItemBookmarkAddInfoFeatureProcessorTest {

	private ItemBookmarkAddInfoFeatureProcessor itemBookmarkAddInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private static final String BASE_PATH = "mockfiles/feature/itemBookmarkAdd/";

	@BeforeEach
	void setUp() {
		itemBookmarkAddInfoFeatureProcessor = new ItemBookmarkAddInfoFeatureProcessor();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		callDefinitionResponseMap = new HashMap<>();
	}

	@Test
	@DisplayName("postProcess: Success for proper response")
	void testPostProcess() {
		//When
		CallDefinitionResponse itembookmarkCDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"itemBookmarkAdd", BASE_PATH + "itemBookmarkAddSuccess.json");
		callDefinitionResponseMap.put("itemBookmarkAddCD", itembookmarkCDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkAddInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals("イーシーエスジー 孫", ((Map) result.get("data")).get("shopName"));
		assertEquals(1080, ((Map) result.get("data")).get("price"));
		assertEquals("_ecsg_qa_0001-itm_20180207 Recommendation Item", ((Map) result.get("data")).get("itemName"));
		assertEquals("https://item.rakuten.co.jp/_ts-sunyang01/qa_itm_20180207_0001/", ((Map) result.get("data")).get("itemUrl"));
		assertEquals(1101, ((Map) result.get("status")).get("code"));
		assertEquals("created", ((Map) result.get("status")).get("message"));
	}


	@Test
	@DisplayName("postProcess: Success for proper response case: 2")
	void testPostProcessSuccess() {
		//When
		CallDefinitionResponse itembookmarkCDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"itemBookmarkAdd", BASE_PATH + "itemBookmarkAddSuccess_2.json");
		callDefinitionResponseMap.put("itemBookmarkAddCD", itembookmarkCDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkAddInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals("イーシーエスジー 孫", ((Map) result.get("data")).get("shopName"));
		assertEquals(1080, ((Map) result.get("data")).get("price"));
		assertEquals("_ecsg_qa_0001-itm_20180207 Recommendation Item", ((Map) result.get("data")).get("itemName"));
		assertEquals("https://item.rakuten.co.jp/_ts-sunyang01/qa_itm_20180207_0001/", ((Map) result.get("data")).get("itemUrl"));
		assertEquals(1101, ((Map) result.get("status")).get("code"));
		assertEquals("created", ((Map) result.get("status")).get("message"));
	}

	@Test
	@DisplayName("postProcess: Success without data object in response. case: 3")
	void testPostProcessSuccessWithoutData() {
		//When
		CallDefinitionResponse itembookmarkCDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"itemBookmarkAdd", BASE_PATH + "itemBookmarkAddSuccess_3.json");
		callDefinitionResponseMap.put("itemBookmarkAddCD", itembookmarkCDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkAddInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertEquals(1, result.size());
		assertFalse(result.containsKey("data"));
		assertEquals(1101, ((Map) result.get("status")).get("code"));
		assertEquals("created", ((Map) result.get("status")).get("message"));
	}

	@Test
	@DisplayName("postProcess: error response")
	void testPostProcess_case2() {

		CustomHttpResponse customHttpResponse = new CustomHttpResponse("itemBookmarkAdd", null, null,
				new CustomError("400", "x request parameter is required!"), null);
		MultipleResponses multipleResponses = new MultipleResponses("SUCCESS", Map.of("itemBookmarkAdd", customHttpResponse));

		//When
		CallDefinitionResponse itembookmarkCDResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.valueOf("SUCCESS"));
		itembookmarkCDResponse.setMultipleResponses(multipleResponses);
		itembookmarkCDResponse.setInterfaceToRequestIdMap(Map.of("itemBookmarkAdd", List.of("itemBookmarkAdd")));

		callDefinitionResponseMap.put("itemBookmarkAddCD", itembookmarkCDResponse);

		// Then + Verify
		BackendException exception = assertThrows(BackendException.class, () -> {
			Mono<FeaturePostProcessorResponse> featurePostProcessorResponseMono =
					itemBookmarkAddInfoFeatureProcessor.postProcess(null, null, callDefinitionResponseMap);
			FeaturePostProcessorResponse response = featurePostProcessorResponseMono.block();
		});
		assertEquals(400, exception.getErrorCode().value());
		assertEquals("x request parameter is required!", exception.getMessage());
	}
}
