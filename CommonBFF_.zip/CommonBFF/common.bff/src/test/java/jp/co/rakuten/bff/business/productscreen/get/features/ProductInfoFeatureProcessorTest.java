package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.MockitoAnnotations.initMocks;

class ProductInfoFeatureProcessorTest {

	private ProductInfoFeatureProcessor productInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private static String BASE_PATH = "mockfiles/feature/productscreen/get/";

	@Mock
	private CommonRequestModel validatedClientData;

	@Mock
	private FeatureTemplate featureTemplate;


	@BeforeEach
	void setUp() {
		initMocks(this);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		productInfoFeatureProcessor = new ProductInfoFeatureProcessor();
	}


	@ParameterizedTest
	@DisplayName("If productInfo call definition succeeded then response preparation is successful")
	@CsvSource(value = {
			// sourceFile			| type 	| inventoryType | isAvailableForSale
		"productInfo_success_1.json |  3	|       2	 	|	true",
		"productInfo_success_2.json |  1	|       0	 	|	false",
		"productInfo_success_3.json |  2	|       -1	 	|	true",
		"productInfo_success_4.json |  0	|       1	 	|	false"
	}
	, delimiter = '|')
	void testProductInfoCallDefinitionGGResponseCheck(String sourceFile, Integer type, Integer inventoryType, Boolean isAvailableForSale) {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		String[] interfaces = {ProductScreenConstant.PRODUCT_INFO_INTERFACE_KEY};
		String[] files = {BASE_PATH + sourceFile};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, interfaces, files));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = productInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		Map<String, Object> productFeatureResponseBody = featurePostProcessorResponse.getResponseMap();
		assertTrue(featurePostProcessorResponse.isCacheable());
		assertEquals("201138", productFeatureResponseBody.get("shopId"));
		assertEquals(2127.0, productFeatureResponseBody.get("taxIncludedPrice"));
		assertArrayEquals(Arrays.asList(1000438).toArray(), ((List) productFeatureResponseBody.get("tags")).toArray());
		assertEquals("4987426002183", productFeatureResponseBody.get("itemNumber"));

		List<Map> varaintMapList =  (List<Map>)(productFeatureResponseBody.get("variantSelectors"));
		if(ObjectUtils.isNotEmpty(varaintMapList)) {
			assertTrue(!varaintMapList.isEmpty());
			Map variantData = varaintMapList.get(0);
			assertNotNull(variantData);
			assertEquals("abc", variantData.get("key"));
			assertNotNull(variantData.get("values"));
		}

		assertEquals(type, productFeatureResponseBody.get("type"));
		assertEquals(isAvailableForSale, productFeatureResponseBody.get("isAvailableForSale"));
		assertEquals(inventoryType, productFeatureResponseBody.get("inventoryType"));
	}

	@Test
	@DisplayName("If itemx interface doesn't exist in GG response than ProductInfoFeatureProcessor should throw BackendException")
	void testItemxInterfaceDoesNotExistInGGResponse() {
		//Given
		CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(
				CallDefinitionResponseStatus.SUCCESS);
		callDefinitionResponse.setInterfaceToRequestIdMap(Collections.emptyMap());
		callDefinitionResponse.setMultipleResponses(new MultipleResponses());
		Map<String, CallDefinitionResponse> productInfoResponse = Map.of(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, callDefinitionResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = productInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, productInfoResponse);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, () -> responseMono.block());
	}

}
