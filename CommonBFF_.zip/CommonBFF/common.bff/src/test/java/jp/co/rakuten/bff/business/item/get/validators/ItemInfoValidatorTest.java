package jp.co.rakuten.bff.business.item.get.validators;

import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.ITEM_INFO_FEATURE_KEY;
import static org.junit.jupiter.api.Assertions.*;

class ItemInfoValidatorTest {

	List<FeatureTemplate> featureTemplateList;
	FeatureTemplate itemInfoFeature;
	@BeforeEach
	void setUp() {
		itemInfoFeature = new FeatureTemplate();
		itemInfoFeature.setName(ITEM_INFO_FEATURE_KEY);
		featureTemplateList = List.of(itemInfoFeature);
	}

	@ParameterizedTest
	@DisplayName("Should do not throw FeatureException if input is  proper")
	@CsvSource(value = {
			// itemId	| manageNumber
			" 			| hello ",
			" 10273872	| 		",
			" 0			| jolly ",
			" 2000		| molly	"
	}, delimiter = '|')
	void testOkInput(Integer itemId,String manageNumber) {
		//Given
		CommonRequestModel commonRequestModel =
				prepareCommonRequestModel(itemId, manageNumber);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(ITEM_INFO_FEATURE_KEY, commonRequestModel);
		ClientRequestModel clientRequestModel = new ClientRequestModel();

		//Then+Verify
		assertDoesNotThrow(
				() -> new ItemInfoValidator().validate(validatedRequest, featureTemplateList, clientRequestModel));
	}


	@ParameterizedTest
	@DisplayName("Should should not throw FeatureException if input is not proper")
	@CsvSource(value = {
			// itemId	| manageNumber
			" 0			| 		 ",
			" 			| 		 "
	}, delimiter = '|')
	void testErrorInput(Integer itemId,String manageNumber) {
		//Given
		CommonRequestModel commonRequestModel =
				prepareCommonRequestModel(itemId, manageNumber);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(ITEM_INFO_FEATURE_KEY, commonRequestModel);
		ClientRequestModel clientRequestModel = new ClientRequestModel();

		//Then+Verify
		assertThrows(FeatureException.class,
				() -> new ItemInfoValidator().validate(validatedRequest, featureTemplateList, clientRequestModel));
	}

	private CommonRequestModel prepareCommonRequestModel( Integer itemId, String manageNumber) {
		Map<String, Object> paramMap = new HashMap<>();
		if (Objects.nonNull(itemId)) {
			paramMap.put("itemId", itemId);
		}
		if (Objects.nonNull(manageNumber)) {
			paramMap.put("manageNumber", manageNumber);
		}
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setParams(paramMap);
		return commonRequestModel;
	}
}