package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.ParameterResolveException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.INVENTORYX_INTERFACE_KEY;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY;
import static jp.co.rakuten.bff.core.constant.BffConstants.CALL_DEFINITION_RESPONSE_KEY;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.URL_PARAMETERS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringJUnitConfig
@TestPropertySource(locations = {"classpath:restful.bff.interfaces-test.properties"})
class GspItemKvsInfoInterfaceProcessorTest {

	@Autowired
	Environment environment;

	@Mock
	Environment environment1;

	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private GspItemKvsInfoInterfaceProcessor gspItemInterfaceProcessor;
	private GspItemKvsInfoInterfaceProcessor gspItemInterfaceProcessor1;

	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private Map<String, Map<String, CommonRequestModel>> validatedRequests;
	Map<String, GenericCallDefinitionProcessedData> genericCDProcessedDatas;
	private static final String BASE_PATH = "mockfiles/feature/itemInfo/";


	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionResponseMap = new HashMap<>();
		gspItemInterfaceProcessor = new GspItemKvsInfoInterfaceProcessor(environment);
		gspItemInterfaceProcessor1 = new GspItemKvsInfoInterfaceProcessor(environment1);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		validatedRequests = TestUtil.prepareValidatedRequests(BASE_PATH + "validatedRequests.json");
		genericCDProcessedDatas =
				TestUtil.getGenericCallDefinitionProcessedData(BASE_PATH + "genericPreparedRequest.json");
	}

	@Test
	@DisplayName("When data is not available and required call cannot be made to GG")
	void preProcessAndValidateFail() {
		//Given
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(
				ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY);
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_failure_2.json");
		// Then
		boolean status = gspItemInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap);
		// Verify
		assertFalse(status);
	}

	@Test
	@DisplayName("When data is available and required call can be made to GG")
	void preProcessAndValidateSuccess() {
		//Given
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(
				ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY);
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		// Then
		boolean status = gspItemInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap);
		// Verify
		assertTrue(status);
	}


	@Test
	@DisplayName("Throws ParamResolve Exception when Interface is Missing")
	void preProcessParameterExceptionInterfaceMissing() {
		//Given
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();

		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		// Then

		// Verify
		assertThrows(ParameterResolveException.class,()->gspItemInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap),"gspItemKvsInfo interface missing in GenericCallDefinitionProcessedData - call definition gspInventoryInfo");
	}


	@Test
	@DisplayName("Returns false Exception when SID is Missing")
	void sidExcpetionDonotCall() {
		//Given
		when(environment1.getProperty(anyString(), anyString())).thenReturn(null);

		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(
				ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY);

		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		//Then
		boolean status = gspItemInterfaceProcessor1.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap);
		// Verify
		assertFalse(status);
	}

	@Test
	@DisplayName("Returns false Exception when SID is Missing")
	void columnsMissingCallButNoColumns() {
		//Given
		when(environment1.getProperty(ItemXInfoConstants.CONF_KEY_GSP + "sid", String.class)).thenReturn("jpmall001");
		when(environment1.getProperty(ItemXInfoConstants.CONF_KEY_GSP + "authKey", String.class)).thenReturn("jpmall001");
		when(environment1.getProperty(ItemXInfoConstants.CONF_KEY_GSP + "columns", String.class)).thenReturn("");

		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(
				ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY);

		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		//Then
		boolean status = gspItemInterfaceProcessor1.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap);
		// Verify
		assertTrue(status);
	}

	@Test
	@DisplayName("Throws ParamResolve Exception when Interface URL Params are Missing")
	void preProcessParameterExceptionInterfaceURLMissing() {
		//Given
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get("shopIdManageNumber");
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		String requestId = UUID.randomUUID().toString();
		Map params = new HashMap<>();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put(BffConstants.URL_PARAMETERS, params);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(GSP_INVENTORY_CALL_DEFINITION_KEY, requestId, genericCDProcessedData);
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		// Then

		// Verify
		assertThrows(ParameterResolveException.class,()->gspItemInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap),"urlParameters is missing in GenericCallDefinitionProcessedData " +
				"- interface gspItemKvsInfo - call definition gspInventoryInfo");
	}

	private void mapInterfaceRequestId(String interfaceMap, String requestId,
			GenericCallDefinitionProcessedData genericCallDefinitionProcessedData) {
		Map<String, List<String>> map = new HashMap<>();
		map.put(interfaceMap, Collections.singletonList(requestId));
		map.put(ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY, Collections.singletonList(requestId));
		genericCallDefinitionProcessedData.setInterfaceToRequestIdMap(map);
	}

}