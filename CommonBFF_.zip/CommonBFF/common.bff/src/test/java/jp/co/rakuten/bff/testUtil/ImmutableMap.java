package jp.co.rakuten.bff.testUtil;

import java.util.HashMap;
import java.util.Map;

public class ImmutableMap<K, V> {

	public static <K, V> Map<K, V> of(Object... keysAndValues) {
		Map<K, V> map = new HashMap<>();
		for (int i = 0; i < keysAndValues.length; i = i + 2) {
			map.put((K) keysAndValues[i], (V) keysAndValues[i + 1]);
		}
		return map;
	}

	public static <K, V> Map<K, V> go(K k, V v) {
		Map<K,V> map = new HashMap<>();
		map.put(k, v);
		return map;
	}

	public static Map<String, Object> wrap(Object... keysAndValues) {
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> valueMap = new HashMap<>();
		for(int i = 1; i < keysAndValues.length; i++) {
			valueMap.putAll((Map<String, Object>)keysAndValues[i]);
		}
		map.put(keysAndValues[0].toString(), valueMap);
		return map;
	}

	public static <K, V> Map<K, V> emptyMap() {
		return new HashMap<K, V>();
	}
}