package jp.co.rakuten.bff.business.browsinghistory.add.processors.features;

import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.MockitoAnnotations.initMocks;

public class BrowsingHistoryAddInfoFeatureProcessorTest {
	private BrowsingHistoryAddInfoFeatureProcessor browsingHistoryAddInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;

	@Mock
	private CommonRequestModel validatedClientData;

	@Mock
	private FeatureTemplate featureTemplate;


	@BeforeEach
	void setUp() {
		initMocks(this);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();

		browsingHistoryAddInfoFeatureProcessor = new BrowsingHistoryAddInfoFeatureProcessor();
	}

	@Test
	@DisplayName("BrowsingHistoryAddInfoFeatureProcessor::postProcess-> Success when browsing history interface succeed")
	void testBrowsingHistoryAddInfoFeatureProcessorPostProcessSuccess() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess("browsingHistoryAddCD",
						"browsingHistoryAdd",
						"mockfiles/feature/browsinghistory.add/browsingHistortAddSuccess_1.json"));
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = browsingHistoryAddInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		assertNotNull(featurePostProcessorResponse);
		assertEquals(0, featurePostProcessorResponse.getResponseMap().size());
	}

	@Test
	@DisplayName("BrowsingHistoryAddInfoFeatureProcessor::postProcess-> Failed when browsing history interface failed")
	void testBrowsingHistoryAddInfoFeatureProcessorPostProcessFailed() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = browsingHistoryAddInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, responseMono::block);
	}
}
