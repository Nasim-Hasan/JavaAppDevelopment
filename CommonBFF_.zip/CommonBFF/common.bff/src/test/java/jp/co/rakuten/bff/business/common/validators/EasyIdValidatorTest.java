package jp.co.rakuten.bff.business.common.validators;

import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.util.MapUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Map;

public class EasyIdValidatorTest {

	@InjectMocks
	private EasyIdValidator easyIdValidator;

	@Mock
	private CommonRequestModel validatedClientData;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		validatedClientData = new CommonRequestModel();
	}

	@AfterEach
	void tearDown() {
		easyIdValidator = null;
	}

	@ParameterizedTest
	@DisplayName("Valid EasyId check")
	@CsvSource(value = {
			//urlParams										| 		message
			"{\"X-ClientId\": \"ichiba_android_long\",\"easyId\": 123}	| SUCCESS",
			"{\"X-ClientId\": \"ichiba_android_long\",\"easyId\": 0} 	| User is not logged-in or " +
					"request can't be performed for this user",
			"{\"X-ClientId\": \"ichiba_android_long\",\"easyId\": -9} 	| User is not logged-in or " +
					"request can't be performed for this user",
			"{\"X-ClientId\": \"ichiba_android_long\",\"easyId\": 1}	| SUCCESS",
	}, delimiter = '|')
	void testEasyIdValidation(String headerParams, String message) throws Throwable {
		//setUp
		Map<String, Object> headers = MapUtil.getObjectMapper().readValue(headerParams, Map.class);

		validatedClientData.setHeaders(headers);

		//then
		TestUtil.assertThrowOrNot(
				() -> easyIdValidator
						.validate(validatedClientData), message);
	}

}
