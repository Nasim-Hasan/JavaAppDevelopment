package jp.co.rakuten.bff.business.browsinghistory.list.processors.features;

import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class BrowsingHistoryListInfoFeatureProcessorTest {
	private BrowsingHistoryListInfoFeatureProcessor browsingHistoryListInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private static final String BASE_PATH = "mockfiles/feature/browsingHistoryList/";

	@BeforeEach
	void setUp() {
		browsingHistoryListInfoFeatureProcessor = new BrowsingHistoryListInfoFeatureProcessor();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
	}

	@Test
	@DisplayName("postProcess: Success for proper response")
	void testPostProcess() {
		//When
		CallDefinitionResponse browsingHistoryListCDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"browsingHistoryList", BASE_PATH + "browsingHistoryListSuccess.json");

		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.put("browsingHistoryListCD", browsingHistoryListCDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = browsingHistoryListInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertEquals(0, result.get("code"));
		assertEquals(20, result.get("num"));
		List items = (List) result.get("items");
		assertEquals("10003972", ((Map) items.get(0)).get("mngNumber"));
		assertEquals(1, ((Map) items.get(0)).get("image128Flag"));
		assertEquals("https://item.rakuten.co.jp/_ppyoshida/10003972", ((Map) items.get(0)).get("itemUrlFull"));
		Map tags = (Map) ((Map) items.get(0)).get("tags");
		assertEquals("test", tags.get("unusedNaviTags"));
		assertEquals("", tags.get("commonTags"));
		assertEquals("1008217", tags.get("uniqueTags"));
	}

	@Test
	@DisplayName("If browsingHistoryListCD call definition failed than BrowsingHistoryListInfoFeatureProcessor should throw BackendException")
	void testCallDefinitionFailure() {
		//Given
		CommonRequestModel requestModel = new CommonRequestModel();

		Map<String, CallDefinitionResponse> responseFailed =
				callDefinitionResponseUtil.getUpstreamResponseFailed(
						"browsingHistoryListCD");

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = browsingHistoryListInfoFeatureProcessor.postProcess(
				requestModel, null, responseFailed);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, responseMono::block);
	}
}
