package jp.co.rakuten.bff.business.itembookmark.delete.processors.features;

import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.http.CustomError;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ItemBookmarkDeleteInfoFeatureProcessorTest {

	private ItemBookmarkDeleteInfoFeatureProcessor itemBookmarkDeleteInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private static final String BASE_PATH = "mockfiles/feature/itemBookmarkDelete/";

	@BeforeEach
	void setUp() {
		itemBookmarkDeleteInfoFeatureProcessor = new ItemBookmarkDeleteInfoFeatureProcessor();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
	}

	@Test
	@DisplayName("postProcess: Success for proper response")
	void testPostProcess() {
		//When
		CallDefinitionResponse itembookmarkDeleteCDDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"itemBookmarkDelete", BASE_PATH + "itemBookmarkDeleteSuccess.json");

		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.put("itemBookmarkDeleteCD", itembookmarkDeleteCDDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkDeleteInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals(8836, ((List) ((Map) result.get("data")).get("deletedItemIds")).get(0));
		assertEquals(1302, ((Map) result.get("status")).get("code"));
		assertEquals("deleted", ((Map) result.get("status")).get("message"));
	}

	@Test
	@DisplayName("postProcess: when no delete action is performed")
	void testPostProcess_case2() {
		//When
		CallDefinitionResponse itembookmarkDeleteCDDResponse = callDefinitionResponseUtil.getCallDefinitionResponseSuccess(
				"itemBookmarkDelete", BASE_PATH + "itemBookmarkDeleteFailed.json");

		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.put("itemBookmarkDeleteCD", itembookmarkDeleteCDDResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkDeleteInfoFeatureProcessor.postProcess(
				null, null, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse response = responseMono.block();
		assertNotNull(response);
		Map result = response.getResponseMap();
		assertNotNull(result);
		assertNull(result.get("data"));
		assertEquals(1303, ((Map) result.get("status")).get("code"));
		assertEquals("No delete performed", ((Map) result.get("status")).get("message"));
	}

	@Test
	@DisplayName("postProcess: when required param is missing for backend")
	void testPostProcess_case3() {

		CustomHttpResponse customHttpResponse = new CustomHttpResponse("itemBookmarkDelete", null, null,
				new CustomError("400", "The field 'x' is required in the map 'bodyParameters'. Expected format: integer"), null);
		MultipleResponses multipleResponses = new MultipleResponses("SUCCESS", Map.of("itemBookmarkDelete", customHttpResponse));

		//When
		CallDefinitionResponse itembookmarkCDResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.valueOf("SUCCESS"));
		itembookmarkCDResponse.setMultipleResponses(multipleResponses);
		itembookmarkCDResponse.setInterfaceToRequestIdMap(Map.of("itemBookmarkDelete", List.of("itemBookmarkDelete")));


		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.put("itemBookmarkDeleteCD", itembookmarkCDResponse);

		// Then + Verify
		BackendException exception = assertThrows(BackendException.class, () -> {
			Mono<FeaturePostProcessorResponse> featurePostProcessorResponseMono =
					itemBookmarkDeleteInfoFeatureProcessor.postProcess(null, null, callDefinitionResponseMap);
			FeaturePostProcessorResponse response = featurePostProcessorResponseMono.block();
		});
		assertEquals(400, exception.getErrorCode().value());
		assertEquals("The field 'x' is required in the map 'bodyParameters'. Expected format: integer", exception.getMessage());
	}
}
