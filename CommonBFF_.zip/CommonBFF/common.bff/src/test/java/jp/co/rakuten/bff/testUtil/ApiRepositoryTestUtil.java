package jp.co.rakuten.bff.testUtil;

import jp.co.rakuten.bff.core.config.ApiConfigurationProperties;
import jp.co.rakuten.bff.core.config.json.ExternalJsonLoader;
import jp.co.rakuten.bff.core.config.json.LocalJsonLoader;
import jp.co.rakuten.bff.core.config.json.RepositoryJsonLoader;
import jp.co.rakuten.bff.core.resolver.JsonSchemaValidator;
import jp.co.rakuten.bff.core.service.impl.ApiRepositoryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import static jp.co.rakuten.bff.core.constant.BffConstants.JSON_EXTENSION;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_API_CONFIG_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_API_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_CLOUD_CONFIG_ENABLED;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_INTERFACE_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_REPO_LOADING_TIMEOUT;
import static jp.co.rakuten.bff.core.constant.BffConstants.UNION_DOT;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ApiRepositoryTestUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApiRepositoryTestUtil.class);
	private static Map<String, ConcurrentHashMap<String, String>> apiMappings = new ConcurrentHashMap<>();

	private static LocalJsonLoader localJsonLoader;
	private static ExternalJsonLoader externalJsonLoader;
	private static Map<String, RepositoryJsonLoader> repoJsonLoaders = new ConcurrentHashMap<>();
	private static Map<String, Environment> mockEnvs = new ConcurrentHashMap<>();
	public static final String DEFAULT_REPO_DIR = "reloadable.config/test_repository/";

	public static ApiRepositoryImpl getRepository() {
		return getRepository(DEFAULT_REPO_DIR);
	}

	public static ApiRepositoryImpl getRepository(String repoDir) {
		return getRepository(getMockEnv(repoDir), new JsonSchemaValidator(), repoDir);
	}

	public static ApiRepositoryImpl getRepository(Environment environment, JsonSchemaValidator schemaValidator,
												  String repoDir) {
		ApplicationContext context = mock(ApplicationContext.class);
		return getRepository(environment, context, schemaValidator, repoDir);
	}

	public static ApiRepositoryImpl getRepository(String repoDir, ApplicationContext context,
												  JsonSchemaValidator schemaValidator) {
		return getRepository(getMockEnv(repoDir), context, schemaValidator, repoDir);
	}

	public static ApiRepositoryImpl getRepository(Environment environment, ApplicationContext context,
												  JsonSchemaValidator schemaValidator, String repoDir) {
		ApiConfigurationProperties apiConfigProperties = getMockApiConfigurationProperties(repoDir);
		ApiRepositoryImpl newRepository = new ApiRepositoryImpl(environment, context, schemaValidator,
				apiConfigProperties, getRepoJsonLoader(repoDir));
		try {
			newRepository.load();
			LOGGER.info("Loaded test repository for repoDir: " + repoDir);
		} catch (Exception e) {
			LOGGER.error("Could not load test Repository", e);
		}
		return newRepository;
	}

	public static RepositoryJsonLoader getRepoJsonLoader(String repoDir) {
		return repoJsonLoaders.computeIfAbsent(repoDir, k -> {
			RepositoryJsonLoader repoJsonLoader = new RepositoryJsonLoader(
					getMockEnv(repoDir), getExternalJsonLoader(), getLocalJsonLoader());
			return repoJsonLoader;
		});
	}

	public static LocalJsonLoader getLocalJsonLoader() {
		if (localJsonLoader == null) {
			localJsonLoader = new LocalJsonLoader();
		}
		return localJsonLoader;
	}

	public static ExternalJsonLoader getExternalJsonLoader() {
		if (externalJsonLoader == null) {
			ExternalJsonLoader mockExternalLoader = mock(ExternalJsonLoader.class);
			when(mockExternalLoader.load(any(), any()))
					.thenAnswer(i -> localJsonLoader.load(
							i.getArgument(0, String.class),
							i.getArgument(1, Class.class))
					);
			externalJsonLoader = mockExternalLoader;
		}
		return externalJsonLoader;
	}

	public static Environment getMockEnv() {
		return getMockEnv(DEFAULT_REPO_DIR);
	}

	public static Environment getMockEnv(String repoDir) {
		return mockEnvs.computeIfAbsent(repoDir, k -> {
			Environment environment = mock(Environment.class);
			doReturn(repoDir + "api/").when(environment).getProperty(PROP_KEY_API_REPO_PATH);
			doReturn(repoDir + "apiConfig/").when(environment).getProperty(PROP_KEY_API_CONFIG_REPO_PATH);
			doReturn(repoDir + "interface/").when(environment).getProperty(PROP_KEY_INTERFACE_REPO_PATH);
			doReturn("false").when(environment).getProperty(PROP_KEY_CLOUD_CONFIG_ENABLED);
			doReturn("1000").when(environment).getProperty(PROP_KEY_REPO_LOADING_TIMEOUT);
			return environment;
		});
	}

	public static ApiConfigurationProperties getMockApiConfigurationProperties(String repoDir) {
		ApiConfigurationProperties apiConfigProperties = mock(ApiConfigurationProperties.class);
		ConcurrentHashMap<String, String> apiMapping = getApiMapping(repoDir);
		doReturn(apiMapping).when(apiConfigProperties).getMapping();
		return apiConfigProperties;
	}

	public static ConcurrentHashMap<String, String> getApiMapping(String repoDir) {
		return apiMappings.computeIfAbsent(repoDir, k -> {
			try {
				ConcurrentHashMap<String, String> apiMapping = new ConcurrentHashMap<>();
				ClassLoader loader = ApiRepositoryTestUtil.class.getClassLoader();
				ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(loader);
				Resource[] resources = resolver.getResources("classpath:" + repoDir + "apiConfig/*/*.json");
				int totalResources = resources.length;
				CompletableFuture[] mappingFutureArray = new CompletableFuture[totalResources];
				for (int i = 0; i < totalResources; i++) {
					Resource apiConfigResource = resources[i];
					CompletableFuture<Void> mappingFuture = CompletableFuture.runAsync(() -> {
						try {
							String[] resourcePathArray = apiConfigResource.getURL().getPath().split("/");
							String operationName = resourcePathArray[resourcePathArray.length - 1];
							String serviceName = resourcePathArray[resourcePathArray.length - 2];
							String operationWithVersion = operationName.replace(JSON_EXTENSION, "");
							String apiKey = serviceName + UNION_DOT + operationWithVersion;
							apiMapping.put(apiKey, "");
						} catch (IOException e) {
							throw new UncheckedIOException(e);
						}
					});
					mappingFutureArray[i] = mappingFuture;
				}
				CompletableFuture.allOf(mappingFutureArray).join();
				return apiMapping;
			} catch (IOException e) {
				throw new UncheckedIOException(e);
			}
		});
	}
}
