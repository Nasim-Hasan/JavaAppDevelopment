package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.MockitoAnnotations.initMocks;

class ReviewInfoFeatureProcessorTest {

    private ReviewInfoFeatureProcessor reviewInfoFeatureProcessor;
    private CallDefinitionResponseUtil callDefinitionResponseUtil;
    private static String BASE_PATH = "mockfiles/feature/productscreen/get/";
    private static final String EVALUATION = "evaluation", FREQUENCY_CODE = "frequencyCode",
            USE_CODE = "useCode", REG_TIME = "regTime", OBJECT_CODE = "objectCode",
            REVIEW = "review", SEX = "sex", AGE = "age", REVIEW_THEME = "reviewTheme";
    @Mock
    private CommonRequestModel validatedClientData;

    @Mock
    private FeatureTemplate featureTemplate;


    @BeforeEach
    void setUp() {
        initMocks(this);
        callDefinitionResponseUtil = new CallDefinitionResponseUtil();
        reviewInfoFeatureProcessor = new ReviewInfoFeatureProcessor();
    }


    @Test
    @DisplayName("If navigationReview call definition succeeded then response preparation is successful for gspItemReveiw interface")
    void testNavigationInfoCallDefinitionGGResponseCheck() {
        //Given
        Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
        String[] interfaces = {ProductScreenConstant.GSP_ITEM_REVIEW_INTERFACE_KEY};
        String[] files = {BASE_PATH + "gspItemReivew_success.json"};

        callDefinitionResponseMap.putAll(callDefinitionResponseUtil
                .getUpstreamResponseSuccess(ProductScreenConstant.NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY, interfaces, files));

        GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
        //Then
        Mono<FeaturePostProcessorResponse> responseMono = reviewInfoFeatureProcessor.postProcess(
                validatedClientData, featureTemplate, callDefinitionResponseMap);

        //Verify
        assertNotNull(responseMono);
        FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
        Map<String, Object> reviewFeatureResponseBody = featurePostProcessorResponse.getResponseMap();
        List<Map<String, Object>> docs = (List) reviewFeatureResponseBody.get("docs");
        List<Map<String, Object>> docCheckList = getDocCheckList();
        for (int i = 0; i < 3; i++) {
            Map<String, Object> docMap = docs.get(i);
            Map<String, Object> docCheckMap = docCheckList.get(i);
            assertEquals(docMap.get(EVALUATION), docCheckMap.get(EVALUATION));
            assertEquals(docMap.get(FREQUENCY_CODE),docCheckMap.get(FREQUENCY_CODE));
            assertEquals(docMap.get(USE_CODE),docCheckMap.get(USE_CODE));
            assertEquals(docMap.get(REG_TIME),docCheckMap.get(REG_TIME));
            assertEquals(docMap.get(OBJECT_CODE),docCheckMap.get(OBJECT_CODE));
            assertEquals(docMap.get(REVIEW),docCheckMap.get(REVIEW));
            assertEquals(docMap.get(SEX),docCheckMap.get(SEX));
            assertEquals(docMap.get(AGE),docCheckMap.get(AGE));
        }

    }

    private List<Map<String, Object>> getDocCheckList() {
        List docs = new ArrayList();

        Map<String, Object> doc = new HashMap<>();
        doc.put(EVALUATION, 4.0);
        doc.put(FREQUENCY_CODE, 1201);
        doc.put(USE_CODE, 1002);
        doc.put(REG_TIME, "2020-06-28T15:55:42.000+09:00");
        doc.put(OBJECT_CODE, 1103);
        doc.put(REVIEW, "氏名・メールアドレスなどの個人情報は記載しないでくださいsp");
        doc.put(SEX, 0);
        doc.put(AGE, 33);
        doc.put(REVIEW_THEME, "ttsp");
        docs.add(doc);

        doc = new HashMap<>();
        doc.put(EVALUATION, 5.0);
        doc.put(FREQUENCY_CODE, 0);
        doc.put(USE_CODE, 0);
        doc.put(REG_TIME, "2020-06-23T13:30:11.000+09:00");
        doc.put(OBJECT_CODE, 0);
        doc.put(REVIEW, "Don't delete.\nけさないで〜");
        doc.put(SEX, 0);
        doc.put(AGE, 9);
        doc.put(REVIEW_THEME, null);
        docs.add(doc);

        doc = new HashMap<>();
        doc.put(EVALUATION, 4.0);
        doc.put(FREQUENCY_CODE, 1201);
        doc.put(USE_CODE, 1003);
        doc.put(REG_TIME, "2018-07-12T14:30:18.000+09:00");
        doc.put(OBJECT_CODE, 1102);
        doc.put(REVIEW, "test test test test test test test test test test test");
        doc.put(SEX, 0);
        doc.put(AGE, 114);
        doc.put(REVIEW_THEME, "test");
        docs.add(doc);

        return docs;
    }

    @Test
    @DisplayName("If gspItemReview interface doesn't exist in GG response than ReviewInfoFeatureProcessor should throw BackendException")
    void testItemxInterfaceDoesNotExistInGGResponse() {
        //Given
        CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(CallDefinitionResponseStatus.SUCCESS);
        callDefinitionResponse.setInterfaceToRequestIdMap(Collections.emptyMap());
        callDefinitionResponse.setMultipleResponses(new MultipleResponses());
        Map<String, CallDefinitionResponse> reviewInfoResponse = Map.of(ProductScreenConstant.NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY, callDefinitionResponse);

        //Then
        Mono<FeaturePostProcessorResponse> responseMono = reviewInfoFeatureProcessor.postProcess(
                validatedClientData, featureTemplate, reviewInfoResponse);

        //Verify
        assertNotNull(responseMono);
        assertThrows(BackendException.class, () -> responseMono.block());
    }
}
