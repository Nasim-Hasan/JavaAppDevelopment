package jp.co.rakuten.bff.business.browsinghistory.list.processors.interfaces;

import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.core.constant.BffConstants.URL_PARAMETERS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringJUnitConfig
public class BrowsingHistoryListInterfaceProcessorTest {

	private static final String GENRE_ID = "genreId";
	private static final String BROWSING_HISTORY_LIST_INTERFACE = "browsingHistoryList";

	@InjectMocks
	private BrowsingHistoryListInterfaceProcessor browsingHistoryListInterfaceProcessor;

	@Mock
	private GenericCallDefinitionProcessedData genericCDProcessedData;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		when(genericCDProcessedData.getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)).thenReturn(new HashMap<>(Map.of(
				"interfaceKey", BROWSING_HISTORY_LIST_INTERFACE,
				"requestId", UUID.randomUUID())));
	}

	@AfterEach
	void tearDown() {
		browsingHistoryListInterfaceProcessor = null;
	}

	@ParameterizedTest
	@DisplayName("genereId IntegerTolist check")
	@CsvSource(value = {
			//				urlParams													| flag	| genreIdVal
			"{\"sid\": 58,\"genreId\": 101025 ,\"historyType\": 1,\"actionType\": 6}	| true	| 101025",
			"{\"sid\": 58,\"genreId\": \"101025\",\"historyType\": 1,\"actionType\": 6}	| false	|",
			"{\"sid\": 58,\"genreId\": 0 ,\"historyType\": 1,\"actionType\": 6}			| true	|0",
			"{\"sid\": 58,\"historyType\": 1,\"actionType\": 6}							| false	|",
	}, delimiter = '|')
	void testBrowsingHistoryListPreProcess(String urlParams, Boolean flag, Integer genreIdVal) throws Throwable {
		//setUp

		Map<String, Object> params = MapUtil.getObjectMapper().readValue(urlParams, Map.class);
		(genericCDProcessedData.
				getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)).put(URL_PARAMETERS, params);
		//then
		assertTrue(browsingHistoryListInterfaceProcessor.
				preProcess(null, genericCDProcessedData, null));

		assertEquals(flag, ((Map) genericCDProcessedData
				.getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)
				.get(URL_PARAMETERS))
				.containsKey(GENRE_ID));

		if (((Map) genericCDProcessedData
				.getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)
				.get(URL_PARAMETERS)).containsKey(GENRE_ID)) {

			assertEquals(1, ((List) ((Map) genericCDProcessedData
					.getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)
					.get(URL_PARAMETERS))
					.get(GENRE_ID)).size());

			assertEquals(genreIdVal, ((List) ((Map) genericCDProcessedData
					.getRequestByInterface(BROWSING_HISTORY_LIST_INTERFACE)
					.get(URL_PARAMETERS))
					.get(GENRE_ID)).get(0));
		}
	}
}
