package jp.co.rakuten.bff.business.itembookmark.list.processors.interfaces;

import jp.co.rakuten.bff.core.constant.GenericEndpointConstants;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;
import static org.junit.jupiter.api.Assertions.*;

class ItemBookmarkGetInterfaceProcessorTest {
	Map<String, CommonRequestModel> validatedRequest;
	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private GenericCallDefinitionProcessedData genericCallDefinitionProcessedData;

	String requestId;

	private ItemBookmarkGetInterfaceProcessor itemBookmarkGetInterfaceProcessor;


	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionResponseMap = new HashMap<>();
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		validatedRequest = Map.of(ITEM_BOOKMARK_LIST_INFO, commonRequestModel);
		requestId = UUID.randomUUID().toString();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		genericCallDefinitionProcessedData = new GenericCallDefinitionProcessedData();
		itemBookmarkGetInterfaceProcessor = new ItemBookmarkGetInterfaceProcessor();
	}

	@AfterEach
	void tearDown() {
		itemBookmarkGetInterfaceProcessor = null;
	}

	@DisplayName("preProcess-> success with shopId")
	@Test
	void preProcessSuccessWithShopId() {
		//Given:

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_ITEM_BOOKMARK_GET);
		innerMap.put("requestId", requestId);
		Map<String, Object> urlParams = new HashMap<>();
		urlParams.put(SHOP_ID, 10);
		innerMap.put("urlParameters", urlParams);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_ITEM_BOOKMARK_GET, requestId, genericCDProcessedData);

		//When:
		boolean result = itemBookmarkGetInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertTrue(result);
		urlParams = (Map<String, Object>) genericCDProcessedData.getRequestByInterface(
				INTERFACE_NAME_ITEM_BOOKMARK_GET).get(GenericEndpointConstants.URL_PARAMETERS);
		assertNotNull(urlParams.get("shopId"));
	}

	@DisplayName("preProcess-> success but removes shopId")
	@Test
	void preProcessSuccessWithoutShopId() {
		//Given:

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_ITEM_BOOKMARK_GET);
		innerMap.put("requestId", requestId);
		Map<String, Object> urlParams = new HashMap<>();
		urlParams.put(SHOP_ID, 0);
		innerMap.put("urlParameters", urlParams);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_ITEM_BOOKMARK_GET, requestId, genericCDProcessedData);

		//When:
		boolean result = itemBookmarkGetInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertTrue(result);
		urlParams = (Map<String, Object>) genericCDProcessedData.getRequestByInterface(
				INTERFACE_NAME_ITEM_BOOKMARK_GET).get(GenericEndpointConstants.URL_PARAMETERS);
		assertNull(urlParams.get("shopId"));
	}

	@DisplayName("preProcess-> fails when feature is not required")
	@Test
	void preProcessFailsWhenItemBookMarkIsNotRequired() {
		//Given:

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_ITEM_BOOKMARK_GET);
		innerMap.put("requestId", requestId);
		Map<String, Object> urlParams = new HashMap<>();
		urlParams.put(SHOP_ID, 0);
		innerMap.put("urlParameters", urlParams);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_ITEM_BOOKMARK_GET, requestId, genericCDProcessedData);

		//When:
		boolean result = itemBookmarkGetInterfaceProcessor.
				preProcess(new HashMap<>(), genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertFalse(result);
	}


	@DisplayName("postProcess: Success when itembookmarkGet interface succeed")
	@Test
	void postProcessSuccessCase() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_Success_1.json"));


		//When:
		itemBookmarkGetInterfaceProcessor.postProcess(validatedRequest,
												   callDefinitionResponseMap.get(CALL_DEF_ITEM_BOOKMARK_GET_CD),
													 genericCallDefinitionProcessedData,
													 callDefinitionResponseMap);

		//Then:
		Map<String, Object> result =
				InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
																   INTERFACE_NAME_ITEM_BOOKMARK_GET,
																   CALL_DEF_ITEM_BOOKMARK_GET_CD);
		Map<String, Object> meta = (Map<String, Object>) result.get(META);
		List<Map<String, Object>> data = (List<Map<String, Object>>) result.get(DATA);
		Map<String, Object> lastItem = data.get(5);
		Map<String, Object> ncpPoints = (Map<String, Object>) lastItem.get("ncpPoints");
		assertNotNull(result);
		assertNotNull(meta);
		assertNotNull(meta.get("hits"));
		assertNotNull(meta.get("ss"));
		assertNotNull(meta.get("offset"));
		assertNotNull(meta.get("ssEndTime"));
		assertNotNull(meta.get("ssStartTime"));
		assertNotNull(data);
		assertEquals(7, data.size());
		assertNotNull(lastItem);
		assertNotNull(ncpPoints);
		assertEquals(4, ncpPoints.size());
		assertNotNull(ncpPoints.get("itemPointRate"));
		assertNotNull(ncpPoints.get("itemPointValue"));
		assertNotNull(ncpPoints.get("itemPointBackRate"));
		assertNotNull(ncpPoints.get("itemPointExtraRate"));
		assertNotNull(lastItem.get("itemType"));
		assertNotNull(lastItem.get("shopId"));
		assertNotNull(lastItem.get("id"));
		assertNotNull(lastItem.get("itemId"));
	}

	private void mapInterfaceRequestId(String interfaceMap, String requestId,
									   GenericCallDefinitionProcessedData genericCallDefinitionProcessedData) {
		Map<String, List<String>> map = new HashMap<>();
		map.put(interfaceMap, Collections.singletonList(requestId));
		genericCallDefinitionProcessedData.setInterfaceToRequestIdMap(map);
	}
}
