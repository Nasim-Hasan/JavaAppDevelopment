package jp.co.rakuten.bff.business.itembookmark.list.processors.features;


import jp.co.rakuten.bff.business.itembookmark.list.logic.CouponResponseLogic;
import jp.co.rakuten.bff.business.itembookmark.list.logic.ItemBookMarkListInfoLogic;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ItemBookmarkListInfoFeatureProcessorTest {

	private ItemBookmarkListInfoFeatureProcessor itemBookmarkListInfoFeatureProcessor;
	private ItemBookMarkListInfoLogic itemBookMarkListInfoLogic;
	private CouponResponseLogic couponResponseLogic;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;

	@Mock
	private CommonRequestModel validatedClientData;

	@Mock
	private FeatureTemplate featureTemplate;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		Environment environment = getMockEnvironment();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		couponResponseLogic = new CouponResponseLogic(environment);
		itemBookMarkListInfoLogic = new ItemBookMarkListInfoLogic(couponResponseLogic);
		itemBookmarkListInfoFeatureProcessor = new ItemBookmarkListInfoFeatureProcessor(itemBookMarkListInfoLogic);
	}

	@Test
	@DisplayName("ItemBookmarkListInfoFeatureProcessor: postProcess-> Success With coupons")
	void testPostProcessSuccessWithCoupons() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_1.json"));
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/feature/itembookmarkInfo/itembookmarkGet_Success_1.json"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkListInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		Map<String, Object> responseMap = featurePostProcessorResponse.getResponseMap();
		Map<String, Object> meta = (Map<String, Object>) responseMap.get("meta");
		List<Map<String, Object>> bookmarkList = (List<Map<String, Object>>) responseMap.get("bookmarkList");
		Map<String, Object> firstItem = bookmarkList.get(0);
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) firstItem.get(COUPONS);
		assertNotNull(coupons);
		assertFalse(coupons.isEmpty());
		coupons.forEach(this::checkCoupon);
		assertNotNull(bookmarkList);
		assertFalse(bookmarkList.isEmpty());
		assertNotNull(responseMap);
		checkMetaData(meta);
		assertNotNull(featurePostProcessorResponse);
		bookmarkList.forEach(this::checkItemBookMark);
	}

	@Test
	@DisplayName("ItemBookmarkListInfoFeatureProcessor: postProcess-> Success Without coupons when couponByItem call definition fails")
	void testPostProcessSuccessWithoutCouponsWhenCallDefinitionFails() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_1.json"));
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/feature/itembookmarkInfo/itembookmarkGet_Success_1.json"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		CallDefinitionResponse callDefinitionResponse = callDefinitionResponseMap.get(CALL_DEF_COUPONS_BY_ITEM_CD);
		callDefinitionResponse.setStatus(CallDefinitionResponseStatus.FAILURE);
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkListInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		Map<String, Object> responseMap = featurePostProcessorResponse.getResponseMap();
		Map<String, Object> meta = (Map<String, Object>) responseMap.get("meta");
		List<Map<String, Object>> bookmarkList = (List<Map<String, Object>>) responseMap.get("bookmarkList");
		assertNotNull(bookmarkList);
		assertFalse(bookmarkList.isEmpty());
		assertNotNull(responseMap);
		checkMetaData(meta);
		assertNotNull(featurePostProcessorResponse);
		bookmarkList.forEach(bookmark-> {
			assertNull(bookmark.get(COUPONS));
			checkItemBookMark(bookmark);
		});
		assertTrue((boolean)bookmarkList.get(0).get("39shopFlag"));
		assertFalse((boolean)bookmarkList.get(1).get("39shopFlag"));
	}

	@Test
	@DisplayName("ItemBookmarkListInfoFeatureProcessor: postProcess-> Success Without coupons when couponByItem call definition null")
	void testPostProcessSuccessWithoutCouponsWhenCouponByItemNull() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/feature/itembookmarkInfo/itembookmarkGet_Success_1.json"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkListInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		Map<String, Object> responseMap = featurePostProcessorResponse.getResponseMap();
		Map<String, Object> meta = (Map<String, Object>) responseMap.get("meta");
		List<Map<String, Object>> bookmarkList = (List<Map<String, Object>>) responseMap.get("bookmarkList");
		assertNotNull(bookmarkList);
		assertFalse(bookmarkList.isEmpty());
		assertNotNull(responseMap);
		checkMetaData(meta);
		assertNotNull(featurePostProcessorResponse);
		bookmarkList.forEach(bookmark-> {
			assertNull(bookmark.get(COUPONS));
			checkItemBookMark(bookmark);
		});

		assertTrue((boolean)bookmarkList.get(0).get("39shopFlag"));
		assertFalse((boolean)bookmarkList.get(1).get("39shopFlag"));
	}

	@Test
	@DisplayName("ItemBookmarkListInfoFeatureProcessor: postProcess-> Fails when itembookmarkGet interface fails")
	void testPostProcessFailWhenItemBookMarkGetFails() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();

		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_InvalidCase_1.json"));
		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemBookmarkListInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		BackendException ex = assertThrows(BackendException.class, () -> {
			itemBookmarkListInfoFeatureProcessor.postProcess(
					validatedClientData, featureTemplate, callDefinitionResponseMap).block();
		});
		assertEquals("Invalid api response", ex.getMessage());
	}


	private void checkMetaData(Map<String, Object> meta) {
		assertNotNull(meta);
		assertNotNull(meta.get("offset"));
		assertNotNull(meta.get("hits"));
		assertNotNull(meta.get("ss"));
		assertNotNull(meta.get("ssStartTime"));
		assertNotNull(meta.get("ssEndTime"));
	}

	private void checkCoupon(Map<String, Object> coupon) {
		assertNotNull(coupon);
		assertFalse(coupon.isEmpty());
		assertNotNull(coupon.get("couponName"));
		assertNotNull(coupon.get("discountTitle"));
		assertNotNull(coupon.get("termsOfUse"));
		assertNotNull(coupon.get("couponEndDate"));
		assertNotNull(coupon.get("couponId"));
		assertNotNull(coupon.get("couponServiceId"));
		assertNotNull(coupon.get("couponCode"));
		assertNotNull(coupon.get("couponStartDate"));
		assertNotNull(coupon.get("acquired"));
	}

	private void checkItemBookMark(Map<String, Object> itemBookMark) {
		Map<String, Object> ncpPoints = (Map<String, Object>) itemBookMark.get("ncpPoints");
		assertFalse(itemBookMark.isEmpty());
		assertNotNull(itemBookMark.get("id"));
		assertNotNull(itemBookMark.get("itemId"));
		assertNotNull(itemBookMark.get("itemName"));
		assertNotNull(itemBookMark.get("itemUrl"));
		assertNotNull(itemBookMark.get("itemType"));
		assertNotNull(itemBookMark.get("shopId"));
		assertNotNull(itemBookMark.get("shopName"));
		assertNotNull(itemBookMark.get("shopUrl"));
		assertNotNull(itemBookMark.get("39shopFlag"));
		assertNotNull(itemBookMark.get("restockNotifyFlag"));
		assertNotNull(itemBookMark.get("originalPrice"));
		assertNotNull(itemBookMark.get("latestPrice"));
		assertNotNull(itemBookMark.get("freeShippingFlag"));
		assertNotNull(itemBookMark.get("taxIncludedFlag"));
		assertNotNull(itemBookMark.get("reviewCount"));
		assertNotNull(itemBookMark.get("reviewUrl"));
		assertNotNull(itemBookMark.get("reviewAvg"));
		assertNotNull(itemBookMark.get("registerTime"));
		assertNotNull(itemBookMark.get("updateTime"));
		assertNotNull(itemBookMark.get("imageUrl"));
		assertNotNull(itemBookMark.get("inventoryFlag"));
		assertNotNull(itemBookMark.get("inventoryId"));
		assertNotNull(itemBookMark.get("inventoryNameVer"));
		assertNotNull(itemBookMark.get("inventoryNameHor"));
		assertNotNull(itemBookMark.get("inventoryAxisVer"));
		assertNotNull(itemBookMark.get("inventoryAxisHor"));
		assertNotNull(itemBookMark.get("itemPointStartTime"));
		assertNotNull(itemBookMark.get("itemPointEndTime"));
		assertNotNull(itemBookMark.get("itemMemo"));
		assertNotNull(itemBookMark.get("cartUrl"));
		assertNotNull(itemBookMark.get("listId"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(itemBookMark.get("asurakuFlag"));
		assertNotNull(itemBookMark.get("inStockFlag"));
		assertNotNull(itemBookMark.get("shopMngId"));
		assertNotNull(itemBookMark.get("genreId"));
		assertNotNull(itemBookMark.get("productPageUrl"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(itemBookMark.get("enableFlag"));
		assertNotNull(ncpPoints);
		assertNotNull(ncpPoints.get("itemPointValue"));
		assertNotNull(ncpPoints.get("itemPointRate"));
		assertNotNull(ncpPoints.get("itemPointExtraRate"));
		assertNotNull(ncpPoints.get("itemPointBackRate"));
	}

	private Environment getMockEnvironment() {
		Environment environment = mock(Environment.class);
		when(environment.getProperty("itembookmark.list.couponByItem.api.designated.product.target")).thenReturn("指定商品対象");
		when(environment.getProperty("itembookmark.list.couponByItem.api.applicable.to.designated.stores")).thenReturn("指定店舗対象");
		when(environment.getProperty("itembookmark.list.couponByItem.api.one.person.up.to.times")).thenReturn("お一人様{}回まで");
		when(environment.getProperty("itembookmark.list.couponByItem.api.first.arrival.until.name")).thenReturn("先着{}回まで");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.separator")).thenReturn("・");
		when(environment.getProperty("itembookmark.list.couponByItem.api.available.at.least")).thenReturn("{}個以上で利用可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.available.in.yen")).thenReturn("{}円以上で利用可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.computer")).thenReturn("パソコン");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.smartphone")).thenReturn("スマートフォン");
		when(environment.getProperty("itembookmark.list.couponByItem.api.can.not.used.together")).thenReturn("併用不可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.separator")).thenReturn("|");
		return environment;
	}

}