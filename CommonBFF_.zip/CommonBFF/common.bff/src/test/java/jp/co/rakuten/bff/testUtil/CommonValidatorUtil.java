package jp.co.rakuten.bff.testUtil;


import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.template.CommonSchema;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.template.RequestSchema;
import jp.co.rakuten.bff.core.template.ResponseSchema;
import org.junit.platform.commons.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;


public class CommonValidatorUtil {

	public static CommonSchema commonSchemaBuilder(String name, String type, Boolean required, String source, String dataType,
	                                               Integer maxSize, Integer minSize, Integer minLength, Integer maxLength, Integer minValue,
	                                               Integer maxValue, Integer minSelectable, Integer maxSelectable, String pattern,
	                                               String propType, String propKeyPrefix, List<Object> options,
	                                               List<CommonSchema> parameters, Object defaultValue, String format){
		CommonSchema commonSchema = new CommonSchema();
		commonSchema.setName(name);
		commonSchema.setType(type);
		commonSchema.setRequired(required);
		commonSchema.setSource(source);
		commonSchema.setDataType(dataType);
		commonSchema.setMaxSize(maxSize);
		commonSchema.setMinSize(minSize);
		commonSchema.setMinLength(minLength);
		commonSchema.setMaxLength(maxLength);
		commonSchema.setMinValue(minValue);
		commonSchema.setMaxValue(maxValue);
		commonSchema.setMinSelectable(minSelectable);
		commonSchema.setMaxSelectable(maxSelectable);
		commonSchema.setPattern(pattern);
		commonSchema.setPropType(propType);
		commonSchema.setPropKeyPrefix(propKeyPrefix);
		commonSchema.setOptions(options);
		commonSchema.setParameters(parameters);
		commonSchema.setDefaultValue(defaultValue);
		commonSchema.setFormat(format);
		return commonSchema;
	}

	public static List<FeatureTemplate> schemaLoader(){
		List<FeatureTemplate> featureTemplateList = new ArrayList<>();
		FeatureTemplate shopbookmarkTemplate = new FeatureTemplate();
		RequestSchema requestSchema = new RequestSchema();
		CommonSchema version = commonSchemaBuilder("version", "string", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema xRequestId = commonSchemaBuilder("x-request-id", "string", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema easyId = commonSchemaBuilder("easy_id", "integer", true, "easyId", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema genreId = commonSchemaBuilder("genreId", "integer", false, null, null, null, null, null, null, 5, 999999, null, null, null, null, null, null, null, null, null);
		CommonSchema marketId = commonSchemaBuilder("marketId", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 5, null);
		CommonSchema minPrice = commonSchemaBuilder("minPrice", "double", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema maxPrice = commonSchemaBuilder("maxPrice", "double", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema userList = commonSchemaBuilder("userList", "list", false, null, "string", 5, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema userId = commonSchemaBuilder("userid", "integer", true, null, null, null, null, null, null, 0, 999999, null, null, null, null, null, null, null, null, null);
		CommonSchema username = commonSchemaBuilder("username", "string", false, null, null, null, null, null, 100, null, null, null, null, "^[a-zA-Z0-9]+$", null, null, null, null, null, null);
		CommonSchema password = commonSchemaBuilder("password", "string", false, null, null, null, null, 4, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema genreInformationFlag = commonSchemaBuilder("genreInformationFlag", "boolean", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema maxAffiliateRate = commonSchemaBuilder("maxAffiliateRate", "decimal", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema deliveryInfo = commonSchemaBuilder("deliveryInfo", "option", false, null, "integer", null, null, null, null, null, null, null, null, null, null, null, Arrays
				.asList(1,2,3,4), null, null, null);
		CommonSchema membershipTypes = commonSchemaBuilder("membershipTypes", "multioption", false, null, "integer", null, null, null, null, null, null, 1, 2, null, null, null, Arrays.asList(1,2,3), null, null, null);

		CommonSchema xAnalyticsAid = commonSchemaBuilder("X-Analytics-Aid", "property", false, null, null, null, null, null, null, null, null, null, null, null, null, "benefits.calculation.aid", null, null, null, null);


		CommonSchema user = commonSchemaBuilder("user", "object", false, null, null,
				null, null, null, null, null, null, null,
				null, null, null, null, null,
				Arrays.asList(userId, username, password), null, null);

		List<CommonSchema> shopbookmarkSchemas = Arrays.asList(version, easyId, genreId, minPrice, userList, maxPrice, marketId, user, genreInformationFlag, maxAffiliateRate, deliveryInfo, membershipTypes, xAnalyticsAid);
		requestSchema.setParameters(shopbookmarkSchemas);
		requestSchema.setHeaders(Collections.singletonList(xRequestId));
		shopbookmarkTemplate.setRequest(requestSchema);

		ResponseSchema responseSchema = new ResponseSchema();
		CommonSchema id = commonSchemaBuilder("id", "integer", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopId = commonSchemaBuilder("shopId", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopName = commonSchemaBuilder("shopName", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopUrl = commonSchemaBuilder("shopUrl", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopImage = commonSchemaBuilder("shopImage", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema registerTime = commonSchemaBuilder("registerTime", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema reviewCount = commonSchemaBuilder("reviewCount", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema reviewRating = commonSchemaBuilder("reviewRating", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema offset = commonSchemaBuilder("offset", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema hits = commonSchemaBuilder("hits", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema code = commonSchemaBuilder("code", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema message = commonSchemaBuilder("message", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		CommonSchema data = commonSchemaBuilder("data", "objectarray", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Arrays.asList(id, shopId, shopName), null, null);
		CommonSchema meta = commonSchemaBuilder("meta", "object", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Arrays.asList(offset, hits), null, null);
		CommonSchema status = commonSchemaBuilder("status", "object", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Arrays.asList(code, message), null, null);

		List<CommonSchema> shopbookmarkResponseSchemas = Arrays.asList(data, meta, status);
		responseSchema.setParameters(shopbookmarkResponseSchemas);
		shopbookmarkTemplate.setResponse(responseSchema);
		shopbookmarkTemplate.setName("shopbookmarkList");
		featureTemplateList.add(shopbookmarkTemplate);

		FeatureTemplate couponTemplate = new FeatureTemplate();
		RequestSchema couponSchema = new RequestSchema();
		CommonSchema couponVer = commonSchemaBuilder("version", "string", true, "version", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema couponUser = commonSchemaBuilder("easy_id", "integer", true, "easyId", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);


		List<CommonSchema> couponSchemas = Arrays.asList(couponVer, couponUser);
		couponSchema.setParameters(couponSchemas);
		couponTemplate.setRequest(couponSchema);
		couponTemplate.setName("coupon");
		featureTemplateList.add(couponTemplate);

		return featureTemplateList;
	}

	public static List<FeatureTemplate> getShopbookmarkSchema() {
		List<FeatureTemplate> featureTemplateList = new ArrayList<>();
		FeatureTemplate shopbookmarkTemplate = new FeatureTemplate();
		ResponseSchema responseSchema = new ResponseSchema();
		CommonSchema id = commonSchemaBuilder("id", "integer", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopId = commonSchemaBuilder("shopId", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema shopName = commonSchemaBuilder("shopName", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema itemName = commonSchemaBuilder("itemName", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);


		CommonSchema data = commonSchemaBuilder("shopBookmarkList", "objectarray", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Arrays.asList(id, shopId, shopName, itemName), null, null);

		List<CommonSchema> shopbookmarkResponseSchemas = Arrays.asList(data);
		responseSchema.setParameters(shopbookmarkResponseSchemas);
		shopbookmarkTemplate.setResponse(responseSchema);
		shopbookmarkTemplate.setName("shopBookmarkInfo");
		featureTemplateList.add(shopbookmarkTemplate);

		return featureTemplateList;
	}

	public static List<FeatureTemplate> getResponseSchema() {
		List<FeatureTemplate> featureTemplateList = new ArrayList<>();
		FeatureTemplate respemplate = new FeatureTemplate();
		ResponseSchema responseSchema = new ResponseSchema();
		CommonSchema id = commonSchemaBuilder("id", "integer", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema userId = commonSchemaBuilder("userId", "integer", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema username = commonSchemaBuilder("shopName", "string", false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		CommonSchema usernameList = commonSchemaBuilder("usernameList", "list", false, null, "string", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);


		CommonSchema data = commonSchemaBuilder("user", "object", true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Arrays.asList(id, userId, username, usernameList), null, null);

		List<CommonSchema> responseSchemas = Collections.singletonList(data);
		responseSchema.setParameters(responseSchemas);
		respemplate.setResponse(responseSchema);
		respemplate.setName("userInfo");
		featureTemplateList.add(respemplate);

		return featureTemplateList;
	}

	public static Map<String, Object> testData(String dataType, Object value){
		Map<String, Object> template = templateLoader(dataType, null);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>)template.get("featureTemplates");
		CommonSchema commonSchema = (CommonSchema)template.get("commonSchema");

		ClientRequestModel ClientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setParams(ImmutableMap.of("param1", value));
		requestModel.setFeatures(ImmutableMap.of("feature", commonRequestModel));
		ClientRequestModel.setRequestModel(requestModel);
		return ImmutableMap.of("featureTemplates", featureTemplates, "ClientRequestModel", ClientRequestModel,
				"name", commonSchema.getName());
	}

	public static Map<String, Object> testDateData(String dateValue, String format){
		Map<String, Object> template = templateLoader("date", format);
		List<FeatureTemplate> featureTemplates = (List<FeatureTemplate>)template.get("featureTemplates");
		CommonSchema commonSchema = (CommonSchema)template.get("commonSchema");

		ClientRequestModel ClientRequestModel = new ClientRequestModel();
		RequestModel requestModel = new RequestModel();
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setParams(ImmutableMap.of("param1", dateValue));
		requestModel.setFeatures(ImmutableMap.of("feature", commonRequestModel));
		ClientRequestModel.setRequestModel(requestModel);
		return ImmutableMap.of("featureTemplates", featureTemplates, "ClientRequestModel", ClientRequestModel,
				"name", commonSchema.getName());
	}

	private static Map<String, Object> templateLoader(String dataType, String format) {
		List<FeatureTemplate> featureTemplates = new ArrayList<>();
		FeatureTemplate featureTemplate = new FeatureTemplate();
		featureTemplate.setName("feature");
		RequestSchema requestSchema = new RequestSchema();
		CommonSchema commonSchema = new CommonSchema();
		commonSchema.setName("param1");
		commonSchema.setType(dataType);

		if(StringUtils.isNotBlank(format)) {
			commonSchema.setFormat(format);
		}

		requestSchema.setParameters(Collections.singletonList(commonSchema));
		featureTemplate.setRequest(requestSchema);
		featureTemplates.add(featureTemplate);

		return Map.of("featureTemplates", featureTemplates, "commonSchema", commonSchema);
	}
}
