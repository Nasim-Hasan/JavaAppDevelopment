package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ShopMasterInfoInterfaceProcessorTest {

    Map<String, Map<String, CommonRequestModel>> validatedRequests;
    Map<String, Object> validatedRequestsObject;

    Map<String, GenericCallDefinitionProcessedData> genericCDProcessedDatas;
    Map<String, GenericCallDefinitionProcessedData> genericCDProcessedData;

    private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
    private static final String BASE_PATH = "mockfiles/feature/productscreen/get/";
    private CallDefinitionResponseUtil callDefinitionResponseUtil;
    private static final String PRODUCT_INFO_VALIDATED_REQUEST = "productInfo_validatedRequests.json";
    @InjectMocks
    private ShopMasterInfoInterfaceProcessor shopMasterInfoInterfaceProcessor;

    @BeforeEach
    void setUp() {
        callDefinitionResponseUtil = new CallDefinitionResponseUtil();
        shopMasterInfoInterfaceProcessor = new ShopMasterInfoInterfaceProcessor();
        callDefinitionResponseMap = new HashMap<>();

        validatedRequests = TestUtil.prepareValidatedRequests(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST);
        validatedRequestsObject = TestUtil.getObjectFromFilename(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST, Map.class);
        genericCDProcessedDatas =
                TestUtil.getGenericCallDefinitionProcessedData(BASE_PATH + "shopMasterInfo_genericPreparedRequest.json");
    }

    @ParameterizedTest
    @DisplayName("ShopMaster interface calls GG successfully with valid parameters through preProcess Method")
    @CsvSource(value = {
            // testing criteria     | expectation
            "   shopIdManageNumber  |   false   ",
            "     shopIdItemId      |   false   ",
            "       itemCode        |   true    ",
            "       itemUrl         |   true    "
    }, delimiter = '|')
    void testPreProcess(String testingCriteria, Boolean expectation) {
        //Given
        Map<String, CommonRequestModel> validatedRequest = validatedRequests.get(testingCriteria);
        GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(testingCriteria);
        callDefinitionResponseMap = callDefinitionResponseUtil
                .getUpstreamResponseSuccess(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, ProductScreenConstant.SHOP_MASTER_INTERFACE_KEY,
                        BASE_PATH + "shopMasterInfo_success_1.json");
        // Then
        boolean status = shopMasterInfoInterfaceProcessor.preProcess(validatedRequest,
                genericCDProcessedData,callDefinitionResponseMap);
        // Verify
        assertEquals(status, expectation);
    }
}