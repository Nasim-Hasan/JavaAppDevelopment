package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.ParameterResolveException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.INVENTORYX_INTERFACE_KEY;
import static org.junit.jupiter.api.Assertions.*;

class InventoryXInterfaceProcessorTest {

	Map<String, CommonRequestModel> validatedRequest;
	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private GenericCallDefinitionProcessedData genericCallDefinitionProcessedData;
	String requestId;

	@InjectMocks
	InventoryXInterfaceProcessor inventoryXInfoInterfaceProcessor;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionResponseMap = new HashMap<>();
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		Map <String ,Object> shopIdParamMap =new HashMap<>();
		shopIdParamMap.put("shopId","501082");
		commonRequestModel.setParams(shopIdParamMap);
		validatedRequest=new HashMap<>();
		validatedRequest.put(ItemXInfoConstants.ITEM_INFO_FEATURE_KEY, commonRequestModel);
		requestId = UUID.randomUUID().toString();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		genericCallDefinitionProcessedData = new GenericCallDefinitionProcessedData();
	}


	@DisplayName("test preProcess: itemx response is valid for inventoryx call")
	@Test
	void preProcess() {
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		GenericCallDefinitionProcessedData genericCallDefinitionProcessedData =
				new GenericCallDefinitionProcessedData();
		Map params = new HashMap<>();
		params.put("shopId","501082");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put(BffConstants.URL_PARAMETERS, params);
		preparedRequest.put(requestId, innerMap);
		genericCallDefinitionProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INVENTORYX_INTERFACE_KEY, requestId, genericCallDefinitionProcessedData);

		boolean result =
				inventoryXInfoInterfaceProcessor.preProcess(validatedRequest, genericCallDefinitionProcessedData,
						callDefinitionResponseMap);

		assertTrue(result);
		assertEquals(1, genericCallDefinitionProcessedData.getPreparedRequest().size());
		Map urlParameters = (Map) genericCallDefinitionProcessedData.getPreparedRequest().entrySet().stream()
				.findFirst().get().getValue().get("urlParameters");
		assertNotNull(urlParameters);
		assertEquals("TestJahid", urlParameters.get("manageNumber"));
		assertEquals("501082", urlParameters.get("shopId"));
	}


	@DisplayName("test preProcess: itemx response is valid for inventoryx call")
	@Test
	void preProcess1() {
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		GenericCallDefinitionProcessedData genericCallDefinitionProcessedData =
				new GenericCallDefinitionProcessedData();
		Map params = new HashMap<>();
		params.put("shopId","501082");
		params.put("manageNumber","TestJahid");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put(BffConstants.URL_PARAMETERS, params);
		preparedRequest.put(requestId, innerMap);
		genericCallDefinitionProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INVENTORYX_INTERFACE_KEY, requestId, genericCallDefinitionProcessedData);
		CommonRequestModel itemInfoModel = validatedRequest.get(ItemXInfoConstants.ITEM_INFO_FEATURE_KEY);
		Map urlParams = itemInfoModel.getParams();
		urlParams.put("manageNumber","TestJahid");
		itemInfoModel.setParams(urlParams);
	validatedRequest.put(ItemXInfoConstants.ITEM_INFO_FEATURE_KEY,itemInfoModel);

		boolean result =
				inventoryXInfoInterfaceProcessor.preProcess(validatedRequest, genericCallDefinitionProcessedData,
						Collections.EMPTY_MAP);

		assertTrue(result);
		assertEquals(1, genericCallDefinitionProcessedData.getPreparedRequest().size());
		Map urlParameters = (Map) genericCallDefinitionProcessedData.getPreparedRequest().entrySet().stream()
				.findFirst().get().getValue().get("urlParameters");
		assertNotNull(urlParameters);
		assertEquals("TestJahid", urlParameters.get("manageNumber"));
		assertEquals("501082", urlParameters.get("shopId"));
	}

	@DisplayName("test preProcess: itemx response is invalid and inventoryx is not called")
	@Test
	void preProcess_failure() {
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_failure_2.json");
		GenericCallDefinitionProcessedData genericCallDefinitionProcessedData =
				new GenericCallDefinitionProcessedData();
		Map params = new HashMap<>();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put(BffConstants.URL_PARAMETERS, params);
		preparedRequest.put(requestId, innerMap);
		genericCallDefinitionProcessedData.setPreparedRequest(preparedRequest);

		mapInterfaceRequestId(INVENTORYX_INTERFACE_KEY, requestId,
				genericCallDefinitionProcessedData);

		boolean result =
				inventoryXInfoInterfaceProcessor.preProcess(validatedRequest, genericCallDefinitionProcessedData,
						callDefinitionResponseMap);

		assertFalse(result);
	}

	private void mapInterfaceRequestId(String interfaceMap, String requestId,
			GenericCallDefinitionProcessedData genericCallDefinitionProcessedData) {
		Map<String, List<String>> map = new HashMap<>();
		map.put(interfaceMap, Collections.singletonList(requestId));
		map.put(ItemXInfoConstants.ITEMX_INTERFACE_KEY, Collections.singletonList(requestId));
		genericCallDefinitionProcessedData.setInterfaceToRequestIdMap(map);
	}


	@Test
	@DisplayName("Throws ParamResolve Exception when Interface URL Params are Missing")
	void preProcessParameterExceptionInterfaceURLMissing() {

 		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		String requestId = UUID.randomUUID().toString();
		Map params = new HashMap<>();
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put(BffConstants.URL_PARAMETERS, params);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INVENTORYX_INTERFACE_KEY, requestId, genericCDProcessedData);
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, ItemXInfoConstants.ITEMX_INTERFACE_KEY,
						"mockfiles/responses/feature/item.get/itemx_success_1.json");
		// Then

		// Verify
		assertThrows(ParameterResolveException.class,()->inventoryXInfoInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap));
	}
}