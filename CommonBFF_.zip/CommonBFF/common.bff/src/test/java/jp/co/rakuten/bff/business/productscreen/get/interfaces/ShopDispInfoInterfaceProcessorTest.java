package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ShopDispInfoInterfaceProcessorTest {

	Map<String, Map<String, CommonRequestModel>> validatedRequests;
	Map<String, Object> validatedRequestsObject;

	Map<String, GenericCallDefinitionProcessedData> genericCDProcessedDatas;
	Map<String, GenericCallDefinitionProcessedData> genericCDProcessedData;

	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private static final String BASE_PATH = "mockfiles/feature/productscreen/get/";
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private static final String PRODUCT_INFO_VALIDATED_REQUEST = "productInfo_validatedRequests.json";
	@InjectMocks
	private ShopDispInfoInterfaceProcessor shopDispInfoInterfaceProcessor;

	@BeforeEach
	void setUp() {
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		shopDispInfoInterfaceProcessor = new ShopDispInfoInterfaceProcessor();
		callDefinitionResponseMap = new HashMap<>();

		validatedRequests = TestUtil.prepareValidatedRequests(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST);
		validatedRequestsObject = TestUtil.getObjectFromFilename(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST, Map.class);
		genericCDProcessedDatas =
				TestUtil.getGenericCallDefinitionProcessedData(BASE_PATH + "shopDisp_genericPreparedRequest.json");
	}

	@ParameterizedTest
	@DisplayName("ShopDisp interface calls GG successfully with valid parameters through preProcess Method")
	@CsvSource(value = {
			//   preparedRequest	|  validRequestParam    | expectation
			"   	shopDisp  		|  shopIdManageNumber	|  true   ",
			"   	shopDisp  		|    shopIdItemId    	|  true   ",
			"   	shopDisp  		|      itemCode      	|  true   ",
			"     	shopDisp   		|      itemUrl       	|  true  ",
			"     shopDispInvalid   |      shopIdItemId     |  false  ",
	}, delimiter = '|')
	void testPreProcess(String preparedRequest, String validRequestParam, Boolean expectation) {
		//Given
		Map<String, CommonRequestModel> validatedRequest = validatedRequests.get(validRequestParam);
		GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(preparedRequest);
		callDefinitionResponseMap = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, ProductScreenConstant.SHOP_DISP_INTERFACE,
						BASE_PATH + "shopDisp_success_1.json");
		// Then
		boolean status = shopDispInfoInterfaceProcessor.preProcess(validatedRequest,
				genericCDProcessedData,callDefinitionResponseMap);
		// Verify
		assertEquals(status, expectation);
	}

}