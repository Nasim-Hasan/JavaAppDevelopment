package jp.co.rakuten.bff.business.itembookmark.delete.validators;

import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;

public class ItemBookmarkDeleteValidatorTest {

	private static final String FEATURE_NAME_ITEM_BOOKMARK_DELETE = "itemBookmarkDeleteInfo";

	@ParameterizedTest
	@DisplayName("Should throw BackendException")
	@ValueSource(ints = {0, -5})
	void validate(int easyId) {

		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setHeaders(Map.of("easyId", easyId));
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(FEATURE_NAME_ITEM_BOOKMARK_DELETE, commonRequestModel);

		//Then+Verify
		assertThrows(ClientException.class,
				() -> new ItemBookmarkDeleteValidator().validate(validatedRequest, null, null));
	}

	@Test
	void validate_shouldReturnValidatedData() {
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setHeaders(Map.of("easyId", 10889027));
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(FEATURE_NAME_ITEM_BOOKMARK_DELETE, commonRequestModel);

		Map<String, CommonRequestModel> validatedData = new ItemBookmarkDeleteValidator().validate(validatedRequest, null, null);

		Integer easyId = (Integer) validatedData.get(FEATURE_NAME_ITEM_BOOKMARK_DELETE).getHeaders().get(EASY_ID);
		assertEquals(10889027, easyId);
	}
}
