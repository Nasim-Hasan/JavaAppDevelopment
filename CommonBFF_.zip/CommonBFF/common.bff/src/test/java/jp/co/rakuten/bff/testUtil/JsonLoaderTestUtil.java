package jp.co.rakuten.bff.testUtil;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.mock.env.MockEnvironment;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import reactor.core.publisher.Mono;

import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_API_CONFIG_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_API_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.PROP_KEY_INTERFACE_REPO_PATH;
import static jp.co.rakuten.bff.core.constant.BffConstants.SPRING_APPLICATION_NAME;
import static jp.co.rakuten.bff.core.constant.BffConstants.SPRING_CLOUD_CONFIG_LABEL;
import static jp.co.rakuten.bff.core.constant.BffConstants.SPRING_CLOUD_CONFIG_URI;
import static jp.co.rakuten.bff.core.constant.BffConstants.SPRING_PROFILES_ACTIVE;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

public class JsonLoaderTestUtil {
	public static Environment getMockEnv(String externalDir, String localDir) {
		MockEnvironment mockEnv = new MockEnvironment();
		mockEnv.setProperty(PROP_KEY_API_REPO_PATH, localDir + "api/");
		mockEnv.setProperty(PROP_KEY_API_CONFIG_REPO_PATH, localDir + "apiConfig/");
		mockEnv.setProperty(PROP_KEY_INTERFACE_REPO_PATH, localDir + "interface/");
		mockEnv.setProperty(SPRING_CLOUD_CONFIG_URI, "test");
		mockEnv.setProperty(SPRING_APPLICATION_NAME, "testBff");
		mockEnv.setProperty(SPRING_PROFILES_ACTIVE, "test");
		mockEnv.setProperty(SPRING_CLOUD_CONFIG_LABEL, "testLabel");
		return mockEnv;
	}

	public static WebClient.Builder getMockWebClientBuilder(String response, int status) {
		WebClient.Builder webClientBuilderMock = mock(WebClient.Builder.class);
		WebClient webClientMock = getMockWebClient(getMockClientResponse(response, status));
		doReturn(webClientBuilderMock).when(webClientBuilderMock).baseUrl(any());
		doReturn(webClientMock).when(webClientBuilderMock).build();
		return webClientBuilderMock;
	}

	public static WebClient.Builder getMockWebClientBuilder(String apiConfigResponse, String apiResponse, int status) {
		WebClient.Builder webClientBuilderMock = mock(WebClient.Builder.class);
		WebClient webClientMock = getMockWebClient(getMockClientResponse(apiConfigResponse, apiResponse, status));
		doReturn(webClientBuilderMock).when(webClientBuilderMock).baseUrl(any());
		doReturn(webClientMock).when(webClientBuilderMock).build();
		return webClientBuilderMock;
	}

	public static WebClient getMockWebClient(ClientResponse clientResponse) {
		Mono<ClientResponse> responseMonoMock = Mono.just(clientResponse);

		RequestBodyUriSpec uriSpecMock = mock(RequestBodyUriSpec.class);
		doReturn(uriSpecMock).when(uriSpecMock).uri(anyString());
		doReturn(uriSpecMock).when(uriSpecMock).accept(any());
		doReturn(responseMonoMock).when(uriSpecMock).exchange();

		WebClient webClientMock = mock(WebClient.class);
		doReturn(uriSpecMock).when(webClientMock).method(any());
		return webClientMock;
	}

	public static ClientResponse getMockClientResponse(String response, int status) {
		ClientResponse clientResponseMock = mock(ClientResponse.class);
		doReturn(Mono.just(response)).when(clientResponseMock).bodyToMono(String.class);
		doReturn(HttpStatus.resolve(status)).when(clientResponseMock).statusCode();
		return clientResponseMock;
	}

	public static ClientResponse getMockClientResponse(String apiConfigResponse, String apiResponse, int status) {
		ClientResponse clientResponseMock = mock(ClientResponse.class);
		doReturn(Mono.just(apiConfigResponse), Mono.just(apiResponse)).when(clientResponseMock).bodyToMono(String.class);
		doReturn(HttpStatus.resolve(status)).when(clientResponseMock).statusCode();
		return clientResponseMock;
	}
}
