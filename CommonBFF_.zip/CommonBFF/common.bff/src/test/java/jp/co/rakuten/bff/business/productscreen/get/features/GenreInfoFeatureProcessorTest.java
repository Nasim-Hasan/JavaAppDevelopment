package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.MockitoAnnotations.initMocks;

class GenreInfoFeatureProcessorTest {

	private GenreInfoFeatureProcessor genreInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private static String BASE_PATH = "mockfiles/feature/productscreen/get/";

	@Mock
	private CommonRequestModel validatedClientData;

	@Mock
	private FeatureTemplate featureTemplate;


	@BeforeEach
	void setUp() {
		initMocks(this);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		genreInfoFeatureProcessor = new GenreInfoFeatureProcessor();
	}


	@ParameterizedTest
	@DisplayName("If navigationReview call definition succeeded then response preparation is successful for navigationInfo interface")
	@CsvSource(value = {
			// premium	|	studentDiscount	|	membershipTypes
			"     0		|       0	 		|		[1, 2]		",
			"	  0 	|  		1			|       [1]	 		",
			"	  1		|       0	 		|		[2]			",
			"	  1		|       1	 		|		[]			",
	}
			, delimiter = '|')
	void testNavigationInfoCallDefinitionGGResponseCheck(Integer premium, Integer studentDiscount, String membershipTypes) {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		String[] interfaces = {ProductScreenConstant.NAVIGATION_INTERFACE_KEY};
		String[] files = {BASE_PATH + "genreInfo_success.json"};

		Map<String, CallDefinitionResponse> callDefinitionResponse = callDefinitionResponseUtil
				.getUpstreamResponseSuccess(ProductScreenConstant.NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY, interfaces, files);
		Map<String, Integer> prohibitedMembershipStatus = (Map)((Map)InterfaceUtil.getInterfaceResponse(callDefinitionResponse, ProductScreenConstant.NAVIGATION_INTERFACE_KEY,
				ProductScreenConstant.NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY).get("genre")).get("prohibitedMembershipStatus");
		prohibitedMembershipStatus.put("prohibitedMembershipPremiumFlg", premium);
		prohibitedMembershipStatus.put("prohibitedMembershipStudentDiscountFlg", studentDiscount);
		callDefinitionResponseMap.putAll(callDefinitionResponse);

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = genreInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		Map<String, Object> genreFeatureResponseBody = featurePostProcessorResponse.getResponseMap();
		assertEquals(membershipTypes, ((List)genreFeatureResponseBody.get("membershipTypes")).toString());
	}

	@Test
	@DisplayName("If navigationInfo interface doesn't exist in GG response than GenreInfoFeatureProcessor should throw BackendException")
	void testItemxInterfaceDoesNotExistInGGResponse() {
		//Given
		CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(
				CallDefinitionResponseStatus.SUCCESS);
		callDefinitionResponse.setInterfaceToRequestIdMap(Collections.emptyMap());
		callDefinitionResponse.setMultipleResponses(new MultipleResponses());
		Map<String, CallDefinitionResponse> genreInfoResponse = Map.of(ProductScreenConstant.NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY, callDefinitionResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = genreInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, genreInfoResponse);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, () -> responseMono.block());
	}

}
