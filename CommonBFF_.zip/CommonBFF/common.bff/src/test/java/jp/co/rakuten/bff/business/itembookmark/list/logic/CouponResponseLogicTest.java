package jp.co.rakuten.bff.business.itembookmark.list.logic;


import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CouponResponseLogicTest {
	private CouponResponseLogic couponResponseLogic;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		Environment environment = getMockEnvironment();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		couponResponseLogic = new CouponResponseLogic(environment);
	}

	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> Success With proper coupon")
	void testPrepareCouponSuccessWithCoupons() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_2.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, true);
			checkCoupon(modifiedCoupon);
			assertNotNull(modifiedCoupon.get("couponServiceId"));
		});
	}


	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> Success With proper coupon for shop")
	void testPrepareCouponSuccessWithCouponsForShop() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_2.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, false);
			checkCoupon(modifiedCoupon);
			assertNotNull(modifiedCoupon.get("couponServiceId"));
		});
	}

	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> Success, coupon without serviceId")
	void testPrepareCouponSuccessCouponWithoutServiceId() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_3.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, true);
			checkCoupon(modifiedCoupon);
			assertNull(modifiedCoupon.get("couponServiceId"));
		});
	}

	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> failed for invalid itemType")
	void testPrepareCouponFailedCaseForInvalidItemType() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemSuccessCase_4.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, true);
			checkCoupon(modifiedCoupon);
			assertNotNull(modifiedCoupon.get("couponServiceId"));
		});
	}

	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> failed with empty coupon as discountTitle is not enabled")
	void testPrepareCouponFailedForDiscountTitleDisabled() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemFailedCase_1.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, true);
			assertTrue(modifiedCoupon.isEmpty());
		});
	}


	@Test
	@DisplayName("CouponResponseLogic: prepareCoupon-> failed with empty coupon for invalid discountTitle")
	void testPrepareCouponFailedForInvalidDiscountTitle() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(CALL_DEF_COUPONS_BY_ITEM_CD,
						INTERFACE_NAME_COUPON_BY_ITEM,
						"mockfiles/feature/itembookmarkInfo/couponByItemFailedCase_2.json"));
		Map<String, Object> couponByItemInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, "couponByItem",
						"couponsByItemCD");
		List<Map<String, Object>> items = (List<Map<String, Object>>) couponByItemInterfaceResponse.get("items");
		List<Map<String, Object>> coupons = (List<Map<String, Object>>) items.get(0).get("coupons");
		coupons.forEach(coupon -> {
			Map<String, Object> modifiedCoupon = couponResponseLogic.prepareCoupon(coupon, true);
			assertTrue(modifiedCoupon.isEmpty());
		});
	}

	private Environment getMockEnvironment() {
		Environment environment = mock(Environment.class);
		when(environment.getProperty("itembookmark.list.couponByItem.api.designated.product.target")).thenReturn("指定商品対象");
		when(environment.getProperty("itembookmark.list.couponByItem.api.applicable.to.designated.stores")).thenReturn("指定店舗対象");
		when(environment.getProperty("itembookmark.list.couponByItem.api.one.person.up.to.times")).thenReturn("お一人様{}回まで");
		when(environment.getProperty("itembookmark.list.couponByItem.api.first.arrival.until.name")).thenReturn("先着{}回まで");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.separator")).thenReturn("・");
		when(environment.getProperty("itembookmark.list.couponByItem.api.available.at.least")).thenReturn("{}個以上で利用可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.available.in.yen")).thenReturn("{}円以上で利用可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.computer")).thenReturn("パソコン");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.rs001.smartphone")).thenReturn("スマートフォン");
		when(environment.getProperty("itembookmark.list.couponByItem.api.can.not.used.together")).thenReturn("併用不可");
		when(environment.getProperty("itembookmark.list.couponByItem.api.term.of.use.separator")).thenReturn("|");
		return environment;
	}

	private void checkCoupon(Map<String, Object> coupon) {
		assertNotNull(coupon);
		assertFalse(coupon.isEmpty());
		assertNotNull(coupon.get("couponName"));
		assertNotNull(coupon.get("discountTitle"));
		assertNotNull(coupon.get("termsOfUse"));
		assertNotNull(coupon.get("couponEndDate"));
		assertNotNull(coupon.get("couponId"));
		assertNotNull(coupon.get("couponCode"));
		assertNotNull(coupon.get("couponStartDate"));
		assertNotNull(coupon.get("acquired"));
	}
}