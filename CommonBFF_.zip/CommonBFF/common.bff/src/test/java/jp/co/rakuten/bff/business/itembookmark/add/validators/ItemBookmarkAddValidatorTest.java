package jp.co.rakuten.bff.business.itembookmark.add.validators;

import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.*;
import static org.junit.jupiter.api.Assertions.*;

public class ItemBookmarkAddValidatorTest {
	private static final String FEATURE_NAME_ITEM_BOOKMARK_ADD = "itemBookmarkAddInfo";
	private CommonRequestModel commonRequestModel;
	private Map<String, CommonRequestModel> validatedRequest;

	@BeforeEach
	void setUp() {
		commonRequestModel = new CommonRequestModel();
		validatedRequest = new HashMap<>();
	}

	@ParameterizedTest
	@DisplayName("Should throw BackendException")
	@ValueSource(ints = {0, -5})
	void validate(int easyId) {
		commonRequestModel.setHeaders(Map.of("easyId", easyId));
		validatedRequest.put(FEATURE_NAME_ITEM_BOOKMARK_ADD, commonRequestModel);

		//Then+Verify
		assertThrows(ClientException.class, () -> new ItemBookmarkAddValidator()
				.validate(validatedRequest, null, null));
	}

	@Test
	@DisplayName("Should return easyId")
	void validate_shouldReturnValidatedData() {
		commonRequestModel.setHeaders(Map.of("easyId", 10889027));
		validatedRequest.put(FEATURE_NAME_ITEM_BOOKMARK_ADD, commonRequestModel);

		Map<String, CommonRequestModel> validatedData = new ItemBookmarkAddValidator()
				.validate(validatedRequest, null, null);

		Integer easyId = (Integer) validatedData.get(FEATURE_NAME_ITEM_BOOKMARK_ADD).getHeaders().get(EASY_ID);
		assertEquals(10889027, easyId);
	}
}
