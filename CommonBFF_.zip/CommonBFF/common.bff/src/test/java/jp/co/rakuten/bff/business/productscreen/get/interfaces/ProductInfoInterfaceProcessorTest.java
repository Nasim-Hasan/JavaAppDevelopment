package jp.co.rakuten.bff.business.productscreen.get.interfaces;
import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.business.productscreen.get.features.ProductInfoFeatureProcessor;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import jp.co.rakuten.bff.testUtil.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductInfoInterfaceProcessorTest {

    Map<String, Map<String, CommonRequestModel>> validatedRequests;
    Map<String, Object> validatedRequestsObject;

    Map<String, GenericCallDefinitionProcessedData> genericCDProcessedDatas;
    Map<String, GenericCallDefinitionProcessedData> genericCDProcessedData;

    private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
    private static final String BASE_PATH = "mockfiles/feature/productscreen/get/";
    private CallDefinitionResponseUtil callDefinitionResponseUtil;
    private static final String PRODUCT_INFO_VALIDATED_REQUEST = "productInfo_validatedRequests.json";
    @InjectMocks
    private ProductInfoInterfaceProcessor productInfoInterfaceProcessor;

    @BeforeEach
    void setUp() {
        callDefinitionResponseUtil = new CallDefinitionResponseUtil();
        productInfoInterfaceProcessor = new ProductInfoInterfaceProcessor();
        callDefinitionResponseMap = new HashMap<>();

        validatedRequests = TestUtil.prepareValidatedRequests(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST);
        validatedRequestsObject = TestUtil.getObjectFromFilename(BASE_PATH + PRODUCT_INFO_VALIDATED_REQUEST, Map.class);
        genericCDProcessedDatas =
                TestUtil.getGenericCallDefinitionProcessedData(BASE_PATH + "productInfo_genericPreparedRequest.json");
    }

    @ParameterizedTest
    @DisplayName("ProductInfo interface calls GG successfully with valid parameters through preProcess Method")
    @ValueSource(strings = {"shopIdManageNumber", "shopIdItemId", "itemCode", "itemUrl"})
    void preProcessAndValidateSuccess(String testingCriteria) {
        //Given
        Map<String, CommonRequestModel> validatedRequest = validatedRequests.get(testingCriteria);
        GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(testingCriteria);
        callDefinitionResponseMap = callDefinitionResponseUtil
                .getUpstreamResponseSuccess(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, ProductScreenConstant.PRODUCT_INFO_INTERFACE_KEY,
                        BASE_PATH + "productInfo_success_1.json");
        // Then
        boolean status = productInfoInterfaceProcessor.preProcess(validatedRequest,
                genericCDProcessedData,callDefinitionResponseMap);
        // Verify
        assertTrue(status);
    }

    @ParameterizedTest
    @DisplayName("ProductInfo interface faild to calls GG with invalid parameters through preProcess Method")
    @ValueSource(strings = {"withoutProductInfoWithoutParameterLinks"})
    void preProcessAndFail(String testingCriteria) {
        //Given
        Map<String, CommonRequestModel> validatedRequest = validatedRequests.get(testingCriteria);
        GenericCallDefinitionProcessedData genericCDProcessedData = genericCDProcessedDatas.get(testingCriteria);
        callDefinitionResponseMap = callDefinitionResponseUtil
                .getUpstreamResponseSuccess(ProductScreenConstant.PRODUCT_INFO_CALL_DEFINITION_KEY, ProductScreenConstant.PRODUCT_INFO_INTERFACE_KEY,
                        BASE_PATH + "productInfo_success_1.json");
        // Then
        boolean status = productInfoInterfaceProcessor.preProcess(validatedRequest,
                genericCDProcessedData,callDefinitionResponseMap);
        // Verify
        assertFalse(status);
    }
}