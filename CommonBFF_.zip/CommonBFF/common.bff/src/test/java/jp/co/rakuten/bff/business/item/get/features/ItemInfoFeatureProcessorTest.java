package jp.co.rakuten.bff.business.item.get.features;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.constant.CallDefinitionResponseStatus;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.MultipleResponses;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.MockitoAnnotations.initMocks;

class ItemInfoFeatureProcessorTest {

	private ItemInfoFeatureProcessor itemInfoFeatureProcessor;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;

	@Mock
	private CommonRequestModel validatedClientData;

	@Mock
	private FeatureTemplate featureTemplate;


	@BeforeEach
	void setUp() {
		initMocks(this);
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		itemInfoFeatureProcessor = new ItemInfoFeatureProcessor();
	}


	@Test
	@DisplayName("If itemx call definition succeeded than ItemInfoFeatureProcessor should run properly")
	void testItemxCallDefinitionGGResponseCheck() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		String[] interfaces = {ItemXInfoConstants.ITEMX_INTERFACE_KEY,ItemXInfoConstants.INVENTORYX_INTERFACE_KEY};
		String[] files = {"mockfiles/responses/feature/item.get/itemx_success_1.json",
				"mockfiles/responses/feature/item.get/inventoryx/valid_inventory_x_response.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, interfaces, files));
		String[] interfaceNames = {ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY};
		String[] fileNames = {"mockfiles/responses/feature/item.get/gspGGResponseBodyMap.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY, interfaceNames, fileNames));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		assertTrue(featurePostProcessorResponse.isCacheable());
		assertEquals("501082", featurePostProcessorResponse.getResponseMap().get("shopId"));
		assertEquals("/0/my/genre/items", featurePostProcessorResponse.getResponseMap().get("genreIdList"));
		assertEquals("キュウエイバルフリーゼロイチ", featurePostProcessorResponse.getResponseMap().get("shopName"));
		assertEquals("_qavalfree01", featurePostProcessorResponse.getResponseMap().get("shopUrl"));
		assertEquals("https://item.rakuten.co.jp/_qavalfree01/ecsg_yama_tuujyoutaguari_oya2/",
				featurePostProcessorResponse.getResponseMap().get("itemUrl"));
		assertEquals("https://m.rakuten.co.jp/_qavalfree01/ecsg_yama_tuujyoutaguari_oya2/",
				featurePostProcessorResponse.getResponseMap().get("itemUrlMobile"));



		List<Map> varaintMapList =  (List<Map>)(featurePostProcessorResponse.getResponseMap().get("variants"));
		assertTrue(!varaintMapList.isEmpty());
		Map variantData = varaintMapList.get(0);
		assertNotNull(variantData);
		assertEquals("sku-ABC-001",variantData.get("sku"));
		assertTrue(variantData.containsKey("inventoryId"));
		assertTrue(variantData.containsKey("quantity"));
		assertEquals("41327d3a-6e44-43db-b7c7-83ec96881c99"
				,variantData.get("inventoryId"));
		assertEquals(100,variantData.get("quantity"));

		List<Map> imagesMapList = (List<Map>)(featurePostProcessorResponse.getResponseMap().get("images"));
		Map absoluteImageMap = imagesMapList.get(2);

		assertNotNull(absoluteImageMap);
		assertTrue(absoluteImageMap.containsKey("imageUrl"));
		assertTrue(absoluteImageMap.containsKey("type"));
		assertTrue(absoluteImageMap.containsKey("location"));
		assertTrue(absoluteImageMap.containsKey("thumbnailUrl"));
		assertEquals("https://thumbnail.image.rakuten.co.jp/@0_mall/book/cabinet/xxx.jpg",absoluteImageMap.get("thumbnailUrl"));

	}


	@Test
	@DisplayName("If itemx call definition succeeded than ItemInfoFeatureProcessor Coverage")
	void testItemxCallDefinitionGGResponseForCoverageOnly() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		String[] interfaces = {ItemXInfoConstants.INVENTORYX_INTERFACE_KEY,ItemXInfoConstants.ITEMX_INTERFACE_KEY};
		String[] files = {"mockfiles/responses/feature/item.get/itemx_success_4.json",
				"mockfiles/responses/feature/item.get/inventoryx/valid_inventory_x_response.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, interfaces, files));
		String[] interfaceNames = {ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY};
		String[] fileNames = {"mockfiles/responses/feature/item.get/gspGGResponseBodyMap.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY, interfaceNames, fileNames));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		assertTrue(featurePostProcessorResponse.isCacheable());
		assertEquals("273914", featurePostProcessorResponse.getResponseMap().get("shopId"));
	}


	@Test
	@DisplayName("If itemx call definition succeeded than ItemInfoFeatureProcessor Conditional Coverage")
	void testItemxCallDefinitionGGResponseForConditionalCoverage() {
		//Given
		Map<String, CallDefinitionResponse> callDefinitionResponseMap = new HashMap<>();
		String[] interfaces = {ItemXInfoConstants.ITEMX_INTERFACE_KEY};
		String[] files = {"mockfiles/responses/feature/item.get/itemx_success_2.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, interfaces, files));
		String[] interfaceNames = {ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY,ItemXInfoConstants.INVENTORYX_INTERFACE_KEY};
		String[] fileNames = {"mockfiles/responses/feature/item.get/gspGGResponseBodyMap1.json",
				"mockfiles/responses/feature/item.get/inventoryx/valid_inventory_x_response.json"};
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY, interfaceNames, fileNames));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, callDefinitionResponseMap);

		//Verify
		assertNotNull(responseMono);
		FeaturePostProcessorResponse featurePostProcessorResponse = responseMono.block();
		assertTrue(featurePostProcessorResponse.isCacheable());
		assertEquals("501082", featurePostProcessorResponse.getResponseMap().get("shopId"));
	}


	@Test
	@DisplayName("If itemx call definition failed than ItemInfoFeatureProcessor should throw BackendException")
	void testItemxCallDefinitionFailure() {
		//Given
		Map<String, CallDefinitionResponse> itemxResponse = callDefinitionResponseUtil.getUpstreamResponseFailed(
				ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, itemxResponse);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, () -> responseMono.block());
	}

	@Test
	@DisplayName("If itemx interface doesn't exist in GG response than ItemInfoFeatureProcessor should throw BackendException")
	void testItemxInterfaceDoesNotExistInGGResponse() {
		//Given
		CallDefinitionResponse callDefinitionResponse = new CallDefinitionResponse(
				CallDefinitionResponseStatus.SUCCESS);
		callDefinitionResponse.setInterfaceToRequestIdMap(Collections.emptyMap());
		callDefinitionResponse.setMultipleResponses(new MultipleResponses());
		Map<String, CallDefinitionResponse> itemxResponse = Map.of(ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY, callDefinitionResponse);

		//Then
		Mono<FeaturePostProcessorResponse> responseMono = itemInfoFeatureProcessor.postProcess(
				validatedClientData, featureTemplate, itemxResponse);

		//Verify
		assertNotNull(responseMono);
		assertThrows(BackendException.class, () -> responseMono.block());
	}

}
