package jp.co.rakuten.bff.business.itembookmark.list.processors.interfaces;


import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.testUtil.CallDefinitionResponseUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CouponByItemInterfaceProcessorTest {
	Map<String, CommonRequestModel> validatedRequest;
	private Map<String, CallDefinitionResponse> callDefinitionResponseMap;
	private CallDefinitionResponseUtil callDefinitionResponseUtil;
	private GenericCallDefinitionProcessedData genericCallDefinitionProcessedData;
	private String propValue = "true";
	private String propKey = "itembookmark.list.needCoupons.ecsgclient";
	String requestId;

	private CouponByItemInterfaceProcessor couponByItemInterfaceProcessor;

	@Mock
	Environment environment;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		callDefinitionResponseMap = new HashMap<>();
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		Map<String, Object> params = new HashMap<>();
		params.put(COUPON_FLAG, true);
		commonRequestModel.setParams(params);
		Map<String, Object> headers = new HashMap<>();
		headers.put(X_CLIENT_ID, "ecsgclient");
		commonRequestModel.setHeaders(headers);
		validatedRequest = Map.of(ITEM_BOOKMARK_LIST_INFO, commonRequestModel);
		requestId = UUID.randomUUID().toString();
		callDefinitionResponseUtil = new CallDefinitionResponseUtil();
		genericCallDefinitionProcessedData = new GenericCallDefinitionProcessedData();
		couponByItemInterfaceProcessor = new CouponByItemInterfaceProcessor(environment);
	}

	@AfterEach
	void tearDown() {
		couponByItemInterfaceProcessor = null;
	}

	@DisplayName("preProcess: validation passed and params loaded")
	@Test
	void preProcessSuccess() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_Success_1.json"));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		when(environment.getProperty(propKey)).thenReturn(propValue);
		when(environment.getProperty("itembookmark.list.couponByItem.max.request.item.size")).thenReturn("1");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_COUPON_BY_ITEM);
		innerMap.put("requestId", requestId);
		Map<String, Object> body = new HashMap<>();
		Map<String, Object> searchConditions = new HashMap<>();
		body.put("searchConditions", searchConditions);
		innerMap.put("body", body);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_COUPON_BY_ITEM, requestId, genericCDProcessedData);

		//When:
		boolean result = couponByItemInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		List<String> requestIdLit = genericCDProcessedData.getInterfaceToRequestIdMap().get(INTERFACE_NAME_COUPON_BY_ITEM);
		preparedRequest = genericCDProcessedData.getPreparedRequest();
		Map<String, Map<String, Object>> finalPreparedRequest = preparedRequest;
		requestIdLit.forEach(requestId->{
			Map<String, Object> interfaceRequest = finalPreparedRequest.get(requestId);
			assertFalse(interfaceRequest.isEmpty());
			Map<String, Object> bodyMap = (Map<String, Object>) interfaceRequest.get("body");
			Map<String, Object> searchCondition = (Map<String, Object>) bodyMap.get("searchConditions");
			List<Map<String, Object>> items = (List<Map<String, Object>>) searchCondition.get("items");
			assertEquals("couponByItem", interfaceRequest.get("interfaceKey"));
			assertNotNull(bodyMap);
			assertNotNull(searchCondition);
			assertNotNull(items);
			assertFalse(items.isEmpty());
			items.forEach(item-> {
				assertNotNull(item.get("itemId"));
				assertNotNull(item.get("itemTypeCode"));
				assertNotNull(item.get("shopId"));
				assertNotNull(item.get("shopTypeCode"));
			});
		});
		assertTrue(result);
		assertEquals(6, requestIdLit.size());
	}

	@DisplayName("preProcess: validation failed when couponFlag is false")
	@Test
	void preProcessWhenCouponFlagIsFalse() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_Success_1.json"));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		when(environment.getProperty(propKey)).thenReturn(propValue);
		when(environment.getProperty("itembookmark.list.couponByItem.max.request.item.size")).thenReturn("1");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_COUPON_BY_ITEM);
		innerMap.put("requestId", requestId);
		Map<String, Object> body = new HashMap<>();
		Map<String, Object> searchConditions = new HashMap<>();
		body.put("searchConditions", searchConditions);
		innerMap.put("body", body);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		Map<String, Object> params = validatedRequest.get(ITEM_BOOKMARK_LIST_INFO).getParams();
		params.put(COUPON_FLAG, false);
		mapInterfaceRequestId(INTERFACE_NAME_COUPON_BY_ITEM, requestId, genericCDProcessedData);

		//When:
		boolean result = couponByItemInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertFalse(result);

	}

	@DisplayName("preProcess: validation failed when coupon is not needed")
	@Test
	void preProcessWhenCouponIsNotNeeded() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_Success_1.json"));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		when(environment.getProperty(propKey)).thenReturn("false");
		when(environment.getProperty("itembookmark.list.couponByItem.max.request.item.size")).thenReturn("1");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_COUPON_BY_ITEM);
		innerMap.put("requestId", requestId);
		Map<String, Object> body = new HashMap<>();
		Map<String, Object> searchConditions = new HashMap<>();
		body.put("searchConditions", searchConditions);
		innerMap.put("body", body);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_COUPON_BY_ITEM, requestId, genericCDProcessedData);

		//When:
		boolean result = couponByItemInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertFalse(result);

	}

	@DisplayName("preProcess: validation failed when itembookmarkGet interface fails")
	@Test
	void preProcessWhenItemBookMarkGetInterfaceFailed() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_InvalidCase_1.json"));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		when(environment.getProperty(propKey)).thenReturn(propValue);
		when(environment.getProperty("itembookmark.list.couponByItem.max.request.item.size")).thenReturn("1");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_COUPON_BY_ITEM);
		innerMap.put("requestId", requestId);
		Map<String, Object> body = new HashMap<>();
		Map<String, Object> searchConditions = new HashMap<>();
		body.put("searchConditions", searchConditions);
		innerMap.put("body", body);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_COUPON_BY_ITEM, requestId, genericCDProcessedData);

		//When:
		boolean result = couponByItemInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertFalse(result);

	}

	@DisplayName("preProcess: validation failed when itembookmarkGet return empty items")
	@Test
	void preProcessWhenItemBookMarkGetInterfaceReturnEmptyItems() {
		//Given:
		callDefinitionResponseMap.putAll(
				callDefinitionResponseUtil.getUpstreamResponseSuccess(
						CALL_DEF_ITEM_BOOKMARK_GET_CD,
						INTERFACE_NAME_ITEM_BOOKMARK_GET,
						"mockfiles/responses/feature/itembookmark/list/itembookmarkGet_InvalidCase_2.json"));

		GenericCallDefinitionProcessedData genericCDProcessedData = new GenericCallDefinitionProcessedData();
		when(environment.getProperty(propKey)).thenReturn(propValue);
		when(environment.getProperty("itembookmark.list.couponByItem.max.request.item.size")).thenReturn("1");
		Map<String, Map<String, Object>> preparedRequest = new HashMap<>();
		Map<String, Object> innerMap = new HashMap<>();
		innerMap.put("interfaceKey", INTERFACE_NAME_COUPON_BY_ITEM);
		innerMap.put("requestId", requestId);
		Map<String, Object> body = new HashMap<>();
		Map<String, Object> searchConditions = new HashMap<>();
		body.put("searchConditions", searchConditions);
		innerMap.put("body", body);
		preparedRequest.put(requestId, innerMap);
		genericCDProcessedData.setPreparedRequest(preparedRequest);
		mapInterfaceRequestId(INTERFACE_NAME_COUPON_BY_ITEM, requestId, genericCDProcessedData);

		//When:
		boolean result = couponByItemInterfaceProcessor.
				preProcess(validatedRequest, genericCDProcessedData, callDefinitionResponseMap);

		//Then:
		assertFalse(result);

	}

	private void mapInterfaceRequestId(String interfaceMap, String requestId,
									   GenericCallDefinitionProcessedData genericCallDefinitionProcessedData) {
		Map<String, List<String>> map = new HashMap<>();
		map.put(interfaceMap, Collections.singletonList(requestId));
		genericCallDefinitionProcessedData.setInterfaceToRequestIdMap(map);
	}
}
