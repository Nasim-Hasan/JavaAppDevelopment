package jp.co.rakuten.bff.business.productscreen.get.validator;

import jp.co.rakuten.bff.business.item.get.validators.ItemInfoValidator;
import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.business.productscreen.get.validators.ProductInfoValidator;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ProductInfoValidatorTest {

	List<FeatureTemplate> featureTemplateList;
	FeatureTemplate itemInfoFeature;

	@BeforeEach
	void setUp() {
		itemInfoFeature = new FeatureTemplate();
		itemInfoFeature.setName(PRODUCT_INFO_FEATURE_KEY);
		featureTemplateList = List.of(itemInfoFeature);
	}

	@ParameterizedTest
	@DisplayName("Should not throw FeatureException if input is proper")
	@CsvSource(value = {
			// shopId	|	itemId	|	manageNumber	|	itemCode		|	itemUrl
			" 	123		| 	1234 	|					|					|			",
			"  	123		| 		 	|		1234		|				    |			",
			"  	123		| 		 	|					|minatofarm:10000014|			",
			" 	123		| 		 	|					|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 		 	|					|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 	1234 	|					|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 	 		|		1234		|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 	1234 	|		1234		|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 	1234 	|		1234		|					|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 		 	|					|minatofarm:10000014|			",
			" 			| 		 	|					|minatofarm:10000014|			",
			" 			| 	1234	|					|minatofarm:10000014|			",
			" 			| 			|		1234		|minatofarm:10000014|			",
			" 			| 	1234	|		1234		|minatofarm:10000014|			",
			" 	123		| 	1234	|		1234		|minatofarm:10000014|			",
			" 			| 		 	|					|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 		 	|		1234		|				    |			",
			" 	123		| 	1234 	|		1234		|					|			",
			" 	123		| 	1234 	|		1234		|minatofarm:10000014|			",
			" 	123		| 	1234 	|		1234		|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 	1234 	|					|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 		 	|		1234		|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 		 	|		1234		|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 		 	|		1234		|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 	1234 	|					|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 	123		| 		 	|					|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",
			" 			| 	123	 	|		123			|minatofarm:10000014|https://item.rakuten.co.jp/bosekk/quietcomfort25	",

	}, delimiter = '|')
	void testOkInput(Integer shopId, Integer itemId, String manageNumber, String itemCode, String itemUrl) {
		CommonRequestModel commonRequestModel =
				prepareCommonRequestModel(shopId, itemId, manageNumber, itemCode, itemUrl);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(PRODUCT_INFO_FEATURE_KEY, commonRequestModel);
		ClientRequestModel clientRequestModel = new ClientRequestModel();

		assertDoesNotThrow(
				() -> new ProductInfoValidator().validate(validatedRequest, featureTemplateList, clientRequestModel));
	}


	@ParameterizedTest
	@DisplayName("Should  throw FeatureException if input is not proper")
	@CsvSource(value = {
			// shopId	|	itemId	|	manageNumber	|	itemCode	|	itemUrl
			" 			| 		 	|					|				|			",
			" 	123		| 		 	|					|				|			",
			"  			| 	1234 	|		1234		|				|			",
			"  			| 	1234 	|					|				|			",
			" 			| 		 	|		1234		|				|			",
			" 			| 		 	|		1234		|	1245		|	1234	",
	}, delimiter = '|')
	void testErrorInput(Integer shopId, Integer itemId, String manageNumber, String itemCode, String itemUrl) {
		//Given
		CommonRequestModel commonRequestModel =
				prepareCommonRequestModel(shopId, itemId, manageNumber, itemCode, itemUrl);
		Map<String, CommonRequestModel> validatedRequest = new HashMap<>();
		validatedRequest.put(PRODUCT_INFO_FEATURE_KEY, commonRequestModel);
		ClientRequestModel clientRequestModel = new ClientRequestModel();

		//Then+Verify
		assertThrows(FeatureException.class,
				() -> new ProductInfoValidator().validate(validatedRequest, featureTemplateList, clientRequestModel));
	}

	private CommonRequestModel prepareCommonRequestModel(Integer shopId, Integer itemId, String manageNumber, String itemCode, String itemUrl) {
		Map<String, Object> paramMap = new HashMap<>();
		if (Objects.nonNull(shopId)) {
			paramMap.put(SHOP_ID, shopId);
		}
		if (Objects.nonNull(itemId)) {
			paramMap.put(ITEM_ID, itemId);
		}
		if (Objects.nonNull(manageNumber)) {
			paramMap.put(MANAGE_NUMBER, manageNumber);
		}
		if (Objects.nonNull(itemCode)) {
			paramMap.put(ITEM_CODE, itemCode);
		}
		if (Objects.nonNull(itemUrl)) {
			paramMap.put(ITEM_URL, itemUrl);
		}
		CommonRequestModel commonRequestModel = new CommonRequestModel();
		commonRequestModel.setParams(paramMap);
		return commonRequestModel;
	}
}