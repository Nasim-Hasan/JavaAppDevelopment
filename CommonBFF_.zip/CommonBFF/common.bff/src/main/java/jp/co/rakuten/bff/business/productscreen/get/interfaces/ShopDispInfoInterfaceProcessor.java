package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.business.productscreen.get.logic.ProductScreenLogic;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("ShopDispInfoInterfaceProcessor")
public class ShopDispInfoInterfaceProcessor implements InterfaceProcessor {
    @Override
    public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
                              GenericCallDefinitionProcessedData genericCDProcessedData,
                              Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        Map<String, Object> shopDispRequestMap
                = genericCDProcessedData.getRequestByInterface(SHOP_DISP_INTERFACE);
        CommonRequestModel commonRequestModel = validatedRequest.get(PRODUCT_INFO_FEATURE_KEY);

        Map<String, Object> params = commonRequestModel.getParams();
        Map<String, Object> shopDispUrlParams = new HashMap<>();
        String itemCode = (String) params.get(ITEM_CODE);
        String itemUrl = (String) params.get(ITEM_URL);

        if (ObjectUtils.isNotEmpty(itemCode)) {
            shopDispUrlParams.put(SHOP_URL, StringUtils.split(itemCode, ":")[0]);
            shopDispRequestMap.put(URL_PARAMETERS, shopDispUrlParams);
        } else if (ObjectUtils.isNotEmpty(itemUrl)) {
            shopDispUrlParams.put(SHOP_URL, StringUtils.split(itemUrl, "/")[2]);
            shopDispRequestMap.put(URL_PARAMETERS, shopDispUrlParams);
        }

        if (!ProductScreenLogic.modifyParentRequest(genericCDProcessedData, PRODUCT_INFO_INTERFACE_KEY, SHOP_DISP_INTERFACE, DEPENDENCY_CONDITION)) {
            return false;
        }
        return true;
    }
}
