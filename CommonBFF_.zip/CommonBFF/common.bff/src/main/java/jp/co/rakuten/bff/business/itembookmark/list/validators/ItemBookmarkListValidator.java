package jp.co.rakuten.bff.business.itembookmark.list.validators;

import jp.co.rakuten.bff.business.common.validators.EasyIdValidator;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * ItemBookmarkList Validator
 * This validator validates ItemBookmarkList request
 */
@Component("ItemBookmarkListValidator")
public class ItemBookmarkListValidator implements CustomValidator {
	@Override
	public Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
			List<FeatureTemplate> featureTemplateList, ClientRequestModel actualRequest) {
		EasyIdValidator.validate(validatedData.get("itemBookmarkListInfo"));
		return validatedData;
	}
}
