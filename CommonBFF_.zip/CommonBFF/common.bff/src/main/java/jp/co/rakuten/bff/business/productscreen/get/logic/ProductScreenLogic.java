package jp.co.rakuten.bff.business.productscreen.get.logic;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;
import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.ITEM_ID;

public class ProductScreenLogic {
    public static Boolean isShopMasterCallNeeded(Map<String, CommonRequestModel> validatedRequest) {
        CommonRequestModel commonRequestModel = validatedRequest.get(PRODUCT_INFO_FEATURE_KEY);

        Map<String, Object> params = commonRequestModel.getParams();
        String itemMangeNumber = (String) params.get(MANAGE_NUMBER);
        Integer shopId = (Integer) params.get(SHOP_ID);
        Integer itemId = (Integer) params.get(ITEM_ID);

        return !(ObjectUtils.isNotEmpty(shopId)
                && (StringUtils.isNotBlank(itemMangeNumber) || ObjectUtils.isNotEmpty(itemId)));
    }

    public static Integer getShopIdFromProductInfo(Map<String, CommonRequestModel> validatedRequest) {
        CommonRequestModel commonRequestModel = validatedRequest.get(PRODUCT_INFO_FEATURE_KEY);

        Map<String, Object> params = commonRequestModel.getParams();
        return (Integer) params.get(SHOP_ID);
    }

    public static Boolean shouldShowChildFeatrue(Map<String, CommonRequestModel> validatedRequest,
                                                 Map<String, CallDefinitionResponse> callDefinitionResponseMap,
                                                 Integer dispTypeParam, Integer dispIdParam) {
        Integer shopId = getShopIdFromProductInfo(validatedRequest);
        Map<String, Object> shopDispInfo = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
                SHOP_DISP_INTERFACE,
                PRODUCT_INFO_CALL_DEFINITION_KEY);
        ArrayList<Map<String, Object>> shopDispDetails = (ArrayList) shopDispInfo.get(SHOP_DISP_INTERFACE_KEY);
        List<Map<String, Object>> shopDispFilterList = shopDispDetails.stream().filter(obj -> obj.get("shopId")
                .equals(shopId)).collect(Collectors.toList());
        if (!shopDispFilterList.isEmpty()) {
            for (int i = 0; i < shopDispFilterList.size(); i++) {
                Integer dispId = (Integer) shopDispFilterList.get(i).get(DISP_ID);
                Integer dispType = (Integer) shopDispFilterList.get(i).get(DISP_TYPE);
                if (dispType == dispTypeParam && dispId == dispIdParam) return false;
            }
        }
        return true;
    }

    public static boolean modifyParentRequest(GenericCallDefinitionProcessedData genericCDProcessedData,
                                              String parentInterfaceKey, String childInterfaceKey, String property) {
        List list = genericCDProcessedData.getInterfaceToRequestIdMap().get(parentInterfaceKey);

        if (CollectionUtils.isEmpty(list) ||
                Objects.isNull(genericCDProcessedData.getPreparedRequest().get(list.iterator().next()))) {
            return false;
        }

        Map<String, Object> shopDispRequest = genericCDProcessedData.getRequestByInterface(childInterfaceKey);
        if (MapUtils.isNotEmpty(shopDispRequest)) {
            List<Map<String, Object>> dependencyConditions = (List<Map<String, Object>>) shopDispRequest.get(property);
            String requestId = (String) list.iterator().next();
            dependencyConditions.forEach(parameterlink -> parameterlink.put(PARENT_REQUEST_ID, requestId));
        } else {
            return false;
        }
        return true;
    }

    public static void setShopIdItemId(GenericCallDefinitionProcessedData genericCDProcessedData,
                                       Map<String, CallDefinitionResponse> callDefinitionResponseMap,
                                       String targetInterface) {
        Map<String, Object> productInfoResponse = InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap.get(PRODUCT_INFO_CALL_DEFINITION_KEY), PRODUCT_INFO_INTERFACE_KEY, PRODUCT_INFO_CALL_DEFINITION_KEY);
        Map<String, Object> gspItemReviewProcessData = (Map) ((Map) genericCDProcessedData.getRequestByInterface(targetInterface)).get(URL_PARAMETERS);
        gspItemReviewProcessData.put(SHOP_ID, productInfoResponse.get(SHOP_ID));
        gspItemReviewProcessData.put(ITEM_ID, productInfoResponse.get(ITEM_ID));
    }

    public static Boolean isValidItemUrl(String itemURL) {
        if (ObjectUtils.isEmpty(itemURL)) return true;
        return StringUtils.split(itemURL, "/").length == 4;
    }

    public static Boolean isValidItemCode(String itemCode) {
        if (ObjectUtils.isEmpty(itemCode)) return true;
        return StringUtils.split(itemCode, ":").length == 2;
    }
}
