package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.exception.ParameterResolveException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.URL_PARAMETERS;


/**
 * GspItemKvsInfo Interface processor
 * <br>
 * Contains custom processor logic for GspItemKvsInfo Endpoint
 */
@Component("GspItemKvsInfoInterfaceProcessor")
public class GspItemKvsInfoInterfaceProcessor implements InterfaceProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(GspItemKvsInfoInterfaceProcessor.class);
	private Environment env;


	/**
	 * Parameterised constructor
	 *
	 * @param env {@link Environment}
	 */
	@Autowired
	public GspItemKvsInfoInterfaceProcessor(Environment env) {
		this.env = env;
	}

	/**
	 * it will modify generically prepared request based on custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	@Override
	public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {

		Map<String, Object> itemResponse =
			InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
					ItemXInfoConstants.ITEMX_INTERFACE_KEY,
					ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);
	Object itemId = itemResponse.get(ItemXInfoConstants.ITEM_ID);
			if (null != itemId) {
		Map<String, Object> urlParams = getUrlParams(genericCDProcessedData);
		String sid = env.getProperty(ItemXInfoConstants.CONF_KEY_GSP + "sid", String.class);
		String authKey = env.getProperty(ItemXInfoConstants.CONF_KEY_GSP + "authKey", String.class);
		if (StringUtils.isBlank(sid) || StringUtils.isBlank(authKey)) {
			LOGGER.info("sid or authKey or hits is null - interface '{}' - call definition '{}' - urlParams {}",
					ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY,
					ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY, urlParams);
			return false;
		}
		urlParams.put("sid", sid);
		urlParams.put("authKey", authKey);

		List<String> columns = getPropValueAsStringList("columns");
		if(CollectionUtils.isNotEmpty(columns)) {
			urlParams.put("column", columns);
		}
		urlParams.put(ItemXInfoConstants.ITEM_ID, itemId);
		return true;
	}

		return false;
}

	//process the column list from properties
	private List<String> getPropValueAsStringList(String propkey) {
		String listItems = env.getProperty(ItemXInfoConstants.CONF_KEY_GSP + propkey);
		if (Objects.nonNull(listItems)) {
			return Arrays.asList(listItems.split(","));
		}
		return Collections.emptyList();
	}

	//fetch the url params from GSPItem Interface Map
	private Map<String, Object> getUrlParams(GenericCallDefinitionProcessedData genericCDProcessedData) {
		Map<String, Object> gspItemKvsRequestMap = genericCDProcessedData.getRequestByInterface(
				ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY);
		if (MapUtils.isEmpty(gspItemKvsRequestMap)) {
			throw new ParameterResolveException(ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY +
					" interface missing in GenericCallDefinitionProcessedData " +
					"- call definition " + ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
		} else {
			Map<String, Object> urlParams = (Map<String, Object>) gspItemKvsRequestMap.get(URL_PARAMETERS);
			if (MapUtils.isEmpty(urlParams)) {
				throw new ParameterResolveException(
						"urlParameters is missing in GenericCallDefinitionProcessedData - interface " +
								ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY + " - call definition "
								+ ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
			}

			return urlParams;
		}
	}
}
