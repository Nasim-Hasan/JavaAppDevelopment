package jp.co.rakuten.bff.business.item.get.constants;

/**
 * Feature related constant file
 * <br>
 * Contains all global constants related to ItemXInfoConstants
 */
public class ItemXInfoConstants {

	public static final String ITEM_INFO_FEATURE_KEY = "itemInfo";
	public static final String GSP_INVENTORY_CALL_DEFINITION_KEY = "gspInventoryInfo";
	public static final String GSP_ITEM_KVS_INTERFACE_KEY = "gspItemKvsInfo";
	public static final String INVENTORYX_INTERFACE_KEY = "inventoryXInfo";
	public static final String ITEMX_INTERFACE_KEY = "itemXInfo";
	public static final String ITEMX_INVENTORY_CALL_DEFINITION_KEY = "itemInventoryInfo";
	public static final String EXCEPTION_MESSAGE_PARAM_RESOLVE =
			"Either of the request set is required shopId+itemId or shopID+manageNumber";
	public static final String CONF_KEY_GSP = "itemInfo.gspItemKvs.api.";

	public static final String GOLD_URL = "https://www.rakuten.ne.jp/gold/%s%s";
	public static final String THUMBNAIL_GOLD_URL = "https://thumbnail.image.rakuten.co.jp/@0_gold/%s%s";
	public static final String CABINET_URL = "https://image.rakuten.co.jp/%s/cabinet%s";
	public static final String THUMBNAIL_CABINET_URL = "https://thumbnail.image.rakuten.co.jp/@0_mall/%s/cabinet%s";

	public static final String ITEM_ID = "itemId";
	public static final String MANAGE_NUMBER = "manageNumber";
	public static final String LOCALE = "locale";
	public static final String ITEMX_TAGLINE = "tagline";
	public static final String DEVICE_TYPE = "deviceType";
	public static final String ITEMX_TITLE = "title";
	public static final String ITEMX_PRODUCT_DESCRIPTION = "productDescription";
	public static final String ITEMX_SALES_DESCRIPTION = "salesDescription";
	public static final String ITEMX_IMAGES = "images";
	public static final String ITEMX_PRECAUTIONS = "precautions";
	public static final String ITEMX_DESCRIPTION = "description";
	public static final String ITEMX_AGREEMENT = "agreement";
	public static final String ITEMX_VIDEO = "video";
	public static final String ITEMX_SUBSCRIPTION = "subscription";
	public static final String ITEMX_PURCHASE_DESCRIPTION = "purchaseDescription";
	public static final String ITEMX_BUYING_CLUB = "buyingClub";
	public static final String ITEMX_CUSTOMIZATION_OPTIONS = "customizationOptions";
	public static final String ITEMX_LABEL = "label";
	public static final String ITEMX_CUSTOMIZATION_OPTIONS_SELECTIONS = "customizationOptions.selections";
	public static final String ITEMX_DISPLAY_VALUE = "displayValue";
	public static final String ITEMX_ITEMS = "items";
	public static final String ITEMX_VARIANTS = "variants";
	public static final String ITEMX_VARIANT_SELECTORS = "variantSelectors";
	public static final String ITEMX_I_18_N = "i18n";
	public static final String ITEMX_VARIANT_SELECTORS_VALUES = "variantSelectors.values";
	public static final String ITEMX_VALUE = "value";


	private ItemXInfoConstants() {
	}
}
