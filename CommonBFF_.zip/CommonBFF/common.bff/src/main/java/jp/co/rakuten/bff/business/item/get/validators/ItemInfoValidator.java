package jp.co.rakuten.bff.business.item.get.validators;

import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.EXCEPTION_MESSAGE_PARAM_RESOLVE;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.ITEM_ID;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.ITEM_INFO_FEATURE_KEY;
import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.MANAGE_NUMBER;

/**
 * This class performs basic validation of the Item X Info features request.
 *
 * @author yugansh.bhola
 */
@Component("ItemInfoValidator")
public class ItemInfoValidator  implements CustomValidator {

	@Override
	public Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
			List<FeatureTemplate> featureTemplateList,
			ClientRequestModel actualRequest) {

		CommonRequestModel 	commonRequestModel = validatedData.	get(ITEM_INFO_FEATURE_KEY);
		if (ObjectUtils.isEmpty(commonRequestModel) || MapUtils.isEmpty(commonRequestModel.getParams())) {
			throw FeatureException.create(ITEM_INFO_FEATURE_KEY, EXCEPTION_MESSAGE_PARAM_RESOLVE);
		}
		Map<String, Object> params = commonRequestModel.getParams();
		String itemMangeNumber = (String) params.get(MANAGE_NUMBER);

		if ((StringUtils.isBlank(itemMangeNumber) && (!params.containsKey(ITEM_ID) || (int)params.get(ITEM_ID)<=0))) {
			throw FeatureException.create(ITEM_INFO_FEATURE_KEY, EXCEPTION_MESSAGE_PARAM_RESOLVE);
		}

		return validatedData;
	}
}
