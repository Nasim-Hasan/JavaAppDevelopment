package jp.co.rakuten.bff.business.itembookmark.list.logic;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;

/**
 * Responsible to process ItemBookmarkListInfo feature data.
 * It is used in ItemBookmarkListInfo feature Processor
 */
@Component
public class ItemBookMarkListInfoLogic {
	private CouponResponseLogic couponResponseLogic;
	private static final Logger LOGGER = LoggerFactory.getLogger(ItemBookMarkListInfoLogic.class);
	public static final boolean IS_BY_ITEM = true;

	/**
	 * Parameterised constructor
	 *
	 * @param couponResponseLogic {@link CouponResponseLogic}
	 */
	@Autowired
	public ItemBookMarkListInfoLogic(CouponResponseLogic couponResponseLogic) {
		this.couponResponseLogic = couponResponseLogic;
	}

	/**
	 * Responsible to add coupons at itembookmark item
	 *
	 * @param callDefinitionResponseMap all upstream responses.
	 * @param itemBookmarkGetInterfaceResponse response of itembookmarkGet interface
	 */
	public void addCouponsToItemBookMarkItems(Map<String, CallDefinitionResponse> callDefinitionResponseMap,
			Map<String, Object> itemBookmarkGetInterfaceResponse ) {
		try {
			List<Map<String, Object>> itemBookMarkList =
					(List<Map<String, Object>>) itemBookmarkGetInterfaceResponse.get(DATA);
			Map<String, Map<String, Object>> couponByItemAllInterfaceResponses = InterfaceUtil.getInterfaceAllResponses(
					callDefinitionResponseMap, INTERFACE_NAME_COUPON_BY_ITEM, CALL_DEF_COUPONS_BY_ITEM_CD);
			Map<String, Object> couponResponseMap = new HashMap<>();
			for(Map<String, Object> couponByItemInterfaceResponse: couponByItemAllInterfaceResponses.values()) {
				if(MapUtils.isNotEmpty(couponByItemInterfaceResponse)) {
					List<Map<String, Object>> items
							= (List<Map<String, Object>>) couponByItemInterfaceResponse.get(ITEMS);
					prepareCouponResponseMap(couponResponseMap, items);
				}
			}
			appendCouponToItemBookMark(couponResponseMap, itemBookMarkList);
		} catch (Exception ex) {
			LOGGER.error("Exception while preparing coupons at itembookmark list: {}", ex.getMessage());
		}
	}

	private void appendCouponToItemBookMark(Map<String, Object> couponResponseMap,
			List<Map<String, Object>> itemBookMarkList) {
		itemBookMarkList.forEach(itemBookMark -> {
			int itemId = (int) itemBookMark.getOrDefault(ITEM_ID, 0);
			int shopId = (int) itemBookMark.getOrDefault(SHOP_ID, 0);
			String key = buildKey(String.valueOf(itemId), String.valueOf(shopId));
			if (couponResponseMap.containsKey(key)) {
				itemBookMark.put(COUPONS, couponResponseMap.get(key));
			}
		});

	}

	private void prepareCouponResponseMap(Map<String, Object> couponResponseMap, List<Map<String, Object>> items) {
		items.forEach(item -> {
			if (item.get(COUPONS) != null) {
				String key = buildKey(String.valueOf(item.get(ITEM_ID)), String.valueOf(item.get(SHOP_ID)));
				List<Map<String, Object>> rawCoupons = (List<Map<String, Object>>) item.get(COUPONS);
				couponResponseMap.put(key, buildCouponResponse(rawCoupons));
			}
		});
	}

	private String buildKey(String itemId, String shopId) {
		return itemId + SEPARATOR + shopId;
	}

	private List<Map<String, Object>> buildCouponResponse(List<Map<String, Object>> rawCoupons) {
		List<Map<String, Object>> coupons = new ArrayList<>();
		rawCoupons.forEach(rawCoupon -> {
			Map<String, Object> coupon = couponResponseLogic.prepareCoupon(rawCoupon, IS_BY_ITEM);
			if (MapUtils.isNotEmpty(coupon)) {
				coupons.add(coupon);
			}
		});
		return coupons;
	}
}
