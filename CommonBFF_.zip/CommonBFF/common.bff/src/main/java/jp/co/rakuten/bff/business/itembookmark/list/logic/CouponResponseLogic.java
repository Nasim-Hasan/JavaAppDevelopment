package jp.co.rakuten.bff.business.itembookmark.list.logic;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;

/**
 * CouponResponseLogic process coupon response
 */
@Component
public class CouponResponseLogic {
	private static final Integer COUPON_SINGLE_ITEM = 1;
	private static final Integer COUPON_PLURAL_ITEM = 3;
	private static final Integer COUPON_ALL_ITEM = 4;
	private static final int COUPON_SERVICE_ID_30 = 30;
	private static final int COUPON_SERVICE_ID_41 = 41;
	private static final Integer COUPON_FIXED_AMOUNT = 1;
	private static final Integer COUPON_FIXED_RATE = 2;

	private static final Logger LOGGER = LoggerFactory.getLogger(CouponResponseLogic.class);
	private Environment env;

	/**
	 * Parameterised constructor
	 *
	 * @param env {@link Environment}
	 */
	public CouponResponseLogic(Environment env) {
		this.env = env;
	}

	/**
	 * Get formatted value for price value
	 *
	 * @param value value
	 * @return Formatted price
	 */
	private String getFormattedValue(int value) {
		String strPrice;
		DecimalFormat formatter = new DecimalFormat(COUPON_PRICE_FORMAT);
		double price = Double.parseDouble(String.valueOf(value));
		strPrice = formatter.format(price);
		return strPrice;
	}

	/**
	 * Process item type
	 *
	 * @param rawCouponResponse  Each coupon response from generic gateway
	 * @param termsOfUseBuilder  Terms of use string builder
	 * @param termOfuseSeparator Terms of use separator character
	 */
	private void processItemType(Map<String, Object> rawCouponResponse,
								 StringBuilder termsOfUseBuilder,
								 String termOfuseSeparator) {
		String designatedProductTarget = env.getProperty(PROP_KEY_DESIGNATED_PRODUCT_TARGET);
		String applicableToDesignatedStores = env.getProperty(PROP_KEY_APPLICABLE_TO_DESIGNATED_STORES);
		Object itemTypeObj = rawCouponResponse.get(ITEM_TYPE);
		try {
			if (Objects.nonNull(itemTypeObj)) {
				int itemType = NumberUtils.toInt(String.valueOf(itemTypeObj), -1);
				if ((itemType == COUPON_SINGLE_ITEM) || (itemType == COUPON_PLURAL_ITEM)) {
					termsOfUseBuilder.append(designatedProductTarget).append(termOfuseSeparator);
				} else if (itemType == COUPON_ALL_ITEM) {
					termsOfUseBuilder.append(applicableToDesignatedStores)
							.append(termOfuseSeparator);
				}
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponResponseLogic] [processMemberAvailMaxCount] Exception while processing " +
								"item type. designatedProductTarget: {}, applicableToDesignatedStores: {}, itemType: {}, Error: {}",
						designatedProductTarget, applicableToDesignatedStores, itemTypeObj, ex.getMessage());
		}
	}

	/**
	 * Process member available max count
	 *
	 * @param rawCouponResponse  Each coupon response from generic gateway
	 * @param termsOfUseBuilder  Terms of use string builder
	 * @param termOfuseSeparator Terms of use separator character
	 */
	private void processMemberAvailMaxCount(Map<String, Object> rawCouponResponse,
											StringBuilder termsOfUseBuilder,
											String termOfuseSeparator) {
		String onePersonUpToTimes = env.getProperty(PROP_KEY_ONE_PERSON_UP_TO_TIMES);
		Object memberAvailMaxCountObj = rawCouponResponse.get(MEMBER_AVAIL_MAX_COUNT);
		try {
			if (Objects.nonNull(memberAvailMaxCountObj)) {
				int memberAvailMaxCount = NumberUtils.toInt(String.valueOf(memberAvailMaxCountObj), -1);
				if (memberAvailMaxCount > 0) {
					termsOfUseBuilder
							.append(onePersonUpToTimes.replace("{}", ""
									+ getFormattedValue(memberAvailMaxCount)))
							.append(termOfuseSeparator);
				}
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponResponseLogic] [processMemberAvailMaxCount] Exception while processing member " +
								"available max count. onePersonUpToTimes: {}, memberAvailMaxCountObj: {}, Error: {}",
						onePersonUpToTimes, memberAvailMaxCountObj, ex.getMessage());
		}
	}

	/**
	 * Process Issue count
	 *
	 * @param rawCouponResponse  Each coupon response from generic gateway
	 * @param termsOfUseBuilder  Terms of use string builder
	 * @param termOfuseSeparator Terms of use separator character
	 */
	private void processIssueCount(Map<String, Object> rawCouponResponse,
								   StringBuilder termsOfUseBuilder,
								   String termOfuseSeparator) {
		String firstArrivalUnitName = env.getProperty(PROP_KEY_FIRST_ARRIVAL_UNTIL_NAME);
		Object issueCountObj = rawCouponResponse.get(ISSUE_COUNT);

		try {
			if (Objects.nonNull(issueCountObj)) {
				int issueCount = NumberUtils.toInt(String.valueOf(issueCountObj), -1);
				if (issueCount > 0) {
					termsOfUseBuilder.append(firstArrivalUnitName.replace("{}", "" + getFormattedValue(issueCount)))
							.append(termOfuseSeparator);
				}
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponResponseLogic] [processIssueCount] Exception while processing issue count. " +
								"firstArrivalUnitName: {}, issueCountObj: {}, Error: {}", firstArrivalUnitName, issueCountObj, ex.getMessage());
		}
	}

	/**
	 * Prepare coupon's terms of use's other condition
	 *
	 * @param rawCouponResponse  Each coupon response from generic gateway
	 * @param termsOfUseBuilder  Terms of use string builder
	 * @param termOfUseSeparator Terms of use separator character
	 * @param isByItem Weather it is called for coupon by item or not
	 */
	private void processOtherCondition(Map<String, Object> rawCouponResponse,
									   StringBuilder termsOfUseBuilder,
									   String termOfUseSeparator, boolean isByItem) {
		String rs001Separator = env.getProperty(PROP_KEY_TERM_OF_USE_RS001_SEPARATOR);

		Map<String, String> rs003And004 = new HashMap<>();
		Map<Integer, String> rs001Terms = new TreeMap<>();
		List<Map<String, Object>> otherConds = (List<Map<String, Object>>) rawCouponResponse.get("otherConds");
		for (Map<String, Object> otherCond : otherConds) {
			processIndividualOtherCond(rs003And004, rs001Terms, otherCond, isByItem);
		}

		if (rs003And004.containsKey(COUPON_RS004)) {
			termsOfUseBuilder.append(rs003And004.get(COUPON_RS004)).append(termOfUseSeparator);
		} else if (rs003And004.containsKey(COUPON_RS003)) {
			termsOfUseBuilder.append(rs003And004.get(COUPON_RS003)).append(termOfUseSeparator);
		}

		if (!isByItem && rs001Terms.size() > 0) {
			termsOfUseBuilder.append(String.join(rs001Separator, rs001Terms.values())).append(termOfUseSeparator);
		}
	}


	/**
	 * Process individual other condition
	 *
	 * @param rs003And004 RS003 & RS004 type coupon's terms map
	 * @param rs001Terms  RS001 type coupon's different start value terms map
	 * @param otherCond   Other condition map
	 */
	private void processIndividualOtherCond(Map<String, String> rs003And004,
											Map<Integer, String> rs001Terms,
											Map<String, Object> otherCond, boolean isByItem) {
		String availableAtLeast = env.getProperty(PROP_KEY_AVAILABLE_AT_LEAST);
		String couponAvialbleInYen = env.getProperty(PROP_KEY_AVAILABLE_IN_YEN);
		String rs001Computer = env.getProperty(PROP_KEY_TERM_OF_USE_RS001_COMPUTER);
		String rs001Smartphone = env.getProperty(PROP_KEY_TERM_OF_USE_RS001_SMARTPHONE);
		Map<Integer, String> rs001Values = new HashMap<>();
		rs001Values.put(0, rs001Computer);
		rs001Values.put(1, rs001Smartphone);

		try {
			String otherCondTypeCd = String.valueOf(otherCond.get(OTHER_COND_TYPE_CD));
			if (COUPON_RS004.equalsIgnoreCase(otherCondTypeCd)) {
				int startValue = NumberUtils.toInt(String.valueOf(otherCond.get(START_VALUE_KEY)), -1);
				if (startValue > 0) {
					rs003And004.put(COUPON_RS004,
									availableAtLeast.replace("{}", getFormattedValue(startValue)));
				}
			} else if (COUPON_RS003.equalsIgnoreCase(otherCondTypeCd)) {
				int startValue = NumberUtils.toInt(String.valueOf(otherCond.get(START_VALUE_KEY)), -1);
				if (startValue > 0) {
					rs003And004.put(COUPON_RS003,
									couponAvialbleInYen.replace("{}", getFormattedValue(startValue)));
				}
			} else if (!isByItem && COUPON_RS001.equalsIgnoreCase(otherCondTypeCd)) {
				int startValue = NumberUtils.toInt(String.valueOf(otherCond.get(START_VALUE_KEY)), -1);
				if ((startValue == 0) || (startValue == 1)) {
					rs001Terms.put(startValue, rs001Values.get(startValue));
				}
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponByShopResponseProcessor] [processOtherCondition] " +
								"Exception while processing otherConds: {}, Error: {}", otherCond, ex.getMessage());
		}
	}

	/**
	 * Prepare coupon
	 *
	 * @param rawCouponResponse {@link Map} Each coupon response from generic gateway
	 * @param isByItem          is for item ori not
	 * @return Map<String, Object>  processed coupon
	 */
	public Map<String, Object> prepareCoupon(Map<String, Object> rawCouponResponse, boolean isByItem) {
		Map<String, Object> coupon = new HashMap<>();
		if (checkAndAddDiscountTitle(coupon, rawCouponResponse)) {
			coupon.put(COUPON_ID, rawCouponResponse.get(COUPON_ID));
			coupon.put("couponCode", rawCouponResponse.get(COUPON_CODE));
			coupon.put(COUPON_NAME, rawCouponResponse.get(COUPON_NAME));
			coupon.put(ACQUIRED, rawCouponResponse.get(ACQUIRED));
			coupon.put(TERMS_OF_USE, prepareTermsOfUse(rawCouponResponse, isByItem));
			coupon.put(COUPON_START_DATE, rawCouponResponse.get(COUPON_START_DATE));
			coupon.put(COUPON_END_DATE, rawCouponResponse.get(COUPON_END_DATE));
			addServiceInfo(coupon, rawCouponResponse);
		}
		return coupon;
	}

	private void addServiceInfo(Map<String, Object> coupon, Map<String, Object> rawCouponResponse) {
		if (isItemExists(rawCouponResponse, SERVICE_ID)) {
			coupon.put(COUPON_SERVICE_ID, rawCouponResponse.get(SERVICE_ID));
			addCouponServiceLabel(coupon, rawCouponResponse);
		}
	}

	private void addCouponServiceLabel(Map<String, Object> coupon, Map<String, Object> rawCouponResponse) {
		int serviceId = NumberUtils.toInt(String.valueOf(rawCouponResponse.get(SERVICE_ID)), -1);
		if (serviceId == COUPON_SERVICE_ID_30) {
			coupon.put(COUPON_SERVICE_LABEL, COUPON_THANK_YOU_COUPON);
		} else if (serviceId == COUPON_SERVICE_ID_41) {
			coupon.put(COUPON_SERVICE_LABEL, COUPON_SMART_COUPON);
		}
	}

	private boolean checkAndAddDiscountTitle(Map<String, Object> coupon, Map<String, Object> rawCouponResponse) {
		try {
			if(rawCouponResponse.get(DISCOUNT_TYPE) != null && rawCouponResponse.get(DISCOUNT_FACTOR) != null) {
				int discountType = NumberUtils.toInt(String.valueOf(rawCouponResponse.get(DISCOUNT_TYPE)));
				int discountFactor = NumberUtils.toInt(String.valueOf(rawCouponResponse.get(DISCOUNT_FACTOR)));
				if (discountType == COUPON_FIXED_AMOUNT) {
					coupon.put(DISCOUNT_TITLE, getFormattedValue(discountFactor) + COUPON_YEN_OFF);
					return true;
				} else if (discountType == COUPON_FIXED_RATE) {
					coupon.put(DISCOUNT_TITLE, discountFactor + COUPON_PERCENT_OFF);
					return true;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception while preparing discount title message: {}", e.getMessage(), e);
		}
		return false;
	}

	/**
	 * Prepare terms of use
	 *
	 * @param rawCouponResponse Each coupon response from generic gateway
	 * @return String terms of use string
	 */
	private String prepareTermsOfUse(Map<String, Object> rawCouponResponse, boolean isByItem) {
		String termsOfUse = "";
		try {
			StringBuilder termsOfUseBuilder = new StringBuilder();
			String separator = env.getProperty(PROP_KEY_TERM_OF_USE_SEPARATOR);
			String termOfuseSeparator = String.format(" %s ", separator);

			processItemType(rawCouponResponse, termsOfUseBuilder, termOfuseSeparator);
			processIssueCount(rawCouponResponse, termsOfUseBuilder, termOfuseSeparator);
			processMemberAvailMaxCount(rawCouponResponse, termsOfUseBuilder, termOfuseSeparator);
			processOtherCondition(rawCouponResponse, termsOfUseBuilder,
					termOfuseSeparator, isByItem);
			processCombineFlg(rawCouponResponse, termsOfUseBuilder, termOfuseSeparator);

			termsOfUse = termsOfUseBuilder.toString();
			if (StringUtils.isNotBlank(termsOfUse) && termsOfUse.endsWith(termOfuseSeparator)) {
				termsOfUse = termsOfUse.substring(0, termsOfUse.length() - termOfuseSeparator.length());
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponByShopResponseProcessor] [prepareTermsOfUse] " +
					"Exception while process: {}", rawCouponResponse, ex);
		}

		return termsOfUse;
	}

	/**
	 * Process combine flag
	 *
	 * @param rawCouponResponse Each coupon response from generic gateway
	 * @param termsOfUseBuilder Terms of use string builder
	 * @param termOfuseSeparator Terms of use separator character
	 */
	private void processCombineFlg(Map<String, Object> rawCouponResponse, StringBuilder termsOfUseBuilder,
			String termOfuseSeparator) {
		String canNotUsedTogether = env.getProperty(PROP_KEY_CAN_NOT_USED_TOGETHER);

		Object combineFlgObj = rawCouponResponse.get(COMBINE_FLG);
		try {
			if (Objects.nonNull(combineFlgObj)) {
				int combineFlg = NumberUtils.toInt(String.valueOf(combineFlgObj), -1);
				if (combineFlg == 0) {
					termsOfUseBuilder.append(canNotUsedTogether).append(termOfuseSeparator);
				}
			}
		} catch (Exception ex) {
			LOGGER.info("[CouponResponseLogic] [processCombineFlg] Exception while processing combine flag. " +
							"canNotUsedTogether: {}, combineFlgObj: {}",
					canNotUsedTogether, combineFlgObj, ex);
		}
	}

	/**
	 *  Will check an item exists or not in source map
	 *
	 * @param sourceMap       Source Map
	 * @param targetItem           Target field name
	 * @return boolean true if item exists
	 */
	private boolean isItemExists(Map<String, Object> sourceMap, String targetItem) {
		return sourceMap.get(targetItem) != null;
	}
}
