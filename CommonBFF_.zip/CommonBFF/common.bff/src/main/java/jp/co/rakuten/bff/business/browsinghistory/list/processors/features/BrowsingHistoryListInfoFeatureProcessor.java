package jp.co.rakuten.bff.business.browsinghistory.list.processors.features;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * BrowsingHistoryListInfo Feature Processor
 */
@Component("BrowsingHistoryListInfoFeatureProcessor")
public class BrowsingHistoryListInfoFeatureProcessor implements FeatureProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(BrowsingHistoryListInfoFeatureProcessor.class);
	private static final String INTERFACE_BROWSING_HISTORY_LIST = "browsingHistoryList";
	private static final String CALL_DEF_BROWSING_HISTORY_LIST = "browsingHistoryListCD";

	/**
	 * BrowsingHistoryListInfo feature post processor - will check/traverse call definition response
	 * and prepare api specific response
	 *
	 * @param validatedClientData       validated client or default data
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionResponseMap It holds call definition response
	 * @return Mono<FeaturePostProcessorResponse> Feature's processed data as mono
	 */
	@Override
	public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
			FeatureTemplate featureTemplate, Map<String, CallDefinitionResponse> callDefinitionResponseMap) {

		return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap(featurePostProcessorResponse -> {
			Map<String, Object> browsingHistoryResponse =
					InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
							INTERFACE_BROWSING_HISTORY_LIST, CALL_DEF_BROWSING_HISTORY_LIST);
			featurePostProcessorResponse.setResponseMap(browsingHistoryResponse);
			featurePostProcessorResponse.setCacheable(true);
			return Mono.just(featurePostProcessorResponse);
		}).doOnRequest(l -> LOGGER.debug("BrowsingHistoryListInfoFeatureProcessor start processing"))
				.doOnSuccess(featurePostProcessorResponse ->
						LOGGER.debug("BrowsingHistoryListInfoFeatureProcessor successfully completed. data: {}",
								featurePostProcessorResponse));
	}
}
