package jp.co.rakuten.bff.business.productscreen.get.constants;

public class ProductScreenConstant {

    public static final String PRODUCT_INFO_FEATURE_KEY = "productInfo";
    public static final String GENRE_INFO_FEATURE_KEY = "genreInfo";
    public static final String REVIEW_INFO_FEATURE_KEY = "reviewInfo";
    public static final String PRODUCT_INFO_INTERFACE_KEY = "productInfo";
    public static final String GSP_ITEM_REVIEW_INTERFACE_KEY = "gspItemReview";
    public static final String SHOP_MASTER_INTERFACE_KEY = "shopMasterInfo";
    public static final String SHOP_DISP_INTERFACE = "shopDispInfo";
    public static final String SHOP_DISP_INTERFACE_KEY = "shopDisp";
    public static final String NAVIGATION_INTERFACE_KEY = "navigationInfo";
    public static final String PRODUCT_INFO_CALL_DEFINITION_KEY = "productInfoCD";
    public static final String SHOP_DISP_CALL_DEFINITION_KEY = "shopDispCD";
    public static final String NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY = "navigationReviewInfoCD";
    public static final String EXCEPTION_MESSAGE_PARAM_RESOLVE =
            "Either of the request set is required shopId+itemId or shopID+manageNumber or itemUrl or itemCode";
    public static final String EXCEPTION_MESSAGE_GENRE_INFO_MERCHANT_FEATURE = "genreInfo feature not enabled for that merchant";
    public static final String EXCEPTION_MESSAGE_REVIEW_INFO_MERCHANT_FEATURE = "reviewInfo feature not enabled for that merchant";
    public static final String EXCEPTION_INVALID_ITEM_URL = "Invalid itemUrl";
    public static final String EXCEPTION_INVALID_ITEM_CODE = "Invalid itemCode";
    public static final String ITEM_ID = "itemId";
    public static final String SHOP_ID = "shopId";
    public static final String MANAGE_NUMBER = "manageNumber";
    public static final String ITEM_URL = "itemUrl";
    public static final String ITEM_CODE = "itemCode";
    public static final String DISP_TYPE = "dispType";
    public static final String DISP_ID = "dispId";
    public static final String DEVICE_TYPE = "deviceType";
    public static final String SHOP_URL = "shopUrl";
    public static final String LOCAL = "locale";
    public static final String SHOP_MASTER_PARENT_ID = "shopMasterInfo";
    public static final String PARENT_REQUEST_ID = "parentRequestId";
    public static final String PARAMETER_LINKS = "parameterLinks";
    public static final String URL_PARAMETERS = "urlParameters";
    public static final String DEPENDENCY_CONDITION = "dependencyConditions";

    public static final String ITEM_TITLE = "title";

    private ProductScreenConstant() {
    }
}

