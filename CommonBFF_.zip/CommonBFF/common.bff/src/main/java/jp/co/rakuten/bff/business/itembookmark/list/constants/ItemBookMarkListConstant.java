package jp.co.rakuten.bff.business.itembookmark.list.constants;

/**
 * Hold all the constant values needed to execute itembookmark/list api.
 * These constants are used in itembookmarklist info feature
 */
public class ItemBookMarkListConstant {

	public static final String INTERFACE_NAME_ITEM_BOOKMARK_GET = "itemBookmarkGet";
	public static final String INTERFACE_NAME_COUPON_BY_ITEM = "couponByItem";
	public static final String CALL_DEF_ITEM_BOOKMARK_GET_CD = "itemBookmarkGetCD";
	public static final String CALL_DEF_COUPONS_BY_ITEM_CD = "couponsByItemCD";
	public static final String ITEM_BOOKMARK_LIST_INFO = "itemBookmarkListInfo";
	public static final String URL_PARAMETERS = "urlParameters";
	public static final String SHOP_ID = "shopId";
	public static final int ITEM_BOOKMARK_SUCCESS_RESPONSE_CODE = 1001;
	public static final String STATUS = "status";
	public static final String CODE = "code";
	public static final String DATA = "data";
	public static final String COUPON_FLAG = "couponFlag";
	public static final String X_CLIENT_ID = "X-ClientId";
	public static final String ITEM_ID = "itemId";
	public static final String BODY = "body";
	public static final String SEARCH_CONDITIONS = "searchConditions";
	public static final String ITEMS = "items";
	public static final String INTERFACE_KEY = "interfaceKey";
	public static final Integer COUPON_NORMAL_ITEM = 1;
	public static final Integer COUPON_CATALOG_ORDER_ITEM = 5;
	public static final String REQUEST_ID = "requestId";
	public static final String META = "meta";
	public static final String BOOKMARK_LIST = "bookmarkList";
	public static final String COUPONS = "coupons";
	public static final String SEPARATOR = ":";
	public static final String NCP_FLAG = "ncpFlag";
	public static final String COUPON_RS004 = "RS004";
	public static final String COUPON_RS003 = "RS003";
	public static final String START_VALUE_KEY = "startValue";
	public static final String COUPON_RS001 = "RS001";
	public static final String COUPON_ID = "couponId";
	public static final String COUPON_CODE = "couponCd";
	public static final String COUPON_NAME = "couponName";
	public static final String ACQUIRED = "acquired";
	public static final String COUPON_START_DATE = "couponStartDate";
	public static final String COUPON_END_DATE = "couponEndDate";
	public static final String SERVICE_ID = "serviceId";
	public static final String COUPON_SERVICE_LABEL = "couponServiceLabel";
	public static final String COUPON_THANK_YOU_COUPON = "リピーター限定";
	public static final String COUPON_SMART_COUPON = "対象者限定";
	public static final String COUPON_PRICE_FORMAT = "#,###";
	public static final String DISCOUNT_TITLE = "discountTitle";
	public static final String COUPON_YEN_OFF = "円OFF";
	public static final String COUPON_PERCENT_OFF = "%OFF";
	public static final String DISCOUNT_TYPE = "discountType";
	public static final String DISCOUNT_FACTOR = "discountFactor";
	public static final String COMBINE_FLG = "combineFlg";
	public static final String MEMBER_AVAIL_MAX_COUNT = "memberAvailMaxCount";
	public static final String ITEM_TYPE = "itemType";
	public static final String COUPON_SERVICE_ID = "couponServiceId";
	public static final String TERMS_OF_USE = "termsOfUse";
	public static final String OTHER_COND_TYPE_CD = "otherCondTypeCd";
	public static final String ISSUE_COUNT = "issueCount";
	public static final String PROP_KEY_DESIGNATED_PRODUCT_TARGET =
			"itembookmark.list.couponByItem.api.designated.product.target";
	public static final String PROP_KEY_ONE_PERSON_UP_TO_TIMES
			= "itembookmark.list.couponByItem.api.one.person.up.to.times";
	public static final String PROP_KEY_FIRST_ARRIVAL_UNTIL_NAME =
			"itembookmark.list.couponByItem.api.first.arrival.until.name";
	public static final String PROP_KEY_TERM_OF_USE_RS001_SEPARATOR =
			"itembookmark.list.couponByItem.api.term.of.use.rs001.separator";
	public static final String PROP_KEY_AVAILABLE_AT_LEAST = "itembookmark.list.couponByItem.api.available.at.least";
	public static final String PROP_KEY_AVAILABLE_IN_YEN = "itembookmark.list.couponByItem.api.available.in.yen";
	public static final String PROP_KEY_TERM_OF_USE_RS001_COMPUTER =
			"itembookmark.list.couponByItem.api.term.of.use.rs001.computer";
	public static final String PROP_KEY_TERM_OF_USE_RS001_SMARTPHONE =
			"itembookmark.list.couponByItem.api.term.of.use.rs001.smartphone";
	public static final String PROP_KEY_APPLICABLE_TO_DESIGNATED_STORES =
			"itembookmark.list.couponByItem.api.applicable.to.designated.stores";
	public static final String PROP_KEY_TERM_OF_USE_SEPARATOR =
			"itembookmark.list.couponByItem.api.term.of.use.separator";
	public static final String PROP_KEY_CAN_NOT_USED_TOGETHER =
			"itembookmark.list.couponByItem.api.can.not.used.together";
	private ItemBookMarkListConstant() {
	}
}
