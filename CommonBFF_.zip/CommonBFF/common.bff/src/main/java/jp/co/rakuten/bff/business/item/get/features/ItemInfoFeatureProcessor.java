package jp.co.rakuten.bff.business.item.get.features;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ItemInfo features processor
 * <br>
 * Contains custom processor logic for ItemInfoFeature
 */
@Component("ItemInfoFeatureProcessor")
public class ItemInfoFeatureProcessor implements FeatureProcessor {

	public static final int SPLIT_INDEX_POS = 3;
	private static final Logger LOGGER = LoggerFactory.getLogger(ItemInfoFeatureProcessor.class);
	private static final String IMAGE_URL = "imageUrl";
	private static final String THUMBNAIL_IMAGE_URL = "thumbnailUrl";
	private static final String VARIANTS = "variants";
	private static final String IMAGES = "images";
	private static final String MAPPED_INVENTORIES = "variantMappedInventories";


	/**
	 * ItemInfo feature post processor - will check/traverse call definition response
	 * and prepare api specific response
	 *
	 * @param validatedClientData       validated client or default data
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionResponseMap It holds call definition response.
	 * @return Mono<FeaturePostProcessorResponse> Feature's processed data as mono.
	 */
	@Override
	public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
			FeatureTemplate featureTemplate,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap((FeaturePostProcessorResponse featureresponse) -> {
			Map<String, Object> itemxResponse = InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
					ItemXInfoConstants.ITEMX_INTERFACE_KEY,
					ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);
			//Process Variants Inventory (Results can be available as part of Different call)
			if (MapUtils.isNotEmpty(itemxResponse)) {
				//Process GSP Response
				parseGspResponse(itemxResponse, callDefinitionResponseMap);
				//Process Variants Inventory (Results can be available as part of Different call)
				processInventoryXResponse(itemxResponse, callDefinitionResponseMap);
			}
			featureresponse.setResponseMap(itemxResponse);
			featureresponse.setCacheable(true);
			return Mono.just(featureresponse);
		})
				.doOnRequest(l -> LOGGER.debug("ItemInfoFeatureProcessor start processing"))
				.doOnSuccess(featurePostProcessorResponse -> LOGGER.debug(
						"ItemInfoFeatureProcessor successfully completed. data: {}",
						featurePostProcessorResponse));
	}

	//Mapping Inventories Data
	private void processInventoryXResponse(Map<String, Object> itemXInfoResponse,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> inventoryResponse = getInventoryResponse(callDefinitionResponseMap);
		if (MapUtils.isNotEmpty(inventoryResponse)) {
			processInventoryData(itemXInfoResponse,
					(List<Object>) itemXInfoResponse.get(VARIANTS),
					(List<Map<String, Object>>) inventoryResponse.get(MAPPED_INVENTORIES));
		}

	}

	//Process inventory data and adds to ItemX Info response
	private void processInventoryData(Map<String, Object> itemXInfoResponse,
			List<Object> variants,
			List<Map<String, Object>> inventories) {
		List<Object> variantList;
		if (CollectionUtils.isNotEmpty(variants) && CollectionUtils.isNotEmpty(inventories)) {
			variantList = new ArrayList<>(variants.size());
			for (Object variant : variants) {
				Map<String, Object> variantMap = (Map<String, Object>) variant;
				inventories.forEach((Map<String, Object> inventoryDataMap) -> {
					if (StringUtils.equalsIgnoreCase((String) inventoryDataMap.get("sku"), (String) variantMap.get("sku"))) {
						variantMap.put("inventoryId", inventoryDataMap.get("inventoryId"));
						variantMap.put("quantity", inventoryDataMap.get("quantity"));
					}
				});
				variantList.add(variant);
			}
			if (CollectionUtils.isNotEmpty(variantList)) {
				itemXInfoResponse.put(VARIANTS, variantList);
			}
		}
	}

	//Fetches Inventory Data from Upstream Response
	private Map<String, Object> getInventoryResponse(Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> inventoryResponse = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
				ItemXInfoConstants.INVENTORYX_INTERFACE_KEY,
				ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);
		if (MapUtils.isEmpty(inventoryResponse)) {
			inventoryResponse = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
					ItemXInfoConstants.INVENTORYX_INTERFACE_KEY,
					ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
		}
		return inventoryResponse;
	}

	//Building GSP Response
	private void parseGspResponse(Map<String, Object> itemXResponse, Map<String,
			CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> ggGspResponse = InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
						ItemXInfoConstants.GSP_ITEM_KVS_INTERFACE_KEY,
						ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
		if (MapUtils.isNotEmpty(ggGspResponse) &&
				CollectionUtils.isNotEmpty((List<Map<String, Object>>)ggGspResponse.get("docs"))) {
			List<Map<String, Object>> docs = (List<Map<String, Object>>) ggGspResponse.get("docs");
			Map<String, Object> gspResponse = docs.get(0);
			String itemUrl = (String) gspResponse.get("itemUrl");
			if (StringUtils.isNotBlank(itemUrl)) {
				itemXResponse.put("itemUrl", itemUrl);
				buildItemMobileUrl(itemXResponse, itemUrl);
			}
			itemXResponse.put("shopName", gspResponse.get("shopName"));
			itemXResponse.put("genreIdList", gspResponse.get("genreIdList"));
			String shopManageId = (String) gspResponse.get("shopMngId");
			itemXResponse.put("shopUrl", shopManageId);

			if (StringUtils.isNotBlank(shopManageId) && itemXResponse.get(IMAGES) instanceof List) {
				//1. Process Images
				List<Map<String, Object>> finalImageSet = parseImagesResponse((List<Object>) itemXResponse.get(IMAGES),
						shopManageId);
				if (CollectionUtils.isNotEmpty(finalImageSet)) {
					itemXResponse.put(IMAGES, finalImageSet);
				}
			}
			processVariantImages(itemXResponse, shopManageId);
		}
	}

	//Process Variant Related Images
	private void processVariantImages(Map<String, Object> itemXResponse, String shopManageId) {
		//2. Process Variants related Images
		List variants = (List<Object>) itemXResponse.get(VARIANTS);
		if (CollectionUtils.isNotEmpty(variants)) {
			List<Object> variantList = new ArrayList<>(variants.size());
			for (Object variant : variants) {
				Map variantMap = (Map<String, Object>) variant;
				List variantImageSet = parseImagesResponse((List<Object>) variantMap.get(IMAGES), shopManageId);
				if (CollectionUtils.isNotEmpty(variantImageSet)) {
					variantMap.put(IMAGES, variantImageSet);
				}
				variantList.add(variantMap);
			}
			if (CollectionUtils.isNotEmpty(variantList)) {
				itemXResponse.put(VARIANTS, variantList);
			}
		}
	}

	//Building Item Mobile URL
	private void buildItemMobileUrl(Map<String, Object> itemXResponse, String itemUrl) {
		if (itemUrl.contains("item.rakuten.co.jp")) {
			itemXResponse.put("itemUrlMobile", itemUrl.replace("item.rakuten.co.jp", "m.rakuten.co.jp"));
		} else if (itemUrl.contains("www.rakuten.co.jp")) {
			itemXResponse.put("itemUrlMobile", itemUrl.replace("www.rakuten.co.jp", "m.rakuten.co.jp"));
		}
	}

	//Parsing Image Response Data
	private List parseImagesResponse(List<Object> imageResponse, String shopManageId) {
		List<Object> finalImageResponse = null;
		if (CollectionUtils.isNotEmpty(imageResponse)) {
			finalImageResponse = new ArrayList<>(imageResponse.size());
			for (Object image : imageResponse) {
				if (image instanceof Map) {
					Map imageData = (Map<String, Object>) image;
					processImage(imageData, shopManageId);
					finalImageResponse.add(imageData);
				}
			}
		}
		return finalImageResponse;
	}

	// Processing Image by Type
	private void processImage(Map<String, Object> image, String shopManageId) {
		if (MapUtils.isNotEmpty(image)) {
			String type = (String) image.get("type");
			String location = (String) image.get("location");
			if (StringUtils.isNotBlank(type) && StringUtils.isNotBlank(location)) {
				if (StringUtils.equalsIgnoreCase("CABINET", type)) {
					image.put(IMAGE_URL, String.format(ItemXInfoConstants.CABINET_URL, shopManageId, location));
					image.put(THUMBNAIL_IMAGE_URL, String.format(ItemXInfoConstants.THUMBNAIL_CABINET_URL,
							shopManageId, location));
				} else if (StringUtils.equalsIgnoreCase("GOLD", type)) {
					image.put(IMAGE_URL, String.format(ItemXInfoConstants.GOLD_URL, shopManageId, location));
					image.put(THUMBNAIL_IMAGE_URL, String.format(ItemXInfoConstants.THUMBNAIL_GOLD_URL,
							shopManageId, location));
				} else if (StringUtils.equalsIgnoreCase("ABSOLUTE", type)) {
					image.put(IMAGE_URL, location);
					image.put(THUMBNAIL_IMAGE_URL, processAbsoluteImageThumbnailURL(location ,shopManageId));
				}
			}
		}
	}

	// this method evaluates the URL for absolute Images
	private String processAbsoluteImageThumbnailURL(String location ,String shopManageId) {
		String thumbnailUrl = location;
		if (location.contains("image.books.rakuten.co.jp")){
			thumbnailUrl = "https://thumbnail.image.rakuten.co.jp/@0_mall/book/cabinet"
					+ location.substring(StringUtils.ordinalIndexOf(location, "/", SPLIT_INDEX_POS));
		} else if(location.contains("rakuten.co.jp"))
		{
			thumbnailUrl = String.format(ItemXInfoConstants.THUMBNAIL_CABINET_URL, shopManageId
					,location.substring(StringUtils.ordinalIndexOf(location, "/", SPLIT_INDEX_POS)));
		}
		return thumbnailUrl;
	}


}


