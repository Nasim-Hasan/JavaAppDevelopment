package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant;
import jp.co.rakuten.bff.business.productscreen.get.logic.ProductScreenLogic;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("GspItemReviewInterfaceProcessor")
public class GspItemReviewInterfaceProcessor implements InterfaceProcessor {
    @Override
    public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
                              GenericCallDefinitionProcessedData genericCDProcessedData,
                              Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        if(!ProductScreenLogic.modifyParentRequest(genericCDProcessedData, NAVIGATION_INTERFACE_KEY, GSP_ITEM_REVIEW_INTERFACE_KEY, DEPENDENCY_CONDITION)){
            return false;
        }

        if(!shouldCallReviewInfo(validatedRequest, callDefinitionResponseMap)) {
            throw FeatureException.create(GENRE_INFO_FEATURE_KEY, EXCEPTION_MESSAGE_REVIEW_INFO_MERCHANT_FEATURE);
        }

        ProductScreenLogic.setShopIdItemId(genericCDProcessedData, callDefinitionResponseMap, GSP_ITEM_REVIEW_INTERFACE_KEY);
        return  true;
    }

    private boolean shouldCallReviewInfo(Map<String, CommonRequestModel> validatedRequest,
                                             Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        return ProductScreenLogic.shouldShowChildFeatrue(validatedRequest, callDefinitionResponseMap, 33, 2);
    }

}
