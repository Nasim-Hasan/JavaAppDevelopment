package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.core.util.ResponseFilterHelper;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

import static jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants.ITEMX_VALUE;

/**
 * ItemX Info Interface processor transform the response of Item X based on Locale and Device Type
 */
@Component("ItemXInterfaceProcessor")
public class ItemXInterfaceProcessor implements InterfaceProcessor {

	/**
	 * @param validatedRequest Map<String, CommonRequestModel> the client request
	 * @param callDefinitionResponse CallDefinitionResponse response for the GG for the executed call
	 * @param genericCDProcessedData GenericCallDefinitionProcessedData the request map being prepared for GG
	 * @param callDefinitionResponseMap Map<String, CallDefinitionResponse> response map of GG if any call already executed
	 */
	@Override
	public void postProcess(Map<String, CommonRequestModel> validatedRequest,
			CallDefinitionResponse callDefinitionResponse,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {

		Map<String, Object> itemxGGResponse = InterfaceUtil.getInterfaceResponse(callDefinitionResponse,
				ItemXInfoConstants.ITEMX_INTERFACE_KEY,
				ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);

		if (MapUtils.isNotEmpty(itemxGGResponse)) {
			Map<String, Object> requestParams = validatedRequest.get(ItemXInfoConstants.ITEM_INFO_FEATURE_KEY).getParams();
			transformResponse(requestParams, itemxGGResponse);
		}

	}

	//Transform the response for locale and deviceType
	public void transformResponse(Map<String, Object> requestParams, Map<String, Object> itemxResponse) {

		if (MapUtils.isNotEmpty(requestParams)) {
			String locale = String.valueOf(requestParams.get(ItemXInfoConstants.LOCALE));
			String device = String.valueOf(requestParams.get(ItemXInfoConstants.DEVICE_TYPE));
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_TITLE, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_TAGLINE, device);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_TAGLINE, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION, device);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_PRODUCT_DESCRIPTION, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_SALES_DESCRIPTION, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_IMAGES, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_PRECAUTIONS,
					ItemXInfoConstants.ITEMX_DESCRIPTION, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_PRECAUTIONS,
					ItemXInfoConstants.ITEMX_AGREEMENT, locale);
			ResponseFilterHelper.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_VIDEO, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_SUBSCRIPTION,
							ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_BUYING_CLUB,
							ItemXInfoConstants.ITEMX_PURCHASE_DESCRIPTION, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS,
							ItemXInfoConstants.ITEMX_LABEL, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_CUSTOMIZATION_OPTIONS_SELECTIONS,
							ItemXInfoConstants.ITEMX_DISPLAY_VALUE,
							locale);
			ResponseFilterHelper
					.digUpValueAndAdd(itemxResponse, ItemXInfoConstants.ITEMX_BUYING_CLUB, ItemXInfoConstants.ITEMX_ITEMS, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_VARIANTS, ItemXInfoConstants.ITEMX_IMAGES, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_VARIANT_SELECTORS,
							ItemXInfoConstants.ITEMX_I_18_N, locale);
			ResponseFilterHelper
					.digUpValueAndSet(itemxResponse, ItemXInfoConstants.ITEMX_VARIANT_SELECTORS_VALUES,
							ItemXInfoConstants.ITEMX_I_18_N, locale);

			//Fix FOR VIDEO
	Map video = (Map)itemxResponse.get(ItemXInfoConstants.ITEMX_VIDEO);
			if(MapUtils.isNotEmpty(video)){
				Map params = (Map)video.get("parameters");
				if(MapUtils.isNotEmpty(params)){
					String value =(String)params.get(ITEMX_VALUE);
					processVideoValue(itemxResponse, video, value);
				}
			}


		}
	}
	//Method to process video value
	private void processVideoValue(Map<String, Object> itemxResponse, Map video, String value) {
		if(StringUtils.isNotBlank(value))
		{ video.put(ITEMX_VALUE,value);
		  video.remove("parameters");
		  itemxResponse.put(ItemXInfoConstants.ITEMX_VIDEO,video);
		}
	}
}
