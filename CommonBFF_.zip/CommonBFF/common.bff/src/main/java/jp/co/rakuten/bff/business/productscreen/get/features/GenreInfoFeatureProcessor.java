package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.features.ItemInfoFeatureProcessor;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("GenreInfoFeatureProcessor")
public class GenreInfoFeatureProcessor implements FeatureProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemInfoFeatureProcessor.class);

    @Override
    public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData, FeatureTemplate featureTemplate, Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap((FeaturePostProcessorResponse featureResponse) -> {
            Map<String, Object> genreInfo = InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
                    NAVIGATION_INTERFACE_KEY,
                    NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY);
            manipulateGenreInfo(genreInfo);
            featureResponse.setResponseMap(genreInfo);

            featureResponse.setCacheable(true);
            return Mono.just(featureResponse);
        })
                .doOnRequest(l -> LOGGER.debug("ReviewInfoFeatureProcessor start processing"))
                .doOnSuccess(featurePostProcessorResponse -> LOGGER.debug(
                        "ReviewInfoFeatureProcessor successfully completed. data: {}",
                        featurePostProcessorResponse));
    }

    public void manipulateGenreInfo(Map<String, Object> genreInfo) {
        List<Integer> membershipTypes = new ArrayList<>();
        if (MapUtils.isNotEmpty(genreInfo)) {
            Map<String, Object> prohibitedMembershipStatus = (Map)((Map) genreInfo.get("genre")).get("prohibitedMembershipStatus");
            Integer premium = (Integer) prohibitedMembershipStatus.get("prohibitedMembershipPremiumFlg");
            Integer studentDiscount = (Integer) prohibitedMembershipStatus.get("prohibitedMembershipStudentDiscountFlg");

            if (premium == 0 && studentDiscount == 0) {
                membershipTypes.add(1);
                membershipTypes.add(2);
            } else if (premium == 0 && studentDiscount == 1) {
                membershipTypes.add(1);
            } else if (premium == 1 && studentDiscount == 0) {
                membershipTypes.add(2);
            }

        }
        genreInfo.remove("genre");
        genreInfo.put("membershipTypes", membershipTypes);
    }
}
