package jp.co.rakuten.bff.business.itembookmark.add.processors.features;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * ItemBookmarkAddInfo feature processor
 */
@Component("ItemBookmarkAddInfoFeatureProcessor")
public class ItemBookmarkAddInfoFeatureProcessor implements FeatureProcessor {

	public static final String INTERFACE_ITEMBOOKMARK_ADD = "itemBookmarkAdd";
	public static final String CALL_DEF_ITEMBOOKMARK_ADD = "itemBookmarkAddCD";
	private static final Logger LOGGER = LoggerFactory.getLogger(ItemBookmarkAddInfoFeatureProcessor.class);
	public static final String PRICE = "price";

	/**
	 * ItemBookmarkAddInfo feature post processor - will check/traverse call definition response
	 * and prepare api specific response
	 *
	 * @param validatedClientData       validated client or default data
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionResponseMap It holds call definition response
	 * @return Mono<FeaturePostProcessorResponse> Feature's processed data as mono
	 */
	@Override
	public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
			FeatureTemplate featureTemplate, Map<String, CallDefinitionResponse> callDefinitionResponseMap) {

		return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap(featurePostProcessorResponse -> {
			Map<String, Object> itemBookmarkAddResponse =
					InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
							INTERFACE_ITEMBOOKMARK_ADD, CALL_DEF_ITEMBOOKMARK_ADD);
			Map<String, Object> data = (Map<String, Object>) itemBookmarkAddResponse.get("data");
			if (MapUtils.isNotEmpty(data) && data.get(PRICE) instanceof Double) {
				data.put(PRICE, ((Double) data.get(PRICE)).intValue());
			}
			featurePostProcessorResponse.setResponseMap(itemBookmarkAddResponse);
			return Mono.just(featurePostProcessorResponse);
		}).doOnRequest(l -> LOGGER.debug("ItemBookmarkAddInfoFeatureProcessor start processing"))
				.doOnSuccess(featurePostProcessorResponse ->
						LOGGER.debug("ItemBookmarkAddInfoFeatureProcessor successfully completed. data: {}",
								featurePostProcessorResponse));
	}
}
