package jp.co.rakuten.bff.business.browsinghistory.list.processors.interfaces;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.core.constant.BffConstants.URL_PARAMETERS;

/**
 * browsingHistory interface processor
 */
@Component("BrowsingHistoryListInterfaceProcessor")
public class BrowsingHistoryListInterfaceProcessor implements InterfaceProcessor {
	private static final String INTERFACE_BROWSING_HISTORY_LIST = "browsingHistoryList";
	private static final String GENRE_ID = "genreId";

	/**
	 * Convert genreId from integer to List[integer] before calling GG.
	 *
	 * @param validatedRequest          {@link Map} contains feature name as key and CommonRequestModel as value.
	 * @param genericCDProcessedData    Every interface's generically prepared parameter list for Generic Gateway.
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return Always return true.
	 */
	@Override
	public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> request = genericCDProcessedData
				.getRequestByInterface(INTERFACE_BROWSING_HISTORY_LIST);
		if (ObjectUtils.isNotEmpty(request.get(URL_PARAMETERS))) {
			Map<String, Object> params = (Map) request.get(URL_PARAMETERS);
			if (params.get(GENRE_ID) instanceof Integer) {
				params.replace(GENRE_ID, List.of(params.get(GENRE_ID)));
			} else {
				params.remove(GENRE_ID);
			}
		}
		return true;
	}
}
