package jp.co.rakuten.bff.business.itembookmark.list.processors.features;

import jp.co.rakuten.bff.business.itembookmark.list.logic.ItemBookMarkListInfoLogic;
import jp.co.rakuten.bff.core.exception.BackendException;
import jp.co.rakuten.bff.core.exception.type.BackendErrorEnum;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;

/**
 * ItemBookmarkListInfo feature processor
 */
@Component("ItemBookmarkListInfoFeatureProcessor")
public class ItemBookmarkListInfoFeatureProcessor implements FeatureProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ItemBookmarkListInfoFeatureProcessor.class);
	private ItemBookMarkListInfoLogic itemBookMarkListInfoLogic;

	/**
	 * Parameterised constructor
	 *
	 * @param itemBookMarkListInfoLogic {@link ItemBookMarkListInfoLogic}
	 */
	@Autowired
	public ItemBookmarkListInfoFeatureProcessor(ItemBookMarkListInfoLogic itemBookMarkListInfoLogic) {
		this.itemBookMarkListInfoLogic = itemBookMarkListInfoLogic;
	}

	/**
	 * Coupons feature post processor - will check/traverse call definition response
	 * and prepare api specific response
	 *
	 * @param validatedClientData       validated client or default data
	 * @param featureTemplate           {@link FeatureTemplate}
	 * @param callDefinitionResponseMap It holds call definition response.
	 * @return Mono<FeaturePostProcessorResponse> Feature's processed data as mono.
	 */
	@Override
	public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData,
			FeatureTemplate featureTemplate,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap(featurePostProcessorResponse -> {

			Map<String, Object> itemBookmarkGetInterfaceResponse =
					InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap, INTERFACE_NAME_ITEM_BOOKMARK_GET,
							CALL_DEF_ITEM_BOOKMARK_GET_CD);
			int statusCode = NumberUtils.toInt(String.valueOf(((Map<String, Object>)
					itemBookmarkGetInterfaceResponse.get(STATUS)).get(CODE)), 0);
			if (statusCode != ITEM_BOOKMARK_SUCCESS_RESPONSE_CODE) {
				return Mono.error(BackendException.create(BackendErrorEnum.SERVICE_CONDITION,
						"Invalid api response"));
			}
			itemBookMarkListInfoLogic.addCouponsToItemBookMarkItems(callDefinitionResponseMap,
					itemBookmarkGetInterfaceResponse);
			Map<String, Object> responseMap = new HashMap<>();
			responseMap.put(META, itemBookmarkGetInterfaceResponse.get(META));
			responseMap.put(BOOKMARK_LIST, itemBookmarkGetInterfaceResponse.get(DATA));
			featurePostProcessorResponse.setResponseMap(responseMap);
			featurePostProcessorResponse.setCacheable(true);
			return Mono.just(featurePostProcessorResponse);
		})
				.doOnRequest(l -> LOGGER.debug("ItemBookmarkListInfoFeatureProcessor start processing"))
				.doOnSuccess(featurePostProcessorResponse -> LOGGER.debug(
						"ItemBookmarkListInfoFeatureProcessor successfully completed. data: {}",
						featurePostProcessorResponse));
	}
}
