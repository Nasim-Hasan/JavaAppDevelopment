package jp.co.rakuten.bff.business.productscreen.get.validators;

import jp.co.rakuten.bff.business.productscreen.get.logic.ProductScreenLogic;
import jp.co.rakuten.bff.core.exception.FeatureException;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("ProductInfoValidator")
public class ProductInfoValidator implements CustomValidator {
    @Override
    public Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
                                                    List<FeatureTemplate> featureTemplateList,
                                                    ClientRequestModel actualRequest) {

        CommonRequestModel 	commonRequestModel = validatedData.	get(PRODUCT_INFO_FEATURE_KEY);

        if (ObjectUtils.isEmpty(commonRequestModel) || MapUtils.isEmpty(commonRequestModel.getParams())) {
            throw FeatureException.create(PRODUCT_INFO_FEATURE_KEY, EXCEPTION_MESSAGE_PARAM_RESOLVE);
        }

        Map<String, Object> params = commonRequestModel.getParams();
        String itemMangeNumber = (String) params.get(MANAGE_NUMBER);
        Integer shopId = (Integer) params.get(SHOP_ID);
        Integer itemId = (Integer) params.get(ITEM_ID);
        String itemURL = (String) params.get(ITEM_URL);
        String itemCode = (String) params.get(ITEM_CODE);

        if(!ProductScreenLogic.isValidItemUrl(itemURL)) {
            throw FeatureException.create(PRODUCT_INFO_FEATURE_KEY, EXCEPTION_INVALID_ITEM_URL);
        }
        if(!ProductScreenLogic.isValidItemCode(itemURL)) {
            throw FeatureException.create(PRODUCT_INFO_FEATURE_KEY, EXCEPTION_INVALID_ITEM_CODE);
        }
        if (!((ObjectUtils.isNotEmpty(shopId)
                && (StringUtils.isNotBlank(itemMangeNumber) || ObjectUtils.isNotEmpty(itemId)))
                || (StringUtils.isNotBlank(itemURL) || StringUtils.isNotBlank(itemCode)))) {
            throw FeatureException.create(PRODUCT_INFO_FEATURE_KEY, EXCEPTION_MESSAGE_PARAM_RESOLVE);
        }

        return validatedData;
    }


}
