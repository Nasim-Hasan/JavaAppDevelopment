package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.features.ItemInfoFeatureProcessor;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.model.RequestModel;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.DateUtil;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.core.util.ResponseFilterHelper;
import jp.co.rakuten.bff.core.util.ResponseUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("ProductInfoFeatureProcessor")
public class ProductInfoFeatureProcessor implements FeatureProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemInfoFeatureProcessor.class);

    @Override
    public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData, FeatureTemplate featureTemplate, Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap((FeaturePostProcessorResponse featureResponse) -> {
            Map<String, Object> productInfoResponse = InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
                    PRODUCT_INFO_INTERFACE_KEY,
                    PRODUCT_INFO_CALL_DEFINITION_KEY);

            manipulateResponse(validatedClientData.getParams(), productInfoResponse);
            featureResponse.setResponseMap(productInfoResponse);
            featureResponse.setCacheable(true);
            return Mono.just(featureResponse);
        })
                .doOnRequest(l -> LOGGER.debug("ProductInfoFeatureProcessor start processing"))
                .doOnSuccess(featurePostProcessorResponse -> LOGGER.debug(
                        "ProductInfoFeatureProcessor successfully completed. data: {}",
                        featurePostProcessorResponse));
    }

    public void manipulateResponse(Map<String, Object> params, Map<String, Object> productInfoResponse) {
        if (MapUtils.isNotEmpty(productInfoResponse)) {
            String deviceType = (String) params.get(DEVICE_TYPE);
            String local = (String) params.get(LOCAL);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "precautions", "description", local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "title", local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "tagline", deviceType, local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "tagline", deviceType);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "productDescription", deviceType, local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "productDescription", deviceType);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "salesDescription", deviceType, local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "salesDescription", deviceType);

            List<Map<String, Object>> customizationOptions = (ArrayList) productInfoResponse.get("customizationOptions");
            if (ObjectUtils.isNotEmpty(customizationOptions)) {
                customizationOptions.forEach(customizationOption -> {
                    ResponseFilterHelper.digUpValueAndSet(customizationOption, "label", local);
                    List<Map<String, Object>> selections = (ArrayList) customizationOption.get("selections");
                    selections.forEach(selection -> {
                        ResponseFilterHelper.digUpValueAndSet(selection, "displayValue", local);
                    });
                });
            }

            List<Map<String, Object>> variantSelectors = (ArrayList) productInfoResponse.get("variantSelectors");
            if (ObjectUtils.isNotEmpty(variantSelectors)) {
                variantSelectors.forEach(variantSelector -> {
                    ResponseFilterHelper.digUpValueAndSet(variantSelector, "i18n", local);
                    List<Map<String, Object>> values = (ArrayList) variantSelector.get("values");
                    values.forEach(value -> {
                        ResponseFilterHelper.digUpValueAndSet(value, "i18n", local);
                    });
                });
            }

            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "subscription", "purchaseDescription", local);
            ResponseFilterHelper.digUpValueAndSet(productInfoResponse, "buyingClub", "purchaseDescription", local);

            //Set Item type
            Boolean containsReleaseDate = productInfoResponse.containsKey("releaseDate");
            Boolean containsSubscription = productInfoResponse.containsKey("subscription");
            Boolean containsBuyingClub = productInfoResponse.containsKey("buyingClub");
            int itemType = 0;
            if (containsReleaseDate) {
                itemType = 3;
            } else if (containsSubscription) {
                itemType = 1;
            } else if (containsBuyingClub) {
                itemType = 2;
            } else {
               itemType = 0;
            }
            productInfoResponse.put("type", itemType);
            //Set isAvailableForSale
            Map<String, Object> purchasablePeriod = (Map) productInfoResponse.get("purchasablePeriod");
            if (ObjectUtils.isNotEmpty(purchasablePeriod)) {
                Date startDate = DateUtil.convertToUTCDate((String) purchasablePeriod.get("start"), "yyyy-MM-dd");
                Date endDate = DateUtil.convertToUTCDate((String) purchasablePeriod.get("end"), "yyyy-MM-dd");
                productInfoResponse.put("isAvailableForSale",
                        DateUtil.isInBetweenCurrentTime(startDate, endDate));
            }

            //Set inventoryType
            Boolean unlimitedInventoryFlag = (Boolean) productInfoResponse.get("unlimitedInventoryFlag");
            List variants = (ArrayList) productInfoResponse.get("variants");
            int variantsCount = ObjectUtils.isEmpty(variants) ? 0 : variants.size();
            Boolean variantSelectorsContain = productInfoResponse.containsKey("variantSelectors");
            int inventoryType;
            if (unlimitedInventoryFlag) {
                inventoryType = 0;
            } else if (unlimitedInventoryFlag == false && variantsCount == 1 && variantSelectorsContain == false) {
                inventoryType = 1;
            } else if (unlimitedInventoryFlag == false && variantsCount >= 1 && variantSelectorsContain) {
                inventoryType = 2;
            } else {
                inventoryType = -1; // Data Error
            }
            productInfoResponse.put("inventoryType", inventoryType);
        }
    }
}
