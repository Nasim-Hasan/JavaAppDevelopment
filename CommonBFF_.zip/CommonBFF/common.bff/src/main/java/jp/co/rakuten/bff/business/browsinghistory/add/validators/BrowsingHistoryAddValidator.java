package jp.co.rakuten.bff.business.browsinghistory.add.validators;

import jp.co.rakuten.bff.business.common.validators.EasyIdValidator;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
/**
 * BrowsingHistoryAdd Validator
 * This validator validates browsing history add request
 */
@Component("BrowsingHistoryAddValidator")
public class BrowsingHistoryAddValidator implements CustomValidator {
	@Override
	public Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
			List<FeatureTemplate> featureTemplateList, ClientRequestModel actualRequest) {
		EasyIdValidator.validate(validatedData.get("browsingHistoryAddInfo"));
		return validatedData;
	}
}
