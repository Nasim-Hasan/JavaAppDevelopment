package jp.co.rakuten.bff.business.itembookmark.list.processors.interfaces;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import jp.co.rakuten.bff.core.util.MapUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.BODY;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.INTERFACE_KEY;
import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.REQUEST_ID;

/**
 * couponsByItem Interface Processor
 * This processor validates and transforms Coupons request and response
 */
@Component("CouponByItemInterfaceProcessor")
public class CouponByItemInterfaceProcessor implements InterfaceProcessor {
	private static final String PROP_KEY_COUPON_BY_ITEM_MAX_REQUEST_ITEM_SIZE
			= "itembookmark.list.couponByItem.max.request.item.size";
	private static final String PROP_KEY_COUPON_BY_ITEM_NEED_COUPONS = "itembookmark.list.needCoupons.";
	public static final int NUMBER_FIVE = 5;
	private Environment environment;

	/**
	 * Parameterised constructor
	 *
	 * @param environment {@link Environment}
	 */
	@Autowired
	public CouponByItemInterfaceProcessor(Environment environment) {
		this.environment = environment;
	}

	/**
	 * Pre processor will modify generically prepared request if this endpoint has any custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	@Override
	public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		return isCouponsByItemInterfaceNeedToBeCalled(validatedRequest, genericCDProcessedData,
				callDefinitionResponseMap);
	}

	private boolean isCouponsByItemInterfaceNeedToBeCalled(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> itemBookmarkGetInterfaceResponse =
				InterfaceUtil.getInterfaceResponseWithoutException(callDefinitionResponseMap,
						INTERFACE_NAME_ITEM_BOOKMARK_GET, CALL_DEF_ITEM_BOOKMARK_GET_CD);
		int statusCode = NumberUtils.toInt(String.valueOf(((Map<String, Object>)
				itemBookmarkGetInterfaceResponse.get(STATUS)).get(CODE)), 0);
		boolean isCouponNeeded = isCouponNeeded(validatedRequest, statusCode);
		List<Map<String, Object>> itemBookMarkList =
				(List<Map<String, Object>>) itemBookmarkGetInterfaceResponse.get(DATA);
		if (!isCouponNeeded || CollectionUtils.isEmpty(itemBookMarkList)) {
			return false;
		}
		Map<String, Object> couponByItemInterfaceRequest =
				genericCDProcessedData.getRequestByInterface(INTERFACE_NAME_COUPON_BY_ITEM);
		List<String> requestIdList =
				genericCDProcessedData.getInterfaceToRequestIdMap().get(INTERFACE_NAME_COUPON_BY_ITEM);
		genericCDProcessedData.getPreparedRequest().remove(requestIdList.iterator().next());
		sliceShopIdAndItemIdAndPrepareSearchJson(itemBookMarkList, genericCDProcessedData,
				(Map<String, Object>) couponByItemInterfaceRequest.get(BODY));
		return true;
	}

	private void sliceShopIdAndItemIdAndPrepareSearchJson(List<Map<String, Object>> itemBookMarkList,
			GenericCallDefinitionProcessedData genericCDProcessedData, Map<String, Object> bodyMap) {
		int maxCouponRequestItemSize = NumberUtils.toInt(
				environment.getProperty(PROP_KEY_COUPON_BY_ITEM_MAX_REQUEST_ITEM_SIZE), NUMBER_FIVE);
		List<Map<String, Object>> itemBookMarkDataList = createBookMarkListByItemType(itemBookMarkList);
		int bookMarkSize = itemBookMarkDataList.size();
		genericCDProcessedData.getInterfaceToRequestIdMap().get(INTERFACE_NAME_COUPON_BY_ITEM);
		List<String> requestIdList = new ArrayList<>();
		for (int fromIdx = 0; fromIdx < bookMarkSize; fromIdx += maxCouponRequestItemSize) {
			int toIdx = Math.min((fromIdx + maxCouponRequestItemSize), bookMarkSize);
			List<Map<String, Object>> bookMarksSubList = itemBookMarkDataList.subList(fromIdx, toIdx);
			Map<String, Object> body = prepareRequestBody(bookMarksSubList, bodyMap);
			String requestId = UUID.randomUUID().toString();
			Map<String, Object> couponByItem = Map.of(INTERFACE_KEY, INTERFACE_NAME_COUPON_BY_ITEM,
					REQUEST_ID, requestId,
					BODY, body);
			genericCDProcessedData.getPreparedRequest().put(requestId, couponByItem);
			requestIdList.add(requestId);
		}
		genericCDProcessedData.getInterfaceToRequestIdMap().put(INTERFACE_NAME_COUPON_BY_ITEM, requestIdList);

	}

	private Map<String, Object> prepareRequestBody(List<Map<String, Object>> bookMarksSubList,
			Map<String, Object> bodyMap) {
		Map<String, Object> body = MapUtil.deepCopy(bodyMap);
		Map<String, Object> searchConditions = (Map<String, Object>) body.get(SEARCH_CONDITIONS);
		List<Map<String, Object>> items = prepareItems(bookMarksSubList);
		searchConditions.put(ITEMS, items);
		return body;
	}

	private List<Map<String, Object>> prepareItems(List<Map<String, Object>> itemList) {
		List<Map<String, Object>> items = new ArrayList<>();
		for (Map<String, Object> item : itemList) {
			Map<String, Object> itemDetail = new HashMap<>();
			itemDetail.put("shopTypeCode", "shop_id");
			itemDetail.put("shopId", item.get(SHOP_ID));
			itemDetail.put("itemTypeCode", "item_id");
			itemDetail.put("itemId", item.get(ITEM_ID));
			items.add(itemDetail);
		}
		return items;
	}

	private List<Map<String, Object>> createBookMarkListByItemType(List<Map<String, Object>> itemBookMarkList) {
		Map<String, Object> bookMarkMap = new HashMap<>();
		List<Map<String, Object>> itemBookMarkDataList = new ArrayList<>();
		for (Map<String, Object> itemBookMark : itemBookMarkList) {
			int itemId = (int) itemBookMark.getOrDefault(ITEM_ID, 0);
			int shopId = (int) itemBookMark.getOrDefault(SHOP_ID, 0);
			String key = String.valueOf(itemId) + SEPARATOR + String.valueOf(shopId);
			int itemType = (int) itemBookMark.getOrDefault(ITEM_TYPE, -1);
			if ((itemType == COUPON_CATALOG_ORDER_ITEM || itemType == COUPON_NORMAL_ITEM)
					&& !bookMarkMap.containsKey(key)) {
				itemBookMarkDataList.add(itemBookMark);
				bookMarkMap.put(key, itemBookMark);
			}

		}
		return itemBookMarkDataList;
	}

	private boolean isCouponNeeded(Map<String, CommonRequestModel> validatedRequest, Integer statusCode) {
		Map<String, Object> itemBookMarkListRequestParams = validatedRequest.get(ITEM_BOOKMARK_LIST_INFO).getParams();
		Map<String, Object> itemBookMarkListRequestHeader = validatedRequest.get(ITEM_BOOKMARK_LIST_INFO).getHeaders();
		boolean couponFlag = (boolean) itemBookMarkListRequestParams.getOrDefault(COUPON_FLAG, false);
		return couponFlag
				&& Boolean.valueOf(environment.getProperty(PROP_KEY_COUPON_BY_ITEM_NEED_COUPONS +
				(String) itemBookMarkListRequestHeader.get(X_CLIENT_ID)))
				&& statusCode == ITEM_BOOKMARK_SUCCESS_RESPONSE_CODE;
	}
}
