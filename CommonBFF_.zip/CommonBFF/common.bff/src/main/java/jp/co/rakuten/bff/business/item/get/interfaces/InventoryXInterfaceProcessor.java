package jp.co.rakuten.bff.business.item.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.core.exception.ParameterResolveException;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

import static jp.co.rakuten.bff.core.constant.GenericEndpointConstants.URL_PARAMETERS;


/**
 * InventoryXManagerNumber interface processor
 * @author yugansh.bhola
 */
@Component("InventoryXInterfaceProcessor")
public class InventoryXInterfaceProcessor implements InterfaceProcessor {

	/**
	 * it will modify generically prepared request based on custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	@Override
	public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		//Fetching ManageNumber from the received request
		String itemManageNumber = (String) validatedRequest.get(ItemXInfoConstants.ITEM_INFO_FEATURE_KEY)
				.getParams().get(ItemXInfoConstants.MANAGE_NUMBER);
		//This is condition to check that we are calling Inventory X as  First Level parallel call as we have ManageNumber
		// and upstreamResponse is empty
		if (StringUtils.isNotBlank(itemManageNumber) && MapUtils.isEmpty(callDefinitionResponseMap)) {
			return true;
		} else {
			//Fetch response for ItemX
			Map<String, Object> itemResponse =
					InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
							ItemXInfoConstants.ITEMX_INTERFACE_KEY,
							ItemXInfoConstants.ITEMX_INVENTORY_CALL_DEFINITION_KEY);
			//Retrieve ManageNumber from ItemX response
			String manageNumFromItemXResponse = (String) itemResponse.get(ItemXInfoConstants.MANAGE_NUMBER);
			//This is condition to check that we are calling Inventory X as  Second Level parallel call as we have ManageNumber
			// and upstreamResponse and it is missing as part of Request.
			if (StringUtils.isBlank(itemManageNumber) && StringUtils.isNotBlank(manageNumFromItemXResponse)) {
				Map<String, Object> urlParamsMap = getUrlParams(genericCDProcessedData);
				urlParamsMap.put(ItemXInfoConstants.MANAGE_NUMBER, manageNumFromItemXResponse);
				return true;
			}
		}
		return  false;
	}

	/* fetch the url params from GSPItem Interface Map */
	private Map<String, Object> getUrlParams(GenericCallDefinitionProcessedData genericCDProcessedData) {
		Map<String, Object> gspItemKvsRequestMap = genericCDProcessedData.getRequestByInterface(
				ItemXInfoConstants.INVENTORYX_INTERFACE_KEY);
		//validates if prepared request map is empty
		if (MapUtils.isEmpty(gspItemKvsRequestMap)) {
			throw new ParameterResolveException(ItemXInfoConstants.INVENTORYX_INTERFACE_KEY +
					" interface missing in GenericCallDefinitionProcessedData " +
					"- call definition " + ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
		} else {
			Map<String, Object> urlParams = (Map<String, Object>) gspItemKvsRequestMap.get(URL_PARAMETERS);
			//Throw exception if URL params are empty and not set for the map
			if (MapUtils.isEmpty(urlParams)) {
				throw new ParameterResolveException(
						"urlParameters is missing in GenericCallDefinitionProcessedData - interface " +
								ItemXInfoConstants.INVENTORYX_INTERFACE_KEY + " - call definition "
								+ ItemXInfoConstants.GSP_INVENTORY_CALL_DEFINITION_KEY);
			}

			return urlParams;
		}
	}

}
