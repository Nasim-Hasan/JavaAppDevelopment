package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.model.http.CustomHttpResponse;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;
import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.ITEM_ID;
import static jp.co.rakuten.bff.business.productscreen.get.logic.ProductScreenLogic.*;

@Component("ShopMasterInfoInterfaceProcessor")
public class ShopMasterInfoInterfaceProcessor implements InterfaceProcessor {
    @Override
    public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
                              GenericCallDefinitionProcessedData genericCDProcessedData,
                              Map<String, CallDefinitionResponse> callDefinitionResponseMap) {

        if (!isShopMasterCallNeeded(validatedRequest)) {
            return false;
        } else {
            Map<String, Object> shopMasterRequestMap
                    = genericCDProcessedData.getRequestByInterface(SHOP_MASTER_INTERFACE_KEY);
            Map<String, Object> shopMasterUrlParams = new HashMap<>();
            CommonRequestModel commonRequestModel = validatedRequest.get(PRODUCT_INFO_FEATURE_KEY);

            Map<String, Object> params = commonRequestModel.getParams();
            String itemCode = (String) params.get(ITEM_CODE);
            String itemUrl = (String) params.get(ITEM_URL);
            Map<String, Object> shopMasterUrlParam = new HashMap<>();
            String shopUrl = "";
            if (ObjectUtils.isNotEmpty(itemCode)) {
                shopUrl = StringUtils.split(itemCode, ":")[0];
            } else {
                shopUrl = StringUtils.split(itemUrl, "/")[2];
            }
            shopMasterUrlParam.put(SHOP_URL, shopUrl);
            shopMasterRequestMap.put("urlParameters", shopMasterUrlParam);
        }

        return true;
    }
}
