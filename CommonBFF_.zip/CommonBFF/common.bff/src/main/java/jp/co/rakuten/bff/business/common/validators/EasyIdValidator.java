package jp.co.rakuten.bff.business.common.validators;

import jp.co.rakuten.bff.core.constant.BffConstants;
import jp.co.rakuten.bff.core.exception.ClientException;
import jp.co.rakuten.bff.core.exception.type.ClientErrorEnum;
import jp.co.rakuten.bff.core.model.CommonRequestModel;

/**
 * validates whether the easyId is within the valid range or not
 */
public class EasyIdValidator {
	public static final String PARAM_EASY_ID_MISSING_ERROR_MSG = "User is not logged-in or request can't " +
																						"be performed for this user";
	private EasyIdValidator() {
	}


	/**
	 * Perform validation related task
	 * if further easyId validation is needed for business criteria.
	 *
	 * @param validatedRequest Generically validated feature request.{@link CommonRequestModel}
	 */
	public static void validate(CommonRequestModel validatedRequest) {
		if ((int) (validatedRequest.getHeaders().get(BffConstants.EASY_ID)) < 1) {
			throw ClientException.create(ClientErrorEnum.BAD_REQUEST, PARAM_EASY_ID_MISSING_ERROR_MSG);
		}
	}
}
