package jp.co.rakuten.bff.business.productscreen.get.features;

import jp.co.rakuten.bff.business.item.get.features.ItemInfoFeatureProcessor;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.FeaturePostProcessorResponse;
import jp.co.rakuten.bff.core.processors.FeatureProcessor;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

@Component("ReviewInfoFeatureProcessor")
public class ReviewInfoFeatureProcessor implements FeatureProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemInfoFeatureProcessor.class);

    @Override
    public Mono<FeaturePostProcessorResponse> postProcess(CommonRequestModel validatedClientData, FeatureTemplate featureTemplate, Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        return FeaturePostProcessorResponse.getEmptyResponseMono().flatMap((FeaturePostProcessorResponse featureResponse) -> {
            Map<String, Object> reviewInfoResponse = InterfaceUtil.getInterfaceResponse(callDefinitionResponseMap,
                    GSP_ITEM_REVIEW_INTERFACE_KEY,
                    NAVIGATION_REVIEW_INFO_CALL_DEFINITION_KEY);

            featureResponse.setResponseMap(reviewInfoResponse);

            featureResponse.setCacheable(true);
            return Mono.just(featureResponse);
        })
                .doOnRequest(l -> LOGGER.debug("ReviewInfoFeatureProcessor start processing"))
                .doOnSuccess(featurePostProcessorResponse -> LOGGER.debug(
                        "ReviewInfoFeatureProcessor successfully completed. data: {}",
                        featurePostProcessorResponse));
    }
}
