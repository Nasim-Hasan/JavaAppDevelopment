package jp.co.rakuten.bff.business.productscreen.get.interfaces;

import jp.co.rakuten.bff.business.item.get.constants.ItemXInfoConstants;
import jp.co.rakuten.bff.business.productscreen.get.logic.ProductScreenLogic;
import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import static jp.co.rakuten.bff.business.productscreen.get.constants.ProductScreenConstant.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component("ProductInfoInterfaceProcessor")
public class ProductInfoInterfaceProcessor implements InterfaceProcessor {
    @Override
    public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
                              GenericCallDefinitionProcessedData genericCDProcessedData,
                              Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
        Map<String, Object> productInfoMap = genericCDProcessedData.getRequestByInterface(
                PRODUCT_INFO_INTERFACE_KEY);
        CommonRequestModel commonRequestModel = validatedRequest.get(PRODUCT_INFO_FEATURE_KEY);

        Map<String, Object> params = commonRequestModel.getParams();
        String itemMangeNumber = (String) params.get(MANAGE_NUMBER);
        Integer shopId = (Integer) params.get(SHOP_ID);
        Integer itemId = (Integer) params.get(ITEM_ID);

        if ((ObjectUtils.isNotEmpty(shopId)
                && (StringUtils.isNotBlank(itemMangeNumber) || ObjectUtils.isNotEmpty(itemId)))) {
            return removeParameterLinks(genericCDProcessedData);
        } else {
            prepareUrlParamters(genericCDProcessedData, params);
            return modifyParentRequest(genericCDProcessedData);
        }

    }

    private void prepareUrlParamters(GenericCallDefinitionProcessedData genericCDProcessedData, Map<String, Object> params) {
        Map<String, Object> productInfoRequestMap
                = genericCDProcessedData.getRequestByInterface(PRODUCT_INFO_INTERFACE_KEY);

        Map<String, Object> productInfoUrlParams = new HashMap<>();
        String itemCode = (String) params.get(ITEM_CODE);
        String itemUrl = (String) params.get(ITEM_URL);
        if (ObjectUtils.isNotEmpty(itemCode)) {
            productInfoUrlParams.put(ITEM_ID, Integer.parseInt(StringUtils.split(itemCode, ":")[1]));
        } else if (ObjectUtils.isNotEmpty(itemUrl)) {
            productInfoUrlParams.put(MANAGE_NUMBER, StringUtils.split(itemUrl, "/")[3]);
        }

        productInfoRequestMap.put("urlParameters", productInfoUrlParams);
    }

    private boolean modifyParentRequest(GenericCallDefinitionProcessedData genericCDProcessedData) {
        return ProductScreenLogic.modifyParentRequest(genericCDProcessedData, SHOP_MASTER_INTERFACE_KEY
                , PRODUCT_INFO_INTERFACE_KEY, PARAMETER_LINKS);
    }

    private boolean removeParameterLinks(GenericCallDefinitionProcessedData genericCDProcessedData) {
        Map<String, Object> itemXRequest = genericCDProcessedData.getRequestByInterface(PRODUCT_INFO_INTERFACE_KEY);
        itemXRequest.remove(PARAMETER_LINKS);
        return true;
    }
}
