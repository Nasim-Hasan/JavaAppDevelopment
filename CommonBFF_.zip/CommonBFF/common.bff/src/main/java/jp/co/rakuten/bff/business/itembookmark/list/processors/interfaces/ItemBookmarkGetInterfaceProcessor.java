package jp.co.rakuten.bff.business.itembookmark.list.processors.interfaces;

import jp.co.rakuten.bff.core.model.CallDefinitionResponse;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.model.GenericCallDefinitionProcessedData;
import jp.co.rakuten.bff.core.processors.InterfaceProcessor;
import jp.co.rakuten.bff.core.util.InterfaceUtil;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jp.co.rakuten.bff.business.itembookmark.list.constants.ItemBookMarkListConstant.*;

/**
 * ItemBookmarkGet Interface Processor
 * This processor validates and transforms ItemBookmarkGet request and response
 */
@Component("ItemBookmarkGetInterfaceProcessor")
public class ItemBookmarkGetInterfaceProcessor implements InterfaceProcessor {

	private static final String ITEM_POINT_VALUE = "itemPointValue";
	private static final String ITEM_POINT_RATE = "itemPointRate";
	private static final String ITEM_POINT_BACK_RATE = "itemPointBackRate";
	private static final String ITEM_POINT_EXTRA_RATE = "itemPointExtraRate";
	private static final String NCP_POINTS = "ncpPoints";

	/**
	 * Pre processor will modify generically prepared request if this endpoint has any custom business logic
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 * @return boolean true - if it has proper data to make request, false - if it doesn't have sufficient data
	 */
	@Override
	public boolean preProcess(Map<String, CommonRequestModel> validatedRequest,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		if (!validatedRequest.containsKey(ITEM_BOOKMARK_LIST_INFO)) {
			return false;
		}
		Map<String, Object> itemBookmarkGetInterfaceRequest =
				genericCDProcessedData.getRequestByInterface(INTERFACE_NAME_ITEM_BOOKMARK_GET);
		Map<String, Object> urlParams = (Map<String, Object>) itemBookmarkGetInterfaceRequest.get(URL_PARAMETERS);
		Integer shopId = (Integer) urlParams.get(SHOP_ID);
		boolean ncpFlag = (boolean) urlParams.getOrDefault(NCP_FLAG, false);
		if (ncpFlag) {
			urlParams.put(NCP_FLAG, 1);
		} else {
			urlParams.put(NCP_FLAG, 0);
		}
		if (shopId <= 0) {
			urlParams.remove(SHOP_ID);
		}
		return true;
	}

	/**
	 * Interface post processor
	 *
	 * @param validatedRequest          {@link Map} contains String as key and CommonRequestModel as value
	 * @param callDefinitionResponse    {@link CallDefinitionResponse}
	 * @param genericCDProcessedData    Every endpoint's generically prepared parameter list for Generic Gateway
	 * @param callDefinitionResponseMap Already resolved upstream response
	 */
	@Override
	public void postProcess(Map<String, CommonRequestModel> validatedRequest,
			CallDefinitionResponse callDefinitionResponse,
			GenericCallDefinitionProcessedData genericCDProcessedData,
			Map<String, CallDefinitionResponse> callDefinitionResponseMap) {
		Map<String, Object> itemBookmarkGetInterfaceResponse =
				InterfaceUtil.getInterfaceResponse(callDefinitionResponse, INTERFACE_NAME_ITEM_BOOKMARK_GET,
						CALL_DEF_ITEM_BOOKMARK_GET_CD);
		prepareResponse(itemBookmarkGetInterfaceResponse);
	}

	private void prepareResponse(Map<String, Object> itemBookmarkGetInterfaceResponse) {
		List<Map<String, Object>> itemBookMarkList = (List<Map<String, Object>>)
				itemBookmarkGetInterfaceResponse.get("data");
		itemBookMarkList.forEach(this::modifySingleBookMark);

	}

	private void modifySingleBookMark(Map<String, Object> bookmark) {
		if (Objects.nonNull(bookmark.get(ITEM_POINT_VALUE)) || Objects.nonNull(bookmark.get(ITEM_POINT_RATE))
				|| Objects.nonNull(bookmark.get(ITEM_POINT_BACK_RATE))
				|| Objects.nonNull(bookmark.get(ITEM_POINT_EXTRA_RATE))) {
			Map<String, Object> ncpPointsDataMap = new HashMap<>();
			ncpPointsDataMap.put(ITEM_POINT_VALUE, bookmark.get(ITEM_POINT_VALUE));
			ncpPointsDataMap.put(ITEM_POINT_RATE, bookmark.get(ITEM_POINT_RATE));
			ncpPointsDataMap.put(ITEM_POINT_BACK_RATE, bookmark.get(ITEM_POINT_BACK_RATE));
			ncpPointsDataMap.put(ITEM_POINT_EXTRA_RATE, bookmark.get(ITEM_POINT_EXTRA_RATE));
			bookmark.put(NCP_POINTS, ncpPointsDataMap);
		}
	}
}
