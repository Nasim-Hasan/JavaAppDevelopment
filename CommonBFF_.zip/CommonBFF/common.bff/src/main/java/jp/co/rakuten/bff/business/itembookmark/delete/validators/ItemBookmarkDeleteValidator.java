package jp.co.rakuten.bff.business.itembookmark.delete.validators;

import jp.co.rakuten.bff.business.common.validators.EasyIdValidator;
import jp.co.rakuten.bff.core.model.ClientRequestModel;
import jp.co.rakuten.bff.core.model.CommonRequestModel;
import jp.co.rakuten.bff.core.template.FeatureTemplate;
import jp.co.rakuten.bff.core.validators.CustomValidator;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * ItemBookmarkDelete Validator
 */
@Component("ItemBookmarkDeleteValidator")
public class ItemBookmarkDeleteValidator implements CustomValidator {

	private static final String FEATURE_NAME_ITEM_BOOKMARK_DELETE = "itemBookmarkDeleteInfo";

	/**
	 * @param validatedData       Generically validated data. key: feature name, value: {@link CommonRequestModel}
	 * @param featureTemplateList List of {@link FeatureTemplate}
	 * @param actualRequest       User's requested data - {@link ClientRequestModel}
	 * @return Map<String, CommonRequestModel> - key: feature name, value: {@link CommonRequestModel}
	 */
	@Override
	public Map<String, CommonRequestModel> validate(Map<String, CommonRequestModel> validatedData,
			List<FeatureTemplate> featureTemplateList,
			ClientRequestModel actualRequest) {

		EasyIdValidator.validate(validatedData.get(FEATURE_NAME_ITEM_BOOKMARK_DELETE));
		return validatedData;
	}
}
